import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from app import db as db_module
from app.accounting import engine
from app.auth import auth as auth_module


class AuthTestCase(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.db_path = str(Path(self.tmpdir.name) / "test.db")
        self.conn = db_module.connect(self.db_path)
        db_module.migrate(self.conn)
        self.org_id = engine.create_organization(self.conn, "Acme")
        self.other_org_id = engine.create_organization(self.conn, "Other Co")

    def tearDown(self):
        self.conn.close()
        self.tmpdir.cleanup()

    def test_password_never_stored_in_plaintext(self):
        auth_module.create_user(self.conn, self.org_id, "a@acme.co", "correcthorsebattery")
        row = self.conn.execute("SELECT password_hash FROM users WHERE email=?", ("a@acme.co",)).fetchone()
        self.assertNotIn("correcthorsebattery", row["password_hash"])

    def test_authenticate_correct_password(self):
        auth_module.create_user(self.conn, self.org_id, "a@acme.co", "correcthorsebattery")
        user_id = auth_module.authenticate(self.conn, self.org_id, "a@acme.co", "correcthorsebattery")
        self.assertIsNotNone(user_id)

    def test_authenticate_wrong_password_rejected(self):
        auth_module.create_user(self.conn, self.org_id, "a@acme.co", "correcthorsebattery")
        with self.assertRaises(auth_module.AuthError):
            auth_module.authenticate(self.conn, self.org_id, "a@acme.co", "wrongpassword")

    def test_short_password_rejected(self):
        with self.assertRaises(auth_module.AuthError):
            auth_module.create_user(self.conn, self.org_id, "a@acme.co", "short")

    def test_jwt_roundtrip(self):
        token = auth_module.issue_token("user-1", self.org_id, "admin", secret="test-secret")
        payload = auth_module.verify_token(token, secret="test-secret")
        self.assertEqual(payload["sub"], "user-1")
        self.assertEqual(payload["org_id"], self.org_id)

    def test_jwt_rejected_with_wrong_secret(self):
        token = auth_module.issue_token("user-1", self.org_id, "admin", secret="test-secret")
        with self.assertRaises(auth_module.AuthError):
            auth_module.verify_token(token, secret="wrong-secret")

    def test_require_role_blocks_disallowed_role(self):
        payload = {"role": "viewer"}
        with self.assertRaises(auth_module.AuthError):
            auth_module.require_role(payload, allowed_roles=("admin",))


if __name__ == "__main__":
    unittest.main()
