import sys
import tempfile
import unittest
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from app import db as db_module
from app.accounting import engine
from app.auth import auth as auth_module


class AccountingEngineTestCase(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.db_path = str(Path(self.tmpdir.name) / "test.db")
        self.conn = db_module.connect(self.db_path)
        db_module.migrate(self.conn)

        self.org_id = engine.create_organization(self.conn, "Acme Co")
        self.cash = engine.create_account(self.conn, self.org_id, "1000", "Cash", "asset")
        self.revenue = engine.create_account(self.conn, self.org_id, "4000", "Revenue", "revenue")
        self.expense = engine.create_account(self.conn, self.org_id, "5000", "Rent Expense", "expense")
        self.period = engine.create_fiscal_period(self.conn, self.org_id, "2026-01", "2026-01-01", "2026-01-31")
        self.user_id = auth_module.create_user(self.conn, self.org_id, "tester@acme.co", "supersecret1", "accountant")

    def tearDown(self):
        self.conn.close()
        self.tmpdir.cleanup()

    def test_balanced_transaction_posts(self):
        journal_id, created = engine.post_transaction(
            self.conn, self.org_id, self.period,
            [
                {"account_id": self.cash, "debit": "100.00", "credit": "0"},
                {"account_id": self.revenue, "debit": "0", "credit": "100.00"},
            ],
            memo="sale", created_by=self.user_id,
        )
        self.assertTrue(created)
        self.assertEqual(engine.get_account_balance(self.conn, self.cash), Decimal("100.00"))
        self.assertEqual(engine.get_account_balance(self.conn, self.revenue), Decimal("100.00"))

    def test_unbalanced_transaction_rejected(self):
        with self.assertRaises(engine.UnbalancedJournalError):
            engine.post_transaction(
                self.conn, self.org_id, self.period,
                [
                    {"account_id": self.cash, "debit": "100.00", "credit": "0"},
                    {"account_id": self.revenue, "debit": "0", "credit": "99.00"},
                ],
                memo="broken", created_by=self.user_id,
            )
        # No partial write: cash balance must still be zero.
        self.assertEqual(engine.get_account_balance(self.conn, self.cash), Decimal("0"))

    def test_line_with_both_debit_and_credit_rejected(self):
        with self.assertRaises(engine.ValidationError):
            engine.post_transaction(
                self.conn, self.org_id, self.period,
                [
                    {"account_id": self.cash, "debit": "50", "credit": "50"},
                    {"account_id": self.revenue, "debit": "0", "credit": "50"},
                ],
                memo="bad line", created_by=self.user_id,
            )

    def test_unknown_account_rejected(self):
        with self.assertRaises(engine.ValidationError):
            engine.post_transaction(
                self.conn, self.org_id, self.period,
                [
                    {"account_id": "does-not-exist", "debit": "10", "credit": "0"},
                    {"account_id": self.revenue, "debit": "0", "credit": "10"},
                ],
                memo="ghost account", created_by=self.user_id,
            )

    def test_idempotency_key_prevents_duplicate(self):
        lines = [
            {"account_id": self.cash, "debit": "20.00", "credit": "0"},
            {"account_id": self.revenue, "debit": "0", "credit": "20.00"},
        ]
        j1, created1 = engine.post_transaction(
            self.conn, self.org_id, self.period, lines, memo="idem test",
            created_by=self.user_id, idempotency_key="fixed-key-1",
        )
        j2, created2 = engine.post_transaction(
            self.conn, self.org_id, self.period, lines, memo="idem test",
            created_by=self.user_id, idempotency_key="fixed-key-1",
        )
        self.assertTrue(created1)
        self.assertFalse(created2)
        self.assertEqual(j1, j2)
        # Balance must reflect only ONE posting, not two.
        self.assertEqual(engine.get_account_balance(self.conn, self.cash), Decimal("20.00"))

    def test_decimal_precision_no_float_drift(self):
        # classic float trap: 0.1 + 0.2 != 0.3 in binary float
        journal_id, _ = engine.post_transaction(
            self.conn, self.org_id, self.period,
            [
                {"account_id": self.expense, "debit": "0.1", "credit": "0"},
                {"account_id": self.expense, "debit": "0.2", "credit": "0"},
                {"account_id": self.cash, "debit": "0", "credit": "0.3"},
            ],
            memo="decimal precision", created_by=self.user_id,
        )
        self.assertEqual(engine.get_account_balance(self.conn, self.expense), Decimal("0.3"))

    def test_reverse_transaction_preserves_history(self):
        journal_id, _ = engine.post_transaction(
            self.conn, self.org_id, self.period,
            [
                {"account_id": self.cash, "debit": "75.00", "credit": "0"},
                {"account_id": self.revenue, "debit": "0", "credit": "75.00"},
            ],
            memo="original", created_by=self.user_id,
        )
        self.assertEqual(engine.get_account_balance(self.conn, self.cash), Decimal("75.00"))

        reversal_id = engine.reverse_transaction(self.conn, self.org_id, journal_id, actor=self.user_id)
        self.assertNotEqual(reversal_id, journal_id)
        self.assertEqual(engine.get_account_balance(self.conn, self.cash), Decimal("0.00"))

        # original journal still exists and is marked reversed, not deleted
        row = self.conn.execute("SELECT status FROM journals WHERE id=?", (journal_id,)).fetchone()
        self.assertEqual(row["status"], "reversed")

    def test_closed_fiscal_period_rejects_postings(self):
        self.conn.execute("UPDATE fiscal_periods SET status='closed' WHERE id=?", (self.period,))
        with self.assertRaises(engine.PeriodClosedError):
            engine.post_transaction(
                self.conn, self.org_id, self.period,
                [
                    {"account_id": self.cash, "debit": "5", "credit": "0"},
                    {"account_id": self.revenue, "debit": "0", "credit": "5"},
                ],
                memo="late posting", created_by=self.user_id,
            )

    def test_trial_balance_always_balances(self):
        engine.post_transaction(
            self.conn, self.org_id, self.period,
            [
                {"account_id": self.cash, "debit": "500", "credit": "0"},
                {"account_id": self.revenue, "debit": "0", "credit": "500"},
            ],
            memo="rev", created_by=self.user_id,
        )
        engine.post_transaction(
            self.conn, self.org_id, self.period,
            [
                {"account_id": self.expense, "debit": "150", "credit": "0"},
                {"account_id": self.cash, "debit": "0", "credit": "150"},
            ],
            memo="exp", created_by=self.user_id,
        )
        tb = engine.get_trial_balance(self.conn, self.org_id)
        self.assertTrue(tb["balanced"])
        self.assertEqual(tb["debit_total"], tb["credit_total"])


if __name__ == "__main__":
    unittest.main()
