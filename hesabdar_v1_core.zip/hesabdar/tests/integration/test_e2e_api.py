"""
End-to-end test through the real Flask API (Flask's test_client drives real
WSGI request/response cycles against the real app — this is not mocked).
Mirrors the acceptance flow required by the PRD section 47:

  create org -> create user -> authenticate -> create accounts
  -> create transaction -> validate debit/credit -> persist -> audit
  -> generate report -> backup -> restore -> another transaction
  -> verify report

Also covers: tenant isolation (org A cannot read org B), and the AI-proposal
path going through the critic before it can post.
"""
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from app import db as db_module
from app.api import server as server_module
from scripts.backup import backup as do_backup
from scripts.restore import restore as do_restore


class EndToEndApiTestCase(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.db_path = str(Path(self.tmpdir.name) / "e2e.db")
        conn = db_module.connect(self.db_path)
        db_module.migrate(conn)
        conn.close()
        self.app = server_module.create_app(self.db_path)
        self.client = self.app.test_client()

    def tearDown(self):
        self.tmpdir.cleanup()

    def _auth_headers(self, token):
        return {"Authorization": f"Bearer {token}"}

    def test_full_acceptance_flow(self):
        # health check on a freshly migrated db
        r = self.client.get("/health")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["status"], "ok")

        # create organization
        r = self.client.post("/organizations", json={"name": "Acme Trading"})
        self.assertEqual(r.status_code, 201, r.get_json())
        org_id = r.get_json()["id"]

        # create user
        r = self.client.post(
            f"/organizations/{org_id}/users",
            json={"email": "owner@acme.co", "password": "supersecret1", "role": "admin"},
        )
        self.assertEqual(r.status_code, 201, r.get_json())

        # authenticate
        r = self.client.post(
            "/auth/login", json={"org_id": org_id, "email": "owner@acme.co", "password": "supersecret1"}
        )
        self.assertEqual(r.status_code, 200, r.get_json())
        token = r.get_json()["token"]

        # create accounts
        r = self.client.post(
            f"/organizations/{org_id}/accounts",
            json={"code": "1000", "name": "Cash", "type": "asset"},
            headers=self._auth_headers(token),
        )
        self.assertEqual(r.status_code, 201, r.get_json())
        cash_id = r.get_json()["id"]

        r = self.client.post(
            f"/organizations/{org_id}/accounts",
            json={"code": "4000", "name": "Sales Revenue", "type": "revenue"},
            headers=self._auth_headers(token),
        )
        self.assertEqual(r.status_code, 201, r.get_json())
        revenue_id = r.get_json()["id"]

        # fiscal period
        r = self.client.post(
            f"/organizations/{org_id}/fiscal-periods",
            json={"name": "2026-01", "start_date": "2026-01-01", "end_date": "2026-01-31"},
            headers=self._auth_headers(token),
        )
        self.assertEqual(r.status_code, 201, r.get_json())
        period_id = r.get_json()["id"]

        # create transaction (balanced) -> validated -> persisted -> audited
        r = self.client.post(
            f"/organizations/{org_id}/transactions",
            json={
                "fiscal_period_id": period_id,
                "memo": "cash sale",
                "lines": [
                    {"account_id": cash_id, "debit": "500.00", "credit": "0"},
                    {"account_id": revenue_id, "debit": "0", "credit": "500.00"},
                ],
            },
            headers=self._auth_headers(token),
        )
        self.assertEqual(r.status_code, 201, r.get_json())

        # reject an unbalanced transaction through the real API
        r = self.client.post(
            f"/organizations/{org_id}/transactions",
            json={
                "fiscal_period_id": period_id,
                "memo": "broken",
                "lines": [
                    {"account_id": cash_id, "debit": "10.00", "credit": "0"},
                    {"account_id": revenue_id, "debit": "0", "credit": "9.00"},
                ],
            },
            headers=self._auth_headers(token),
        )
        self.assertEqual(r.status_code, 400)

        # generate report
        r = self.client.get(f"/organizations/{org_id}/trial-balance", headers=self._auth_headers(token))
        self.assertEqual(r.status_code, 200)
        tb = r.get_json()
        self.assertTrue(tb["balanced"])
        self.assertEqual(tb["debit_total"], "500.00")

        # audit trail was written
        conn = db_module.connect(self.db_path)
        audit_count = conn.execute(
            "SELECT COUNT(*) FROM audit_events WHERE org_id=?", (org_id,)
        ).fetchone()[0]
        conn.close()
        self.assertGreater(audit_count, 0)

        # ---- backup ----
        backup_path = str(Path(self.tmpdir.name) / "e2e_backup.db")
        do_backup(self.db_path, backup_path)
        self.assertTrue(Path(backup_path).exists())

        # ---- restore into a fresh target and verify health ----
        restore_target = str(Path(self.tmpdir.name) / "restored.db")
        result = do_restore(backup_path, restore_target)
        self.assertEqual(result["status"], "ok")

        # run another transaction against the restored database via a new app instance
        restored_app = server_module.create_app(restore_target)
        restored_client = restored_app.test_client()

        r = restored_client.post(
            f"/organizations/{org_id}/transactions",
            json={
                "fiscal_period_id": period_id,
                "memo": "post-restore sale",
                "lines": [
                    {"account_id": cash_id, "debit": "250.00", "credit": "0"},
                    {"account_id": revenue_id, "debit": "0", "credit": "250.00"},
                ],
            },
            headers=self._auth_headers(token),
        )
        self.assertEqual(r.status_code, 201, r.get_json())

        # verify report reflects both the pre-restore and post-restore transactions
        r = restored_client.get(f"/organizations/{org_id}/trial-balance", headers=self._auth_headers(token))
        tb2 = r.get_json()
        self.assertEqual(tb2["debit_total"], "750.00")
        self.assertTrue(tb2["balanced"])

    def test_tenant_isolation(self):
        # org A
        r = self.client.post("/organizations", json={"name": "Org A"})
        org_a = r.get_json()["id"]
        self.client.post(f"/organizations/{org_a}/users", json={"email": "a@a.co", "password": "supersecret1"})
        token_a = self.client.post(
            "/auth/login", json={"org_id": org_a, "email": "a@a.co", "password": "supersecret1"}
        ).get_json()["token"]

        # org B
        r = self.client.post("/organizations", json={"name": "Org B"})
        org_b = r.get_json()["id"]

        # org A's token must not be able to touch org B's resources
        r = self.client.post(
            f"/organizations/{org_b}/accounts",
            json={"code": "1000", "name": "Cash", "type": "asset"},
            headers=self._auth_headers(token_a),
        )
        self.assertEqual(r.status_code, 403)

        r = self.client.get(f"/organizations/{org_b}/trial-balance", headers=self._auth_headers(token_a))
        self.assertEqual(r.status_code, 403)

    def test_ai_proposal_goes_through_critic_not_direct_to_ledger(self):
        r = self.client.post("/organizations", json={"name": "AI Co"})
        org_id = r.get_json()["id"]
        self.client.post(f"/organizations/{org_id}/users", json={"email": "u@ai.co", "password": "supersecret1"})
        token = self.client.post(
            "/auth/login", json={"org_id": org_id, "email": "u@ai.co", "password": "supersecret1"}
        ).get_json()["token"]

        cash_id = self.client.post(
            f"/organizations/{org_id}/accounts",
            json={"code": "1000", "name": "Cash", "type": "asset"},
            headers=self._auth_headers(token),
        ).get_json()["id"]
        expense_id = self.client.post(
            f"/organizations/{org_id}/accounts",
            json={"code": "5000", "name": "Rent Expense", "type": "expense"},
            headers=self._auth_headers(token),
        ).get_json()["id"]
        period_id = self.client.post(
            f"/organizations/{org_id}/fiscal-periods",
            json={"name": "2026-01", "start_date": "2026-01-01", "end_date": "2026-01-31"},
            headers=self._auth_headers(token),
        ).get_json()["id"]

        # A well-formed, low-amount proposal should auto-post through validation.
        r = self.client.post(
            f"/organizations/{org_id}/ai/propose-transaction",
            json={
                "text": "paid 200 for rent expense",
                "fiscal_period_id": period_id,
                "account_lookup": {"cash": cash_id, "rent": expense_id, "expense": expense_id},
            },
            headers=self._auth_headers(token),
        )
        self.assertEqual(r.status_code, 201, r.get_json())
        self.assertEqual(r.get_json()["decision"]["decision"], "auto_post")

        # Nonsense input the mock provider cannot classify must be rejected, never guessed.
        r = self.client.post(
            f"/organizations/{org_id}/ai/propose-transaction",
            json={
                "text": "the weather is nice today",
                "fiscal_period_id": period_id,
                "account_lookup": {"cash": cash_id, "rent": expense_id},
            },
            headers=self._auth_headers(token),
        )
        self.assertEqual(r.status_code, 422)

        # A large amount must require human approval, not auto-post.
        r = self.client.post(
            f"/organizations/{org_id}/ai/propose-transaction",
            json={
                "text": "paid 5000000 for rent expense",
                "fiscal_period_id": period_id,
                "account_lookup": {"cash": cash_id, "rent": expense_id, "expense": expense_id},
            },
            headers=self._auth_headers(token),
        )
        self.assertEqual(r.status_code, 202)
        self.assertEqual(r.get_json()["decision"]["decision"], "requires_approval")


if __name__ == "__main__":
    unittest.main()
