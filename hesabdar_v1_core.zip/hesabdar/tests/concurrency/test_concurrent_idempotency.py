"""Real concurrency test: N threads submit the SAME idempotency key at the
same time. Exactly one journal must be created; the rest must return the
same journal_id. This uses real OS threads and a real sqlite file on disk
(not an in-memory mock), so it genuinely exercises the locking path.
"""
import sys
import tempfile
import threading
import unittest
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from app import db as db_module
from app.accounting import engine
from app.auth import auth as auth_module

THREAD_COUNT = 20


class ConcurrentIdempotencyTestCase(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.db_path = str(Path(self.tmpdir.name) / "concurrency.db")
        setup_conn = db_module.connect(self.db_path)
        db_module.migrate(setup_conn)
        self.org_id = engine.create_organization(setup_conn, "Concurrency Co")
        self.cash = engine.create_account(setup_conn, self.org_id, "1000", "Cash", "asset")
        self.revenue = engine.create_account(setup_conn, self.org_id, "4000", "Revenue", "revenue")
        self.period = engine.create_fiscal_period(setup_conn, self.org_id, "2026-01", "2026-01-01", "2026-01-31")
        self.user_id = auth_module.create_user(setup_conn, self.org_id, "c@co.co", "supersecret1", "accountant")
        setup_conn.close()

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_concurrent_duplicate_submissions_create_exactly_one_journal(self):
        results = []
        errors = []
        lock = threading.Lock()
        barrier = threading.Barrier(THREAD_COUNT)

        def worker():
            conn = db_module.connect(self.db_path)
            try:
                barrier.wait()  # maximize actual overlap
                journal_id, created = engine.post_transaction(
                    conn, self.org_id, self.period,
                    [
                        {"account_id": self.cash, "debit": "10.00", "credit": "0"},
                        {"account_id": self.revenue, "debit": "0", "credit": "10.00"},
                    ],
                    memo="race", created_by=self.user_id, idempotency_key="race-key-xyz",
                )
                with lock:
                    results.append((journal_id, created))
            except Exception as e:  # noqa: BLE001
                with lock:
                    errors.append(str(e))
            finally:
                conn.close()

        threads = [threading.Thread(target=worker) for _ in range(THREAD_COUNT)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=30)

        self.assertEqual(errors, [], f"unexpected errors: {errors}")
        self.assertEqual(len(results), THREAD_COUNT)

        distinct_journal_ids = {jid for jid, _created in results}
        self.assertEqual(len(distinct_journal_ids), 1, "duplicate submissions produced more than one journal")

        created_flags = [c for _jid, c in results]
        self.assertEqual(sum(created_flags), 1, "exactly one thread should have created the journal")

        verify_conn = db_module.connect(self.db_path)
        try:
            balance = engine.get_account_balance(verify_conn, self.cash)
        finally:
            verify_conn.close()
        self.assertEqual(balance, Decimal("10.00"), "race must post the transaction exactly once")


if __name__ == "__main__":
    unittest.main()
