-- Hesabdar v1 core schema
-- SQLite dialect (development / test). Production target: PostgreSQL (see migrations/README.md).
-- Money is stored as TEXT holding a canonical Decimal string. Never stored as REAL/FLOAT.

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS schema_meta (
    version     INTEGER NOT NULL,
    applied_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS organizations (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    base_currency TEXT NOT NULL DEFAULT 'IRR',
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
    id              TEXT PRIMARY KEY,
    org_id          TEXT NOT NULL REFERENCES organizations(id),
    email           TEXT NOT NULL,
    password_hash   TEXT NOT NULL,
    password_salt   TEXT NOT NULL,
    role            TEXT NOT NULL CHECK (role IN ('admin','accountant','viewer')),
    is_active       INTEGER NOT NULL DEFAULT 1,
    created_at      TEXT NOT NULL,
    UNIQUE(org_id, email)
);

CREATE TABLE IF NOT EXISTS accounts (
    id          TEXT PRIMARY KEY,
    org_id      TEXT NOT NULL REFERENCES organizations(id),
    code        TEXT NOT NULL,
    name        TEXT NOT NULL,
    type        TEXT NOT NULL CHECK (type IN ('asset','liability','equity','revenue','expense')),
    normal_side TEXT NOT NULL CHECK (normal_side IN ('debit','credit')),
    is_active   INTEGER NOT NULL DEFAULT 1,
    created_at  TEXT NOT NULL,
    UNIQUE(org_id, code)
);

CREATE TABLE IF NOT EXISTS fiscal_periods (
    id          TEXT PRIMARY KEY,
    org_id      TEXT NOT NULL REFERENCES organizations(id),
    name        TEXT NOT NULL,
    start_date  TEXT NOT NULL,
    end_date    TEXT NOT NULL,
    status      TEXT NOT NULL CHECK (status IN ('open','closed')) DEFAULT 'open',
    UNIQUE(org_id, name)
);

-- A journal is one atomic, balanced accounting event (what the PRD calls a Transaction).
CREATE TABLE IF NOT EXISTS journals (
    id                  TEXT PRIMARY KEY,
    org_id              TEXT NOT NULL REFERENCES organizations(id),
    fiscal_period_id    TEXT NOT NULL REFERENCES fiscal_periods(id),
    memo                TEXT,
    status              TEXT NOT NULL CHECK (status IN ('posted','reversed')) DEFAULT 'posted',
    reverses_journal_id TEXT REFERENCES journals(id),
    source              TEXT NOT NULL CHECK (source IN ('manual','ai_proposed')) DEFAULT 'manual',
    created_by          TEXT NOT NULL REFERENCES users(id),
    idempotency_key     TEXT,
    created_at          TEXT NOT NULL,
    UNIQUE(org_id, idempotency_key)
);

CREATE TABLE IF NOT EXISTS transaction_lines (
    id          TEXT PRIMARY KEY,
    journal_id  TEXT NOT NULL REFERENCES journals(id),
    account_id  TEXT NOT NULL REFERENCES accounts(id),
    debit       TEXT NOT NULL DEFAULT '0',
    credit      TEXT NOT NULL DEFAULT '0',
    currency    TEXT NOT NULL,
    line_no     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_events (
    id          TEXT PRIMARY KEY,
    org_id      TEXT NOT NULL REFERENCES organizations(id),
    entity_type TEXT NOT NULL,
    entity_id   TEXT NOT NULL,
    action      TEXT NOT NULL,
    actor       TEXT,
    details     TEXT,
    created_at  TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_lines_account ON transaction_lines(account_id);
CREATE INDEX IF NOT EXISTS idx_lines_journal ON transaction_lines(journal_id);
CREATE INDEX IF NOT EXISTS idx_journals_org ON journals(org_id);
CREATE INDEX IF NOT EXISTS idx_accounts_org ON accounts(org_id);
CREATE INDEX IF NOT EXISTS idx_audit_org ON audit_events(org_id);
