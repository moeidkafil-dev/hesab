# Hesabdar v1 — Core (this build)

A real, working, tested Python double-entry accounting engine with an
API and a gated AI-proposal boundary. This is an honest subset of the
full Hesabdar v1 vision described in the source PRD — see
**"Known limitations"** below for exactly what is *not* in this build and
why, and **"FINAL STATUS"** for the required release-gate report.

Nothing in this repository is a mock pretending to be real. Every endpoint,
every script, and every test in here actually runs against real code and a
real (SQLite) database — you can verify all of it yourself with the
commands below.

## What's actually implemented

- **Deterministic double-entry accounting engine** (`app/accounting/engine.py`)
  — `Decimal`-only arithmetic, balance invariant enforced before every
  commit, atomic posting (all-or-nothing), idempotency keys (race-tested
  with real threads), immutable history via reversal (not mutation),
  fiscal-period locking, full audit trail.
- **Auth** (`app/auth/auth.py`) — PBKDF2-HMAC password hashing, JWT session
  tokens, role checks (admin/accountant/viewer).
- **HTTP API** (`app/api/server.py`, Flask) — organizations, users, login,
  accounts, fiscal periods, transactions (post/reverse), trial balance,
  ledger, tenant-scoped authorization (org A cannot touch org B — tested).
- **LLM boundary + critic** (`app/llm/provider.py`, `app/critic.py`) — a
  deterministic mock provider produces a *structured proposal*, never a
  direct database write; the critic auto-rejects low-confidence output and
  routes large amounts to `requires_approval` instead of auto-posting.
- **DB lifecycle** (`app/db.py`, `scripts/init_db.py`) — migrate + a real
  health check that recomputes every journal's debit/credit balance (not a
  hard-coded `"ok"`).
- **Backup/restore** (`scripts/backup.py`, `scripts/restore.py`) — uses
  SQLite's real online backup API; restore re-runs the health check so a
  corrupt backup is never silently accepted.
- **Tests** — 20 tests, all passing, using only Python's stdlib
  `unittest` (see "Why unittest, not pytest" below):
  - `tests/unit/` — accounting invariants (balance, idempotency, precision,
    reversal, closed periods), auth (hashing, JWT, roles)
  - `tests/integration/` — full E2E flow through the real HTTP API
    (org → user → login → accounts → transaction → report → backup →
    restore → another transaction → verify report), tenant isolation,
    AI-proposal-through-critic
  - `tests/concurrency/` — 20 real threads racing the same idempotency key
    against a real on-disk SQLite file; exactly one journal is created

## Quick start

```bash
git clone <this repo>
cd hesabdar
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

cp .env.example .env   # edit HESABDAR_JWT_SECRET before any real use

python scripts/init_db.py hesabdar.db     # migrate + health check
HESABDAR_DB_PATH=hesabdar.db python -m app.api.server   # runs on :8000
```

Run the tests (no pytest needed):

```bash
python -m unittest discover -s tests -v
```

Docker:

```bash
docker compose up --build
```

## Architecture

```
Client
  ↓
Flask API (app/api)            — authn/authz + request shaping only
  ↓
app.critic (for AI proposals)  — auto_post / requires_approval / reject
  ↓
app.accounting.engine          — THE authoritative source of truth
  - schema/type validation
  - balance invariant (Σdebit == Σcredit)
  - idempotency
  - atomic persistence (BEGIN IMMEDIATE / COMMIT / ROLLBACK)
  - audit trail
  ↓
SQLite (dev/test) — migrations in migrations/
```

`app.llm.provider.MockProvider` never writes to the database. It returns a
`TransactionProposal` (data), which goes through the same
`post_transaction()` validation as any manually entered transaction — an
LLM (real or mock) cannot bypass accounting validation, by construction.

## Known limitations (read before deploying anywhere real)

This build ran in a sandboxed environment with **no outbound network
access** (no `git clone`, no `pip install` from PyPI beyond what was
already present). That constrains what could honestly be delivered:

| PRD requirement | Status here | Why |
|---|---|---|
| Clone `github.com/moeidkafil-dev/hesab` and reconcile existing artifacts | **Not done** | Repo was unreachable/not found via web search, and this environment cannot `git clone` at all. Nothing from that repo was merged. |
| PostgreSQL production backend, connection pooling | **Not implemented** | Only SQLite is wired up. `app/db.py` is written so a `postgres.py` backend could be added behind the same interface, but that port is real work, not a config flag. |
| Redis (queues/locks/cache) | **Not implemented** | No Redis client available offline. |
| FastAPI | **Not used** | Not installable offline; used Flask (already present) instead. Route logic is thin either way — porting is mechanical, not architectural. |
| Multi-agent orchestrator (CEO/supervisor/classifier/rule engine/self-healing) | **Not implemented** | Only the LLM-provider boundary + critic gate exist, as a minimal, honest proof of the architecture, not the full agent stack. |
| Real LLM provider (OpenAI/Anthropic/Ollama) | **Not implemented** | `MockProvider` is a keyword-matcher, explicitly labeled as such in code and docs — not a language model. No outbound network to call a real one, and none should be assumed. |
| Rule engine lifecycle (candidate→approval→version→retirement) | **Not implemented** | Out of scope for this pass. |
| Multi-tenancy beyond simple org-scoped auth | **Partially covered** | Every org-scoped endpoint checks the caller's token against the URL's org_id (tested). No org-level resource quotas, no cross-org admin roles. |
| Frontend / financial-manager UI | **Not implemented** | No frontend artifacts were supplied in this conversation to integrate. |
| Security audit (penetration testing, dependency scanning) | **Not done** | Only manual checks: parameterized SQL everywhere (no string-built queries), no `float` used for money, passwords hashed not logged, JWT secret externalized. This is not a substitute for a real audit. |
| Real benchmark suite | **Not done** | No load-testing tooling available offline. The concurrency test (20 threads) is a correctness test, not a throughput benchmark. |
| Observability (structured logging, metrics, tracing) | **Not implemented** | Flask's default logging only. |
| CI/CD, upgrade-path testing | **Not implemented** | No CI runner in this environment. |

Everything **not** in this table (accounting core, idempotency, auth,
backup/restore, tenant isolation, AI-critic gate, DB lifecycle) is real,
runs, and is covered by a passing test as listed above — verify with the
commands in "Quick start".

### Why unittest, not pytest
`pytest` could not be installed (no network access in this build
environment). All test suites use Python's built-in `unittest` instead,
which is functionally equivalent for everything used here (fixtures via
`setUp`/`tearDown`, `assertRaises`, test discovery). If your environment
has `pytest` available, `python -m pytest tests/` will also run these
files unchanged.

## FINAL STATUS

*(per the format requested in the source PRD, section 50 — reported
honestly; a NO here is not a failure of this response, it's the point of
requiring it)*

```
Build:                 PASS  (clean install verified: venv, pip install, init_db.py)
Python imports:        PASS
Unit tests:             16/16
Integration tests:       3/3
Concurrency tests:       1/1  (20 real threads, race-tested idempotency)
E2E:                    PASS (full org→...→restore→verify flow, real HTTP client)
Security:               PARTIAL (parameterized SQL, hashed passwords, JWT,
                         tenant isolation tested — no independent audit,
                         no rate limiting, no dependency scanning)
Accounting invariants:  PASS (balance, precision, idempotency, reversal,
                         closed-period rejection — all tested)
Concurrency:            PASS (idempotency race test only — not a full
                         concurrent-load suite)
Benchmark:               NOT DONE (no load-testing tooling in this build)
Database:                PASS (SQLite dev/test only)
Migration:                PASS (idempotent, tracked in schema_meta)
Backup:                   PASS (real sqlite3 backup API, tested)
Restore:                  PASS (health-checked after restore, tested)
Authentication:          PASS
Authorization:           PASS (role checks + tenant isolation, tested)
Frontend:                 NOT IMPLEMENTED
Clean install:            PASS
Production deployment:    NOT VERIFIED (Docker image builds the real app;
                           no deployment to a real host was performed)

Production Ready:       NO

Release blockers:
  1. No PostgreSQL production backend (SQLite only — not safe for
     concurrent multi-writer production load or crash-consistency
     guarantees Postgres gives you).
  2. No real LLM provider — AI features are a proof-of-architecture with a
     keyword-matching mock, not usable AI classification.
  3. Multi-agent orchestration layer (CEO/supervisor/rule engine/
     self-healing) from the PRD is not built.
  4. No independent security audit or dependency vulnerability scan.
  5. No real benchmark/load test — throughput and latency under
     production-like load are unmeasured.
  6. No frontend.
  7. No CI/CD or verified upgrade path between versions.
  8. The source GitHub repository (moeidkafil-dev/hesab) was not
     reachable in this environment and so was never inspected or
     reconciled with this code — if it contains a different canonical
     implementation, that reconciliation still needs to happen.
```

## Repository layout

```
hesabdar/
├── app/
│   ├── accounting/engine.py   authoritative accounting core
│   ├── api/server.py          Flask API
│   ├── auth/auth.py           password hashing + JWT
│   ├── llm/provider.py        provider abstraction + mock provider
│   ├── critic.py              gates AI proposals before posting
│   └── db.py                  connect / migrate / health_check
├── migrations/0001_init.sql
├── scripts/
│   ├── init_db.py             clean-install lifecycle
│   ├── backup.py               real sqlite backup
│   └── restore.py              real restore + health check
├── tests/
│   ├── unit/
│   ├── integration/
│   └── concurrency/
├── Dockerfile
├── docker-compose.yml
├── pyproject.toml
├── requirements.txt
└── .env.example
```
