#!/usr/bin/env python3
"""Clean-install lifecycle step: configure -> migrate -> health check.
Usage: python scripts/init_db.py [db_path]
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app import db as db_module  # noqa: E402


def main():
    db_path = sys.argv[1] if len(sys.argv) > 1 else "hesabdar.db"
    conn = db_module.connect(db_path)
    applied = db_module.migrate(conn)
    result = db_module.health_check(conn)
    conn.close()
    print(f"db: {db_path}")
    print(f"migrations applied: {applied or '(already up to date)'}")
    print(f"health check: {result}")
    if result["status"] != "ok":
        sys.exit(1)


if __name__ == "__main__":
    main()
