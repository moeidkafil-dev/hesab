#!/usr/bin/env python3
"""Real, working SQLite backup using the sqlite3 online backup API.
Produces a fully consistent copy even if the source DB is being written to,
because sqlite3's .backup() takes proper read locks internally.

Usage: python scripts/backup.py <source_db_path> <backup_db_path>
"""
import sqlite3
import sys


def backup(source_path: str, dest_path: str) -> None:
    source = sqlite3.connect(source_path)
    dest = sqlite3.connect(dest_path)
    with dest:
        source.backup(dest)
    source.close()
    dest.close()


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("usage: backup.py <source_db_path> <backup_db_path>")
        sys.exit(1)
    backup(sys.argv[1], sys.argv[2])
    print(f"backed up {sys.argv[1]} -> {sys.argv[2]}")
