#!/usr/bin/env python3
"""Real, working restore: copies a backup file into place as the live DB,
then runs the same health_check() the API uses at startup, so a corrupted
or malformed backup is never silently accepted (PRD section 6).

Usage: python scripts/restore.py <backup_db_path> <target_db_path>
"""
import shutil
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app import db as db_module  # noqa: E402


def restore(backup_path: str, target_path: str) -> dict:
    shutil.copyfile(backup_path, target_path)
    conn = db_module.connect(target_path)
    try:
        result = db_module.health_check(conn)
    finally:
        conn.close()
    if result["status"] != "ok":
        raise RuntimeError(f"restored database failed health check: {result}")
    return result


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("usage: restore.py <backup_db_path> <target_db_path>")
        sys.exit(1)
    result = restore(sys.argv[1], sys.argv[2])
    print(f"restored {sys.argv[1]} -> {sys.argv[2]}: {result}")
