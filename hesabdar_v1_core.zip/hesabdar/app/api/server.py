"""
HTTP API. Built on Flask because FastAPI/uvicorn could not be installed in
this offline build environment (see README "Known limitations"). The route
layer is intentionally thin: every write goes straight into
app.accounting.engine, which is where all real validation happens. The API
layer performs authn/authz and request shaping only — it never computes or
trusts a balance itself.
"""
from __future__ import annotations

import os
import sqlite3
from decimal import Decimal
from functools import wraps

from flask import Flask, request, jsonify, g

from app import db as db_module
from app.accounting import engine
from app.auth import auth as auth_module
from app.llm.provider import get_provider
from app import critic as critic_module

JWT_SECRET = os.environ.get("HESABDAR_JWT_SECRET", "dev-secret-change-me")


def create_app(db_path: str) -> Flask:
    app = Flask(__name__)
    app.config["DB_PATH"] = db_path

    def get_conn() -> sqlite3.Connection:
        if "conn" not in g:
            g.conn = db_module.connect(app.config["DB_PATH"])
        return g.conn

    @app.teardown_appcontext
    def close_conn(exc):
        conn = g.pop("conn", None)
        if conn is not None:
            conn.close()

    def require_auth(allowed_roles=("admin", "accountant", "viewer")):
        def decorator(fn):
            @wraps(fn)
            def wrapper(*args, **kwargs):
                header = request.headers.get("Authorization", "")
                if not header.startswith("Bearer "):
                    return jsonify(error="missing bearer token"), 401
                token = header.split(" ", 1)[1]
                try:
                    payload = auth_module.verify_token(token, JWT_SECRET)
                    auth_module.require_role(payload, allowed_roles)
                except auth_module.AuthError as e:
                    return jsonify(error=str(e)), 403
                g.auth = payload
                return fn(*args, **kwargs)
            return wrapper
        return decorator

    def enforce_org_scope(org_id: str):
        """Release-blocking tenant isolation check: a caller may only act on
        the organization encoded in their own token."""
        if g.auth["org_id"] != org_id:
            return jsonify(error="forbidden: token does not belong to this organization"), 403
        return None

    # ---- health -------------------------------------------------------
    @app.get("/health")
    def health():
        result = db_module.health_check(get_conn())
        code = 200 if result["status"] == "ok" else 503
        return jsonify(result), code

    # ---- organizations / users -----------------------------------------
    @app.post("/organizations")
    def create_organization():
        body = request.get_json(force=True)
        try:
            org_id = engine.create_organization(get_conn(), body["name"], body.get("base_currency", "IRR"))
        except (KeyError, engine.ValidationError) as e:
            return jsonify(error=str(e)), 400
        return jsonify(id=org_id), 201

    @app.post("/organizations/<org_id>/users")
    def create_user(org_id):
        body = request.get_json(force=True)
        try:
            user_id = auth_module.create_user(
                get_conn(), org_id, body["email"], body["password"], body.get("role", "admin")
            )
        except (KeyError, auth_module.AuthError) as e:
            return jsonify(error=str(e)), 400
        return jsonify(id=user_id), 201

    @app.post("/auth/login")
    def login():
        body = request.get_json(force=True)
        try:
            user_id = auth_module.authenticate(get_conn(), body["org_id"], body["email"], body["password"])
            row = get_conn().execute("SELECT role FROM users WHERE id=?", (user_id,)).fetchone()
            token = auth_module.issue_token(user_id, body["org_id"], row["role"], JWT_SECRET)
        except (KeyError, auth_module.AuthError) as e:
            return jsonify(error=str(e)), 401
        return jsonify(token=token)

    # ---- accounts / periods --------------------------------------------
    @app.post("/organizations/<org_id>/accounts")
    @require_auth(allowed_roles=("admin", "accountant"))
    def create_account(org_id):
        forbidden = enforce_org_scope(org_id)
        if forbidden:
            return forbidden
        body = request.get_json(force=True)
        try:
            account_id = engine.create_account(
                get_conn(), org_id, body["code"], body["name"], body["type"], actor=g.auth["sub"]
            )
        except (KeyError, engine.ValidationError) as e:
            return jsonify(error=str(e)), 400
        return jsonify(id=account_id), 201

    @app.post("/organizations/<org_id>/fiscal-periods")
    @require_auth(allowed_roles=("admin", "accountant"))
    def create_fiscal_period(org_id):
        forbidden = enforce_org_scope(org_id)
        if forbidden:
            return forbidden
        body = request.get_json(force=True)
        try:
            period_id = engine.create_fiscal_period(
                get_conn(), org_id, body["name"], body["start_date"], body["end_date"]
            )
        except (KeyError, engine.ValidationError) as e:
            return jsonify(error=str(e)), 400
        return jsonify(id=period_id), 201

    # ---- transactions -----------------------------------------------------
    @app.post("/organizations/<org_id>/transactions")
    @require_auth(allowed_roles=("admin", "accountant"))
    def post_transaction(org_id):
        forbidden = enforce_org_scope(org_id)
        if forbidden:
            return forbidden
        body = request.get_json(force=True)
        idem_key = request.headers.get("Idempotency-Key") or body.get("idempotency_key")
        try:
            journal_id, created = engine.post_transaction(
                get_conn(), org_id, body["fiscal_period_id"], body["lines"],
                memo=body.get("memo", ""), created_by=g.auth["sub"],
                currency=body.get("currency", "IRR"), idempotency_key=idem_key,
            )
        except (KeyError, engine.AccountingError) as e:
            return jsonify(error=str(e)), 400
        status = 201 if created else 200
        return jsonify(id=journal_id, created=created), status

    @app.post("/organizations/<org_id>/transactions/<journal_id>/reverse")
    @require_auth(allowed_roles=("admin", "accountant"))
    def reverse_transaction(org_id, journal_id):
        forbidden = enforce_org_scope(org_id)
        if forbidden:
            return forbidden
        body = request.get_json(silent=True) or {}
        try:
            new_id = engine.reverse_transaction(
                get_conn(), org_id, journal_id, actor=g.auth["sub"], memo=body.get("memo", "reversal")
            )
        except engine.AccountingError as e:
            return jsonify(error=str(e)), 400
        return jsonify(id=new_id), 201

    # ---- AI-proposed transactions (goes through critic, never posts blind) ----
    @app.post("/organizations/<org_id>/ai/propose-transaction")
    @require_auth(allowed_roles=("admin", "accountant"))
    def ai_propose_transaction(org_id):
        forbidden = enforce_org_scope(org_id)
        if forbidden:
            return forbidden
        body = request.get_json(force=True)
        provider = get_provider(body.get("provider", "mock"))
        account_lookup = body.get("account_lookup", {})
        proposal = provider.propose_transaction(body["text"], account_lookup)
        decision = critic_module.review(proposal)

        if decision["decision"] == "reject":
            return jsonify(decision=decision, posted=False), 422
        if decision["decision"] == "requires_approval":
            return jsonify(decision=decision, posted=False, proposal=proposal.__dict__ if proposal else None), 202

        try:
            journal_id, created = engine.post_transaction(
                get_conn(), org_id, body["fiscal_period_id"], proposal.lines,
                memo=proposal.memo, created_by=g.auth["sub"], source="ai_proposed",
                idempotency_key=body.get("idempotency_key"),
            )
        except engine.AccountingError as e:
            return jsonify(error=str(e), decision=decision), 400
        return jsonify(id=journal_id, created=created, decision=decision), 201

    # ---- reporting ---------------------------------------------------------
    @app.get("/organizations/<org_id>/trial-balance")
    @require_auth()
    def trial_balance(org_id):
        forbidden = enforce_org_scope(org_id)
        if forbidden:
            return forbidden
        return jsonify(engine.get_trial_balance(get_conn(), org_id))

    @app.get("/accounts/<account_id>/ledger")
    @require_auth()
    def ledger(account_id):
        rows = engine.get_ledger(get_conn(), account_id)
        return jsonify(rows)

    return app


if __name__ == "__main__":
    path = os.environ.get("HESABDAR_DB_PATH", "hesabdar.db")
    conn = db_module.connect(path)
    db_module.migrate(conn)
    conn.close()
    application = create_app(path)
    application.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8000)))
