"""
Authentication: password hashing (PBKDF2-HMAC-SHA256, stdlib only) and JWT
session tokens (PyJWT). This is a real, working implementation suitable for
development and small deployments — see README for what a production
hardening pass would still need to add (rate limiting, refresh-token
rotation, password-policy enforcement, etc.).
"""
from __future__ import annotations

import hashlib
import hmac
import os
import sqlite3
import uuid
from datetime import datetime, timedelta, timezone

import jwt

PBKDF2_ITERATIONS = 260_000
JWT_ALGORITHM = "HS256"
JWT_EXPIRY_MINUTES = 60


class AuthError(Exception):
    pass


def _hash_password(password: str, salt: bytes) -> str:
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS)
    return dk.hex()


def create_user(conn: sqlite3.Connection, org_id: str, email: str, password: str, role: str = "admin") -> str:
    if role not in ("admin", "accountant", "viewer"):
        raise AuthError(f"invalid role: {role}")
    if len(password) < 8:
        raise AuthError("password must be at least 8 characters")

    salt = os.urandom(16)
    password_hash = _hash_password(password, salt)
    user_id = uuid.uuid4().hex
    try:
        conn.execute(
            "INSERT INTO users (id, org_id, email, password_hash, password_salt, role, is_active, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, 1, ?)",
            (user_id, org_id, email.lower().strip(), password_hash, salt.hex(), role,
             datetime.now(timezone.utc).isoformat()),
        )
    except sqlite3.IntegrityError as e:
        raise AuthError(f"user already exists in this org: {email}") from e
    return user_id


def authenticate(conn: sqlite3.Connection, org_id: str, email: str, password: str) -> str:
    """Returns user_id on success, raises AuthError on failure.
    Uses constant-time comparison to avoid timing side-channels.
    """
    row = conn.execute(
        "SELECT id, password_hash, password_salt, is_active FROM users WHERE org_id=? AND email=?",
        (org_id, email.lower().strip()),
    ).fetchone()
    if row is None or not row["is_active"]:
        raise AuthError("invalid credentials")

    salt = bytes.fromhex(row["password_salt"])
    candidate = _hash_password(password, salt)
    if not hmac.compare_digest(candidate, row["password_hash"]):
        raise AuthError("invalid credentials")
    return row["id"]


def issue_token(user_id: str, org_id: str, role: str, secret: str) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": user_id,
        "org_id": org_id,
        "role": role,
        "iat": now,
        "exp": now + timedelta(minutes=JWT_EXPIRY_MINUTES),
    }
    return jwt.encode(payload, secret, algorithm=JWT_ALGORITHM)


def verify_token(token: str, secret: str) -> dict:
    try:
        return jwt.decode(token, secret, algorithms=[JWT_ALGORITHM])
    except jwt.PyJWTError as e:
        raise AuthError(f"invalid or expired token: {e}") from e


def require_role(payload: dict, allowed_roles: tuple[str, ...]) -> None:
    if payload.get("role") not in allowed_roles:
        raise AuthError(f"role {payload.get('role')} is not permitted; requires one of {allowed_roles}")
