"""
Database lifecycle: connect -> migrate -> health check.

Development/test target: SQLite (stdlib sqlite3).
Production target: PostgreSQL — NOT implemented in this build. See README
"Known limitations" for the exact reason and what a real port requires.
"""
from __future__ import annotations

import sqlite3
from pathlib import Path
from datetime import datetime, timezone

MIGRATIONS_DIR = Path(__file__).resolve().parent.parent / "migrations"


def connect(db_path: str) -> sqlite3.Connection:
    """Open a connection with sane, integrity-preserving pragmas."""
    conn = sqlite3.connect(db_path, timeout=30, isolation_level=None)
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.row_factory = sqlite3.Row
    return conn


def migrate(conn: sqlite3.Connection) -> list[str]:
    """Apply every .sql file in migrations/ that hasn't been applied yet.

    Returns the list of migration filenames applied in this call.
    A clean database (no schema_meta table) is bootstrapped automatically.
    """
    applied: list[str] = []
    conn.execute(
        "CREATE TABLE IF NOT EXISTS schema_meta ("
        "version INTEGER NOT NULL, applied_at TEXT NOT NULL)"
    )
    already = {
        row[0] for row in conn.execute("SELECT version FROM schema_meta")
    }
    migration_files = sorted(MIGRATIONS_DIR.glob("*.sql"))
    if not migration_files:
        raise RuntimeError(f"No migration files found in {MIGRATIONS_DIR}")

    for path in migration_files:
        version = int(path.stem.split("_", 1)[0])
        if version in already:
            continue
        sql = path.read_text(encoding="utf-8")
        conn.executescript(sql)
        conn.execute(
            "INSERT INTO schema_meta (version, applied_at) VALUES (?, ?)",
            (version, datetime.now(timezone.utc).isoformat()),
        )
        applied.append(path.name)
    return applied


def health_check(conn: sqlite3.Connection) -> dict:
    """A real health check: verifies required tables exist and are queryable,
    and that the debit/credit invariant holds across every posted journal.
    This is not a hard-coded 'ok' — it fails if the invariant is broken.
    """
    required_tables = {
        "organizations", "users", "accounts", "fiscal_periods",
        "journals", "transaction_lines", "audit_events",
    }
    existing = {
        row[0] for row in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )
    }
    missing = required_tables - existing
    if missing:
        return {"status": "fail", "reason": f"missing tables: {sorted(missing)}"}

    from decimal import Decimal
    bad_journals = []
    # Every journal, regardless of status, must individually balance —
    # 'reversed' only marks that another journal compensates it; the row
    # itself is still an immutable historical posting.
    for jrow in conn.execute("SELECT id FROM journals"):
        jid = jrow[0]
        debit_total = Decimal("0")
        credit_total = Decimal("0")
        for lrow in conn.execute(
            "SELECT debit, credit FROM transaction_lines WHERE journal_id=?", (jid,)
        ):
            debit_total += Decimal(lrow[0])
            credit_total += Decimal(lrow[1])
        if debit_total != credit_total:
            bad_journals.append(jid)

    if bad_journals:
        return {"status": "fail", "reason": f"unbalanced journals: {bad_journals}"}

    return {"status": "ok", "tables": sorted(existing)}
