"""
LLM provider abstraction.

HONESTY NOTE: this build ships exactly one provider — MockProvider, a
deterministic, rule-based (keyword-matching) stand-in. It is NOT a real
language model. It exists to prove out and test the architectural boundary
described in the PRD (LLM -> structured candidate -> schema validation ->
accounting engine -> critic -> persistence), without ever letting free-text
input touch the ledger directly.

A real provider (OpenAI/Anthropic/Ollama-backed) would implement the same
LLMProvider interface and could be swapped in without touching the
accounting engine, API, or critic — that boundary is the point of this
abstraction. Wiring a real network-backed provider was not possible in this
build environment (no outbound network access), so it is not included, and
is NOT claimed to work.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


@dataclass
class TransactionProposal:
    """A structured, not-yet-validated candidate. This is data, never code,
    and it carries no authority — the accounting engine re-validates it from
    scratch exactly like any manually submitted transaction.
    """
    lines: list[dict]
    memo: str
    confidence: float
    raw_input: str


class LLMProvider(Protocol):
    def propose_transaction(
        self, text: str, account_lookup: dict[str, str]
    ) -> TransactionProposal | None:
        ...


class ProviderError(Exception):
    pass


class MockProvider:
    """Deterministic keyword-based classifier standing in for a real LLM.

    account_lookup maps human-readable account names/keywords (lowercased)
    to account_id, e.g. {"cash": "<id>", "revenue": "<id>", "rent": "<id>"}.

    This provider NEVER writes to the database. It only returns a
    TransactionProposal for the caller to push through the normal
    post_transaction() validation pipeline.
    """

    name = "mock"

    def propose_transaction(
        self, text: str, account_lookup: dict[str, str]
    ) -> TransactionProposal | None:
        text_l = text.lower()

        # Extremely simple deterministic pattern: "paid X for Y" or "received X for Y"
        # is intentionally minimal — it is a placeholder for a real classifier, not a
        # production NLU system. Malformed/unrecognized input returns None so the
        # caller can reject/escalate rather than silently guessing.
        import re
        amount_match = re.search(r"(\d+(?:\.\d+)?)", text_l)
        if not amount_match:
            return None
        amount = amount_match.group(1)

        debit_key = credit_key = None
        if "paid" in text_l or "expense" in text_l or "purchase" in text_l:
            debit_key = next((k for k in account_lookup if k in text_l and k not in ("cash", "bank")), "expense")
            credit_key = "cash" if "cash" in account_lookup else next(iter(account_lookup), None)
        elif "received" in text_l or "revenue" in text_l or "income" in text_l:
            credit_key = next((k for k in account_lookup if k in text_l and k not in ("cash", "bank")), "revenue")
            debit_key = "cash" if "cash" in account_lookup else next(iter(account_lookup), None)
        else:
            return None

        if debit_key not in account_lookup or credit_key not in account_lookup:
            return None

        return TransactionProposal(
            lines=[
                {"account_id": account_lookup[debit_key], "debit": amount, "credit": "0"},
                {"account_id": account_lookup[credit_key], "debit": "0", "credit": amount},
            ],
            memo=f"AI-proposed from: {text!r}",
            confidence=0.6,
            raw_input=text,
        )


def get_provider(name: str = "mock") -> LLMProvider:
    if name == "mock":
        return MockProvider()
    raise ProviderError(
        f"provider '{name}' is not available in this build (no outbound network access). "
        f"Only 'mock' is implemented."
    )
