"""
Critic / final checker for AI-proposed transactions.

Per the PRD: AI may propose, but AI may not silently activate a privileged
posting. Any journal proposed via app.llm must pass through here, and any
proposal above a configurable amount threshold requires human approval
(approve_ai_transaction) instead of being auto-posted.
"""
from __future__ import annotations

from decimal import Decimal

from app.llm.provider import TransactionProposal

AUTO_APPROVE_THRESHOLD = Decimal("1000000")  # amounts at/above this always require approval


class CriticRejection(Exception):
    pass


def review(proposal: TransactionProposal) -> dict:
    """Returns {'decision': 'auto_post'|'requires_approval'|'reject', 'reason': str}.
    Never mutates the database — pure decision function, easy to unit test.
    """
    if proposal is None:
        return {"decision": "reject", "reason": "provider returned no structured proposal"}

    if proposal.confidence < 0.5:
        return {"decision": "reject", "reason": f"confidence too low: {proposal.confidence}"}

    total = Decimal("0")
    for line in proposal.lines:
        total += Decimal(line.get("debit", "0"))

    if total >= AUTO_APPROVE_THRESHOLD:
        return {"decision": "requires_approval", "reason": f"amount {total} >= threshold {AUTO_APPROVE_THRESHOLD}"}

    return {"decision": "auto_post", "reason": "within confidence and amount thresholds"}
