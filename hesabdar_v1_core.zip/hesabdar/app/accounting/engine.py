"""
Deterministic double-entry accounting engine.

This module is the single authoritative place where money moves. It is pure
Python + sqlite3, uses Decimal exclusively for amounts, and never trusts
caller-supplied balance claims — every posting is re-validated here
regardless of what an API layer, agent, or LLM upstream claims.

Authoritative flow enforced by post_transaction():
  candidate lines -> schema/type validation -> account/period validation
  -> balance invariant (sum(debit) == sum(credit)) -> idempotency check
  -> atomic persistence -> audit event

Nothing upstream (API, agents, LLM providers) can bypass this module and
write directly to transaction_lines / journals.
"""
from __future__ import annotations

import sqlite3
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation


class AccountingError(Exception):
    """Base class for all rejections raised by the accounting engine."""


class ValidationError(AccountingError):
    pass


class UnbalancedJournalError(AccountingError):
    pass


class PeriodClosedError(AccountingError):
    pass


def _new_id() -> str:
    return uuid.uuid4().hex


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _to_decimal(value, field: str) -> Decimal:
    try:
        d = Decimal(str(value))
    except (InvalidOperation, TypeError):
        raise ValidationError(f"{field} is not a valid decimal amount: {value!r}")
    if d != d.quantize(Decimal("0.01")) and d.as_tuple().exponent < -2:
        # Allow more precision than 2dp (e.g. crypto/FX) but reject garbage like NaN/inf,
        # which Decimal() would already have raised on. This branch is a documented no-op
        # guard kept for future currency-precision rules.
        pass
    return d


@dataclass
class LineInput:
    account_id: str
    debit: str = "0"
    credit: str = "0"
    currency: str | None = None


def create_organization(conn: sqlite3.Connection, name: str, base_currency: str = "IRR") -> str:
    if not name or not name.strip():
        raise ValidationError("organization name is required")
    org_id = _new_id()
    conn.execute(
        "INSERT INTO organizations (id, name, base_currency, created_at) VALUES (?, ?, ?, ?)",
        (org_id, name.strip(), base_currency, _now()),
    )
    _audit(conn, org_id, "organization", org_id, "created", actor=None, details=name)
    return org_id


def create_account(
    conn: sqlite3.Connection,
    org_id: str,
    code: str,
    name: str,
    account_type: str,
    actor: str | None = None,
) -> str:
    normal_side_map = {
        "asset": "debit",
        "expense": "debit",
        "liability": "credit",
        "equity": "credit",
        "revenue": "credit",
    }
    if account_type not in normal_side_map:
        raise ValidationError(f"invalid account type: {account_type}")
    if not code or not name:
        raise ValidationError("account code and name are required")

    account_id = _new_id()
    try:
        conn.execute(
            "INSERT INTO accounts (id, org_id, code, name, type, normal_side, is_active, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, 1, ?)",
            (account_id, org_id, code, name, account_type, normal_side_map[account_type], _now()),
        )
    except sqlite3.IntegrityError as e:
        raise ValidationError(f"account code already exists in this org: {code}") from e
    _audit(conn, org_id, "account", account_id, "created", actor, f"{code} {name} ({account_type})")
    return account_id


def create_fiscal_period(
    conn: sqlite3.Connection, org_id: str, name: str, start_date: str, end_date: str
) -> str:
    period_id = _new_id()
    try:
        conn.execute(
            "INSERT INTO fiscal_periods (id, org_id, name, start_date, end_date, status) "
            "VALUES (?, ?, ?, ?, ?, 'open')",
            (period_id, org_id, name, start_date, end_date),
        )
    except sqlite3.IntegrityError as e:
        raise ValidationError(f"fiscal period name already exists: {name}") from e
    return period_id


def _audit(conn, org_id, entity_type, entity_id, action, actor, details):
    conn.execute(
        "INSERT INTO audit_events (id, org_id, entity_type, entity_id, action, actor, details, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (_new_id(), org_id, entity_type, entity_id, action, actor, details, _now()),
    )


def post_transaction(
    conn: sqlite3.Connection,
    org_id: str,
    fiscal_period_id: str,
    lines: list[dict],
    memo: str,
    created_by: str,
    currency: str = "IRR",
    idempotency_key: str | None = None,
    source: str = "manual",
) -> tuple[str, bool]:
    """Post a balanced journal atomically.

    Returns (journal_id, was_created). was_created is False when an existing
    journal is returned because idempotency_key was already used for this org
    — the caller gets the original result instead of a duplicate posting.

    Raises ValidationError / UnbalancedJournalError / PeriodClosedError and
    performs NO partial writes on failure (the whole insert is one sqlite
    transaction that is rolled back).
    """
    if idempotency_key:
        existing = conn.execute(
            "SELECT id FROM journals WHERE org_id=? AND idempotency_key=?",
            (org_id, idempotency_key),
        ).fetchone()
        if existing:
            return existing[0], False

    if not lines or len(lines) < 2:
        raise ValidationError("a journal requires at least two lines")

    period = conn.execute(
        "SELECT status FROM fiscal_periods WHERE id=? AND org_id=?",
        (fiscal_period_id, org_id),
    ).fetchone()
    if period is None:
        raise ValidationError(f"unknown fiscal period: {fiscal_period_id}")
    if period["status"] != "open":
        raise PeriodClosedError(f"fiscal period {fiscal_period_id} is closed")

    debit_total = Decimal("0")
    credit_total = Decimal("0")
    normalized: list[dict] = []

    for idx, raw in enumerate(lines):
        account_id = raw.get("account_id")
        acct = conn.execute(
            "SELECT id, is_active FROM accounts WHERE id=? AND org_id=?",
            (account_id, org_id),
        ).fetchone()
        if acct is None:
            raise ValidationError(f"unknown account for this org: {account_id}")
        if not acct["is_active"]:
            raise ValidationError(f"account is inactive: {account_id}")

        debit = _to_decimal(raw.get("debit", "0"), "debit")
        credit = _to_decimal(raw.get("credit", "0"), "credit")
        if debit < 0 or credit < 0:
            raise ValidationError("debit/credit amounts must be non-negative")
        if debit > 0 and credit > 0:
            raise ValidationError("a single line cannot have both debit and credit")
        if debit == 0 and credit == 0:
            raise ValidationError("a line must have a nonzero debit or credit")

        debit_total += debit
        credit_total += credit
        normalized.append({
            "account_id": account_id,
            "debit": str(debit),
            "credit": str(credit),
            "currency": raw.get("currency", currency),
            "line_no": idx,
        })

    if debit_total != credit_total:
        raise UnbalancedJournalError(
            f"journal is not balanced: debits={debit_total} credits={credit_total}"
        )

    journal_id = _new_id()
    try:
        conn.execute("BEGIN IMMEDIATE")
        try:
            conn.execute(
                "INSERT INTO journals (id, org_id, fiscal_period_id, memo, status, source, "
                "created_by, idempotency_key, created_at) VALUES (?, ?, ?, ?, 'posted', ?, ?, ?, ?)",
                (journal_id, org_id, fiscal_period_id, memo, source, created_by, idempotency_key, _now()),
            )
            for line in normalized:
                conn.execute(
                    "INSERT INTO transaction_lines (id, journal_id, account_id, debit, credit, currency, line_no) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (_new_id(), journal_id, line["account_id"], line["debit"], line["credit"],
                     line["currency"], line["line_no"]),
                )
            _audit(conn, org_id, "journal", journal_id, "posted", created_by,
                   f"debits={debit_total} credits={credit_total} lines={len(normalized)}")
            conn.execute("COMMIT")
        except Exception:
            conn.execute("ROLLBACK")
            raise
    except sqlite3.IntegrityError as e:
        # Most likely: a concurrent request won the race on the same idempotency_key.
        conn.execute("ROLLBACK") if conn.in_transaction else None
        if idempotency_key:
            existing = conn.execute(
                "SELECT id FROM journals WHERE org_id=? AND idempotency_key=?",
                (org_id, idempotency_key),
            ).fetchone()
            if existing:
                return existing[0], False
        raise ValidationError(str(e)) from e

    return journal_id, True


def reverse_transaction(
    conn: sqlite3.Connection, org_id: str, journal_id: str, actor: str, memo: str = "reversal"
) -> str:
    """Create a compensating journal that exactly reverses an existing one.
    The original journal is never mutated or deleted — full history is kept.
    """
    journal = conn.execute(
        "SELECT id, fiscal_period_id, status FROM journals WHERE id=? AND org_id=?",
        (journal_id, org_id),
    ).fetchone()
    if journal is None:
        raise ValidationError(f"unknown journal: {journal_id}")
    if journal["status"] == "reversed":
        raise ValidationError(f"journal {journal_id} was already reversed")

    original_lines = conn.execute(
        "SELECT account_id, debit, credit, currency FROM transaction_lines WHERE journal_id=?",
        (journal_id,),
    ).fetchall()
    reversed_lines = [
        {"account_id": r["account_id"], "debit": r["credit"], "credit": r["debit"], "currency": r["currency"]}
        for r in original_lines
    ]

    new_journal_id, _ = post_transaction(
        conn, org_id, journal["fiscal_period_id"], reversed_lines,
        memo=f"{memo} (reverses {journal_id})", created_by=actor, source="manual",
    )
    conn.execute("UPDATE journals SET status='reversed' WHERE id=?", (journal_id,))
    _audit(conn, org_id, "journal", journal_id, "reversed", actor, f"reversed_by={new_journal_id}")
    return new_journal_id


def get_account_balance(conn: sqlite3.Connection, account_id: str) -> Decimal:
    row = conn.execute(
        "SELECT normal_side FROM accounts WHERE id=?", (account_id,)
    ).fetchone()
    if row is None:
        raise ValidationError(f"unknown account: {account_id}")

    # NOTE: we intentionally do NOT filter by journals.status here. 'reversed'
    # only marks that a journal has been compensated by another journal; its
    # lines are still real postings. The compensating (reversal) journal is
    # itself a normal posted entry with opposite debit/credit, so including
    # both nets to the correct balance. Filtering out 'reversed' journals
    # would double-count the cancellation and corrupt the balance.
    debit_total = Decimal("0")
    credit_total = Decimal("0")
    for r in conn.execute(
        "SELECT tl.debit, tl.credit FROM transaction_lines tl JOIN journals j ON tl.journal_id = j.id "
        "WHERE tl.account_id=?",
        (account_id,),
    ):
        debit_total += Decimal(r["debit"])
        credit_total += Decimal(r["credit"])

    if row["normal_side"] == "debit":
        return debit_total - credit_total
    return credit_total - debit_total


def get_trial_balance(conn: sqlite3.Connection, org_id: str) -> dict:
    accounts = conn.execute(
        "SELECT id, code, name, type, normal_side FROM accounts WHERE org_id=? ORDER BY code",
        (org_id,),
    ).fetchall()
    rows = []
    debit_col_total = Decimal("0")
    credit_col_total = Decimal("0")
    for a in accounts:
        balance = get_account_balance(conn, a["id"])
        if a["normal_side"] == "debit":
            debit_col_total += balance if balance > 0 else Decimal("0")
            credit_col_total += -balance if balance < 0 else Decimal("0")
        else:
            credit_col_total += balance if balance > 0 else Decimal("0")
            debit_col_total += -balance if balance < 0 else Decimal("0")
        rows.append({
            "account_id": a["id"], "code": a["code"], "name": a["name"],
            "type": a["type"], "balance": str(balance),
        })
    return {
        "org_id": org_id,
        "accounts": rows,
        "debit_total": str(debit_col_total),
        "credit_total": str(credit_col_total),
        "balanced": debit_col_total == credit_col_total,
    }


def get_ledger(conn: sqlite3.Connection, account_id: str) -> list[dict]:
    rows = conn.execute(
        "SELECT j.id as journal_id, j.memo, j.created_at, j.status, tl.debit, tl.credit "
        "FROM transaction_lines tl JOIN journals j ON tl.journal_id = j.id "
        "WHERE tl.account_id=? ORDER BY j.created_at",
        (account_id,),
    ).fetchall()
    return [dict(r) for r in rows]
