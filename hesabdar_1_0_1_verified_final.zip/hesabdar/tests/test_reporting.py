import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from hesabdar.reporting import ReportingPipeline, ReportType, FinancialStatementGenerator


class TestReportingSubsystem(unittest.TestCase):
    def test_trial_balance_generation(self):
        accounts = [
            {"id": "1010", "code": "1010", "name": "Cash", "category": "asset", "balance": 500000.0},
            {"id": "5040", "code": "5040", "name": "Utilities", "category": "expense", "balance": 100000.0},
            {"id": "4010", "code": "4010", "name": "Sales", "category": "revenue", "balance": 600000.0},
        ]
        rep = FinancialStatementGenerator.generate_trial_balance(accounts)
        self.assertEqual(rep.report_type, ReportType.TRIAL_BALANCE)
        self.assertTrue(rep.is_valid)
        self.assertEqual(rep.summary["total_debit"], 600000.0)
        self.assertEqual(rep.summary["total_credit"], 600000.0)

    def test_balance_sheet_equation(self):
        accounts = [
            {"id": "1010", "code": "1010", "name": "Cash", "category": "asset", "balance": 1000000.0},
            {"id": "2010", "code": "2010", "name": "Payables", "category": "liability", "balance": 400000.0},
            {"id": "3010", "code": "3010", "name": "Capital", "category": "equity", "balance": 600000.0},
        ]
        rep = FinancialStatementGenerator.generate_balance_sheet(accounts)
        self.assertTrue(rep.is_valid)
        self.assertTrue(rep.summary["accounting_equation_holds"])

    def test_reporting_pipeline_with_forecasting(self):
        pipeline = ReportingPipeline()
        rep = pipeline.build_full_report(ReportType.INCOME_STATEMENT)
        self.assertIsNotNone(rep.forecast_projection)
        self.assertIn("month_plus_1", rep.forecast_projection)


if __name__ == "__main__":
    unittest.main()
