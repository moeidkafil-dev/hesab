"""
Regression tests for HESABDAR_FINAL_REPAIR_PRD:
  - S3/S7  database corruption is detected and safely recovered, never
           silently used and never silently destroyed
  - S8     authoritative money values are exact (no binary float drift)
  - S9     the debit == credit invariant is enforced before persistence
  - S10    idempotent financial mutation: a retried request with the same
           idempotency_key never creates a second authoritative transaction
  - S38    the web tool refuses non-http(s) schemes and non-public hosts
           (SSRF / local-file-read guard)
"""
from __future__ import annotations


import pytest

from hesabdar.accounting.money import to_money
from hesabdar.db_health import doctor
from hesabdar.db_manager.agent import DBManagerAgent, UnbalancedEntryError
from hesabdar.tools.web_tool import SSRFBlocked, WebTool


@pytest.fixture()
def agent(tmp_path):
    return DBManagerAgent(db_path=tmp_path / "production.sqlite3")


def _account(agent, name="Cash", account_type="asset"):
    return agent._op_create_account(name=name, account_type=account_type)


class TestDatabaseCorruptionRecovery:
    def test_malformed_file_is_quarantined_not_used_not_deleted(self, tmp_path):
        db_path = tmp_path / "production.sqlite3"
        db_path.write_bytes(b"this is not a valid sqlite database")

        agent = DBManagerAgent(db_path=db_path)

        # The corrupted bytes must still exist somewhere (never silently destroyed) ...
        quarantine_dir = tmp_path / "quarantine"
        assert quarantine_dir.exists()
        quarantined_files = list(quarantine_dir.iterdir())
        assert len(quarantined_files) == 1
        assert quarantined_files[0].read_bytes() == b"this is not a valid sqlite database"

        # ... but a fresh, healthy database must now be usable in its place.
        health = agent.health()
        assert health["ok"] is True
        acc_id = _account(agent)
        assert acc_id

    def test_doctor_reports_corruption_without_mutating_the_file(self, tmp_path):
        db_path = tmp_path / "production.sqlite3"
        db_path.write_bytes(b"corrupt")
        before = db_path.read_bytes()

        result = doctor(db_path)

        assert result["ok"] is False
        assert db_path.read_bytes() == before  # doctor() is read-only

    def test_healthy_database_passes_doctor(self, tmp_path):
        db_path = tmp_path / "production.sqlite3"
        DBManagerAgent(db_path=db_path)  # initializes a fresh, valid db
        result = doctor(db_path)
        assert result["ok"] is True


class TestMoneyPrecision:
    def test_classic_float_drift_does_not_reappear(self):
        # The canonical example of binary float drift: 0.1 + 0.2 != 0.3 in
        # plain Python floats. The decimal-safe helper must not exhibit it.
        assert to_money(0.1) + to_money(0.2) == to_money(0.3)

    def test_ledger_balance_is_exact_over_many_small_postings(self, agent):
        cash = _account(agent, "Cash", "asset")
        revenue = _account(agent, "Revenue", "revenue")
        for _ in range(20):
            agent._op_post_transaction(
                description="micro-sale",
                lines=[
                    {"account_id": cash, "debit": "0.10", "credit": 0},
                    {"account_id": revenue, "debit": 0, "credit": "0.10"},
                ],
            )
        assert agent._op_query_balance(cash) == "2.00"
        assert agent._op_query_balance(revenue) == "-2.00"


class TestDebitCreditInvariant:
    def test_unbalanced_entry_is_rejected_before_persistence(self, agent):
        cash = _account(agent, "Cash", "asset")
        revenue = _account(agent, "Revenue", "revenue")
        with pytest.raises(UnbalancedEntryError):
            agent._op_post_transaction(
                description="broken entry",
                lines=[
                    {"account_id": cash, "debit": "10.00", "credit": 0},
                    {"account_id": revenue, "debit": 0, "credit": "9.99"},
                ],
            )
        # Nothing should have been written for the rejected entry.
        assert agent._op_list_transactions() == []

    def test_balanced_entry_is_persisted(self, agent):
        cash = _account(agent, "Cash", "asset")
        revenue = _account(agent, "Revenue", "revenue")
        txn_id = agent._op_post_transaction(
            description="valid sale",
            lines=[
                {"account_id": cash, "debit": "10.00", "credit": 0},
                {"account_id": revenue, "debit": 0, "credit": "10.00"},
            ],
        )
        assert txn_id
        assert len(agent._op_list_transactions()) == 1


class TestIdempotency:
    def test_repeated_request_with_same_key_does_not_duplicate(self, agent):
        cash = _account(agent, "Cash", "asset")
        revenue = _account(agent, "Revenue", "revenue")
        lines = [
            {"account_id": cash, "debit": "50.00", "credit": 0},
            {"account_id": revenue, "debit": 0, "credit": "50.00"},
        ]
        first = agent._op_post_transaction(description="idempotent sale", lines=lines, idempotency_key="req-123")
        second = agent._op_post_transaction(description="idempotent sale", lines=lines, idempotency_key="req-123")

        assert first == second
        assert len(agent._op_list_transactions()) == 1
        assert agent._op_query_balance(cash) == "50.00"  # not 100.00

    def test_different_keys_create_distinct_transactions(self, agent):
        cash = _account(agent, "Cash", "asset")
        revenue = _account(agent, "Revenue", "revenue")
        lines = [
            {"account_id": cash, "debit": "50.00", "credit": 0},
            {"account_id": revenue, "debit": 0, "credit": "50.00"},
        ]
        first = agent._op_post_transaction(description="sale", lines=lines, idempotency_key="req-1")
        second = agent._op_post_transaction(description="sale", lines=lines, idempotency_key="req-2")
        assert first != second
        assert len(agent._op_list_transactions()) == 2


class TestWebToolSSRFGuard:
    def test_file_scheme_is_blocked(self):
        with pytest.raises(SSRFBlocked):
            WebTool().page_html_exporter("file:///etc/passwd")

    def test_loopback_host_is_blocked(self):
        with pytest.raises(SSRFBlocked):
            WebTool().page_html_exporter("http://127.0.0.1/admin")

    def test_localhost_hostname_is_blocked(self):
        with pytest.raises(SSRFBlocked):
            WebTool().page_html_exporter("http://localhost:8080/")

    def test_link_local_metadata_host_is_blocked(self):
        # e.g. the cloud-provider instance-metadata SSRF target
        with pytest.raises(SSRFBlocked):
            WebTool().page_html_exporter("http://169.254.169.254/latest/meta-data/")
