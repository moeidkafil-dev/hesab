import shutil
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from hesabdar.resilience import BackupSystem, RecoverySystem, SelfHealingSystem, DebuggerSystem
from hesabdar.super_logs import SuperLogManager


class TestResilienceSubsystem(unittest.TestCase):
    def setUp(self):
        self.temp_dir = Path(tempfile.mkdtemp())
        self.data_dir = self.temp_dir / "data"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        # Create a sample db file
        (self.data_dir / "production.sqlite3").write_text("DUMMY_DB_DATA_V1")

        self.backup_sys = BackupSystem(data_dir=self.data_dir)
        self.recovery_sys = RecoverySystem(data_dir=self.data_dir, backup_system=self.backup_sys)
        self.logs = SuperLogManager(log_path=self.data_dir / "super_logs.jsonl")
        self.self_healing = SelfHealingSystem(super_logs=self.logs, max_tries=3)
        self.debugger = DebuggerSystem(super_logs=self.logs)

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_backup_and_recovery_round_trip(self):
        # 1. Capture snapshot
        snapshot = self.backup_sys.create_backup("Initial State")
        self.assertTrue(snapshot.verified)
        self.assertIn("production.sqlite3", snapshot.files)

        # 2. Mutate / corrupt file
        (self.data_dir / "production.sqlite3").write_text("CORRUPTED_DATA")

        # 3. Restore snapshot
        rec_res = self.recovery_sys.restore_from_backup(snapshot.id)
        self.assertTrue(rec_res.ok)
        self.assertEqual((self.data_dir / "production.sqlite3").read_text(), "DUMMY_DB_DATA_V1")

    def test_self_healing_bounded_retry_escalation(self):
        task_id = "test_failing_task"
        # Attempts 1, 2, 3 succeed in applying automated recovery
        h1 = self.self_healing.diagnose_and_heal(task_id, "DB lock timeout", {})
        self.assertTrue(h1.ok)
        self.assertEqual(h1.tries_count, 1)

        h2 = self.self_healing.diagnose_and_heal(task_id, "DB lock timeout", {})
        self.assertEqual(h2.tries_count, 2)

        h3 = self.self_healing.diagnose_and_heal(task_id, "DB lock timeout", {})
        self.assertEqual(h3.tries_count, 3)

        # Attempt 4 exceeds max_tries -> escalates to human oversight (PRD §38)
        h4 = self.self_healing.diagnose_and_heal(task_id, "DB lock timeout", {})
        self.assertFalse(h4.ok)
        self.assertTrue(h4.escalated_to_human)

    def test_debugger_causality_trace(self):
        self.logs.log(task_id="task_debug_1", agent_id="ceo", prompt="Start flow")
        self.logs.log(task_id="task_debug_1", agent_id="accounting_engine", output="Calculated lines", latency_ms=45.0)

        trace = self.debugger.trace(task_id="task_debug_1")
        self.assertEqual(trace.total_events, 2)
        self.assertEqual(trace.total_latency_ms, 45.0)


if __name__ == "__main__":
    unittest.main()
