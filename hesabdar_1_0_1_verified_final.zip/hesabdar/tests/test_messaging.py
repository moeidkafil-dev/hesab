import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from hesabdar.messaging import AgentIdentity, IdentityRegistry, Channel, new_message
from hesabdar.messaging.channel import CommandDeduplicator


class TestMessaging(unittest.TestCase):
    def test_signed_message_round_trips(self):
        registry = IdentityRegistry()
        a = AgentIdentity.create("agent_a", persist=False)
        b = AgentIdentity.create("agent_b", persist=False)
        registry.register(a)
        registry.register(b)

        chan_a = Channel(a, registry)
        chan_b = Channel(b, registry)

        result = chan_a.send("agent_b", {"op": "ping"}, chan_b)
        self.assertTrue(result.ok)
        self.assertEqual(result.message.payload, {"op": "ping"})

    def test_tampered_signature_rejected(self):
        registry = IdentityRegistry()
        a = AgentIdentity.create("agent_a", persist=False)
        b = AgentIdentity.create("agent_b", persist=False)
        registry.register(a)
        registry.register(b)
        chan_a = Channel(a, registry)
        chan_b = Channel(b, registry)

        msg = chan_a.aim_for_message("agent_b", {"op": "post_transaction", "amount": 100})
        msg = chan_a.signner(msg)
        msg.payload["amount"] = 999999  # tamper after signing
        result = chan_b.receiver(msg)
        self.assertFalse(result.ok, "tampered payload must fail signature verification")

    def test_command_deduplication(self):
        dedup = CommandDeduplicator(window_seconds=5.0)
        msg1 = new_message("agent_1", "accounting", {"op": "query_balance", "args": {"acc": "1010"}})
        msg2 = new_message("agent_2", "accounting", {"op": "query_balance", "args": {"acc": "1010"}})

        is_dup1, rec1 = dedup.get_or_register(msg1)
        self.assertFalse(is_dup1)
        self.assertIsNotNone(rec1)

        is_dup2, rec2 = dedup.get_or_register(msg2)
        self.assertTrue(is_dup2)
        self.assertEqual(len(rec2.requesters), 2)


if __name__ == "__main__":
    unittest.main()
