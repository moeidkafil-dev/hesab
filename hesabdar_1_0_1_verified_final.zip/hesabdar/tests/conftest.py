"""
PRD S32, "Test Database Isolation": tests must never use the repository's
persistent development database. This conftest runs before any `hesabdar`
module is imported (pytest imports conftest.py first) and points
HESABDAR_DATA_DIR at a fresh temporary directory for the whole test
session, so every MemoryStore / DBManagerAgent created during the run
gets its own clean SQLite files, never the developer's data/ directory.

It also forces the LLM provider to "mock" so the deterministic test
suite never depends on an external LLM being reachable (PRD S12).
"""
from __future__ import annotations

import os
import shutil
import tempfile

_TEST_DATA_DIR = tempfile.mkdtemp(prefix="hesabdar_test_data_")
os.environ["HESABDAR_DATA_DIR"] = _TEST_DATA_DIR
os.environ.setdefault("HESABDAR_LLM_PROVIDER", "mock")

import pytest  # noqa: E402  (import after env vars are set, before hesabdar.* imports)


@pytest.fixture(autouse=True, scope="session")
def _cleanup_test_data_dir():
    yield
    shutil.rmtree(_TEST_DATA_DIR, ignore_errors=True)
