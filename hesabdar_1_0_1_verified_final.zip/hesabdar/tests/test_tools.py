import shutil
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from hesabdar.tools import ToolManager, AuthorizationError


class TestTools(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_unauthorized_tool_call_raises(self):
        tm = ToolManager(sandbox_root=str(self.temp_dir))
        with self.assertRaises(AuthorizationError):
            tm.invoke("random_agent", "bash_run", command="echo hi")

    def test_sandbox_escape_blocked(self):
        tm = ToolManager(sandbox_root=str(self.temp_dir))
        tm.grant("agent_x", ["file_read"])
        result = tm.invoke("agent_x", "file_read", path="../../../etc/passwd")
        self.assertFalse(result.ok)
        self.assertIn("SandboxViolation", result.log)

    def test_authorized_file_roundtrip(self):
        tm = ToolManager(sandbox_root=str(self.temp_dir))
        tm.grant("agent_x", ["file_make", "file_read"])
        made = tm.invoke("agent_x", "file_make", path="a.txt", content="hi")
        self.assertTrue(made.ok)
        read = tm.invoke("agent_x", "file_read", path="a.txt")
        self.assertTrue(read.ok)
        self.assertEqual(read.result, "hi")


if __name__ == "__main__":
    unittest.main()
