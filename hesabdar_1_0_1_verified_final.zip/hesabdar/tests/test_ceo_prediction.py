import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from hesabdar.ceo.orchestrator import CEOAgentArchitecture


class TestCEOPredictionAndExecution(unittest.TestCase):
    def setUp(self):
        self.ceo = CEOAgentArchitecture()

    def test_end_to_end_expense_task_execution(self):
        prompt = "Record payment of 500,000 Rials for internet subscription"
        res = self.ceo.execute_accounting_task(
            prompt,
            raw_payload={"description": prompt, "amount": 500000.0, "category": "expense", "sub_category": "utilities"},
        )
        self.assertTrue(res["ok"])
        self.assertIn("task_id", res)
        self.assertIsNotNone(res["prediction"])
        self.assertIsNotNone(res["critic_report"])
        self.assertTrue(res["critic_report"]["passed"])
        self.assertEqual(res["decision"]["action"], "PASS")

    def test_human_approval_gate_for_restricted_action(self):
        prompt = "Process high risk supplier payment of 10,000,000 Rials to Vendor_X"
        res = self.ceo.execute_accounting_task(
            prompt,
            raw_payload={"description": prompt, "amount": 10000000.0, "vendor": "Vendor_X", "category": "expense"},
        )
        self.assertTrue(res["ok"])
        self.assertEqual(res["status"], "pending_human_approval")
        self.assertIn("approval_id", res)

        # Human operator approves the item
        appr_id = res["approval_id"]
        approved = self.ceo.approve_item(appr_id, approver="chief_auditor")
        self.assertTrue(approved)


if __name__ == "__main__":
    unittest.main()
