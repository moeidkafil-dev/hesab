import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from hesabdar.accounting.schema import JournalEntry, JournalEntryLine
from hesabdar.critic.final_checker import FinalCheckerAgent, VerificationDisposition


class TestCriticFinalChecker(unittest.TestCase):
    def setUp(self):
        self.checker = FinalCheckerAgent()

    def test_structural_invariant_balanced_entry_passes(self):
        entry = JournalEntry(
            id="je_test_1",
            transaction_date=1700000000.0,
            description="Office rent",
            lines=[
                JournalEntryLine("l1", "5030", "5030", "Rent Expense", debit=1000000.0, credit=0.0),
                JournalEntryLine("l2", "1010", "1010", "Bank", debit=0.0, credit=1000000.0),
            ],
        )
        report = self.checker.check(entry, input_task="Record office rent payment")
        self.assertTrue(report.passed)
        self.assertEqual(report.disposition, VerificationDisposition.PASS)
        self.assertGreaterEqual(report.overall_confidence, 0.7)

    def test_structural_invariant_unbalanced_entry_rejected(self):
        entry = JournalEntry(
            id="je_test_broken",
            transaction_date=1700000000.0,
            description="Corrupted entry",
            lines=[
                JournalEntryLine("l1", "5030", "5030", "Rent Expense", debit=1000000.0, credit=0.0),
                JournalEntryLine("l2", "1010", "1010", "Bank", debit=0.0, credit=800000.0),  # unbalanced!
            ],
        )
        report = self.checker.check(entry, input_task="Record unbalanced entry")
        self.assertFalse(report.passed)
        self.assertEqual(report.disposition, VerificationDisposition.REJECT)
        self.assertEqual(report.overall_confidence, 0.0)

    def test_statistical_anomaly_triggers_human_review(self):
        entry = JournalEntry(
            id="je_large",
            transaction_date=1700000000.0,
            description="Massive Capital Asset Acquisition",
            lines=[
                JournalEntryLine("l1", "1500", "1500", "Equipment", debit=250000000.0, credit=0.0),
                JournalEntryLine("l2", "1010", "1010", "Bank", debit=0.0, credit=250000000.0),
            ],
        )
        report = self.checker.check(entry, input_task="Buy mega equipment", historical_txs=[100000.0, 150000.0, 200000.0, 120000.0, 180000.0])
        self.assertTrue(report.passed)
        self.assertEqual(report.disposition, VerificationDisposition.HUMAN_REVIEW)


if __name__ == "__main__":
    unittest.main()
