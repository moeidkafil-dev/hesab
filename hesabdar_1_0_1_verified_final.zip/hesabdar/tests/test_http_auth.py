"""
Tests for the new hesabdar/http_server.py + hesabdar/auth/auth.py layer.
Does not touch or depend on the existing engine test suite; uses its own
isolated temp SQLite files for both the users DB and the accounting DBs so
it cannot interfere with (or be interfered with by) other test modules.
"""
from __future__ import annotations

import os
import tempfile
import unittest

from hesabdar.auth import auth as authmod


class AuthModuleTestCase(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.db_path = os.path.join(self.tmpdir.name, "users.sqlite3")
        self.conn = authmod.connect(self.db_path)
        self.secret = "test-secret"

    def tearDown(self):
        self.conn.close()
        self.tmpdir.cleanup()

    def test_create_and_authenticate_user(self):
        authmod.create_user(self.conn, "a@x.com", "supersecret", role="admin")
        user = authmod.authenticate(self.conn, "a@x.com", "supersecret")
        self.assertEqual(user["role"], "admin")

    def test_wrong_password_rejected(self):
        authmod.create_user(self.conn, "b@x.com", "supersecret", role="accountant")
        with self.assertRaises(authmod.AuthError):
            authmod.authenticate(self.conn, "b@x.com", "wrong-password")

    def test_duplicate_email_rejected(self):
        authmod.create_user(self.conn, "c@x.com", "supersecret")
        with self.assertRaises(authmod.AuthError):
            authmod.create_user(self.conn, "c@x.com", "another-pass")

    def test_short_password_rejected(self):
        with self.assertRaises(authmod.AuthError):
            authmod.create_user(self.conn, "d@x.com", "short")

    def test_invalid_role_rejected(self):
        with self.assertRaises(authmod.AuthError):
            authmod.create_user(self.conn, "e@x.com", "supersecret", role="superuser")

    def test_jwt_roundtrip(self):
        token = authmod.issue_token("user-1", "admin", self.secret)
        claims = authmod.verify_token(token, self.secret)
        self.assertEqual(claims["sub"], "user-1")
        self.assertEqual(claims["role"], "admin")

    def test_jwt_wrong_secret_rejected(self):
        token = authmod.issue_token("user-1", "admin", self.secret)
        with self.assertRaises(authmod.AuthError):
            authmod.verify_token(token, "wrong-secret")

    def test_require_role_blocks_disallowed(self):
        with self.assertRaises(authmod.AuthError):
            authmod.require_role({"role": "viewer"}, ("admin", "accountant"))

    def test_require_role_allows_permitted(self):
        authmod.require_role({"role": "accountant"}, ("admin", "accountant"))  # no raise

    def test_secret_persists_across_calls_and_is_not_hardcoded(self):
        secret_path = os.path.join(self.tmpdir.name, "jwt_secret.key")
        s1 = authmod.get_or_create_secret(secret_path)
        s2 = authmod.get_or_create_secret(secret_path)
        self.assertEqual(s1, s2)
        self.assertNotEqual(s1, "dev-secret-change-me")
        self.assertGreaterEqual(len(s1), 32)


class HttpServerTestCase(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        os.environ["HESABDAR_DATA_DIR"] = self.tmpdir.name
        # http_server + api_server + orchestrator create their own sqlite
        # files relative to cwd/data by default; isolate by chdir'ing into
        # a fresh temp dir per test process run.
        self._old_cwd = os.getcwd()
        os.chdir(self.tmpdir.name)

        # Public self-registration is disabled by default in production
        # (S-hardening: prevents anonymous privilege escalation). This test
        # class exercises the full register -> login -> API flow, so it
        # opts in explicitly for the duration of each test, exactly like an
        # operator would via deployment config. Every account created this
        # way is still forced to "viewer" by the endpoint itself.
        self._had_flag = "HESABDAR_ALLOW_PUBLIC_REGISTRATION" in os.environ
        self._old_flag = os.environ.get("HESABDAR_ALLOW_PUBLIC_REGISTRATION")
        os.environ["HESABDAR_ALLOW_PUBLIC_REGISTRATION"] = "1"

        from hesabdar.http_server import create_app
        users_db = os.path.join(self.tmpdir.name, "users.sqlite3")
        self.app = create_app(secret="test-secret", users_db_path=users_db)
        self.client = self.app.test_client()

    def tearDown(self):
        os.chdir(self._old_cwd)
        self.tmpdir.cleanup()
        if self._had_flag:
            os.environ["HESABDAR_ALLOW_PUBLIC_REGISTRATION"] = self._old_flag
        else:
            os.environ.pop("HESABDAR_ALLOW_PUBLIC_REGISTRATION", None)

    def _register_and_login(self, email="admin@x.com", password="supersecret123", role="admin"):
        self.client.post("/auth/register", json={"email": email, "password": password, "role": role})
        resp = self.client.post("/auth/login", json={"email": email, "password": password})
        return resp.get_json()["token"]

    def test_healthz_no_auth_required(self):
        resp = self.client.get("/healthz")
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(resp.get_json()["ok"])

    def test_protected_endpoint_without_token_rejected(self):
        resp = self.client.post("/api/status", json={})
        self.assertEqual(resp.status_code, 401)

    def test_login_then_status_succeeds(self):
        token = self._register_and_login()
        resp = self.client.post(
            "/api/status", json={}, headers={"Authorization": f"Bearer {token}"}
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(resp.get_json()["ok"])

    def test_viewer_cannot_post_journal_entry(self):
        token = self._register_and_login(email="viewer@x.com", role="viewer")
        resp = self.client.post(
            "/api/post_journal_entry",
            json={"description": "x", "lines": []},
            headers={"Authorization": f"Bearer {token}"},
        )
        self.assertEqual(resp.status_code, 403)

    def test_admin_can_post_journal_entry_endpoint(self):
        token = self._register_and_login()
        # list_accounts is read-only and safe to call regardless of seed state
        resp = self.client.post(
            "/api/list_accounts", json={}, headers={"Authorization": f"Bearer {token}"}
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(resp.get_json()["ok"])

    def test_invalid_token_rejected(self):
        resp = self.client.post(
            "/api/status", json={}, headers={"Authorization": "Bearer not-a-real-token"}
        )
        self.assertEqual(resp.status_code, 401)

    def test_login_rate_limited_after_repeated_failures(self):
        self.client.post(
            "/auth/register",
            json={"email": "rl@x.com", "password": "supersecret123", "role": "admin"},
        )
        last_status = None
        for _ in range(10):
            resp = self.client.post(
                "/auth/login", json={"email": "rl@x.com", "password": "wrong-password"}
            )
            last_status = resp.status_code
        self.assertEqual(last_status, 429)

    def test_successful_login_resets_rate_limit(self):
        self.client.post(
            "/auth/register",
            json={"email": "rl2@x.com", "password": "supersecret123", "role": "admin"},
        )
        for _ in range(3):
            self.client.post("/auth/login", json={"email": "rl2@x.com", "password": "wrong"})
        resp = self.client.post(
            "/auth/login", json={"email": "rl2@x.com", "password": "supersecret123"}
        )
        self.assertEqual(resp.status_code, 200)


class RateLimiterUnitTestCase(unittest.TestCase):
    def test_blocks_after_max_attempts(self):
        limiter = authmod.LoginRateLimiter(max_attempts=3, window_seconds=60)
        for _ in range(3):
            limiter.check_and_record("k1")
        with self.assertRaises(authmod.RateLimitExceeded):
            limiter.check_and_record("k1")

    def test_independent_keys_not_shared(self):
        limiter = authmod.LoginRateLimiter(max_attempts=1, window_seconds=60)
        limiter.check_and_record("k1")
        limiter.check_and_record("k2")  # different key, should not raise

    def test_reset_clears_attempts(self):
        limiter = authmod.LoginRateLimiter(max_attempts=1, window_seconds=60)
        limiter.check_and_record("k1")
        limiter.reset("k1")
        limiter.check_and_record("k1")  # should not raise after reset


if __name__ == "__main__":
    unittest.main()
