"""Concurrency and invariant testing under parallel multi-agent workloads (PRD §36, §37)."""

import concurrent.futures
from hesabdar.db_manager.agent import DBManagerAgent


class TestConcurrencyInvariants:
    def test_parallel_transaction_postings_maintain_ledger_integrity(self, tmp_path):
        db_path = tmp_path / "concurrency_test.sqlite3"
        agent = DBManagerAgent(db_path=db_path)

        cash_id = agent._op_create_account("Cash", "asset")
        rev_id = agent._op_create_account("Revenue", "revenue")

        num_threads = 8
        txns_per_thread = 10
        amount_per_txn = "100.00"

        def post_batch(thread_idx: int):
            posted = 0
            for i in range(txns_per_thread):
                lines = [
                    {"account_id": cash_id, "debit": amount_per_txn, "credit": 0},
                    {"account_id": rev_id, "debit": 0, "credit": amount_per_txn},
                ]
                agent._op_post_transaction(
                    description=f"Thread {thread_idx} sale {i}",
                    lines=lines,
                    idempotency_key=f"thread_{thread_idx}_sale_{i}",
                )
                posted += 1
            return posted

        with concurrent.futures.ThreadPoolExecutor(max_workers=num_threads) as executor:
            futures = [executor.submit(post_batch, t) for t in range(num_threads)]
            results = [f.result() for f in futures]

        total_txns = sum(results)
        assert total_txns == num_threads * txns_per_thread

        # Verify exact ledger balance: 8 * 10 * 100.00 = 8000.00
        cash_balance = agent._op_query_balance(cash_id)
        assert cash_balance == "8000.00"
        rev_balance = agent._op_query_balance(rev_id)
        assert rev_balance == "-8000.00"

        # Verify DB health integrity pragma passes
        health = agent.health()
        assert health["ok"] is True

    def test_concurrent_idempotent_submissions_race_safe(self, tmp_path):
        db_path = tmp_path / "idempotency_race.sqlite3"
        agent = DBManagerAgent(db_path=db_path)

        cash_id = agent._op_create_account("Cash", "asset")
        rev_id = agent._op_create_account("Revenue", "revenue")

        shared_idempotency_key = "idempotent_race_key_999"
        lines = [
            {"account_id": cash_id, "debit": "500.00", "credit": 0},
            {"account_id": rev_id, "debit": 0, "credit": "500.00"},
        ]

        def attempt_post():
            return agent._op_post_transaction(
                description="Simultaneous Idempotent Request",
                lines=lines,
                idempotency_key=shared_idempotency_key,
            )

        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(attempt_post) for _ in range(10)]
            txn_ids = [f.result() for f in futures]

        # All 10 concurrent requests must return the EXACT same transaction id
        assert len(set(txn_ids)) == 1
        # Exactly one transaction exists in the database
        all_txns = agent._op_list_transactions()
        assert len(all_txns) == 1
        assert agent._op_query_balance(cash_id) == "500.00"
