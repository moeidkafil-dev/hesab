import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from hesabdar.skills import (
    Skill,
    SkillRegistry,
    SkillSecurityError,
    SkillSecurityVerifier,
    SkillStatus,
)


class TestSkillRegistry(unittest.TestCase):
    def setUp(self):
        self.registry = SkillRegistry()

    def test_default_skills_seeded_and_valid(self):
        skills = self.registry.list_skills()
        self.assertGreaterEqual(len(skills), 4)
        for s in skills:
            self.assertEqual(s.status, SkillStatus.ACTIVE)
            self.assertTrue(s.checksum)
            valid, errs = SkillSecurityVerifier.validate(s)
            self.assertTrue(valid, f"Skill {s.id} failed verification: {errs}")

    def test_skill_authorization_and_execution(self):
        skill = Skill(
            id="test_calc_skill",
            name="Test Calculator Skill",
            version="1.0.0",
            repository="https://github.com/moeidkafil-dev/hessabdar-skills/test-calc",
            readme="https://github.com/moeidkafil-dev/hessabdar-skills/test-calc/README.md",
            documentation="https://hesabdar.internal/docs/test-calc",
            capabilities=["interest_rate_calc"],
            permissions=["read_ledger", "analytics_compute"],
            compatible_agents=["ceo", "accounting_engine"],
            handler=lambda principal=1000, rate=0.05: {"interest": principal * rate},
        )
        ok, errs = self.registry.register(skill)
        self.assertTrue(ok)

        # Authorized execution
        exec_res = self.registry.executor.execute("ceo", "test_calc_skill", principal=2000, rate=0.1)
        self.assertTrue(exec_res["ok"])
        self.assertEqual(exec_res["result"]["interest"], 200.0)

        # Unauthorized execution throws SkillSecurityError
        with self.assertRaises(SkillSecurityError):
            self.registry.executor.execute("unauthorized_agent_xyz", "test_calc_skill")

    def test_invalid_checksum_rejected(self):
        skill = Skill(
            id="tampered_skill",
            name="Tampered Skill",
            version="1.0.0",
            repository="https://github.com/moeidkafil-dev/hessabdar-skills/fake",
            readme="README.md",
            documentation="docs",
            checksum="bad_checksum_hash_12345",
        )
        valid, errs = SkillSecurityVerifier.validate(skill)
        self.assertFalse(valid)
        self.assertTrue(any("Checksum mismatch" in e for e in errs))


if __name__ == "__main__":
    unittest.main()
