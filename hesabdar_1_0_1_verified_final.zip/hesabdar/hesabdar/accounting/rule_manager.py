"""
Rule Manager Subsystem (n17, PRD §23, Docs 05 §5.2).
Rules as Data: deterministic rule definitions, versioning, conflict detection,
candidate lifecycle, human approval gates, and conservative resolution
(most restrictive rule wins per §5.5).
"""
from __future__ import annotations

import time
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Optional


class RuleStatus(str, Enum):
    CANDIDATE = "candidate"
    PENDING_APPROVAL = "pending_approval"
    APPROVED = "approved"
    ACTIVE = "active"
    RETIRED = "retired"
    REJECTED = "rejected"


class RuleScope(str, Enum):
    STATUTORY = "statutory"  # Tax, labor, compliance laws
    ORGANIZATIONAL = "organizational"  # Company-wide chart of accounts rules
    DEPARTMENTAL = "departmental"  # Specific cost center policies
    CLIENT_OVERRIDE = "client_override"  # Specific customer/vendor overrides


class RuleDisposition(str, Enum):
    AUTO_POST = "auto_post"
    REQUIRE_HUMAN_APPROVAL = "require_human_approval"
    REJECT = "reject"
    FLAG_WARNING = "flag_warning"


@dataclass
class RuleCondition:
    field: str
    operator: str  # "==", "!=", ">", "<", ">=", "<=", "in", "contains", "regex"
    value: Any

    def evaluate(self, context: dict[str, Any]) -> bool:
        ctx_val = context.get(self.field)
        if ctx_val is None:
            return False

        op = self.operator
        try:
            if op == "==":
                return ctx_val == self.value
            elif op == "!=":
                return ctx_val != self.value
            elif op == ">":
                return float(ctx_val) > float(self.value)
            elif op == "<":
                return float(ctx_val) < float(self.value)
            elif op == ">=":
                return float(ctx_val) >= float(self.value)
            elif op == "<=":
                return float(ctx_val) <= float(self.value)
            elif op == "in":
                return ctx_val in self.value
            elif op == "contains":
                return str(self.value).lower() in str(ctx_val).lower()
        except Exception:
            return False
        return False


@dataclass
class RuleAction:
    disposition: RuleDisposition = RuleDisposition.AUTO_POST
    debit_account_code: str = ""
    credit_account_code: str = ""
    tax_rate: float = 0.0
    tax_account_code: str = ""
    custom_logic: Optional[str] = None


@dataclass
class AccountingRule:
    id: str
    code: str
    name: str
    description: str
    category: str  # e.g., "purchase", "sale", "payroll", "tax", "depreciation"
    scope: RuleScope
    priority: int  # Higher number = higher precedence (1..100)
    version: int = 1
    status: RuleStatus = RuleStatus.ACTIVE
    conditions: list[RuleCondition] = field(default_factory=list)
    action: RuleAction = field(default_factory=RuleAction)
    created_by: str = "system"
    approved_by: Optional[str] = None
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    metadata: dict[str, Any] = field(default_factory=dict)

    def matches(self, context: dict[str, Any]) -> bool:
        if self.status != RuleStatus.ACTIVE:
            return False
        # Category check if provided in context
        if "category" in context and context["category"] != self.category:
            return False
        if not self.conditions:
            return True
        return all(c.evaluate(context) for c in self.conditions)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["scope"] = self.scope.value
        d["status"] = self.status.value
        d["action"]["disposition"] = self.action.disposition.value
        return d


class RuleManager:
    """Manages rules database, candidate lifecycle, and conflict resolution (n17, PRD §23)."""

    def __init__(self):
        self._rules: dict[str, AccountingRule] = {}
        self._history: list[dict] = []
        self._seed_default_rules()

    def _seed_default_rules(self) -> None:
        default_rules = [
            # Standard operating expense
            AccountingRule(
                id="rule_exp_office",
                code="R-EXP-001",
                name="Standard Office Expense",
                description="Records office supplies, petty cash and utilities expense paid via bank",
                category="expense",
                scope=RuleScope.ORGANIZATIONAL,
                priority=10,
                conditions=[
                    RuleCondition("category", "==", "expense"),
                    RuleCondition("sub_category", "in", ["office_supplies", "utilities", "subscriptions"]),
                ],
                action=RuleAction(
                    disposition=RuleDisposition.AUTO_POST,
                    debit_account_code="5040",  # Utilities/Office
                    credit_account_code="1010",  # Cash/Bank
                ),
            ),
            # Rent Expense with large threshold human gate
            AccountingRule(
                id="rule_exp_rent_large",
                code="R-EXP-002",
                name="Large Rent / Lease Payment Check",
                description="Rent payments over 50,000,000 Rials require human approval gate",
                category="expense",
                scope=RuleScope.ORGANIZATIONAL,
                priority=50,
                conditions=[
                    RuleCondition("category", "==", "expense"),
                    RuleCondition("sub_category", "==", "rent"),
                    RuleCondition("amount", ">", 50000000),
                ],
                action=RuleAction(
                    disposition=RuleDisposition.REQUIRE_HUMAN_APPROVAL,
                    debit_account_code="5030",  # Rent Expense
                    credit_account_code="1010",  # Bank
                ),
            ),
            # Standard Sales Revenue
            AccountingRule(
                id="rule_sales_standard",
                code="R-REV-001",
                name="Standard Sales with VAT",
                description="Sales revenue with standard 10% VAT tax",
                category="sale",
                scope=RuleScope.STATUTORY,
                priority=20,
                conditions=[
                    RuleCondition("category", "==", "sale"),
                ],
                action=RuleAction(
                    disposition=RuleDisposition.AUTO_POST,
                    debit_account_code="1100",  # Accounts Receivable
                    credit_account_code="4010",  # Sales Revenue
                    tax_rate=0.10,
                    tax_account_code="2030",  # VAT Payable
                ),
            ),
            # Payroll Disbursement
            AccountingRule(
                id="rule_payroll_salary",
                code="R-PAY-001",
                name="Monthly Salary Disbursement",
                description="Salary payment with standard withholding tax deduction",
                category="payroll",
                scope=RuleScope.STATUTORY,
                priority=30,
                conditions=[
                    RuleCondition("category", "==", "payroll"),
                ],
                action=RuleAction(
                    disposition=RuleDisposition.AUTO_POST,
                    debit_account_code="5020",  # Salaries Expense
                    credit_account_code="1010",  # Bank
                    tax_rate=0.07,
                    tax_account_code="2040",  # Withholding Tax
                ),
            ),
            # Restricted Vendor Override (Doc 05 §5.5 example)
            AccountingRule(
                id="rule_vendor_restricted",
                code="R-OVR-001",
                name="Restricted Vendor Approval Policy",
                description="All transactions with sensitive/restricted vendor require manual approval",
                category="expense",
                scope=RuleScope.CLIENT_OVERRIDE,
                priority=90,
                conditions=[
                    RuleCondition("vendor", "in", ["Vendor_X", "HighRisk_Supplier"]),
                ],
                action=RuleAction(
                    disposition=RuleDisposition.REQUIRE_HUMAN_APPROVAL,
                    debit_account_code="5010",
                    credit_account_code="1010",
                ),
            ),
        ]
        for r in default_rules:
            self._rules[r.id] = r

    def get_rule(self, rule_id: str) -> Optional[AccountingRule]:
        return self._rules.get(rule_id)

    def list_rules(self, status: Optional[RuleStatus] = None) -> list[AccountingRule]:
        if status is None:
            return list(self._rules.values())
        return [r for r in self._rules.values() if r.status == status]

    def add_candidate_rule(self, rule: AccountingRule) -> str:
        rule.status = RuleStatus.PENDING_APPROVAL
        self._rules[rule.id] = rule
        self._history.append({
            "event": "candidate_created",
            "rule_id": rule.id,
            "created_by": rule.created_by,
            "timestamp": time.time(),
        })
        return rule.id

    def approve_rule(self, rule_id: str, approver: str) -> bool:
        rule = self._rules.get(rule_id)
        if not rule:
            return False
        rule.status = RuleStatus.ACTIVE
        rule.approved_by = approver
        rule.updated_at = time.time()
        self._history.append({
            "event": "rule_approved",
            "rule_id": rule_id,
            "approved_by": approver,
            "timestamp": time.time(),
        })
        return True

    def reject_rule(self, rule_id: str, reason: str = "") -> bool:
        rule = self._rules.get(rule_id)
        if not rule:
            return False
        rule.status = RuleStatus.REJECTED
        rule.updated_at = time.time()
        self._history.append({
            "event": "rule_rejected",
            "rule_id": rule_id,
            "reason": reason,
            "timestamp": time.time(),
        })
        return True

    def rollback_rule(self, rule_id: str) -> bool:
        rule = self._rules.get(rule_id)
        if not rule:
            return False
        rule.status = RuleStatus.RETIRED
        rule.updated_at = time.time()
        self._history.append({
            "event": "rule_retired",
            "rule_id": rule_id,
            "timestamp": time.time(),
        })
        return True
