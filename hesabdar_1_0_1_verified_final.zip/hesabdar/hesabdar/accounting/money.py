"""
Canonical decimal-safe monetary representation (PRD §8, "Financial
Numeric Safety"). Every authoritative money value — anything that
reaches DBManagerAgent (the sole authorized writer to the production
database) or the critic's pre-commit invariant check — must be parsed
and compared through this module instead of raw `float`.

Amounts are normalized to a `Decimal` quantized to 2 places and are
persisted as canonical decimal strings (not SQLite REAL), so no value
ever round-trips through binary floating point.
"""
from __future__ import annotations

from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Union

CENTS = Decimal("0.01")

MoneyLike = Union[str, int, float, Decimal, None]


def to_money(value: MoneyLike) -> Decimal:
    """Parses any input into an exact, 2-decimal-place Decimal.

    Floats are converted via `str()` first so we never inherit their
    binary representation error (Decimal(0.1) != Decimal("0.1"), but
    Decimal(str(0.1)) == Decimal("0.1")).
    """
    if value is None:
        d = Decimal("0")
    elif isinstance(value, Decimal):
        d = value
    elif isinstance(value, float):
        d = Decimal(str(value))
    else:
        try:
            d = Decimal(str(value))
        except InvalidOperation as exc:
            raise ValueError(f"not a valid monetary value: {value!r}") from exc
    return d.quantize(CENTS, rounding=ROUND_HALF_UP)


def money_to_str(value: MoneyLike) -> str:
    """Canonical storage representation: a plain decimal string, e.g. '12.50'."""
    return str(to_money(value))


def sum_money(values) -> Decimal:
    total = Decimal("0")
    for v in values:
        total += to_money(v)
    return total.quantize(CENTS, rounding=ROUND_HALF_UP)
