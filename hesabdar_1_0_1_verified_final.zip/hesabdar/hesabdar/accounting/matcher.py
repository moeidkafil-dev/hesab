"""
Rule Matcher (n17, PRD §25, Docs 05 §5.2, §5.5).
Evaluates candidate rules against classified transactions, ranks by priority,
and implements conservative conflict resolution: the most restrictive
applicable rule outcome always prevails (§5.5).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from hesabdar.accounting.rule_manager import (
    AccountingRule,
    RuleDisposition,
    RuleManager,
    RuleStatus,
)


@dataclass
class MatchResult:
    matched: bool
    selected_rule: Optional[AccountingRule] = None
    all_matching_rules: list[AccountingRule] = field(default_factory=list)
    governing_disposition: RuleDisposition = RuleDisposition.AUTO_POST
    conflict_detected: bool = False
    conflict_rationale: str = ""
    reason: str = ""


class RuleMatcher:
    def __init__(self, rule_manager: RuleManager):
        self.rule_manager = rule_manager

    def match(self, context: dict[str, Any]) -> MatchResult:
        active_rules = self.rule_manager.list_rules(status=RuleStatus.ACTIVE)
        matching_rules = [r for r in active_rules if r.matches(context)]

        if not matching_rules:
            return MatchResult(
                matched=False,
                selected_rule=None,
                all_matching_rules=[],
                reason="No active rule matched the transaction context.",
            )

        # Sort by priority descending (highest priority first)
        matching_rules.sort(key=lambda r: r.priority, reverse=True)

        # Conflict resolution check per §5.5: Most restrictive outcome wins
        dispositions = [r.action.disposition for r in matching_rules]
        conflict_detected = len(set(dispositions)) > 1

        if RuleDisposition.REJECT in dispositions:
            governing_disposition = RuleDisposition.REJECT
            selected = next(r for r in matching_rules if r.action.disposition == RuleDisposition.REJECT)
            rationale = "Rejected because at least one matched rule dictates REJECT (§5.5 conservative policy)."
        elif RuleDisposition.REQUIRE_HUMAN_APPROVAL in dispositions:
            governing_disposition = RuleDisposition.REQUIRE_HUMAN_APPROVAL
            selected = next(r for r in matching_rules if r.action.disposition == RuleDisposition.REQUIRE_HUMAN_APPROVAL)
            rationale = "Requires human approval because a matched restrictive rule overrides automatic posting (§5.5)."
        elif RuleDisposition.FLAG_WARNING in dispositions:
            governing_disposition = RuleDisposition.FLAG_WARNING
            selected = next(r for r in matching_rules if r.action.disposition == RuleDisposition.FLAG_WARNING)
            rationale = "Flagged with warning per matched policy rule."
        else:
            governing_disposition = RuleDisposition.AUTO_POST
            selected = matching_rules[0]  # Highest priority
            rationale = f"Matched rule {selected.code} with highest priority {selected.priority}."

        return MatchResult(
            matched=True,
            selected_rule=selected,
            all_matching_rules=matching_rules,
            governing_disposition=governing_disposition,
            conflict_detected=conflict_detected,
            conflict_rationale=rationale,
            reason=rationale,
        )
