"""
Transaction Classifier (n17, PRD §24, Docs 05 §5.2).
Classifies transaction intent deterministically into accounting categories
(e.g., purchase, sale, payroll, tax, depreciation) so that Rule Matcher
searches an indexed subset rather than the entire rule library.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from hesabdar.llm import LLMProvider, get_llm


@dataclass
class ClassificationResult:
    category: str
    sub_category: str
    confidence: float
    evidence: list[str] = field(default_factory=list)
    parsed_fields: dict[str, Any] = field(default_factory=dict)
    is_ambiguous: bool = False


class TransactionClassifier:
    def __init__(self, llm: Optional[LLMProvider] = None):
        self.llm = llm or get_llm()

    def classify(self, raw_tx: dict[str, Any]) -> ClassificationResult:
        """Determines category from structured inputs or freeform descriptions."""
        description = str(raw_tx.get("description", "")).lower()
        float(raw_tx.get("amount", 0))
        vendor = str(raw_tx.get("vendor", ""))
        customer = str(raw_tx.get("customer", ""))

        evidence = []
        parsed = dict(raw_tx)

        # 1. Deterministic keyword and structure matching
        if raw_tx.get("category"):
            return ClassificationResult(
                category=raw_tx["category"],
                sub_category=raw_tx.get("sub_category", "general"),
                confidence=1.0,
                evidence=["Explicit category supplied in transaction payload"],
                parsed_fields=parsed,
                is_ambiguous=False,
            )

        # Payroll patterns
        if any(w in description for w in ["salary", "payroll", "حقوق", "دستمزد", "پاداش", "wages"]):
            evidence.append("Matched payroll terms in description")
            return ClassificationResult(
                category="payroll",
                sub_category="salary",
                confidence=0.95,
                evidence=evidence,
                parsed_fields=parsed,
            )

        # Sale / Revenue patterns
        if customer or any(w in description for w in ["sale", "invoice", "فروش", "درآمد", "خدمات", "client payment"]):
            evidence.append("Matched sales/revenue keywords")
            return ClassificationResult(
                category="sale",
                sub_category="service" if "service" in description or "خدمات" in description else "goods",
                confidence=0.90,
                evidence=evidence,
                parsed_fields=parsed,
            )

        # Rent Expense
        if any(w in description for w in ["rent", "اجاره", "رهن", "lease"]):
            evidence.append("Matched rent keywords")
            return ClassificationResult(
                category="expense",
                sub_category="rent",
                confidence=0.95,
                evidence=evidence,
                parsed_fields=parsed,
            )

        # Office & Utilities Expense
        if any(w in description for w in ["office", "internet", "electricity", "water", "قبض", "اینترنت", "لوازم‌التحریر", "supplies", "subscription", "server", "cloud"]):
            evidence.append("Matched operating expense keywords")
            return ClassificationResult(
                category="expense",
                sub_category="office_supplies",
                confidence=0.90,
                evidence=evidence,
                parsed_fields=parsed,
            )

        # General expense if vendor is present
        if vendor or any(w in description for w in ["purchase", "خرید", "هزینه", "paid", "expense"]):
            evidence.append("Matched general expense keywords")
            return ClassificationResult(
                category="expense",
                sub_category="general",
                confidence=0.80,
                evidence=evidence,
                parsed_fields=parsed,
            )

        # 2. Ambiguous fallback: flag for research or LLM interpretation
        evidence.append("No deterministic classification pattern matched")
        return ClassificationResult(
            category="unclassified",
            sub_category="ambiguous",
            confidence=0.30,
            evidence=evidence,
            parsed_fields=parsed,
            is_ambiguous=True,
        )
