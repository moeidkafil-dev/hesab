"""
Accounting Domain Engine Subsystem for HESABDAR (PRD §21-§27, Docs 05).
"""
from hesabdar.accounting.rule_manager import (
    AccountingRule,
    RuleManager,
    RuleStatus,
    RuleScope,
    RuleCondition,
    RuleAction,
    RuleDisposition,
)
from hesabdar.accounting.classifier import TransactionClassifier, ClassificationResult
from hesabdar.accounting.matcher import RuleMatcher, MatchResult
from hesabdar.accounting.executor import RuleExecutor, ExecutionResult
from hesabdar.accounting.researcher import KnowledgeResearcher, CandidateRuleResult
from hesabdar.accounting.self_evaluation import AccountingSelfEvaluation, EvaluationReport
from hesabdar.accounting.engine import AccountingDomainEngine

__all__ = [
    "AccountingRule",
    "RuleManager",
    "RuleStatus",
    "RuleScope",
    "RuleCondition",
    "RuleAction",
    "RuleDisposition",
    "TransactionClassifier",
    "ClassificationResult",
    "RuleMatcher",
    "MatchResult",
    "RuleExecutor",
    "ExecutionResult",
    "KnowledgeResearcher",
    "CandidateRuleResult",
    "AccountingSelfEvaluation",
    "EvaluationReport",
    "AccountingDomainEngine",
]
