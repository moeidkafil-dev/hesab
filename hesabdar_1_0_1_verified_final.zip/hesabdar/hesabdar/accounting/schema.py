"""
Accounting Domain Schemas and Invariants (PRD §21, §46).
Standard Chart of Accounts (IFRS & Iranian Accounting Standards compliant),
Double-Entry Journal Entries, and Invariant Definitions.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class AccountCategory(str, Enum):
    ASSET = "asset"
    LIABILITY = "liability"
    EQUITY = "equity"
    REVENUE = "revenue"
    EXPENSE = "expense"


class NormalBalance(str, Enum):
    DEBIT = "debit"
    CREDIT = "credit"


@dataclass
class Account:
    id: str
    code: str
    name: str
    name_fa: str
    category: AccountCategory
    normal_balance: NormalBalance
    is_active: bool = True
    parent_code: Optional[str] = None
    balance: float = 0.0


@dataclass
class JournalEntryLine:
    id: str
    account_id: str
    account_code: str
    account_name: str
    debit: float = 0.0
    credit: float = 0.0
    description: str = ""


@dataclass
class JournalEntry:
    id: str
    transaction_date: float
    description: str
    lines: list[JournalEntryLine] = field(default_factory=list)
    reference_number: str = ""
    rule_id_applied: Optional[str] = None
    created_at: float = field(default_factory=time.time)
    verified: bool = False
    source_message_id: Optional[str] = None

    @property
    def total_debit(self) -> float:
        return round(sum(l.debit for l in self.lines), 2)

    @property
    def total_credit(self) -> float:
        return round(sum(l.credit for l in self.lines), 2)

    @property
    def is_balanced(self) -> bool:
        return self.total_debit == self.total_credit and self.total_debit > 0


# Pre-seeded standard Chart of Accounts
DEFAULT_CHART_OF_ACCOUNTS: list[Account] = [
    # 1xxx Assets
    Account("acc_1010", "1010", "Cash and Cash Equivalents", "موجودی نقد و بانک", AccountCategory.ASSET, NormalBalance.DEBIT),
    Account("acc_1020", "1020", "Petty Cash", "تنخواه‌گردان", AccountCategory.ASSET, NormalBalance.DEBIT),
    Account("acc_1100", "1100", "Accounts Receivable", "حساب‌های دریافتنی تجاری", AccountCategory.ASSET, NormalBalance.DEBIT),
    Account("acc_1200", "1200", "Merchandise Inventory", "موجودی کالا", AccountCategory.ASSET, NormalBalance.DEBIT),
    Account("acc_1300", "1300", "Prepaid Expenses", "پیش‌پرداخت‌ها", AccountCategory.ASSET, NormalBalance.DEBIT),
    Account("acc_1500", "1500", "Equipment and Machinery", "اموال، ماشین‌آلات و تجهیزات", AccountCategory.ASSET, NormalBalance.DEBIT),
    Account("acc_1510", "1510", "Accumulated Depreciation - Equipment", "استهلاک انباشته تجهیزات", AccountCategory.ASSET, NormalBalance.CREDIT),

    # 2xxx Liabilities
    Account("acc_2010", "2010", "Accounts Payable", "حساب‌های پرداختنی تجاری", AccountCategory.LIABILITY, NormalBalance.CREDIT),
    Account("acc_2020", "2020", "Salaries and Wages Payable", "حقوق و دستمزد پرداختنی", AccountCategory.LIABILITY, NormalBalance.CREDIT),
    Account("acc_2030", "2030", "VAT Taxes Payable", "مالیات بر ارزش افزوده پرداختنی", AccountCategory.LIABILITY, NormalBalance.CREDIT),
    Account("acc_2040", "2040", "Withholding Tax Payable", "مالیات تکلیفی پرداختنی", AccountCategory.LIABILITY, NormalBalance.CREDIT),
    Account("acc_2050", "2050", "Short-Term Loans Payable", "تسهیلات مالی کوتاه‌مدت", AccountCategory.LIABILITY, NormalBalance.CREDIT),

    # 3xxx Equity
    Account("acc_3010", "3010", "Shareholder Capital", "سرمایه پرداخت‌شده", AccountCategory.EQUITY, NormalBalance.CREDIT),
    Account("acc_3020", "3020", "Retained Earnings", "سود (زیان) انباشته", AccountCategory.EQUITY, NormalBalance.CREDIT),
    Account("acc_3030", "3030", "Current Year Net Income/Loss", "خلاصه سود و زیان سال جاری", AccountCategory.EQUITY, NormalBalance.CREDIT),

    # 4xxx Revenue
    Account("acc_4010", "4010", "Sales Revenue", "درآمد حاصل از فروش کالا", AccountCategory.REVENUE, NormalBalance.CREDIT),
    Account("acc_4020", "4020", "Service Revenue", "درآمد حاصل از ارائه خدمات", AccountCategory.REVENUE, NormalBalance.CREDIT),
    Account("acc_4090", "4090", "Other Income", "سایر درآمدها و هزینه‌های غیرعملیاتی", AccountCategory.REVENUE, NormalBalance.CREDIT),

    # 5xxx Expenses
    Account("acc_5010", "5010", "Cost of Goods Sold (COGS)", "بهای تمام‌شده کالای فروش‌رفته", AccountCategory.EXPENSE, NormalBalance.DEBIT),
    Account("acc_5020", "5020", "Salaries and Benefits Expense", "هزینه حقوق و مزایای پرسنل", AccountCategory.EXPENSE, NormalBalance.DEBIT),
    Account("acc_5030", "5030", "Office Rent Expense", "هزینه اجاره دفتر و انبار", AccountCategory.EXPENSE, NormalBalance.DEBIT),
    Account("acc_5040", "5040", "Utilities and Internet", "هزینه آب، برق، گاز و ارتباطات", AccountCategory.EXPENSE, NormalBalance.DEBIT),
    Account("acc_5050", "5050", "Marketing and Advertising", "هزینه تبلیغات و بازاریابی", AccountCategory.EXPENSE, NormalBalance.DEBIT),
    Account("acc_5060", "5060", "Depreciation Expense", "هزینه استهلاک", AccountCategory.EXPENSE, NormalBalance.DEBIT),
    Account("acc_5070", "5070", "Bank Fees and Interest Expense", "کارمزد و هزینه‌های مالی بانکی", AccountCategory.EXPENSE, NormalBalance.DEBIT),
    Account("acc_5080", "5080", "Software and Subscription Expense", "هزینه نرم‌افزار و اشتراک ابری", AccountCategory.EXPENSE, NormalBalance.DEBIT),
]
