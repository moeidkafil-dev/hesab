"""
حسابدار (Hesabdar) — Agentic Accounting Operating System.

This package is a direct, node-for-node implementation of the architecture
specified in حسابدار.graphml. Every subpackage/class name below is chosen to
mirror a specific node or node-group in that diagram; see MAPPING.md at the
project root for the full node-id -> code-symbol table.

Step 1 (tonight):
    hesabdar.memory      -> n4 / n5::n8   (Memory Architecture, 27 types)
    hesabdar.messaging   -> n10           (New Messages Architecture)
    hesabdar.db_manager  -> n6            (DB Manager Agent Architecture)
    hesabdar.ceo         -> n5            (CEO Agent Architecture, 11 subgroups)

Step 2 (tonight):
    hesabdar.tools       -> n3            (tools / execution sandbox)
"""

__version__ = "0.1.0-step1-2"
