"""
Authentication for the HESABDAR HTTP API.

Ported from the hesabdar_v1_core prototype and adapted to sit alongside the
multi-agent core without touching it: PBKDF2-HMAC-SHA256 password hashing
(stdlib only) + JWT session tokens (PyJWT) + role checks
(admin/accountant/viewer). Users live in their own SQLite file
(``data/users.sqlite3``) — completely separate from the accounting
production/memory databases, so nothing here can corrupt or race with the
accounting engine's schema.

Includes a simple in-memory sliding-window rate limiter on login attempts
(per email, per IP) to blunt brute-force credential guessing.

This is a real, working implementation suitable for development and small
deployments. See FINAL_STATUS.md for what a further production hardening
pass would still need (refresh-token rotation, password-policy enforcement,
persistent/distributed rate-limit storage for multi-process deployments).
"""
from __future__ import annotations

import hashlib
import hmac
import os
import sqlite3
import threading
import time
import uuid
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

import jwt

PBKDF2_ITERATIONS = 260_000
JWT_ALGORITHM = "HS256"
JWT_EXPIRY_MINUTES = 60
VALID_ROLES = ("admin", "accountant", "viewer")

DEFAULT_USERS_DB_PATH = Path(__file__).resolve().parent.parent.parent / "data" / "users.sqlite3"
DEFAULT_SECRET_FILE = Path(__file__).resolve().parent.parent.parent / "data" / "jwt_secret.key"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    email TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    password_salt TEXT NOT NULL,
    role TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    UNIQUE(email)
);
"""

# Login rate limiting: max attempts per key (email or IP) within the window.
LOGIN_RATE_LIMIT_MAX_ATTEMPTS = 5
LOGIN_RATE_LIMIT_WINDOW_SECONDS = 300  # 5 minutes


class AuthError(Exception):
    pass


class RateLimitExceeded(AuthError):
    pass


class LoginRateLimiter:
    """Thread-safe sliding-window rate limiter, in-process memory.

    Not distributed — fine for a single-process deployment; a multi-process
    deployment behind a load balancer needs a shared store (Redis, etc.)
    instead. Documented as a known limitation, not silently pretended away.
    """

    def __init__(self, max_attempts: int = LOGIN_RATE_LIMIT_MAX_ATTEMPTS,
                 window_seconds: int = LOGIN_RATE_LIMIT_WINDOW_SECONDS):
        self.max_attempts = max_attempts
        self.window_seconds = window_seconds
        self._attempts: dict[str, deque] = defaultdict(deque)
        self._lock = threading.Lock()

    def check_and_record(self, key: str) -> None:
        """Raises RateLimitExceeded if `key` has hit the limit; otherwise
        records this attempt."""
        now = time.time()
        with self._lock:
            q = self._attempts[key]
            while q and now - q[0] > self.window_seconds:
                q.popleft()
            if len(q) >= self.max_attempts:
                raise RateLimitExceeded(
                    f"too many login attempts; try again in "
                    f"{int(self.window_seconds - (now - q[0]))}s"
                )
            q.append(now)

    def reset(self, key: str) -> None:
        with self._lock:
            self._attempts.pop(key, None)


def get_or_create_secret(path: Optional[str] = None) -> str:
    """Reads a persisted random JWT secret, generating one on first run.

    Never falls back to a hardcoded default — a weak, guessable, shared
    default secret would let anyone forge admin tokens. The generated
    secret persists across restarts (so existing sessions/tokens survive a
    redeploy) but is unique per installation.
    """
    secret_path = Path(path or DEFAULT_SECRET_FILE)
    if secret_path.exists():
        return secret_path.read_text().strip()
    secret_path.parent.mkdir(parents=True, exist_ok=True)
    secret = os.urandom(32).hex()
    secret_path.write_text(secret)
    try:
        secret_path.chmod(0o600)
    except OSError:
        pass
    return secret


def connect(db_path: Optional[str] = None) -> sqlite3.Connection:
    path = db_path or str(DEFAULT_USERS_DB_PATH)
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript(_SCHEMA)
    conn.commit()
    return conn


def _hash_password(password: str, salt: bytes) -> str:
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS)
    return dk.hex()


def create_user(conn: sqlite3.Connection, email: str, password: str, role: str = "admin") -> str:
    if role not in VALID_ROLES:
        raise AuthError(f"invalid role: {role}; must be one of {VALID_ROLES}")
    if len(password) < 8:
        raise AuthError("password must be at least 8 characters")

    salt = os.urandom(16)
    password_hash = _hash_password(password, salt)
    user_id = uuid.uuid4().hex
    try:
        conn.execute(
            "INSERT INTO users (id, email, password_hash, password_salt, role, is_active, created_at) "
            "VALUES (?, ?, ?, ?, ?, 1, ?)",
            (user_id, email.lower().strip(), password_hash, salt.hex(), role,
             datetime.now(timezone.utc).isoformat()),
        )
        conn.commit()
    except sqlite3.IntegrityError as e:
        raise AuthError(f"user already exists: {email}") from e
    return user_id


def authenticate(conn: sqlite3.Connection, email: str, password: str) -> dict:
    """Returns {id, role} on success, raises AuthError on failure.
    Uses constant-time comparison to avoid timing side-channels.
    """
    row = conn.execute(
        "SELECT id, password_hash, password_salt, role, is_active FROM users WHERE email=?",
        (email.lower().strip(),),
    ).fetchone()
    if row is None or not row["is_active"]:
        raise AuthError("invalid credentials")

    salt = bytes.fromhex(row["password_salt"])
    candidate = _hash_password(password, salt)
    if not hmac.compare_digest(candidate, row["password_hash"]):
        raise AuthError("invalid credentials")
    return {"id": row["id"], "role": row["role"]}


def issue_token(user_id: str, role: str, secret: str) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": user_id,
        "role": role,
        "iat": now,
        "exp": now + timedelta(minutes=JWT_EXPIRY_MINUTES),
    }
    return jwt.encode(payload, secret, algorithm=JWT_ALGORITHM)


def verify_token(token: str, secret: str) -> dict:
    try:
        return jwt.decode(token, secret, algorithms=[JWT_ALGORITHM])
    except jwt.PyJWTError as e:
        raise AuthError(f"invalid or expired token: {e}") from e


def require_role(payload: dict, allowed_roles: tuple) -> None:
    if payload.get("role") not in allowed_roles:
        raise AuthError(f"role {payload.get('role')} is not permitted; requires one of {allowed_roles}")
