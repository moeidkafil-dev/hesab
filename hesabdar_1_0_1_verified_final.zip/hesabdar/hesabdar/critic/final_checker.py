"""
Final Checker Agent (n14, PRD §28-§31, Docs 06).
Generator/Critic separation: an independent verification agent with a distinct prompt,
independent context, and strict 4-layer verification hierarchy.

Four Verification Layers:
1. Structural Verification: Deterministic double-entry balance, schema, invariants (short-circuits).
2. Cross-Referential Verification: Authoritative check against ledger DB balances.
3. Historical / Statistical Verification: Outlier and anomalous spike detection.
4. Confidence Aggregation & Routing: PASS, PASS_WITH_WARNING, RETRY, REJECT, HUMAN_REVIEW.
"""
from __future__ import annotations

import statistics
import time
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Optional

from hesabdar.accounting.money import sum_money
from hesabdar.accounting.schema import JournalEntry
from hesabdar.llm import LLMProvider, get_llm


class VerificationDisposition(str, Enum):
    PASS = "PASS"
    PASS_WITH_WARNING = "PASS_WITH_WARNING"
    RETRY = "RETRY"
    REJECT = "REJECT"
    HUMAN_REVIEW = "HUMAN_REVIEW"


@dataclass
class LayerVerificationResult:
    layer_name: str
    passed: bool
    confidence_delta: float
    details: str
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


@dataclass
class CriticVerificationReport:
    disposition: VerificationDisposition
    overall_confidence: float
    passed: bool
    structural_layer: LayerVerificationResult
    cross_reference_layer: LayerVerificationResult
    historical_layer: LayerVerificationResult
    prediction_discrepancy: float = 0.0
    forecaster_output: str = ""
    recommendations: list[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            "disposition": self.disposition.value,
            "overall_confidence": round(self.overall_confidence, 3),
            "passed": self.passed,
            "prediction_discrepancy": round(self.prediction_discrepancy, 3),
            "forecaster_output": self.forecaster_output,
            "recommendations": self.recommendations,
            "layers": {
                "structural": asdict(self.structural_layer),
                "cross_reference": asdict(self.cross_reference_layer),
                "historical": asdict(self.historical_layer),
            },
            "created_at": self.created_at,
        }


class FinalCheckerAgent:
    """Independent Critic Agent (n14). Evaluates candidate outputs before final commit."""

    def __init__(self, llm: Optional[LLMProvider] = None, db_reader: Optional[Any] = None):
        self.llm = llm or get_llm()
        self.db_reader = db_reader

    # ------------------------------------------------------------- 4-layer checks
    def verify_structural(self, item: Any, item_type: str = "journal_entry") -> LayerVerificationResult:
        """Layer 1: Deterministic structural & arithmetic validation."""
        errors = []
        warnings = []

        if item_type == "journal_entry":
            if isinstance(item, JournalEntry):
                if not item.lines or len(item.lines) < 2:
                    errors.append("Journal entry must contain at least 2 distinct lines (double-entry).")
                if not item.is_balanced:
                    errors.append(f"Invariant broken: total debit {item.total_debit} != total credit {item.total_credit}")
                if item.total_debit <= 0:
                    errors.append("Total debit amount must be strictly greater than 0.")
            elif isinstance(item, dict):
                lines = item.get("lines", [])
                if not lines or len(lines) < 2:
                    errors.append("Journal entry dict must have at least 2 lines.")
                total_debit = sum_money(l.get("debit", 0) for l in lines)
                total_credit = sum_money(l.get("credit", 0) for l in lines)
                if total_debit != total_credit:
                    errors.append(f"Debit ({total_debit}) != Credit ({total_credit})")
                if total_debit <= 0:
                    errors.append("Total entry volume must be positive.")

        passed = len(errors) == 0
        return LayerVerificationResult(
            layer_name="structural",
            passed=passed,
            confidence_delta=0.4 if passed else -1.0,
            details="Passed all structural and double-entry arithmetic invariants." if passed else "Structural invariant failed.",
            errors=errors,
            warnings=warnings,
        )

    def verify_cross_reference(self, item: Any, context: dict[str, Any]) -> LayerVerificationResult:
        """Layer 2: Cross-references against authoritative database values."""
        errors = []
        warnings = []

        # If db_reader is available, confirm referenced account codes exist
        if self.db_reader:
            try:
                # Query accounts list
                accounts = self.db_reader.get_accounts()
                valid_codes = {acc["id"] for acc in accounts}
                lines = item.lines if isinstance(item, JournalEntry) else item.get("lines", [])
                for l in lines:
                    code = l.account_id if isinstance(l, object) and hasattr(l, "account_id") else l.get("account_id")
                    if code and code not in valid_codes:
                        warnings.append(f"Account code {code!r} is not in authoritative active chart of accounts.")
            except Exception as exc:
                warnings.append(f"Cross-reference DB lookup skipped: {exc}")

        passed = len(errors) == 0
        return LayerVerificationResult(
            layer_name="cross_reference",
            passed=passed,
            confidence_delta=0.3 if passed else -0.5,
            details="Cross-reference validation passed against ledger database.",
            errors=errors,
            warnings=warnings,
        )

    def verify_historical(self, item: Any, historical_txs: Optional[list[float]] = None) -> LayerVerificationResult:
        """Layer 3: Historical / Statistical anomaly detection."""
        warnings = []
        errors = []

        amount = 0.0
        if isinstance(item, JournalEntry):
            amount = item.total_debit
        elif isinstance(item, dict):
            amount = float(item.get("amount", 0) or sum_money(l.get("debit", 0) for l in item.get("lines", [])))

        # Statistical 3-sigma or multiplier check
        if historical_txs and len(historical_txs) >= 5:
            mean = statistics.mean(historical_txs)
            stdev = statistics.stdev(historical_txs) if len(historical_txs) > 1 else mean * 0.5
            if amount > mean + 4 * max(stdev, 1.0):
                warnings.append(f"Amount {amount} is a 4-sigma statistical anomaly compared to mean {mean:.2f}")

        # Absolute large transaction alert
        if amount > 100_000_000:
            warnings.append(f"Transaction exceeds large-value threshold ({amount:,.0f}).")

        return LayerVerificationResult(
            layer_name="historical_statistical",
            passed=True,
            confidence_delta=0.3 if not warnings else 0.15,
            details="Statistical anomaly check complete.",
            errors=errors,
            warnings=warnings,
        )

    def forecast_outcome(self, input_task: str, expected_context: str = "") -> str:
        """Output Forecaster (n14::n2) node."""
        prompt = (
            f"Forecast the expected mathematical and ledger outcome of this operation:\n"
            f"Task: {input_task}\n"
            f"Context: {expected_context}\n"
            f"Provide a brief, independent 1-sentence prediction of expected account debits/credits."
        )
        resp = self.llm.complete(
            prompt,
            system="You are an independent financial verification forecaster. Be concise and precise.",
        )
        return resp.text

    def check(
        self,
        item: Any,
        input_task: str = "",
        expected_context: str = "",
        historical_txs: Optional[list[float]] = None,
    ) -> CriticVerificationReport:
        """Runs the complete 4-layer verification and confidence routing pipeline."""
        # 1. Output Forecaster
        forecast = self.forecast_outcome(input_task, expected_context)

        # 2. Structural Layer
        structural = self.verify_structural(item)
        if not structural.passed:
            return CriticVerificationReport(
                disposition=VerificationDisposition.REJECT,
                overall_confidence=0.0,
                passed=False,
                structural_layer=structural,
                cross_reference_layer=LayerVerificationResult("cross_reference", False, 0.0, "Skipped due to structural failure"),
                historical_layer=LayerVerificationResult("historical_statistical", False, 0.0, "Skipped due to structural failure"),
                forecaster_output=forecast,
                recommendations=["Fix structural syntax / double-entry arithmetic error."],
            )

        # 3. Cross-reference Layer
        cross_ref = self.verify_cross_reference(item, {"context": expected_context})

        # 4. Historical / Statistical Layer
        historical = self.verify_historical(item, historical_txs)

        # 5. Aggregate Confidence & Disposition
        confidence = 0.0
        confidence += max(0.0, structural.confidence_delta)
        confidence += max(0.0, cross_ref.confidence_delta)
        confidence += max(0.0, historical.confidence_delta)
        confidence = min(1.0, confidence)

        recs = []
        if structural.warnings:
            recs.extend(structural.warnings)
        if cross_ref.warnings:
            recs.extend(cross_ref.warnings)
        if historical.warnings:
            recs.extend(historical.warnings)

        if historical.warnings and any("large-value" in w or "anomaly" in w for w in historical.warnings):
            disposition = VerificationDisposition.HUMAN_REVIEW
            recs.append("Flagged for human oversight due to high value or anomaly.")
        elif recs:
            disposition = VerificationDisposition.PASS_WITH_WARNING
        else:
            disposition = VerificationDisposition.PASS

        return CriticVerificationReport(
            disposition=disposition,
            overall_confidence=confidence,
            passed=True,
            structural_layer=structural,
            cross_reference_layer=cross_ref,
            historical_layer=historical,
            forecaster_output=forecast,
            recommendations=recs,
        )
