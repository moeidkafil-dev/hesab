"""
Super Log and Universal Traceability Subsystem (PRD §14-§18).
"""
from hesabdar.super_logs.manager import SuperLogEntry, SuperLogManager

__all__ = ["SuperLogEntry", "SuperLogManager"]
