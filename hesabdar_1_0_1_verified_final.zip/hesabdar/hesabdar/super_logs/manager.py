"""
Super Log Manager (PRD §14-§18).
Implements universal structured traceability across all tasks, agents,
models, skills, tools, and human review decisions with append-only
durability and rapid in-memory index queries.
"""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Optional

from hesabdar.config import LOGS_DIR


@dataclass
class SuperLogEntry:
    id: str = field(default_factory=lambda: f"log_{uuid.uuid4().hex[:12]}")
    timestamp: float = field(default_factory=time.time)
    task_id: str = ""
    subtask_id: str = ""
    agent_id: str = ""
    agent_role: str = ""
    message_id: str = ""
    correlation_id: str = ""
    model: str = ""
    prompt: Optional[str] = None
    response: Optional[str] = None
    skill: Optional[str] = None
    tool: Optional[str] = None
    input: Any = None
    output: Any = None
    prediction: Optional[str] = None
    prediction_discrepancy: float = 0.0
    resources: dict[str, Any] = field(default_factory=dict)
    latency_ms: float = 0.0
    error: Optional[str] = None
    retry_count: int = 0
    recovery_invoked: bool = False
    human_approval_required: bool = False
    human_approver: Optional[str] = None
    human_decision: Optional[str] = None  # "approved", "rejected", "modified"

    def to_dict(self) -> dict:
        return asdict(self)


class SuperLogManager:
    """Manages the append-only Super Log file and multi-key query indexing."""

    def __init__(self, log_path: Optional[Path] = None):
        self.log_path = log_path or (LOGS_DIR / "super_logs.jsonl")
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self._entries: list[SuperLogEntry] = []
        self._by_task: dict[str, list[SuperLogEntry]] = {}
        self._by_agent: dict[str, list[SuperLogEntry]] = {}
        self._by_correlation: dict[str, list[SuperLogEntry]] = {}
        self._load_existing()

    def _load_existing(self) -> None:
        if not self.log_path.exists():
            return
        try:
            with open(self.log_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    data = json.loads(line)
                    entry = SuperLogEntry(**data)
                    self._index_entry(entry)
        except Exception:
            pass

    def _index_entry(self, entry: SuperLogEntry) -> None:
        self._entries.append(entry)
        if entry.task_id:
            self._by_task.setdefault(entry.task_id, []).append(entry)
        if entry.agent_id:
            self._by_agent.setdefault(entry.agent_id, []).append(entry)
        if entry.correlation_id:
            self._by_correlation.setdefault(entry.correlation_id, []).append(entry)

    def log(self, **kwargs) -> SuperLogEntry:
        entry = SuperLogEntry(**kwargs)
        self._index_entry(entry)
        # Append to persistent JSONL
        try:
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry.to_dict(), ensure_ascii=False) + "\n")
        except Exception:
            pass
        return entry

    def query(
        self,
        task_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        correlation_id: Optional[str] = None,
        has_error: Optional[bool] = None,
        human_approval_required: Optional[bool] = None,
        limit: int = 100,
    ) -> list[SuperLogEntry]:
        candidates: list[SuperLogEntry] = []
        if task_id and task_id in self._by_task:
            candidates = self._by_task[task_id]
        elif agent_id and agent_id in self._by_agent:
            candidates = self._by_agent[agent_id]
        elif correlation_id and correlation_id in self._by_correlation:
            candidates = self._by_correlation[correlation_id]
        else:
            candidates = list(self._entries)

        filtered = []
        for e in reversed(candidates):
            if has_error is not None:
                if has_error and not e.error:
                    continue
                if not has_error and e.error:
                    continue
            if human_approval_required is not None:
                if e.human_approval_required != human_approval_required:
                    continue
            filtered.append(e)
            if len(filtered) >= limit:
                break
        return filtered

    def get_recent(self, count: int = 50) -> list[SuperLogEntry]:
        return list(reversed(self._entries[-count:]))
