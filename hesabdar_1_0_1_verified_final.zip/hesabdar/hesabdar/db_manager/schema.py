"""
Production database (n12::n8 / n7::n8) - written to *only* through
DBManagerAgent (S9.2: "sole authorized writer to the production database").
Minimal double-entry-friendly accounting schema; extend per the Accounting
Domain Engine's needs as step 3+ is built.

Repair note (PRD S8 / S10): `debit`/`credit` are stored as TEXT holding a
canonical decimal string ("12.50"), never SQLite REAL - REAL is IEEE-754
binary floating point and is not a safe representation for authoritative
money values. `idempotency_key` is UNIQUE so a retried financial request
with the same key can never create a second authoritative transaction.
"""
SCHEMA = """
CREATE TABLE IF NOT EXISTS accounts (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    account_type TEXT NOT NULL,   -- asset / liability / equity / revenue / expense
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    description TEXT,
    created_at REAL NOT NULL,
    source_message_id TEXT,       -- traces back to the signed Message that caused this write
    idempotency_key TEXT UNIQUE   -- NULL-safe: SQLite allows multiple NULLs in a UNIQUE column
);

CREATE TABLE IF NOT EXISTS transaction_lines (
    id TEXT PRIMARY KEY,
    transaction_id TEXT NOT NULL REFERENCES transactions(id),
    account_id TEXT NOT NULL REFERENCES accounts(id),
    debit TEXT NOT NULL DEFAULT '0.00',   -- canonical decimal string, not REAL
    credit TEXT NOT NULL DEFAULT '0.00'   -- canonical decimal string, not REAL
);
CREATE INDEX IF NOT EXISTS idx_txn_lines_txn ON transaction_lines(transaction_id);
CREATE INDEX IF NOT EXISTS idx_txn_lines_account ON transaction_lines(account_id);

CREATE TABLE IF NOT EXISTS db_operation_log (
    id TEXT PRIMARY KEY,
    op TEXT NOT NULL,
    ok INTEGER NOT NULL,
    detail TEXT,
    created_at REAL NOT NULL
);
"""
