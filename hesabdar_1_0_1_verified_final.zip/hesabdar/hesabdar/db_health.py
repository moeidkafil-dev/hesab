"""
Shared SQLite lifecycle helpers used by every component that owns a
SQLite database (hesabdar.memory.store.MemoryStore,
hesabdar.db_manager.agent.DBManagerAgent).

Repairs the defect documented in the PRD ("database disk image is
malformed"): a component must never silently open and trust whatever
bytes happen to be sitting at its db_path. Every connection goes
through `connect_with_recovery`, which:

  1. runs `PRAGMA integrity_check` before the database is trusted;
  2. if the file is malformed, never uses it and never deletes it —
     it is moved into a timestamped quarantine directory so the
     corrupted bytes remain available for forensics/audit;
  3. reinitializes a fresh, schema-valid database in its place.

`doctor()` is the read-only counterpart, used by the CLI's health
check and by tests, and never mutates anything on disk.
"""
from __future__ import annotations

import shutil
import sqlite3
import time
from pathlib import Path
from typing import Union


class DatabaseCorruptionError(Exception):
    """Raised when a database fails PRAGMA integrity_check and cannot
    be safely auto-recovered by the caller's chosen policy."""


def check_integrity(conn: sqlite3.Connection) -> tuple[bool, str]:
    """Runs PRAGMA integrity_check on an already-open connection."""
    try:
        rows = conn.execute("PRAGMA integrity_check").fetchall()
    except sqlite3.DatabaseError as exc:
        return False, str(exc)
    ok = len(rows) == 1 and str(rows[0][0]).lower() == "ok"
    detail = "ok" if ok else "; ".join(str(r[0]) for r in rows)
    return ok, detail


def _quarantine(db_path: Path, quarantine_dir: Union[str, Path, None]) -> Path:
    qdir = Path(quarantine_dir) if quarantine_dir else db_path.parent / "quarantine"
    qdir.mkdir(parents=True, exist_ok=True)
    stamp = int(time.time() * 1000)
    target = qdir / f"{db_path.name}.corrupt.{stamp}"
    shutil.move(str(db_path), str(target))
    # Best-effort: WAL/SHM sidecars, if present, travel with the corrupt file.
    for suffix in ("-wal", "-shm"):
        side = Path(str(db_path) + suffix)
        if side.exists():
            shutil.move(str(side), str(qdir / f"{side.name}.corrupt.{stamp}"))
    return target


def connect_with_recovery(
    db_path: Union[str, Path],
    schema: str,
    quarantine_dir: Union[str, Path, None] = None,
) -> sqlite3.Connection:
    """
    Opens db_path, verifying integrity first. A malformed existing file
    is quarantined (never silently used, never destroyed) and replaced
    with a freshly initialized database. Always returns a connection to
    a database that has just passed `PRAGMA integrity_check` and has
    `schema` applied.
    """
    db_path = Path(db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)

    def _open_raw() -> sqlite3.Connection:
        conn = sqlite3.connect(str(db_path), check_same_thread=False, timeout=30.0)
        conn.row_factory = sqlite3.Row
        return conn

    def _apply_pragmas(conn: sqlite3.Connection) -> None:
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA journal_mode = WAL")

    if db_path.exists() and db_path.stat().st_size > 0:
        is_corrupt = False
        conn = None
        try:
            conn = _open_raw()
            ok, _ = check_integrity(conn)
            if not ok:
                is_corrupt = True
        except sqlite3.DatabaseError:
            is_corrupt = True

        if is_corrupt:
            if conn:
                try:
                    conn.close()
                except Exception:
                    pass
            _quarantine(db_path, quarantine_dir)
            conn = _open_raw()
    else:
        conn = _open_raw()

    _apply_pragmas(conn)
    conn.executescript(schema)
    conn.commit()
    return conn


def doctor(db_path: Union[str, Path]) -> dict:
    """Read-only health check. Never mutates the file on disk."""
    db_path = Path(db_path)
    if not db_path.exists():
        return {"path": str(db_path), "exists": False, "ok": True, "detail": "not yet created"}
    if db_path.stat().st_size == 0:
        return {"path": str(db_path), "exists": True, "ok": True, "detail": "empty file"}
    try:
        conn = sqlite3.connect(str(db_path), check_same_thread=False, timeout=10.0)
        ok, detail = check_integrity(conn)
        conn.close()
        return {"path": str(db_path), "exists": True, "ok": ok, "detail": detail}
    except sqlite3.DatabaseError as exc:
        return {"path": str(db_path), "exists": True, "ok": False, "detail": str(exc)}
