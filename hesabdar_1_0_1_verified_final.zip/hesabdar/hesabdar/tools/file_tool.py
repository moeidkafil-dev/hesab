"""
n14::n0::n15-n18 "file maker / file reader / file deleter / file
changer/runner". §9.1: `file deleter` "can destroy data" — every path is
resolved and confined under sandbox_root so a directory-traversal payload
in an argument can't reach outside the intended working area, regardless
of what the (already ToolManager-authorized) caller passes in.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional


class SandboxViolation(Exception):
    pass


class FileTool:
    def __init__(self, sandbox_root: Optional[str] = None):
        self.sandbox_root = Path(sandbox_root or Path.cwd()).resolve()
        self.sandbox_root.mkdir(parents=True, exist_ok=True)

    def _resolve(self, relative_path: str) -> Path:
        candidate = (self.sandbox_root / relative_path).resolve()
        if self.sandbox_root not in candidate.parents and candidate != self.sandbox_root:
            raise SandboxViolation(f"{relative_path!r} resolves outside sandbox root {self.sandbox_root}")
        return candidate

    def file_maker(self, path: str, content: str = "") -> str:
        p = self._resolve(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return str(p)

    def file_reader(self, path: str) -> str:
        return self._resolve(path).read_text(encoding="utf-8")

    def file_deleter(self, path: str) -> bool:
        p = self._resolve(path)
        if p.exists():
            p.unlink()
            return True
        return False

    def file_changer_runner(self, path: str, content: str) -> str:
        """'format\\nname\\n.\\n.\\n.' per the node's description — reformats
        (overwrites) an existing file's content; distinct from file_maker
        in that it requires the file to already exist."""
        p = self._resolve(path)
        if not p.exists():
            raise FileNotFoundError(f"{path} does not exist; use file_maker to create it")
        p.write_text(content, encoding="utf-8")
        return str(p)
