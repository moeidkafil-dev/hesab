"""
n14::n0::n9-n13 "chrome researcher / page html exporter / chrome reader /
api user / curl system". Diagram note: "with curl or wget" - implemented
here as a plain HTTP fetch (urllib, no extra dependency), which is exactly
what curl/wget do at the protocol level. `chrome_researcher`/`chrome_reader`
are named for a real headless-browser backend (e.g. Selenium/Playwright)
on a machine that has one installed; here they degrade to the same HTTP
fetch, clearly labeled, since this sandbox has no browser - swap the
implementation in `chrome_researcher` for a Playwright call on your own
machine if you need JS-rendered pages.

Repair note (PRD S38 acceptance criteria, "network tools cannot SSRF
internal resources"): every fetch goes through `_guard_url`, which
rejects non-http(s) schemes (this blocks the file:// local-file-read
trick urllib otherwise allows) and resolves the hostname to reject
loopback, link-local, private, and other non-global addresses before
any request is made.
"""
from __future__ import annotations

import ipaddress
import json
import socket
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Optional


class SSRFBlocked(Exception):
    pass


@dataclass
class HttpResult:
    status: int
    text: str
    headers: dict


def _guard_url(url: str) -> None:
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise SSRFBlocked(f"scheme {parsed.scheme!r} is not permitted (only http/https)")
    hostname = parsed.hostname
    if not hostname:
        raise SSRFBlocked("URL has no hostname")
    try:
        addrinfo = socket.getaddrinfo(hostname, None)
    except socket.gaierror as exc:
        raise SSRFBlocked(f"could not resolve host {hostname!r}: {exc}") from exc
    for family, _type, _proto, _canon, sockaddr in addrinfo:
        ip = ipaddress.ip_address(sockaddr[0])
        if (
            ip.is_private
            or ip.is_loopback
            or ip.is_link_local
            or ip.is_multicast
            or ip.is_reserved
            or ip.is_unspecified
        ):
            raise SSRFBlocked(f"{hostname!r} resolves to non-public address {ip} - blocked")


class WebTool:
    def _fetch(self, url: str, headers: Optional[dict] = None, method: str = "GET",
               data: Optional[bytes] = None, timeout: int = 20) -> HttpResult:
        _guard_url(url)
        req = urllib.request.Request(url, headers=headers or {}, method=method, data=data)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                body = resp.read().decode("utf-8", errors="replace")
                return HttpResult(resp.status, body, dict(resp.headers))
        except urllib.error.HTTPError as exc:
            return HttpResult(exc.code, exc.read().decode("utf-8", errors="replace"), dict(exc.headers or {}))

    def curl_system(self, url: str, headers: Optional[dict] = None, method: str = "GET",
                     data: Optional[bytes] = None) -> HttpResult:
        return self._fetch(url, headers=headers, method=method, data=data)

    def page_html_exporter(self, url: str) -> str:
        return self.curl_system(url).text

    def chrome_researcher(self, url: str) -> str:
        """Degrades to curl_system in this environment; see module docstring."""
        return self.page_html_exporter(url)

    def chrome_reader(self, html: str, selector_hint: str = "") -> str:
        """Extremely small, dependency-free text-from-HTML fallback (strips
        tags). For real selector-based extraction, parse `html` with
        BeautifulSoup/lxml on your own machine - kept dependency-free here."""
        import re
        text = re.sub(r"<[^>]+>", " ", html)
        return re.sub(r"\s+", " ", text).strip()

    def api_user(self, url: str, api_key: Optional[str] = None, method: str = "GET",
                 json_body: Optional[dict] = None) -> HttpResult:
        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        data = json.dumps(json_body).encode("utf-8") if json_body is not None else None
        return self._fetch(url, headers=headers, method=method, data=data)
