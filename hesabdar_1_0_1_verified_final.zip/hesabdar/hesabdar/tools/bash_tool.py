"""
n14::n0::n6-n8 "bash command maker -> bash compiler -> bash runner".
docs example: bash compiler applies `chmod +x "file_name"`, bash runner
executes `./"file_name"`. Only ever invoked through ToolManager, which is
where authorization is enforced — this module has no policy logic of its
own on purpose (§9.1: one chokepoint, not eighteen).
"""
from __future__ import annotations

import shlex
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

DEFAULT_TIMEOUT_SECONDS = 30


@dataclass
class BashResult:
    returncode: int
    stdout: str
    stderr: str


class BashTool:
    def __init__(self, sandbox_root: Optional[str] = None):
        self.sandbox_root = Path(sandbox_root) if sandbox_root else Path.cwd()

    def bash_command_maker(self, command: str) -> str:
        return command

    def bash_compiler(self, command: str, make_executable: Optional[str] = None) -> list[str]:
        if make_executable:
            subprocess.run(["chmod", "+x", make_executable], check=True, cwd=self.sandbox_root)
        return shlex.split(command)

    def bash_runner(self, argv: list[str], timeout: int = DEFAULT_TIMEOUT_SECONDS) -> BashResult:
        proc = subprocess.run(argv, cwd=self.sandbox_root, capture_output=True,
                               text=True, timeout=timeout)
        return BashResult(proc.returncode, proc.stdout, proc.stderr)

    def run(self, command: str, make_executable: Optional[str] = None,
            timeout: int = DEFAULT_TIMEOUT_SECONDS) -> BashResult:
        made = self.bash_command_maker(command)
        argv = self.bash_compiler(made, make_executable=make_executable)
        return self.bash_runner(argv, timeout=timeout)
