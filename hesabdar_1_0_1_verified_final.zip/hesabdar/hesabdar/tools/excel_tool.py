"""
n14::n0::n0-n5 "excel command maker / excel vbs maker / file injector /
excel file reader / excel file writer / excel file maker".
Supports openpyxl when installed, with seamless CSV/TSV table fallback.
"""
from __future__ import annotations

import csv
from typing import Any, Optional

from hesabdar.tools.file_tool import FileTool

try:
    import openpyxl
    _HAS_OPENPYXL = True
except ImportError:
    _HAS_OPENPYXL = False


class ExcelTool:
    def __init__(self, sandbox_root: Optional[str] = None):
        self.file_tool = FileTool(sandbox_root=sandbox_root)

    def excel_command_maker(self, instruction: str) -> str:
        return f"EXCEL_OP: {instruction}"

    def excel_vbs_maker(self, macro_body: str, sub_name: str = "HesabdarMacro") -> str:
        return f"Sub {sub_name}()\n{macro_body}\nEnd Sub\n"

    def file_injector(self, path: str, script_text: str) -> str:
        return self.file_tool.file_maker(path, script_text)

    def excel_file_maker(self, path: str, headers: Optional[list[str]] = None) -> str:
        resolved = self.file_tool._resolve(path)
        resolved.parent.mkdir(parents=True, exist_ok=True)
        if _HAS_OPENPYXL and resolved.suffix in {".xlsx", ".xlsm"}:
            wb = openpyxl.Workbook()
            ws = wb.active
            if headers:
                ws.append(headers)
            wb.save(resolved)
        else:
            with open(resolved, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                if headers:
                    writer.writerow(headers)
        return str(resolved)

    def excel_file_reader(self, path: str, sheet: Optional[str] = None) -> list[list[Any]]:
        resolved = self.file_tool._resolve(path)
        if not resolved.exists():
            raise FileNotFoundError(f"File not found: {path}")
        if _HAS_OPENPYXL and resolved.suffix in {".xlsx", ".xlsm"}:
            wb = openpyxl.load_workbook(resolved, data_only=True)
            ws = wb[sheet] if sheet and sheet in wb.sheetnames else wb.active
            return [list(row) for row in ws.iter_rows(values_only=True)]
        else:
            with open(resolved, "r", newline="", encoding="utf-8") as f:
                reader = csv.reader(f)
                return [list(row) for row in reader]

    def excel_file_writer(
        self,
        path: str,
        rows: list[list[Any]],
        sheet: Optional[str] = None,
        append: bool = True,
    ) -> str:
        resolved = self.file_tool._resolve(path)
        resolved.parent.mkdir(parents=True, exist_ok=True)
        if _HAS_OPENPYXL and resolved.suffix in {".xlsx", ".xlsm"}:
            if resolved.exists():
                wb = openpyxl.load_workbook(resolved)
                ws = wb[sheet] if sheet and sheet in wb.sheetnames else wb.active
                if not append:
                    ws.delete_rows(1, ws.max_row)
            else:
                wb = openpyxl.Workbook()
                ws = wb.active
                if sheet:
                    ws.title = sheet
            for row in rows:
                ws.append(row)
            wb.save(resolved)
        else:
            mode = "a" if append and resolved.exists() else "w"
            with open(resolved, mode, newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                for row in rows:
                    writer.writerow(row)
        return str(resolved)
