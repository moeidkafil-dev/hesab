"""
HTTP entrypoint for HESABDAR (PRD-compatible with the bundled React frontend,
which calls ``POST /api/{endpoint}`` with a JSON body — see
``src/services/api.ts``).

This module is new: it does not modify ``hesabdar/api_server.py`` (the
already-tested in-process dispatcher) or any engine code. It only adds:
  - a real Flask HTTP layer
  - JWT-based auth (``hesabdar/auth/auth.py``) in front of that dispatcher

Endpoints:
  POST /auth/register   { email, password, role? }        -> { user_id }
  POST /auth/login      { email, password }                -> { token, role }
                          Rate-limited: 5 attempts per (email, IP) per 5
                          minutes -> 429 once exceeded.
  POST /api/<endpoint>   Authorization: Bearer <jwt>         -> forwarded to
                          HesabdarAPI.handle(endpoint, payload)
  GET  /healthz          -> { ok: true }   (no auth; for load balancers)

Role gating: "viewer" may call read-only endpoints only (status,
list_accounts, list_transactions, get_account_ledger, list_rules,
list_skills, list_agents, list_logs, list_approvals, generate_report,
list_backups). Everything else (posting transactions, executing tasks,
creating rules, approve/reject, backup/restore, self-healing, benchmark,
seeding data) requires "accountant" or "admin".
"""
from __future__ import annotations

import os

from flask import Flask, jsonify, request

from hesabdar.api_server import HesabdarAPI
from hesabdar.auth import auth as authmod

READ_ONLY_ENDPOINTS = {
    "status",
    "list_accounts",
    "list_transactions",
    "get_account_ledger",
    "list_rules",
    "list_skills",
    "list_agents",
    "list_logs",
    "list_approvals",
    "generate_report",
    "list_backups",
}


def create_app(secret: str | None = None, users_db_path: str | None = None,
               secret_file: str | None = None) -> Flask:
    app = Flask(__name__)
    # Never falls back to a hardcoded default secret: if none is passed and
    # none is set via HESABDAR_JWT_SECRET, a random one is generated and
    # persisted to disk on first run (see auth.get_or_create_secret).
    app.config["HESABDAR_JWT_SECRET"] = (
        secret
        or os.environ.get("HESABDAR_JWT_SECRET")
        or authmod.get_or_create_secret(secret_file)
    )

    auth_conn = authmod.connect(users_db_path)
    login_limiter = authmod.LoginRateLimiter()
    api = HesabdarAPI()

    def _current_secret() -> str:
        return app.config["HESABDAR_JWT_SECRET"]

    @app.get("/healthz")
    def healthz():
        return jsonify({"ok": True})

    @app.post("/auth/register")
    def register():
        # Public registration must never allow privilege escalation. It is
        # disabled by default; when explicitly enabled, every public signup
        # is a viewer. Admin/accountant accounts must be provisioned by an
        # already-authenticated administrator or through the deployment's
        # bootstrap process.
        if os.environ.get("HESABDAR_ALLOW_PUBLIC_REGISTRATION", "0").lower() not in {"1", "true", "yes"}:
            return jsonify({"ok": False, "error": "public registration is disabled"}), 403
        body = request.get_json(force=True, silent=True) or {}
        email = body.get("email", "")
        password = body.get("password", "")
        role = "viewer"
        try:
            user_id = authmod.create_user(auth_conn, email, password, role=role)
        except authmod.AuthError as e:
            return jsonify({"ok": False, "error": str(e)}), 400
        return jsonify({"ok": True, "user_id": user_id}), 201

    @app.post("/auth/login")
    def login():
        body = request.get_json(force=True, silent=True) or {}
        email = body.get("email", "")
        password = body.get("password", "")

        rate_key = f"{email.lower().strip()}:{request.remote_addr or 'unknown'}"
        try:
            login_limiter.check_and_record(rate_key)
        except authmod.RateLimitExceeded as e:
            return jsonify({"ok": False, "error": str(e)}), 429

        try:
            user = authmod.authenticate(auth_conn, email, password)
        except authmod.AuthError as e:
            return jsonify({"ok": False, "error": str(e)}), 401
        login_limiter.reset(rate_key)
        token = authmod.issue_token(user["id"], user["role"], _current_secret())
        return jsonify({"ok": True, "token": token, "role": user["role"]})

    @app.post("/auth/users")
    def create_user_admin():
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return jsonify({"ok": False, "error": "missing bearer token"}), 401
        try:
            claims = authmod.verify_token(auth_header[len("Bearer "):], _current_secret())
            authmod.require_role(claims, ("admin",))
        except authmod.AuthError as e:
            return jsonify({"ok": False, "error": str(e)}), 403
        body = request.get_json(force=True, silent=True) or {}
        try:
            user_id = authmod.create_user(
                auth_conn,
                body.get("email", ""),
                body.get("password", ""),
                role=body.get("role", "viewer"),
            )
        except authmod.AuthError as e:
            return jsonify({"ok": False, "error": str(e)}), 400
        return jsonify({"ok": True, "user_id": user_id}), 201

    @app.post("/api/<endpoint>")
    def api_dispatch(endpoint: str):
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return jsonify({"ok": False, "error": "missing bearer token"}), 401
        token = auth_header[len("Bearer "):]
        try:
            claims = authmod.verify_token(token, _current_secret())
        except authmod.AuthError as e:
            return jsonify({"ok": False, "error": str(e)}), 401

        admin_only = {"restore_backup", "trigger_self_healing", "seed_sample_data"}
        if endpoint not in READ_ONLY_ENDPOINTS:
            try:
                authmod.require_role(claims, ("admin",) if endpoint in admin_only else ("admin", "accountant"))
            except authmod.AuthError as e:
                return jsonify({"ok": False, "error": str(e)}), 403

        payload = request.get_json(force=True, silent=True) or {}
        result = api.handle(endpoint, payload)
        status = 200 if result.get("ok", True) else 400
        return jsonify(result), status

    return app


def main():
    app = create_app()
    port = int(os.environ.get("PORT", "8000"))
    app.run(host="0.0.0.0", port=port)


if __name__ == "__main__":
    main()
