"""
n5::n3 "agent killer": agent killer -> saving agents rule -> summary maker.
An agent is never simply discarded: a summary of its accumulated state is
captured first, feeding Experience/Reflection Memory (§3.3, §4.2).
"""
from __future__ import annotations

from hesabdar.ceo.new_agent_manager import NewAgentManager, ProvisionedAgent
from hesabdar.llm import LLMProvider, get_llm
from hesabdar.memory.memory_manager import MemoryManager
from hesabdar.memory.taxonomy import MemoryType


class AgentKiller:
    def __init__(self, agent_manager: NewAgentManager, ceo_memory: MemoryManager, llm: LLMProvider | None = None):
        self.agent_manager = agent_manager
        self.ceo_memory = ceo_memory
        self.llm = llm or get_llm()

    def agent_killer(self, agent_id: str) -> ProvisionedAgent:
        agent = self.agent_manager.get(agent_id)
        if agent is None:
            raise ValueError(f"unknown agent {agent_id}")
        return agent

    def saving_agents_rule(self, agent: ProvisionedAgent) -> None:
        self.ceo_memory.remember(
            {"agent_id": agent.agent_id, "rules": agent.rules, "relationships": agent.relationships},
            hint_type=MemoryType.PROCEDURAL,
        )

    def summary_maker(self, agent: ProvisionedAgent, session_notes: str = "") -> str:
        prompt = (f"Summarize this agent's lifecycle for institutional memory.\n"
                  f"agent_id={agent.agent_id}\nrules={agent.rules}\nnotes={session_notes}")
        try:
            summary = self.llm.complete(prompt, system="You write terse, factual agent post-mortems.").text
        except ConnectionError:
            summary = f"[llm unavailable] agent {agent.agent_id} terminated; rules preserved; notes={session_notes}"
        self.ceo_memory.remember({"agent_id": agent.agent_id, "summary": summary},
                                  hint_type=MemoryType.EXPERIENCE)
        return summary

    def terminate(self, agent_id: str, session_notes: str = "") -> str:
        agent = self.agent_killer(agent_id)
        self.saving_agents_rule(agent)
        summary = self.summary_maker(agent, session_notes)
        del self.agent_manager._agents[agent_id]
        return summary
