"""
n5::n9 "agent builder": agent builder -> teacher of agent from memory ->
agent configurer -> agent runner -> agent registerer.

`teacher of agent from memory` is architecturally significant (§4.2): new
agents are seeded with relevant accumulated memory rather than instantiated
from a static template alone, letting institutional knowledge survive
Agent Killer recycling (§4.2, §3.3).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from hesabdar.ceo.new_agent_manager import NewAgentManager, ProvisionedAgent
from hesabdar.memory.memory_manager import MemoryManager
from hesabdar.memory.taxonomy import MemoryType


@dataclass
class AgentBlueprint:
    agent_id: str
    role: str
    seeded_memory: list[dict]


class AgentBuilder:
    def __init__(self, agent_manager: NewAgentManager, ceo_memory: MemoryManager):
        self.agent_manager = agent_manager
        self.ceo_memory = ceo_memory

    def agent_builder(self, agent_id: str, role: str) -> AgentBlueprint:
        return AgentBlueprint(agent_id=agent_id, role=role, seeded_memory=[])

    def teacher_of_agent_from_memory(self, blueprint: AgentBlueprint) -> AgentBlueprint:
        relevant = [
            {"memory_type": e.memory_type.value, "content": e.content}
            for e in self.ceo_memory.store.read("ceo", memory_type=MemoryType.PROCEDURAL, limit=20)
            if isinstance(e.content, dict) and e.content.get("agent_id") == blueprint.agent_id
        ]
        blueprint.seeded_memory = relevant
        return blueprint

    def agent_configer(self, blueprint: AgentBlueprint, related_to: Optional[list[str]] = None) -> dict:
        return {"agent_id": blueprint.agent_id, "role": blueprint.role,
                "related_to": related_to or [], "seeded_memory_count": len(blueprint.seeded_memory)}

    def agent_runner(self, config: dict) -> ProvisionedAgent:
        return self.agent_manager.provision(config["agent_id"], config["role"], related_to=config["related_to"])

    def agent_registerer(self, agent: ProvisionedAgent) -> str:
        return agent.agent_id  # already registered in the identity registry by NewAgentManager.provision

    def build(self, agent_id: str, role: str, related_to: Optional[list[str]] = None) -> ProvisionedAgent:
        blueprint = self.teacher_of_agent_from_memory(self.agent_builder(agent_id, role))
        config = self.agent_configer(blueprint, related_to=related_to)
        agent = self.agent_runner(config)
        self.agent_registerer(agent)
        return agent
