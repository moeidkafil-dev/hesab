"""
n5::n7 "Resource Distributor": log reader -> log analyser -> hidden memory
-> agents information -> agents log -> llm -> planner -> schedule ->
plan checker -> hidden memory -> tool manager -> tool executor.

Enforcement point for §4.5's two trade-off rules:
  1. operational telemetry is elastic; financial/decision telemetry is not
  2. deterministic paths are preferred to probabilistic ones when both are available
"""
from __future__ import annotations

from dataclasses import dataclass

from hesabdar.config import RESOURCES, ResourceConfig


@dataclass
class AllocationDecision:
    agent_id: str
    granted: bool
    reason: str


class ResourceDistributor:
    def __init__(self, cfg: ResourceConfig = RESOURCES):
        self.cfg = cfg
        self._active_agents: set[str] = set()

    def log_reader(self, logs: list[dict]) -> list[dict]:
        return logs

    def log_analyser(self, logs: list[dict]) -> dict:
        load = sum(1 for l in logs if l.get("level") in ("warn", "error"))
        return {"load_signal": load}

    def agents_information(self) -> dict:
        return {"active": sorted(self._active_agents), "count": len(self._active_agents)}

    def request_allocation(self, agent_id: str, is_financial: bool = False) -> AllocationDecision:
        """§4.5 rule 1: financial/decision-critical requests are never
        denied for resource reasons; only elastic (operational) requests
        are subject to the concurrency cap."""
        if is_financial:
            self._active_agents.add(agent_id)
            return AllocationDecision(agent_id, True, "financial/decision-critical: always granted")
        if len(self._active_agents) >= self.cfg.max_concurrent_agents:
            return AllocationDecision(agent_id, False, "at max_concurrent_agents; operational request deferred")
        self._active_agents.add(agent_id)
        return AllocationDecision(agent_id, True, "granted within concurrency budget")

    def release(self, agent_id: str) -> None:
        self._active_agents.discard(agent_id)

    def suppress_telemetry_if_needed(self, logs: list[dict]) -> list[dict]:
        """Under load, may drop performance-only entries; never drops
        entries the caller marks financial=True (§4.5 rule 1)."""
        analysis = self.log_analyser(logs)
        if analysis["load_signal"] < 5:
            return logs
        return [l for l in logs if l.get("financial") or l.get("level") in ("warn", "error", "critical")]

    def prefer_deterministic(self) -> bool:
        return self.cfg.prefer_deterministic
