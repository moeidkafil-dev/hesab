"""
n5::n4 "memory manager" (CEO-scoped) — a CEO-local instance of the
write/maintenance pattern from hesabdar.memory.MemoryManager, paired here
with a dedicated `planner system` and `schedule system`, reflecting that the
CEO's memory concerns are inseparable from its planning concerns (§4.2).
"""
from __future__ import annotations

from dataclasses import dataclass

from hesabdar.memory.memory_manager import MemoryManager
from hesabdar.memory.taxonomy import MemoryType


@dataclass
class PlannedMaintenance:
    task: str
    due_in_seconds: float


class CEOMemoryManager(MemoryManager):
    """Same write/maintenance pipelines as the general MemoryManager,
    always bound to scope='ceo', plus the two extra nodes this group adds."""

    def __init__(self, **kwargs):
        super().__init__(scope="ceo", **kwargs)

    def planner_system(self, goal: str) -> PlannedMaintenance:
        """n5::n4's planner system: decides *when* the next consolidation
        pass should run, given current write volume."""
        recent = self.store.read(self.scope, limit=200)
        due_in = 7200.0 if len(recent) < 50 else 1800.0  # busier scope -> sooner sweep
        return PlannedMaintenance(task=goal, due_in_seconds=due_in)

    def schedule_system(self, plan: PlannedMaintenance) -> dict:
        """n5::n4's schedule system: records the plan as a Planning Memory
        entry so InputOutputManager/CEOAgentCore loops can check it."""
        entry = self.remember({"task": plan.task, "due_in_seconds": plan.due_in_seconds},
                               hint_type=MemoryType.PLANNING)
        return {"scheduled": entry.id if entry else None, "due_in_seconds": plan.due_in_seconds}
