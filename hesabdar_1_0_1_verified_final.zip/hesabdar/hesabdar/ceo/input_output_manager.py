"""
n5::n10 "input / output manager" — the system's checkpointing mechanism,
per §4.3. Deliberately *not* a general state machine; a bounded-retry loop:

    input receiver -> input compiler -> input analyser -> output forecaster
    -> output checker -> decision system -> counter
                                              |
                       (retry) -----> input analyser
                       (exhausted / success) -> result / log

§4.3's system-wide invariant: the database is authoritative whenever the
checkpoint counter, logs, memory, and DB disagree. This class only owns the
counter/loop; callers are responsible for actually consulting the DB as the
tie-breaker.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Optional

from hesabdar.config import RESOURCES, ResourceConfig


@dataclass
class CheckpointResult:
    ok: bool
    attempts: int
    result: Any
    log: str


class InputOutputManager:
    def __init__(self, cfg: ResourceConfig = RESOURCES):
        self.cfg = cfg

    def input_reciver(self, raw_input: Any) -> Any:
        return raw_input

    def input_compiler(self, raw_input: Any) -> dict:
        return {"input": raw_input}

    def input_analyser(self, compiled: dict) -> dict:
        return compiled

    def output_forecaster(self, compiled: dict, expected_shape: Optional[dict] = None) -> dict:
        """Predicts the expected result shape ahead of execution (§4.4:
        generator/critic pattern applied at the level of I/O itself)."""
        return expected_shape or {}

    def output_checker(self, actual: Any, forecast: dict) -> bool:
        if not forecast:
            return True
        if isinstance(actual, dict):
            return all(k in actual for k in forecast)
        return True

    def decision_system(self, success: bool) -> str:
        return "success" if success else "retry"

    def counter(self, attempts: int) -> bool:
        """Returns True if another retry is allowed."""
        return attempts < self.cfg.max_io_retries

    def run(self, raw_input: Any, action: Callable[[Any], Any], expected_shape: Optional[dict] = None) -> CheckpointResult:
        compiled = self.input_compiler(self.input_reciver(raw_input))
        analysed = self.input_analyser(compiled)
        forecast = self.output_forecaster(analysed, expected_shape)

        attempts = 0
        last_result = None
        while True:
            attempts += 1
            try:
                last_result = action(analysed["input"])
                success = self.output_checker(last_result, forecast)
            except Exception as exc:  # noqa: BLE001 - captured into the checkpoint log, not raised
                last_result = str(exc)
                success = False

            decision = self.decision_system(success)
            if decision == "success":
                return CheckpointResult(True, attempts, last_result, "success")
            if not self.counter(attempts):
                return CheckpointResult(False, attempts, last_result, "retries exhausted")
            analysed = self.input_analyser(compiled)  # loop back per the diagram's retry edge
