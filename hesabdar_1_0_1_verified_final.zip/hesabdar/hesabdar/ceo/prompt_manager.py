"""
n5::n1 "prompt manager": input receiver -> input compiler -> input analyser
-> policy checker -> prompt reader -> prompt analyser -> decision system for
choosing best agents.

§4.2: `policy checker` sits *before* agent selection, not after — intent is
validated against policy prior to any agent being invoked.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


class PolicyViolation(Exception):
    pass


@dataclass
class AgentSelection:
    chosen_agents: list[str]
    reasoning: str


# A minimal, extensible policy surface. Real accounting-specific policy
# (statutory thresholds, chart-of-accounts conformance) belongs in the
# Accounting Domain Engine (§5) — this is the request-intake-level check
# the diagram places ahead of it.
DENY_PATTERNS = ("drop table", "rm -rf /", "delete all", "پاک کن همه")


class PromptManager:
    def __init__(self, known_agents: Optional[list[str]] = None):
        self.known_agents = known_agents or ["accounting_domain_engine", "db_manager_agent",
                                              "study_knowledge_agent", "final_checker_agent"]

    def input_receiver(self, raw_prompt: str) -> str:
        return raw_prompt

    def input_compiler(self, raw_prompt: str) -> dict:
        return {"text": raw_prompt.strip(), "length": len(raw_prompt.strip())}

    def input_analyser(self, compiled: dict) -> dict:
        text = compiled["text"].lower()
        intents = []
        if any(k in text for k in ("report", "گزارش")):
            intents.append("reporting")
        if any(k in text for k in ("transaction", "post", "تراکنش", "ثبت")):
            intents.append("transaction")
        if any(k in text for k in ("rule", "قانون")):
            intents.append("rule_management")
        if not intents:
            intents.append("general")
        return {**compiled, "intents": intents}

    def policy_checker(self, analysed: dict) -> dict:
        text = analysed["text"].lower()
        for pattern in DENY_PATTERNS:
            if pattern in text:
                raise PolicyViolation(f"prompt matched deny pattern: {pattern!r}")
        return analysed

    def prompt_reader(self, checked: dict) -> dict:
        return checked

    def prompt_analyser(self, checked: dict) -> dict:
        return checked

    def decision_system_for_choosing_best_agents(self, analysed: dict) -> AgentSelection:
        intent_to_agent = {
            "reporting": "reporting_pipeline",
            "transaction": "accounting_domain_engine",
            "rule_management": "accounting_domain_engine.rule_manager",
            "general": "study_knowledge_agent",
        }
        chosen = sorted({intent_to_agent[i] for i in analysed["intents"] if i in intent_to_agent})
        return AgentSelection(chosen_agents=chosen or [intent_to_agent["general"]],
                               reasoning=f"intents={analysed['intents']}")

    def process(self, raw_prompt: str) -> AgentSelection:
        c = self.input_compiler(self.input_receiver(raw_prompt))
        a = self.policy_checker(self.input_analyser(c))
        r = self.prompt_analyser(self.prompt_reader(a))
        return self.decision_system_for_choosing_best_agents(r)
