"""
Per-agent cryptographic identity. Backs `sign maker` / `rule signer`
(n5::n2::n2, n5::n2::n7) at agent-creation time, and the `sign reader`
stage repeated in every n10 channel.

Docs 07 §7.4: "message authentication ... uses digital signature scheme such as Ed25519"
This module provides Ed25519 signing using the `cryptography` C-extension
(fast — this is what the whole system's per-message latency was actually
dominated by before this fix; see FINAL_STATUS.md) with a pure-Python
RFC 8032 fallback if `cryptography` is unavailable. Both paths implement
the same standard algorithm, so keys and signatures are interchangeable
between them — no format/compatibility change for anything already signed
or persisted.
"""
from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass

from hesabdar.config import KEYS_DIR

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import (
        Ed25519PrivateKey,
        Ed25519PublicKey,
    )
    from cryptography.exceptions import InvalidSignature
    _HAS_CRYPTOGRAPHY = True
except ImportError:  # pragma: no cover - exercised only if dependency is missing
    _HAS_CRYPTOGRAPHY = False

# ---------------------------------------------------------------------------
# Pure-Python RFC 8032 Ed25519 Implementation (fallback only)
# ---------------------------------------------------------------------------
_p = 2**255 - 19
_d = -121665 * pow(121666, _p - 2, _p) % _p
_q = 2**252 + 27742317777372353535851937790883648493
_b = 256


def _sha512(s: bytes) -> bytes:
    return hashlib.sha512(s).digest()


def _inv(x: int) -> int:
    return pow(x, _p - 2, _p)


def _xrecover(y: int) -> int:
    xx = (y * y - 1) * _inv(_d * y * y + 1)
    x = pow(xx, (_p + 3) // 8, _p)
    if (x * x - xx) % _p != 0:
        x = (x * pow(2, (_p - 1) // 4, _p)) % _p
    if x % 2 != 0:
        x = _p - x
    return x


_By = 4 * _inv(5) % _p
_Bx = _xrecover(_By)
_B = (_Bx, _By)


def _edwards_add(P: tuple[int, int], Q: tuple[int, int]) -> tuple[int, int]:
    x1, y1 = P
    x2, y2 = Q
    x3 = (x1 * y2 + x2 * y1) * _inv(1 + _d * x1 * x2 * y1 * y2) % _p
    y3 = (y1 * y2 + x1 * x2) * _inv(1 - _d * x1 * x2 * y1 * y2) % _p
    return (x3, y3)


def _scalarmult(P: tuple[int, int], e: int) -> tuple[int, int]:
    if e == 0:
        return (0, 1)
    Q = _scalarmult(P, e // 2)
    Q = _edwards_add(Q, Q)
    if e & 1:
        Q = _edwards_add(Q, P)
    return Q


def _encodepoint(P: tuple[int, int]) -> bytes:
    x, y = P
    bits = [(y >> i) & 1 for i in range(_b - 1)] + [x & 1]
    return bytes(sum([bits[i * 8 + j] << j for j in range(8)]) for i in range(_b // 8))


def _decodepoint(s: bytes) -> tuple[int, int]:
    y = sum(2**i * ((s[i // 8] >> (i % 8)) & 1) for i in range(_b - 1))
    x = _xrecover(y)
    if (x & 1) != ((s[_b // 8 - 1] >> 7) & 1):
        x = _p - x
    return (x, y)


def _secret_to_public(sk: bytes) -> bytes:
    h = _sha512(sk)
    a = 2**(_b - 2) + sum(2**i * ((h[i // 8] >> (i % 8)) & 1) for i in range(3, _b - 2))
    A = _scalarmult(_B, a)
    return _encodepoint(A)


def _ed25519_sign_py(sk: bytes, pk: bytes, m: bytes) -> bytes:
    h = _sha512(sk)
    a = 2**(_b - 2) + sum(2**i * ((h[i // 8] >> (i % 8)) & 1) for i in range(3, _b - 2))
    r = int.from_bytes(_sha512(h[32:] + m), "little") % _q
    R = _scalarmult(_B, r)
    k = int.from_bytes(_sha512(_encodepoint(R) + pk + m), "little") % _q
    S = (r + k * a) % _q
    return _encodepoint(R) + S.to_bytes(32, "little")


def _ed25519_verify_py(pk: bytes, m: bytes, sig: bytes) -> bool:
    if len(sig) != 64 or len(pk) != 32:
        return False
    try:
        R = _decodepoint(sig[:32])
        A = _decodepoint(pk)
        S = int.from_bytes(sig[32:], "little")
        if S >= _q:
            return False
        k = int.from_bytes(_sha512(sig[:32] + pk + m), "little") % _q
        return _scalarmult(_B, S) == _edwards_add(R, _scalarmult(A, k))
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Fast path (cryptography C-extension) with pure-Python fallback
# ---------------------------------------------------------------------------

def _ed25519_sign(sk: bytes, pk: bytes, m: bytes) -> bytes:
    if _HAS_CRYPTOGRAPHY:
        return Ed25519PrivateKey.from_private_bytes(sk).sign(m)
    return _ed25519_sign_py(sk, pk, m)


def _ed25519_verify(pk: bytes, m: bytes, sig: bytes) -> bool:
    if len(sig) != 64 or len(pk) != 32:
        return False
    if _HAS_CRYPTOGRAPHY:
        try:
            Ed25519PublicKey.from_public_bytes(pk).verify(sig, m)
            return True
        except InvalidSignature:
            return False
        except Exception:
            return False
    return _ed25519_verify_py(pk, m, sig)


# ---------------------------------------------------------------------------
# Key abstractions
# ---------------------------------------------------------------------------

def _secret_to_public_fast(sk: bytes) -> bytes:
    if _HAS_CRYPTOGRAPHY:
        priv = Ed25519PrivateKey.from_private_bytes(sk)
        from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
        return priv.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
    return _secret_to_public(sk)


@dataclass
class AgentIdentity:
    agent_id: str
    private_key_bytes: bytes
    public_key_bytes: bytes

    def sign(self, payload: bytes) -> bytes:
        return _ed25519_sign(self.private_key_bytes, self.public_key_bytes, payload)

    def public_bytes(self) -> bytes:
        return self.public_key_bytes

    @classmethod
    def create(cls, agent_id: str, persist: bool = True) -> "AgentIdentity":
        sk = os.urandom(32)
        pk = _secret_to_public_fast(sk)
        identity = cls(agent_id=agent_id, private_key_bytes=sk, public_key_bytes=pk)
        if persist:
            identity._save()
        return identity

    @classmethod
    def load_or_create(cls, agent_id: str) -> "AgentIdentity":
        path = KEYS_DIR / f"{agent_id}.key"
        if path.exists():
            sk = path.read_bytes()
            if len(sk) == 32:
                pk = _secret_to_public_fast(sk)
                return cls(agent_id=agent_id, private_key_bytes=sk, public_key_bytes=pk)
        return cls.create(agent_id, persist=True)

    def _save(self) -> None:
        path = KEYS_DIR / f"{self.agent_id}.key"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(self.private_key_bytes)
        try:
            path.chmod(0o600)
        except OSError:
            pass


class IdentityRegistry:
    """Tracks known agents' public keys so a `sign reader` stage can verify
    a message claiming to be from any registered agent, per §7.3's
    'Identity' property."""

    def __init__(self):
        self._public_keys: dict[str, bytes] = {}

    def register(self, identity: AgentIdentity) -> None:
        self._public_keys[identity.agent_id] = identity.public_key_bytes

    def register_public_key(self, agent_id: str, public_key_bytes: bytes) -> None:
        self._public_keys[agent_id] = public_key_bytes

    def is_registered(self, agent_id: str) -> bool:
        return agent_id in self._public_keys

    def verify(self, agent_id: str, payload: bytes, signature: bytes) -> bool:
        pub = self._public_keys.get(agent_id)
        if pub is None:
            return False
        return _ed25519_verify(pub, payload, signature)
