"""JSON API Server Bridge for HESABDAR Multi-Agent Accounting Operating System.
Provides structured JSON endpoints for the web UI, REST API clients, and external systems.
"""

from __future__ import annotations

import json
import sys
import time
import uuid
from dataclasses import asdict
from typing import Any

from hesabdar.accounting.rule_manager import AccountingRule, RuleAction, RuleCondition, RuleDisposition, RuleScope, RuleStatus
from hesabdar.benchmarks.runner import BenchmarkRunner
from hesabdar.ceo.orchestrator import CEOAgentArchitecture


class HesabdarAPI:
    def __init__(self):
        self.ceo = CEOAgentArchitecture()

    def handle(self, endpoint: str, payload: dict[str, Any]) -> dict[str, Any]:
        try:
            if endpoint == "status":
                health = self.ceo.get_system_health()
                accounts = self.ceo.db_manager.get_accounts()
                txns = self.ceo.db_manager._op_list_transactions(limit=10)
                recent_logs = self.ceo.super_logs.query(limit=20)
                pending = self.ceo.list_pending_approvals()
                return {
                    "ok": True,
                    "health": health,
                    "accounts_count": len(accounts),
                    "transactions_count": len(txns),
                    "recent_logs": [asdict(l) for l in recent_logs],
                    "pending_approvals": pending,
                }

            elif endpoint == "execute_task":
                prompt = payload.get("prompt", "")
                raw_payload = payload.get("payload")
                result = self.ceo.execute_accounting_task(prompt, raw_payload=raw_payload)
                return {"ok": True, "result": result}

            elif endpoint == "post_journal_entry":
                description = payload.get("description", "Journal Entry")
                lines = payload.get("lines", [])
                idempotency_key = payload.get("idempotency_key") or str(uuid.uuid4())
                source_msg_id = payload.get("source_message_id", f"manual_ui_{uuid.uuid4().hex[:6]}")

                if not lines or len(lines) < 2:
                    return {"ok": False, "error": "Journal entry must contain at least 2 balanced lines"}

                try:
                    txn_id = self.ceo.db_manager._op_post_transaction(
                        description=description,
                        lines=lines,
                        source_message_id=source_msg_id,
                        idempotency_key=idempotency_key,
                    )
                    # Record in super logs
                    self.ceo.super_logs.log(
                        task_id=txn_id,
                        agent_id="human_accountant",
                        agent_role="manual_entry",
                        prompt=f"Post manual journal entry: {description}",
                        output=f"Committed transaction {txn_id}",
                    )
                    return {
                        "ok": True,
                        "transaction_id": txn_id,
                        "description": description,
                        "lines_count": len(lines),
                    }
                except Exception as exc:
                    return {"ok": False, "error": str(exc)}

            elif endpoint == "list_accounts":
                accounts = self.ceo.db_manager.get_accounts()
                return {
                    "ok": True,
                    "accounts": accounts,
                }

            elif endpoint == "create_account":
                name = payload.get("name", "").strip()
                account_type = payload.get("account_type", "asset").strip().lower()
                code = payload.get("code", "").strip()
                if not name:
                    return {"ok": False, "error": "Account name cannot be empty"}
                if account_type not in ["asset", "liability", "equity", "revenue", "expense"]:
                    return {"ok": False, "error": f"Invalid account category: {account_type}"}

                acc_id = self.ceo.db_manager._op_create_account(
                    name=name,
                    account_type=account_type,
                    code=code if code else None,
                )
                return {"ok": True, "account_id": acc_id}

            elif endpoint == "list_transactions":
                limit = int(payload.get("limit", 50))
                txns = self.ceo.db_manager._op_list_transactions_detailed(limit=limit)
                return {
                    "ok": True,
                    "transactions": txns,
                }

            elif endpoint == "get_account_ledger":
                account_id = payload.get("account_id", "")
                ledger = self.ceo.db_manager._op_get_account_ledger(account_id)
                return {"ok": True, "ledger": ledger}

            elif endpoint == "list_rules":
                rules = self.ceo.rule_manager.list_rules()
                return {
                    "ok": True,
                    "rules": [r.to_dict() for r in rules],
                }

            elif endpoint == "create_rule":
                code = payload.get("code", f"R-CUST-{uuid.uuid4().hex[:4].upper()}")
                name = payload.get("name", "Custom Accounting Rule")
                description = payload.get("description", "")
                category = payload.get("category", "expense")
                priority = int(payload.get("priority", 20))
                debit_acc = payload.get("debit_account_code", "5040")
                credit_acc = payload.get("credit_account_code", "1010")
                disposition = payload.get("disposition", "auto_post")

                rule = AccountingRule(
                    id=f"rule_{uuid.uuid4().hex[:8]}",
                    code=code,
                    name=name,
                    description=description,
                    category=category,
                    scope=RuleScope.ORGANIZATIONAL,
                    priority=priority,
                    status=RuleStatus.PENDING_APPROVAL,
                    conditions=[RuleCondition("category", "==", category)],
                    action=RuleAction(
                        disposition=RuleDisposition(disposition) if disposition in RuleDisposition._value2member_map_ else RuleDisposition.AUTO_POST,
                        debit_account_code=debit_acc,
                        credit_account_code=credit_acc,
                    ),
                    created_by=payload.get("created_by", "human_supervisor"),
                )
                rule_id = self.ceo.rule_manager.add_candidate_rule(rule)
                # Add to approval queue
                appr_id = f"appr_{uuid.uuid4().hex[:8]}"
                self.ceo._pending_approvals.append({
                    "id": appr_id,
                    "task_id": f"task_rule_{rule_id}",
                    "prompt": f"New candidate rule proposal: {name} ({code})",
                    "path_taken": "user_creation",
                    "reason": f"Manual rule submission by {rule.created_by}",
                    "candidate_rule": rule.to_dict(),
                    "created_at": time.time(),
                    "status": "pending",
                })
                return {"ok": True, "rule_id": rule_id, "approval_id": appr_id}

            elif endpoint == "list_skills":
                skills = self.ceo.skill_registry.list_skills()
                return {
                    "ok": True,
                    "skills": [s.to_dict() for s in skills],
                }

            elif endpoint == "list_agents":
                agents = []
                for aid, pk in self.ceo.registry._public_keys.items():
                    agents.append({
                        "agent_id": aid,
                        "public_key_hex": pk.hex()[:16] + "...",
                        "status": "authenticated",
                        "algorithm": "Ed25519",
                    })
                # Add core specialized agents
                core_roles = [
                    {"agent_id": "ceo_orchestrator", "role": "Supervisor Kernel", "algorithm": "Ed25519", "status": "active"},
                    {"agent_id": "accounting_domain_engine", "role": "Fast/Research Rule Engine", "algorithm": "Deterministic", "status": "active"},
                    {"agent_id": "critic_final_checker", "role": "4-Layer Invariant QA", "algorithm": "Formal Proof", "status": "active"},
                    {"agent_id": "db_manager_agent", "role": "Authorized Ledger Writer", "algorithm": "SQLite/Postgres", "status": "active"},
                    {"agent_id": "tool_manager", "role": "RBAC & Security Sandbox", "algorithm": "Capability Gate", "status": "active"},
                    {"agent_id": "memory_manager", "role": "27-Taxonomy Cognitive Substrate", "algorithm": "Vector/Relational", "status": "active"},
                    {"agent_id": "resilience_guardian", "role": "Self-Healing & Backups", "algorithm": "Supervised Recovery", "status": "active"},
                ]
                return {"ok": True, "agents": agents, "core_agents": core_roles}

            elif endpoint == "list_logs":
                limit = int(payload.get("limit", 50))
                errors_only = payload.get("errors_only", False)
                logs = self.ceo.super_logs.query(has_error=True if errors_only else None, limit=limit)
                return {"ok": True, "logs": [asdict(l) for l in logs]}

            elif endpoint == "list_approvals":
                pending = self.ceo.list_pending_approvals()
                return {"ok": True, "approvals": pending}

            elif endpoint == "approve_item":
                appr_id = payload.get("approval_id", "")
                approver = payload.get("approver", "human_supervisor")
                ok = self.ceo.approve_item(appr_id, approver=approver)
                return {"ok": ok, "approval_id": appr_id}

            elif endpoint == "reject_item":
                appr_id = payload.get("approval_id", "")
                reason = payload.get("reason", "Rejected by human supervisor")
                ok = self.ceo.reject_item(appr_id, reason=reason)
                return {"ok": ok, "approval_id": appr_id}

            elif endpoint == "generate_report":
                report_type_str = payload.get("report_type", "trial_balance")
                rep = self.ceo.generate_financial_report(report_type_str)
                return {"ok": True, "report": rep.to_dict()}

            elif endpoint == "create_backup":
                label = payload.get("label", "Manual UI Snapshot")
                snap = self.ceo.backup_system.create_backup(label)
                return {"ok": True, "snapshot": asdict(snap)}

            elif endpoint == "list_backups":
                backups = self.ceo.backup_system.list_backups()
                return {"ok": True, "backups": [asdict(b) for b in backups]}

            elif endpoint == "restore_backup":
                backup_id = payload.get("backup_id", "")
                res = self.ceo.recovery_system.restore_from_backup(backup_id)
                return {"ok": res.ok, "details": res.details}

            elif endpoint == "trigger_self_healing":
                task_id = payload.get("task_id", "simulated_task")
                error_msg = payload.get("error", "Simulated database connection lock timeout")
                res = self.ceo.self_healing.diagnose_and_heal(task_id, error_msg, {})
                return {"ok": res.ok, "healing_result": asdict(res)}

            elif endpoint == "run_benchmark":
                tiers = payload.get("tiers", [1, 2, 5, 10, 25])
                runner = BenchmarkRunner(ceo=self.ceo)
                res = runner.run_full_suite(tiers=tiers)
                return {"ok": True, "benchmark": res.to_dict()}

            elif endpoint == "seed_sample_data":
                count = self.ceo.db_manager.seed_sample_business_data()
                return {"ok": True, "seeded_count": count, "message": f"Successfully seeded {count} sample business transactions"}

            return {"ok": False, "error": f"Unknown endpoint: {endpoint}"}
        except Exception as exc:
            return {"ok": False, "error": f"Unhandled API exception: {str(exc)}"}


def main():
    if len(sys.argv) < 2:
        print(json.dumps({"ok": False, "error": "Missing endpoint argument"}))
        return

    endpoint = sys.argv[1]
    payload = {}
    if len(sys.argv) > 2:
        try:
            payload = json.loads(sys.argv[2])
        except Exception:
            payload = {}

    api = HesabdarAPI()
    result = api.handle(endpoint, payload)
    print(json.dumps(result, ensure_ascii=False, default=str))


if __name__ == "__main__":
    main()
