"""
Central configuration for HESABDAR Multi-Agent Accounting Operating System.
Environment-driven with resilient offline defaults.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get("HESABDAR_DATA_DIR", PROJECT_ROOT / "data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)

KEYS_DIR = DATA_DIR / "keys"
KEYS_DIR.mkdir(parents=True, exist_ok=True)

LOGS_DIR = DATA_DIR / "logs"
LOGS_DIR.mkdir(parents=True, exist_ok=True)

BACKUPS_DIR = DATA_DIR / "backups"
BACKUPS_DIR.mkdir(parents=True, exist_ok=True)

MEMORY_DB_PATH = DATA_DIR / "memory.sqlite3"
PRODUCTION_DB_PATH = DATA_DIR / "production.sqlite3"
AUDIT_LOG_PATH = DATA_DIR / "audit_chain.jsonl"


@dataclass
class LLMConfig:
    """
    provider: "ollama" | "gemini" | "anthropic" | "openai" | "mock"
    """
    provider: str = field(default_factory=lambda: os.environ.get("HESABDAR_LLM_PROVIDER", "ollama"))
    model: str = field(default_factory=lambda: os.environ.get("HESABDAR_LLM_MODEL", "gemma2"))
    ollama_host: str = field(default_factory=lambda: os.environ.get("OLLAMA_HOST", "http://localhost:11434"))
    gemini_api_key: str = field(default_factory=lambda: os.environ.get("GEMINI_API_KEY", ""))
    anthropic_api_key: str = field(default_factory=lambda: os.environ.get("ANTHROPIC_API_KEY", ""))
    openai_api_key: str = field(default_factory=lambda: os.environ.get("OPENAI_API_KEY", ""))
    temperature: float = 0.2
    max_tokens: int = 2048


@dataclass
class ResourceConfig:
    """
    Enforcement knobs for the CEO's Resource Distributor (n5::n7),
    per §4.5 of 04-orchestration-and-ceo-agent.md.
    """
    max_concurrent_agents: int = int(os.environ.get("HESABDAR_MAX_AGENTS", "5"))
    max_io_retries: int = int(os.environ.get("HESABDAR_MAX_RETRIES", "3"))
    prefer_deterministic: bool = True
    financial_logs_are_permanent: bool = True


LLM = LLMConfig()
RESOURCES = ResourceConfig()
