"""
Command-Line Interface (CLI) for HESABDAR Multi-Agent Accounting OS (PRD §64).
Supports: start, status, run-task, list-agents, list-skills, list-tools,
inspect-task, inspect-logs, approve, reject, backup, restore, benchmark, report.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from typing import Optional

from hesabdar.benchmarks.runner import BenchmarkRunner
from hesabdar.ceo.orchestrator import CEOAgentArchitecture


def print_banner():
    print(r"""
===============================================================
  _   _ _____ ____    _    ____  ____    _    ____  
 | | | | ____/ ___|  / \  | __ )|  _ \  / \  |  _ \ 
 | |_| |  _| \___ \ / _ \ |  _ \| | | |/ _ \ | |_) |
 |  _  | |___ ___) / ___ \| |_) | |_| / ___ \|  _ < 
 |_| |_|_____|____/_/   \_\____/|____/_/   \_\_| \_\
  Autonomous Multi-Agent Accounting Operating System
===============================================================
""")


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        prog="hesabdar",
        description="HESABDAR - Autonomous Multi-Agent Accounting Operating System",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # status
    subparsers.add_parser("status", help="Show system status and health")

    # doctor
    subparsers.add_parser("doctor", help="Run a read-only database integrity check (PRAGMA integrity_check)")

    # run-task
    task_parser = subparsers.add_parser("run-task", help="Execute an accounting task via CEO pipeline")
    task_parser.add_argument("prompt", help="Natural language or structured accounting prompt")
    task_parser.add_argument("--amount", type=float, default=0.0, help="Optional numeric amount")
    task_parser.add_argument("--vendor", type=str, default="", help="Optional vendor/party")

    # list-agents
    subparsers.add_parser("list-agents", help="List registered agents")

    # list-skills
    subparsers.add_parser("list-skills", help="List registered skills")

    # list-tools
    subparsers.add_parser("list-tools", help="List available tools and permissions")

    # inspect-task
    inspect_parser = subparsers.add_parser("inspect-task", help="Inspect causality trace of a task")
    inspect_parser.add_argument("task_id", help="Task ID to inspect")

    # inspect-logs
    log_parser = subparsers.add_parser("inspect-logs", help="View recent Super Logs")
    log_parser.add_argument("--limit", type=int, default=20, help="Number of entries")
    log_parser.add_argument("--errors-only", action="store_true", help="Filter errors only")

    # approvals
    subparsers.add_parser("list-approvals", help="List pending human approval requests")
    appr_parser = subparsers.add_parser("approve", help="Approve a pending item/rule")
    appr_parser.add_argument("approval_id", help="Approval ID")
    rej_parser = subparsers.add_parser("reject", help="Reject a pending item/rule")
    rej_parser.add_argument("approval_id", help="Approval ID")
    rej_parser.add_argument("--reason", type=str, default="Rejected by operator", help="Reason")

    # backup & restore
    subparsers.add_parser("backup", help="Create a verified snapshot backup")
    restore_parser = subparsers.add_parser("restore", help="Restore state from backup")
    restore_parser.add_argument("backup_id", help="Backup ID")

    # benchmark
    subparsers.add_parser("benchmark", help="Run multi-agent scale benchmark suite")

    # report
    report_parser = subparsers.add_parser("report", help="Generate financial statements")
    report_parser.add_argument(
        "type",
        choices=["trial_balance", "income_statement", "balance_sheet"],
        default="income_statement",
        nargs="?",
        help="Statement type",
    )

    args = parser.parse_args(argv)
    if not args.command:
        print_banner()
        parser.print_help()
        return 0

    ceo = CEOAgentArchitecture()

    if args.command == "status":
        print_banner()
        health = ceo.get_system_health()
        print(f"[*] System Status:       {health['status'].upper()}")
        print(f"[*] CEO Identity:        {health['ceo_identity']}")
        print(f"[*] Registered Agents:   {health['registered_agents']}")
        print(f"[*] Active Rules:        {health['active_rules']}")
        print(f"[*] Active Skills:       {health['active_skills']}")
        print(f"[*] Super Logs Entries:  {health['super_logs_count']}")
        print(f"[*] Pending Approvals:   {health['pending_approvals']}")
        return 0

    elif args.command == "doctor":
        health = ceo.get_system_health()
        prod_ok = health["production_db"].get("ok", False)
        mem_ok = (health.get("memory_db") or {}).get("ok", False)
        print(f"[*] production.sqlite3: {'OK' if prod_ok else 'CORRUPT'}  {health['production_db']}")
        print(f"[*] memory.sqlite3:      {'OK' if mem_ok else 'CORRUPT'}  {health.get('memory_db')}")
        return 0 if (prod_ok and mem_ok) else 1

    elif args.command == "run-task":
        payload = {"description": args.prompt, "amount": args.amount, "vendor": args.vendor}
        print("[*] Submitting task to CEO Agent Kernel...")
        res = ceo.execute_accounting_task(args.prompt, raw_payload=payload)
        print(json.dumps(res, indent=2, ensure_ascii=False, default=str))
        return 0

    elif args.command == "list-agents":
        print("[*] Registered Agents in Identity Registry:")
        for agent_id in ceo.registry._public_keys.keys():
            print(f"  - {agent_id} (Ed25519 authenticated)")
        return 0

    elif args.command == "list-skills":
        skills = ceo.skill_registry.list_skills()
        print(f"[*] Registered Skills ({len(skills)}):")
        for s in skills:
            print(f"  - [{s.status.value.upper()}] {s.id}: {s.name} (v{s.version})")
            print(f"    Repo: {s.repository}")
            print(f"    Capabilities: {', '.join(s.capabilities)}")
        return 0

    elif args.command == "list-tools":
        print("[*] Available Tools:")
        print("  - bash_tool: sandbox bash execution (restricted)")
        print("  - file_tool: read/write/list files in sandbox")
        print("  - excel_tool: openpyxl spreadsheet & csv generator/reader")
        print("  - web_tool: internet search & document retrieval")
        return 0

    elif args.command == "inspect-task":
        report = ceo.debugger.trace(task_id=args.task_id)
        print(json.dumps(report.to_dict(), indent=2, ensure_ascii=False))
        return 0

    elif args.command == "inspect-logs":
        logs = ceo.super_logs.query(has_error=args.errors_only if args.errors_only else None, limit=args.limit)
        print(f"[*] Showing {len(logs)} Super Log records:")
        for l in logs:
            err_tag = f" [ERROR: {l.error}]" if l.error else ""
            print(f"  - [{time.strftime('%H:%M:%S', time.localtime(l.timestamp))}] Task={l.task_id} Agent={l.agent_id} Latency={l.latency_ms:.1f}ms{err_tag}")
        return 0

    elif args.command == "list-approvals":
        items = ceo.list_pending_approvals()
        print(f"[*] Pending Human Approvals ({len(items)}):")
        for it in items:
            print(f"  - ID: {it['id']} | Task: {it['task_id']} | Reason: {it['reason']}")
        return 0

    elif args.command == "approve":
        ok = ceo.approve_item(args.approval_id)
        print(f"[*] Approved {args.approval_id}: {ok}")
        return 0 if ok else 1

    elif args.command == "reject":
        ok = ceo.reject_item(args.approval_id, reason=args.reason)
        print(f"[*] Rejected {args.approval_id}: {ok}")
        return 0 if ok else 1

    elif args.command == "backup":
        print("[*] Creating verified backup snapshot...")
        snap = ceo.backup_system.create_backup("CLI Snapshot")
        print(f"[+] Backup created: {snap.id} (Verified: {snap.verified}, Size: {snap.size_bytes} bytes)")
        return 0

    elif args.command == "restore":
        print(f"[*] Restoring state from backup {args.backup_id}...")
        res = ceo.recovery_system.restore_from_backup(args.backup_id)
        print(f"[+] Recovery result: ok={res.ok}, details={res.details}")
        return 0 if res.ok else 1

    elif args.command == "benchmark":
        print("[*] Launching HESABDAR Progressive Scale Benchmark Suite (1..100 agents)...")
        runner = BenchmarkRunner(ceo=ceo)
        res = runner.run_full_suite()
        print(json.dumps(res.to_dict(), indent=2))
        return 0

    elif args.command == "report":
        rep = ceo.generate_financial_report(args.type)
        print(json.dumps(rep.to_dict(), indent=2, ensure_ascii=False))
        return 0

    return 0


if __name__ == "__main__":
    sys.exit(main())
