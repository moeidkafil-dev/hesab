"""
The 27-type memory taxonomy, per docs/03-memory-architecture.md §3.2 and
graphml nodes n13::n0::n8::n0..n26 (CEO memory architecture) /
n13::n3::n0::n0..n26 (general memory architecture) — the two are structurally
identical, replicated per §3.6 ("CEO maintains its own private state distinct
from the resources it supervises").
"""
from __future__ import annotations

from enum import Enum


class MemoryType(str, Enum):
    # -- Temporal-span family (how long information survives) --
    SENSORY = "sensory_memory"
    WORKING = "working_memory"
    STM = "short_term_memory"
    LTM = "long_term_memory"
    TEMPORAL = "temporal_memory"

    # -- Content-type family (what kind of information is held) --
    EPISODIC = "episodic_memory"
    SEMANTIC = "semantic_knowledge_memory"
    PROCEDURAL = "procedural_memory"

    # -- Task-management family --
    GOAL = "goal_memory"
    TASK = "task_memory"
    PLANNING = "planning_memory"
    CONTEXT = "context_memory"

    # -- Interaction family --
    CONVERSATION = "conversation_memory"
    USER_PROFILE = "user_profile_memory"
    SHARED = "shared_memory"          # cross-agent
    AGENT_LOCAL = "agent_local_memory"  # private to one agent instance

    # -- Self-monitoring family --
    LEARNING = "learning_memory"
    EXPERIENCE = "experience_memory"
    FAILURE = "failure_memory"
    SUCCESS = "success_memory"
    REFLECTION = "reflection_memory"
    META = "meta_memory"
    AUDIT_HISTORY = "audit_history_memory"

    # -- Infrastructural (support retrieval mechanics) --
    TOOL = "tool_memory"
    ENVIRONMENT = "environment_world_state"
    RAG = "rag_memory"
    CACHE = "cache_memory"

    # -- Domain-specific extension (§3.5 retention rule references this
    #    explicitly even though it is not one of the diagram's 27 boxes;
    #    kept separate from generic Audit/History so the permanent-retention
    #    rule can target it precisely) --
    FINANCIAL_TRANSACTION = "financial_transaction_memory"


# §3.5's explicit, auditable retention rule. `permanent=True` types are
# categorically exempt from `tables cleaner` / `find junks` pruning
# regardless of resource pressure — this is the load-bearing invariant
# from §3.5 and must not be silently overridden elsewhere in the codebase.
PERMANENT_MEMORY_TYPES = frozenset({
    MemoryType.FAILURE,
    MemoryType.AUDIT_HISTORY,
    MemoryType.FINANCIAL_TRANSACTION,
})

DEFAULT_TTL_DAYS = {
    MemoryType.CONVERSATION: 30,
    MemoryType.CACHE: 30,
    MemoryType.SENSORY: 1,
    MemoryType.WORKING: 1,
}
