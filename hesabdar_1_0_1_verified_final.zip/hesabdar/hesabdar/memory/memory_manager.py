"""
n13::n3::n1 "memory manager" — implements the two pipelines from
docs/03-memory-architecture.md §3.4:

Write path:       input_reader -> input_analyser -> input_setter_in_memory -> memory_analyser
Maintenance path:  memory_complete_analyser -> find_junks -> tables_cleaner -> memory_analyser -> being_in_sleep_mode

Method names below are the transliterated node names so the mapping to the
diagram stays 1:1 (see MAPPING.md).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from hesabdar.llm import LLMProvider, get_llm
from hesabdar.memory.store import MemoryStore, MemoryEntry
from hesabdar.memory.taxonomy import MemoryType


@dataclass
class WriteDecision:
    should_write: bool
    memory_type: MemoryType
    importance: float
    reason: str


class MemoryManager:
    def __init__(self, scope: str, store: Optional[MemoryStore] = None, llm: Optional[LLMProvider] = None):
        self.scope = scope
        self.store = store or MemoryStore()
        self.llm = llm or get_llm()

    # ---------------------------------------------------------------- write path
    def input_reader(self, raw_input: Any) -> Any:
        """n13::n3::n1::n0 — accept raw candidate content, unmodified."""
        return raw_input

    def input_analyser(self, raw_input: Any, hint_type: Optional[MemoryType] = None) -> WriteDecision:
        """n13::n3::n1::n1 — decide *whether*, *where*, and at what priority
        to commit, before anything is written (§3.4: store/discard/prioritize
        happens before commitment, not after)."""
        if hint_type is not None:
            return WriteDecision(True, hint_type, importance=0.6, reason="explicit type hint")

        text = str(raw_input)
        lowered = text.lower()
        if any(k in lowered for k in ("transaction", "debit", "credit", "تراکنش", "بدهکار", "بستانکار")):
            return WriteDecision(True, MemoryType.FINANCIAL_TRANSACTION, importance=1.0, reason="financial content")
        if any(k in lowered for k in ("error", "failed", "خطا", "شکست")):
            return WriteDecision(True, MemoryType.FAILURE, importance=0.9, reason="failure signal")
        if any(k in lowered for k in ("goal", "objective", "هدف")):
            return WriteDecision(True, MemoryType.GOAL, importance=0.7, reason="goal-bearing content")
        return WriteDecision(True, MemoryType.EPISODIC, importance=0.4, reason="default episodic bucket")

    def input_setter_in_memory(self, raw_input: Any, decision: WriteDecision) -> Optional[MemoryEntry]:
        """n13::n3::n1::n2 — commit to the store."""
        if not decision.should_write:
            return None
        return self.store.write(self.scope, decision.memory_type, raw_input, importance=decision.importance)

    def memory_analyser(self, entries: Optional[list[MemoryEntry]] = None) -> str:
        """n13::n3::n1::n3 / n13::n3::n1::n7 — reused by both pipelines. Summarizes
        the state of a set of entries; used post-write for logging and
        post-maintenance to report what changed."""
        entries = entries or []
        if not entries:
            return "no entries to analyse"
        by_type: dict[str, int] = {}
        for e in entries:
            by_type[e.memory_type.value] = by_type.get(e.memory_type.value, 0) + 1
        return ", ".join(f"{k}: {v}" for k, v in by_type.items())

    def remember(self, raw_input: Any, hint_type: Optional[MemoryType] = None) -> Optional[MemoryEntry]:
        """Convenience wrapper chaining the full write path."""
        content = self.input_reader(raw_input)
        decision = self.input_analyser(content, hint_type=hint_type)
        entry = self.input_setter_in_memory(content, decision)
        self.memory_analyser([entry] if entry else [])
        return entry

    # ---------------------------------------------------------- maintenance path
    def memory_complete_analyser(self) -> list[MemoryEntry]:
        """n13::n3::n1::n4 — full-scope snapshot ahead of consolidation."""
        return self.store.read(self.scope, limit=10_000)

    def find_junks(self) -> list[MemoryEntry]:
        """n13::n3::n1::n5"""
        return self.store.find_junks(self.scope)

    def tables_cleaner(self, junk: list[MemoryEntry]) -> int:
        """n13::n3::n1::n6"""
        return self.store.tables_cleaner(junk)

    def being_in_sleep_mode(self) -> dict:
        """n13::n3::n1::n8 — "runs the cleanup/management system every 2 hours"
        per the node's stated description. Callers (e.g. a scheduler in
        hesabdar.ceo) invoke this on that cadence; this method just performs
        one consolidation pass."""
        snapshot = self.memory_complete_analyser()
        junk = self.find_junks()
        removed = self.tables_cleaner(junk)
        report = self.memory_analyser(snapshot)
        return {"scanned": len(snapshot), "removed": removed, "summary": report}
