"""
Recovery Subsystem (n8, PRD §36, Docs 08 §8.3).
Restores system state from verified backups:
backup catcher -> backup analyser -> DB changer -> main DB setter ->
system analyser -> system restarter -> CEO -> log.
"""
from __future__ import annotations

import json
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from hesabdar.config import DATA_DIR
from hesabdar.resilience.backup import BackupSnapshot, BackupSystem


@dataclass
class RecoveryResult:
    ok: bool
    backup_id: str
    restored_files: list[str] = field(default_factory=list)
    system_restarted: bool = False
    details: str = ""
    error: Optional[str] = None


class RecoverySystem:
    """n8 Recovery System. Handles clean state recovery from verified backups."""

    def __init__(self, data_dir: Optional[Path] = None, backup_system: Optional[BackupSystem] = None):
        self.data_dir = data_dir or DATA_DIR
        self.backup_system = backup_system or BackupSystem(data_dir=self.data_dir)

    def restore_from_backup(self, backup_id: str) -> RecoveryResult:
        backup_dir = self.backup_system.backups_dir / backup_id
        manifest_file = backup_dir / "manifest.json"
        if not manifest_file.exists():
            return RecoveryResult(
                ok=False,
                backup_id=backup_id,
                details="Manifest not found in backup directory",
                error=f"Backup {backup_id} does not exist or lacks manifest.",
            )

        with open(manifest_file, "r", encoding="utf-8") as f:
            snapshot_data = json.load(f)
            snapshot = BackupSnapshot(**snapshot_data)

        # 1. Backup Analyser verification before restoring
        valid = self.backup_system.analyze_backup(snapshot)
        if not valid:
            return RecoveryResult(
                ok=False,
                backup_id=backup_id,
                details="Backup failed cryptographic checksum verification.",
                error="Corrupted or tampered backup snapshot.",
            )

        # 2. Restore files (DB Changer & Main DB Setter)
        restored = []
        try:
            for item in backup_dir.iterdir():
                if item.name == "manifest.json":
                    continue
                dest = self.data_dir / item.name
                if item.is_file():
                    shutil.copy2(item, dest)
                    restored.append(item.name)
                elif item.is_dir():
                    shutil.copytree(item, dest, dirs_exist_ok=True)
                    restored.append(item.name)

            return RecoveryResult(
                ok=True,
                backup_id=backup_id,
                restored_files=restored,
                system_restarted=True,
                details=f"Successfully restored state from backup {backup_id}. All DBs and memories synchronized.",
            )
        except Exception as exc:
            return RecoveryResult(
                ok=False,
                backup_id=backup_id,
                restored_files=restored,
                details="Exception occurred during file copy",
                error=str(exc),
            )
