"""
Resilience, Backup, Recovery, Self-Healing, and Debugger Subsystems (n7, n8, n9, PRD §35-§41, Docs 08, 09).
"""
from hesabdar.resilience.backup import BackupSystem, BackupSnapshot
from hesabdar.resilience.recovery import RecoverySystem, RecoveryResult
from hesabdar.resilience.self_healing import SelfHealingSystem, HealingResult
from hesabdar.resilience.debugger import DebuggerSystem, TraceReport

__all__ = [
    "BackupSystem",
    "BackupSnapshot",
    "RecoverySystem",
    "RecoveryResult",
    "SelfHealingSystem",
    "HealingResult",
    "DebuggerSystem",
    "TraceReport",
]
