"""
Backup Subsystem (n7, PRD §35, Docs 08 §8.2).
Creates cryptographically verified point-in-time snapshots of:
- Primary DB
- Hidden Memory stores
- Rules configuration
- Identity registry
- Super Logs metadata
Includes automated sha256 integrity hashing and backup analyzer.
"""
from __future__ import annotations

import hashlib
import json
import shutil
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Optional

from hesabdar.config import DATA_DIR


@dataclass
class BackupSnapshot:
    id: str
    timestamp: float
    files: list[str] = field(default_factory=list)
    sha256_hashes: dict[str, str] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    verified: bool = False
    size_bytes: int = 0
    destination_dir: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


class BackupSystem:
    """n7 Backup Agent. Manages snapshots, analyzer validation, and integrity."""

    def __init__(self, data_dir: Optional[Path] = None, backups_dir: Optional[Path] = None):
        self.data_dir = data_dir or DATA_DIR
        self.backups_dir = backups_dir or (self.data_dir / "backups")
        self.backups_dir.mkdir(parents=True, exist_ok=True)

    def _hash_file(self, path: Path) -> str:
        if not path.exists():
            return ""
        h = hashlib.sha256()
        with open(path, "rb") as f:
            while chunk := f.read(65536):
                h.update(chunk)
        return h.hexdigest()

    def create_backup(self, description: str = "Automated System Snapshot") -> BackupSnapshot:
        backup_id = f"backup_{int(time.time())}_{uuid.uuid4().hex[:6]}"
        target_dir = self.backups_dir / backup_id
        target_dir.mkdir(parents=True, exist_ok=True)

        copied_files = []
        hashes = {}
        total_size = 0

        # Snapshot files in data dir (db, memory, logs, keys)
        for item in self.data_dir.iterdir():
            if item.name == "backups":
                continue
            if item.is_file():
                dest = target_dir / item.name
                shutil.copy2(item, dest)
                h = self._hash_file(dest)
                copied_files.append(item.name)
                hashes[item.name] = h
                total_size += dest.stat().st_size
            elif item.is_dir():
                dest_dir = target_dir / item.name
                shutil.copytree(item, dest_dir, dirs_exist_ok=True)
                for sub in dest_dir.rglob("*"):
                    if sub.is_file():
                        rel = str(sub.relative_to(target_dir))
                        copied_files.append(rel)
                        hashes[rel] = self._hash_file(sub)
                        total_size += sub.stat().st_size

        snapshot = BackupSnapshot(
            id=backup_id,
            timestamp=time.time(),
            files=copied_files,
            sha256_hashes=hashes,
            metadata={"description": description, "source": str(self.data_dir)},
            verified=False,
            size_bytes=total_size,
            destination_dir=str(target_dir),
        )

        # Run Backup Analyser to verify integrity
        snapshot.verified = self.analyze_backup(snapshot)

        # Write manifest
        manifest_file = target_dir / "manifest.json"
        with open(manifest_file, "w", encoding="utf-8") as f:
            json.dump(snapshot.to_dict(), f, indent=2)

        return snapshot

    def analyze_backup(self, snapshot: BackupSnapshot) -> bool:
        """n7::n4 Backup Analyser. Verifies checksums and mandatory files."""
        target = Path(snapshot.destination_dir)
        if not target.exists():
            return False

        for file_rel, expected_hash in snapshot.sha256_hashes.items():
            fpath = target / file_rel
            if not fpath.exists():
                return False
            actual_hash = self._hash_file(fpath)
            if actual_hash != expected_hash:
                return False
        return True

    def list_backups(self) -> list[BackupSnapshot]:
        results = []
        if not self.backups_dir.exists():
            return results

        for child in sorted(self.backups_dir.iterdir(), reverse=True):
            if child.is_dir():
                manifest_file = child / "manifest.json"
                if manifest_file.exists():
                    try:
                        with open(manifest_file, "r", encoding="utf-8") as f:
                            data = json.load(f)
                            results.append(BackupSnapshot(**data))
                    except Exception:
                        pass
        return results
