#!/usr/bin/env python3
"""
Main Entry Point for HESABDAR Multi-Agent Accounting Operating System.
"""
import sys
from pathlib import Path

# Ensure package directory is on path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from hesabdar.cli import main

if __name__ == "__main__":
    sys.exit(main())
