"""
Benchmarking Suite for HESABDAR Multi-Agent Accounting OS (PRD §51-§54).
"""
from hesabdar.benchmarks.runner import BenchmarkRunner, BenchmarkSuiteResult

__all__ = ["BenchmarkRunner", "BenchmarkSuiteResult"]
