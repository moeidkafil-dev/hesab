# نگاشت node id های حسابدار.graphml به کد

هر کلاس/متد زیر دقیقاً روی یک node یا گروه node در `حسابدار.graphml` منطبقه.
اسم متدها عمداً همون اسم node (translit شده) هست تا رفت‌وبرگشت بین دیاگرام و
کد راحت باشه.

## Step 1

| Node(s) | فایل | کلاس/متد |
|---|---|---|
| `n13::n3::n0` (memory architecture, ۲۷ نوع) | `hesabdar/memory/taxonomy.py` | `MemoryType` |
| `n13::n3::n1` (memory manager: write + maintenance path) | `hesabdar/memory/memory_manager.py` | `MemoryManager` |
| `n5::n8` (CEO memory architecture) + `n5::n4` (memory manager, CEO) | `hesabdar/ceo/ceo_memory_manager.py` | `CEOMemoryManager` |
| `n13::n2` (new massages architecture — receiver/compiler/sign reader/read) | `hesabdar/messaging/channel.py` | `Channel` |
| `n5::n2::n2`, `n5::n2::n7` (rule signer, sign maker) | `hesabdar/messaging/identity.py` | `AgentIdentity`, `IdentityRegistry` |
| `n10::n32`, `n10::n33` (name and sign hasher, message maker) | `hesabdar/messaging/message.py` | `NameAndSignHasher`, `new_message` |
| `n13::n1` / `n6` (DB manager agent architecture) | `hesabdar/db_manager/agent.py` | `DBManagerAgent` |
| `n5::n0` (log input manager) | `hesabdar/ceo/log_input_manager.py` | `LogInputManager` |
| `n5::n1` (prompt manager) | `hesabdar/ceo/prompt_manager.py` | `PromptManager` |
| `n5::n2` (new agent manager) | `hesabdar/ceo/new_agent_manager.py` | `NewAgentManager` |
| `n5::n3` (agent killer) | `hesabdar/ceo/agent_killer.py` | `AgentKiller` |
| `n5::n5` (CEO agent core) | `hesabdar/ceo/ceo_core.py` | `CEOAgentCore` |
| `n5::n6` (agents input messages manager) | `hesabdar/ceo/agents_input_messages_manager.py` | `AgentsInputMessagesManager` |
| `n5::n7` (Resource Distributor) | `hesabdar/ceo/resource_distributor.py` | `ResourceDistributor` |
| `n5::n9` (agent builder) | `hesabdar/ceo/agent_builder.py` | `AgentBuilder` |
| `n5::n10` (input/output manager, checkpoint loop) | `hesabdar/ceo/input_output_manager.py` | `InputOutputManager` |
| `n5` کل (ترکیب همه‌ی ۱۱ زیرگروه بالا) | `hesabdar/ceo/orchestrator.py` | `CEOAgentArchitecture` |

## Step 2

| Node(s) | فایل | کلاس/متد |
|---|---|---|
| `n14::n0` (tool manager — نقطه‌ی مرکزی مجوزدهی) | `hesabdar/tools/tool_manager.py` | `ToolManager` |
| `n14::n0::n6-n8` (bash command maker/compiler/runner) | `hesabdar/tools/bash_tool.py` | `BashTool` |
| `n14::n0::n15-n18` (file maker/reader/deleter/changer) | `hesabdar/tools/file_tool.py` | `FileTool` |
| `n14::n0::n0-n5` (excel command/vbs maker, file injector, reader/writer/maker) | `hesabdar/tools/excel_tool.py` | `ExcelTool` |
| `n14::n0::n9-n13` (chrome researcher/reader, page html exporter, api user, curl system) | `hesabdar/tools/web_tool.py` | `WebTool` |

## هنوز نساخته‌ایم (step 3+، طبق مستندات)

- `n1` data input, `n2` report maker, `n0` prompt architecture (Reporting & Analytics Pipeline — سند ۱۰)
- `n10` Accounting Domain Engine + `n11`/`n12` rule manager (سند ۵)
- `n8` final checker agent (Critic pattern — سند ۶)
- `n3` backup system, `n4` recovery system, `n5` (root) debugger system (Resilience — سند ۸)
