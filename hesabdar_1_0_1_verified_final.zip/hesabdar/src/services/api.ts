import type {
  Account,
  AccountingRule,
  BackupSnapshot,
  BenchmarkSuite,
  FinancialReport,
  PendingApproval,
  SuperLog,
  SystemStatus,
  Transaction,
} from '../types';

async function request<T>(endpoint: string, payload: Record<string, any> = {}): Promise<T> {
  const res = await fetch(`/api/${endpoint}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const errorText = await res.text();
    throw new Error(`API error (${res.status}): ${errorText || res.statusText}`);
  }

  return res.json();
}

export const api = {
  getStatus: () => request<SystemStatus>('status'),

  executeTask: (prompt: string, payload?: any) =>
    request<{ ok: boolean; result: any }>('execute_task', { prompt, payload }),

  postJournalEntry: (data: {
    description: string;
    lines: Array<{ account_id: string; debit: number | string; credit: number | string }>;
    idempotency_key?: string;
  }) =>
    request<{ ok: boolean; transaction_id?: string; error?: string }>('post_journal_entry', data),

  listAccounts: () =>
    request<{ ok: boolean; accounts: Account[] }>('list_accounts'),

  createAccount: (data: { name: string; account_type: string; code?: string }) =>
    request<{ ok: boolean; account_id?: string; error?: string }>('create_account', data),

  listTransactions: (limit = 50) =>
    request<{ ok: boolean; transactions: Transaction[] }>('list_transactions', { limit }),

  getAccountLedger: (accountId: string) =>
    request<{ ok: boolean; ledger: any }>('get_account_ledger', { account_id: accountId }),

  listRules: () =>
    request<{ ok: boolean; rules: AccountingRule[] }>('list_rules'),

  createRule: (data: {
    code?: string;
    name: string;
    description: string;
    category: string;
    priority?: number;
    debit_account_code: string;
    credit_account_code: string;
    disposition?: string;
  }) => request<{ ok: boolean; rule_id?: string; approval_id?: string; error?: string }>('create_rule', data),

  listSkills: () =>
    request<{ ok: boolean; skills: any[] }>('list_skills'),

  listAgents: () =>
    request<{ ok: boolean; agents: any[]; core_agents: any[] }>('list_agents'),

  listLogs: (limit = 50, errorsOnly = false) =>
    request<{ ok: boolean; logs: SuperLog[] }>('list_logs', { limit, errors_only: errorsOnly }),

  listApprovals: () =>
    request<{ ok: boolean; approvals: PendingApproval[] }>('list_approvals'),

  approveItem: (approvalId: string, approver = 'human_supervisor') =>
    request<{ ok: boolean; approval_id: string }>('approve_item', { approval_id: approvalId, approver }),

  rejectItem: (approvalId: string, reason = 'Rejected by supervisor') =>
    request<{ ok: boolean; approval_id: string }>('reject_item', { approval_id: approvalId, reason }),

  generateReport: (reportType: string) =>
    request<{ ok: boolean; report: FinancialReport }>('generate_report', { report_type: reportType }),

  createBackup: (label = 'Manual UI Snapshot') =>
    request<{ ok: boolean; snapshot: BackupSnapshot }>('create_backup', { label }),

  listBackups: () =>
    request<{ ok: boolean; backups: BackupSnapshot[] }>('list_backups'),

  restoreBackup: (backupId: string) =>
    request<{ ok: boolean; details?: string; error?: string }>('restore_backup', { backup_id: backupId }),

  triggerSelfHealing: (taskId = 'simulated_task', error = 'Database lock contention timeout') =>
    request<{ ok: boolean; healing_result: any }>('trigger_self_healing', { task_id: taskId, error }),

  runBenchmark: (tiers = [1, 2, 5, 10, 25]) =>
    request<{ ok: boolean; benchmark: BenchmarkSuite }>('run_benchmark', { tiers }),

  seedSampleData: () =>
    request<{ ok: boolean; seeded_count: number; message: string }>('seed_sample_data'),
};
