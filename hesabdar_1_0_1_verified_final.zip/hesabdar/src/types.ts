export type AccountCategory = 'asset' | 'liability' | 'equity' | 'revenue' | 'expense';

export interface Account {
  id: string;
  name: string;
  account_type: AccountCategory;
  category?: AccountCategory;
  code?: string;
  created_at: number;
  balance: string;
}

export interface TransactionLine {
  id?: string;
  transaction_id?: string;
  account_id: string;
  account_name?: string;
  account_type?: string;
  debit: string | number;
  credit: string | number;
}

export interface Transaction {
  id: string;
  description: string;
  created_at: number;
  source_message_id?: string;
  idempotency_key?: string;
  lines: TransactionLine[];
  total_amount: number;
}

export interface RuleCondition {
  field: string;
  operator: string;
  value: any;
}

export interface RuleAction {
  disposition: 'auto_post' | 'require_human_approval' | 'reject';
  debit_account_code?: string;
  credit_account_code?: string;
  tax_rate?: number;
  tax_account_code?: string;
}

export interface AccountingRule {
  id: string;
  code: string;
  name: string;
  description: string;
  category: string;
  scope: string;
  priority: number;
  status: 'active' | 'pending_approval' | 'disabled' | 'archived';
  conditions: RuleCondition[];
  action: RuleAction;
  created_by: string;
}

export interface PendingApproval {
  id: string;
  task_id: string;
  prompt: string;
  path_taken: string;
  reason: string;
  candidate_rule?: any;
  created_at: number;
  status: string;
}

export interface SuperLog {
  id: string;
  timestamp: number;
  task_id: string;
  agent_id: string;
  agent_role: string;
  prompt: string;
  output: string;
  has_error: boolean;
  error_message?: string;
}

export interface FinancialReport {
  id: string;
  report_type: 'trial_balance' | 'income_statement' | 'balance_sheet' | 'cash_flow' | 'expense_analysis';
  title: string;
  period: string;
  generated_at: number;
  summary: Record<string, any>;
  table_data: any[];
  chart_data: any[];
  identified_issues: string[];
  recommended_solutions: string[];
  forecast_projection: Record<string, any>;
  is_valid: boolean;
}

export interface BackupSnapshot {
  id: string;
  created_at: number;
  db_filename: string;
  sha256_hash: string;
  file_size_bytes: number;
  label: string;
  status: string;
}

export interface BenchmarkTierResult {
  agent_count: number;
  total_operations: number;
  total_duration_sec: number;
  throughput_ops_sec: number;
  p50_latency_ms: number;
  p95_latency_ms: number;
  p99_latency_ms: number;
  dedup_hit_rate_pct: number;
  errors_count: number;
  determinism_score_pct: number;
}

export interface BenchmarkSuite {
  timestamp: number;
  results: BenchmarkTierResult[];
  recovery_metrics: {
    backup_capture_ms: number;
    restore_time_ms: number;
    self_healing_time_ms: number;
  };
  system_summary: Record<string, any>;
}

export interface SystemStatus {
  ok: boolean;
  health: {
    status: string;
    ceo_identity: string;
    registered_agents: number;
    active_rules_count: number;
    db_health: {
      ok: boolean;
      detail: string;
      exists: boolean;
      path: string;
    };
    memory_store: {
      ok: boolean;
      total_memories: number;
    };
    pending_approvals_count: number;
    timestamp: number;
  };
  accounts_count: number;
  transactions_count: number;
  recent_logs: SuperLog[];
  pending_approvals: PendingApproval[];
}
