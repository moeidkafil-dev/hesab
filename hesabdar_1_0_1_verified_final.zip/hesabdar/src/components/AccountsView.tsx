import React, { useState } from 'react';
import {
  BookOpen,
  Filter,
  Layers,
  Plus,
  Search,
  TrendingDown,
  TrendingUp,
  X,
} from 'lucide-react';
import type { Account, AccountCategory } from '../types';

interface AccountsViewProps {
  accounts: Account[];
  onCreateAccount: (data: { name: string; account_type: string; code?: string }) => Promise<boolean>;
  onViewLedger: (accountId: string) => void;
  selectedLedger: any | null;
  onCloseLedger: () => void;
  isLoadingLedger: boolean;
}

export const AccountsView: React.FC<AccountsViewProps> = ({
  accounts,
  onCreateAccount,
  onViewLedger,
  selectedLedger,
  onCloseLedger,
  isLoadingLedger,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);

  // New Account Form
  const [newName, setNewName] = useState('');
  const [newType, setNewType] = useState<AccountCategory>('asset');
  const [newCode, setNewCode] = useState('');
  const [modalError, setModalError] = useState<string | null>(null);

  const categories: Array<{ id: string; label: string; count: number }> = [
    { id: 'all', label: 'همه حساب‌ها', count: accounts.length },
    { id: 'asset', label: 'دارایی‌ها (Asset)', count: accounts.filter((a) => a.account_type === 'asset').length },
    { id: 'liability', label: 'بدهی‌ها (Liability)', count: accounts.filter((a) => a.account_type === 'liability').length },
    { id: 'equity', label: 'حقوق صاحبان سهام (Equity)', count: accounts.filter((a) => a.account_type === 'equity').length },
    { id: 'revenue', label: 'درآمدها (Revenue)', count: accounts.filter((a) => a.account_type === 'revenue').length },
    { id: 'expense', label: 'هزینه‌ها (Expense)', count: accounts.filter((a) => a.account_type === 'expense').length },
  ];

  const filteredAccounts = accounts.filter((acc) => {
    const matchSearch =
      acc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      acc.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchCategory = selectedCategory === 'all' || acc.account_type === selectedCategory;
    return matchSearch && matchCategory;
  });

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setModalError(null);
    if (!newName.trim()) {
      setModalError('نام حساب الزامی است');
      return;
    }

    try {
      const ok = await onCreateAccount({
        name: newName,
        account_type: newType,
        code: newCode ? `acc_${newCode}` : undefined,
      });
      if (ok) {
        setShowAddModal(false);
        setNewName('');
        setNewCode('');
      }
    } catch (err: any) {
      setModalError(err.message || 'خطا در ایجاد حساب');
    }
  };

  const getCategoryBadgeColor = (type: string) => {
    switch (type) {
      case 'asset':
        return 'bg-blue-500/10 text-blue-300 border-blue-500/30';
      case 'liability':
        return 'bg-amber-500/10 text-amber-300 border-amber-500/30';
      case 'equity':
        return 'bg-purple-500/10 text-purple-300 border-purple-500/30';
      case 'revenue':
        return 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30';
      case 'expense':
        return 'bg-rose-500/10 text-rose-300 border-rose-500/30';
      default:
        return 'bg-gray-500/10 text-gray-300 border-gray-500/30';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#131826] border border-gray-800 p-4 rounded-xl">
        <div className="space-y-1">
          <h2 className="text-sm font-semibold text-white flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-emerald-400" />
            <span>جدول کدینگ حساب‌ها و دفتر کل (Chart of Accounts)</span>
          </h2>
          <p className="text-xs text-gray-400">
            سرفصل‌های استاندارد با محاسبه لحظه‌ای مانده از خطوط آرتیکل دفتر
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-emerald-950 bg-emerald-400 hover:bg-emerald-300 rounded-md transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>افزودن سرفصل حساب جدید</span>
        </button>
      </div>

      {/* Category Filter Pills & Search */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCategory(c.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors flex items-center gap-1.5 ${
                selectedCategory === c.id
                  ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40'
                  : 'bg-[#131826] text-gray-400 hover:text-gray-200 border-gray-800'
              }`}
            >
              <span>{c.label}</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-gray-800 text-gray-400 font-mono">
                {c.count}
              </span>
            </button>
          ))}
        </div>

        <div className="relative">
          <Search className="w-4 h-4 text-gray-500 absolute right-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="جستجو در کد یا عنوان سرفصل حساب..."
            className="w-full bg-[#131826] border border-gray-800 rounded-lg py-2 pr-9 pl-4 text-xs text-gray-200 placeholder-gray-500 focus:outline-none focus:border-emerald-500/50"
          />
        </div>
      </div>

      {/* Accounts Table */}
      <div className="bg-[#131826] border border-gray-800 rounded-xl overflow-hidden shadow-sm">
        <table className="w-full text-right text-xs">
          <thead className="bg-[#0c0f17] text-gray-400 border-b border-gray-800">
            <tr>
              <th className="py-3 px-4 font-medium">کد حساب</th>
              <th className="py-3 px-4 font-medium">عنوان سرفصل حساب</th>
              <th className="py-3 px-4 font-medium">گروه / طبقه حساب</th>
              <th className="py-3 px-4 font-medium text-left">مانده حساب (Balance) - ریال</th>
              <th className="py-3 px-4 font-medium text-center">گردش دفتر (Ledger)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-800/80">
            {filteredAccounts.length === 0 ? (
              <tr>
                <td colSpan={5} className="py-8 text-center text-gray-500 text-xs">
                  هیچ حسابی مطابق با این فیلتر یافت نشد.
                </td>
              </tr>
            ) : (
              filteredAccounts.map((acc) => {
                const balNum = parseFloat(acc.balance) || 0;
                return (
                  <tr key={acc.id} className="hover:bg-gray-800/30 transition-colors">
                    <td className="py-3 px-4 font-mono text-gray-400 font-medium">
                      {acc.id}
                    </td>
                    <td className="py-3 px-4 font-medium text-gray-200">
                      {acc.name}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-block text-[11px] px-2.5 py-0.5 rounded-full border font-medium ${getCategoryBadgeColor(
                          acc.account_type
                        )}`}
                      >
                        {acc.account_type}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono text-left font-semibold">
                      <span className={balNum > 0 ? 'text-emerald-400' : balNum < 0 ? 'text-rose-400' : 'text-gray-400'}>
                        {balNum.toLocaleString()}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() => onViewLedger(acc.id)}
                        className="text-xs text-blue-400 hover:text-blue-300 px-2.5 py-1 rounded bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/30 transition-colors"
                      >
                        مشاهده گردش
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Account Ledger Modal Drilldown */}
      {selectedLedger && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="bg-[#131826] border border-gray-800 rounded-xl w-full max-w-4xl max-h-[85vh] flex flex-col shadow-2xl">
            <div className="flex items-center justify-between p-4 border-b border-gray-800">
              <div className="space-y-0.5">
                <h3 className="text-sm font-semibold text-white">
                  ریز گردش حساب (Account Ledger Detail): {selectedLedger.account?.name}
                </h3>
                <div className="text-xs text-gray-400 font-mono">
                  کد: {selectedLedger.account?.id} • مانده نهایی: {parseFloat(selectedLedger.current_balance || '0').toLocaleString()} ریال
                </div>
              </div>
              <button
                onClick={onCloseLedger}
                className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-gray-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 overflow-y-auto flex-1">
              {!selectedLedger.entries || selectedLedger.entries.length === 0 ? (
                <div className="text-center py-12 text-gray-500 text-xs">
                  هیچ تراکنشی در این سرفصل ثبت نشده است (مانده صفر).
                </div>
              ) : (
                <table className="w-full text-right text-xs">
                  <thead className="bg-[#0c0f17] text-gray-400 border-b border-gray-800">
                    <tr>
                      <th className="py-2.5 px-3 font-medium">تاریخ</th>
                      <th className="py-2.5 px-3 font-medium">شرح رویداد مالی</th>
                      <th className="py-2.5 px-3 font-medium text-left">بدهکار</th>
                      <th className="py-2.5 px-3 font-medium text-left">بستانکار</th>
                      <th className="py-2.5 px-3 font-medium text-left">مانده متوالی</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-800/80">
                    {selectedLedger.entries.map((ent: any) => (
                      <tr key={ent.line_id} className="hover:bg-gray-800/20">
                        <td className="py-2.5 px-3 font-mono text-gray-500">
                          {new Date(ent.date * 1000).toLocaleDateString('fa-IR')}
                        </td>
                        <td className="py-2.5 px-3 text-gray-200">{ent.description}</td>
                        <td className="py-2.5 px-3 font-mono text-emerald-400 text-left">
                          {ent.debit > 0 ? ent.debit.toLocaleString() : '-'}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-purple-400 text-left">
                          {ent.credit > 0 ? ent.credit.toLocaleString() : '-'}
                        </td>
                        <td className="py-2.5 px-3 font-mono font-semibold text-gray-100 text-left">
                          {ent.running_balance.toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Add Account Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="bg-[#131826] border border-gray-800 rounded-xl w-full max-w-md p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-gray-800">
              <h3 className="text-sm font-semibold text-white">افزودن سرفصل حساب جدید</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-gray-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-medium text-gray-300">عنوان حساب:</label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="مثال: حساب ارزی بانک سامان"
                  className="w-full bg-[#0c0f17] border border-gray-700 rounded-lg p-2.5 text-xs text-gray-200 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-medium text-gray-300">طبقه سرفصل:</label>
                <select
                  value={newType}
                  onChange={(e) => setNewType(e.target.value as AccountCategory)}
                  className="w-full bg-[#0c0f17] border border-gray-700 rounded-lg p-2.5 text-xs text-gray-200 focus:outline-none focus:border-emerald-500"
                >
                  <option value="asset">دارایی (Asset)</option>
                  <option value="liability">بدهی (Liability)</option>
                  <option value="equity">حقوق صاحبان سهام (Equity)</option>
                  <option value="revenue">درآمد (Revenue)</option>
                  <option value="expense">هزینه (Expense)</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-medium text-gray-300">کد اختیاری:</label>
                <input
                  type="text"
                  value={newCode}
                  onChange={(e) => setNewCode(e.target.value)}
                  placeholder="مثال: 1015"
                  className="w-full bg-[#0c0f17] border border-gray-700 rounded-lg p-2.5 text-xs text-gray-200 font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>

              {modalError && (
                <div className="text-xs text-rose-400 bg-rose-500/10 p-2 rounded border border-rose-500/30">
                  {modalError}
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3.5 py-1.5 text-xs text-gray-400 hover:text-gray-200 rounded-md"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold text-emerald-950 bg-emerald-400 hover:bg-emerald-300 rounded-md"
                >
                  ایجاد حساب
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
