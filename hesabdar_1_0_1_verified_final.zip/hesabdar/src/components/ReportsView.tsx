import React, { useState, useEffect } from 'react';
import {
  AlertTriangle,
  ArrowDownToLine,
  CheckCircle2,
  FileSpreadsheet,
  LineChart,
  PieChart,
  Printer,
  RefreshCw,
  TrendingUp,
} from 'lucide-react';
import type { FinancialReport } from '../types';

interface ReportsViewProps {
  onGenerateReport: (type: string) => Promise<FinancialReport>;
}

export const ReportsView: React.FC<ReportsViewProps> = ({ onGenerateReport }) => {
  const [selectedType, setSelectedType] = useState<string>('trial_balance');
  const [report, setReport] = useState<FinancialReport | null>(null);
  const [loading, setLoading] = useState(false);

  const reportTypes = [
    { id: 'trial_balance', label: 'تراز آزمایشی (Trial Balance)' },
    { id: 'income_statement', label: 'صورت سود و زیان (Income Statement / P&L)' },
    { id: 'balance_sheet', label: 'ترازنامه مالی (Balance Sheet)' },
    { id: 'cash_flow', label: 'صورت جریان وجوه نقد (Cash Flow)' },
    { id: 'expense_analysis', label: 'تحلیل و تفکیک هزینه‌ها (Expense Breakdown)' },
  ];

  const fetchReport = async (type: string) => {
    setLoading(true);
    try {
      const rep = await onGenerateReport(type);
      setReport(rep);
    } catch (e) {
      console.error('Report fetch error:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReport(selectedType);
  }, [selectedType]);

  const handleExportJSON = () => {
    if (!report) return;
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${report.report_type}_report_${Date.now()}.json`;
    a.click();
  };

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#131826] border border-gray-800 p-4 rounded-xl">
        <div className="space-y-1">
          <h2 className="text-sm font-semibold text-white flex items-center gap-2">
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>گزارش‌ها و صورت‌های مالی قانونی (Financial Statements)</span>
          </h2>
          <p className="text-xs text-gray-400">
            محاسبه قطعی و استاندارد از پایگاه داده دفتر کل با تضمین تراز ریاضی
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => fetchReport(selectedType)}
            disabled={loading}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-gray-300 bg-gray-800/80 hover:bg-gray-700 rounded-md border border-gray-700/60"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>بروزرسانی</span>
          </button>
          <button
            onClick={handleExportJSON}
            disabled={!report}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-950 bg-emerald-400 hover:bg-emerald-300 rounded-md shadow-sm"
          >
            <ArrowDownToLine className="w-3.5 h-3.5" />
            <span>خروجی JSON / داده</span>
          </button>
        </div>
      </div>

      {/* Report Tabs */}
      <div className="flex flex-wrap items-center gap-2">
        {reportTypes.map((rt) => (
          <button
            key={rt.id}
            onClick={() => setSelectedType(rt.id)}
            className={`px-3.5 py-2 text-xs font-medium rounded-lg border transition-colors ${
              selectedType === rt.id
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                : 'bg-[#131826] text-gray-400 hover:text-gray-200 border-gray-800'
            }`}
          >
            {rt.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="bg-[#131826] border border-gray-800 rounded-xl p-16 flex flex-col items-center justify-center text-center space-y-3">
          <div className="w-8 h-8 border-3 border-emerald-400 border-t-transparent rounded-full animate-spin" />
          <div className="text-xs text-gray-400 font-mono">در حال استخراج و اعتبارسنجی صورت مالی از دفتر کل...</div>
        </div>
      ) : !report ? (
        <div className="bg-[#131826] border border-gray-800 rounded-xl p-12 text-center text-gray-500 text-xs">
          گزارشی دریافت نشد.
        </div>
      ) : (
        <div className="space-y-6">
          {/* Summary KPI Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {Object.entries(report.summary).map(([key, val]) => (
              <div
                key={key}
                className="bg-[#131826] border border-gray-800 rounded-xl p-4 space-y-1"
              >
                <div className="text-xs text-gray-400 capitalize">
                  {key.replace(/_/g, ' ')}
                </div>
                <div className="text-lg font-bold text-white font-mono">
                  {typeof val === 'number'
                    ? val.toLocaleString() + (key.includes('pct') ? ' %' : ' ریال')
                    : typeof val === 'boolean'
                    ? val
                      ? '✓ تایید شده'
                      : '✕ عدم توازن'
                    : String(val)}
                </div>
              </div>
            ))}
          </div>

          {/* Report Main Content Table */}
          <div className="bg-[#131826] border border-gray-800 rounded-xl p-5 space-y-4 shadow-sm">
            <div className="flex items-center justify-between border-b border-gray-800 pb-3">
              <div>
                <h3 className="text-sm font-semibold text-white">{report.title}</h3>
                <div className="text-xs text-gray-400">دوره مالی: {report.period}</div>
              </div>
              <div className="flex items-center gap-2">
                {report.is_valid ? (
                  <span className="flex items-center gap-1 text-[11px] px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 font-medium">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>ترازنامه و فرمول حسابداری معتبر است</span>
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-[11px] px-2.5 py-1 rounded-full bg-rose-500/15 text-rose-300 border border-rose-500/30 font-medium">
                    <AlertTriangle className="w-3 h-3" />
                    <span>عدم انطباق تراز</span>
                  </span>
                )}
              </div>
            </div>

            {/* Render according to structure */}
            {selectedType === 'trial_balance' ? (
              <table className="w-full text-right text-xs">
                <thead className="bg-[#0c0f17] text-gray-400 border-b border-gray-800">
                  <tr>
                    <th className="py-2.5 px-3 font-medium">کد حساب</th>
                    <th className="py-2.5 px-3 font-medium">نام سرفصل</th>
                    <th className="py-2.5 px-3 font-medium">طبقه</th>
                    <th className="py-2.5 px-3 font-medium text-left">گردش بدهکار (Debit)</th>
                    <th className="py-2.5 px-3 font-medium text-left">گردش بستانکار (Credit)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-800/80">
                  {report.table_data.map((row: any, idx: number) => (
                    <tr key={idx} className="hover:bg-gray-800/20">
                      <td className="py-2 px-3 font-mono text-gray-400">{row.code}</td>
                      <td className="py-2 px-3 text-gray-200">{row.name}</td>
                      <td className="py-2 px-3 text-gray-400">{row.category}</td>
                      <td className="py-2 px-3 font-mono text-emerald-400 text-left">
                        {row.debit > 0 ? row.debit.toLocaleString() : '-'}
                      </td>
                      <td className="py-2 px-3 font-mono text-purple-400 text-left">
                        {row.credit > 0 ? row.credit.toLocaleString() : '-'}
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="bg-[#0c0f17] font-mono text-xs font-bold border-t border-gray-800">
                  <tr>
                    <td colSpan={3} className="py-3 px-3 font-sans text-gray-200">
                      مجموع کل تراز آزمایشی:
                    </td>
                    <td className="py-3 px-3 text-emerald-400 text-left">
                      {report.summary.total_debit?.toLocaleString()}
                    </td>
                    <td className="py-3 px-3 text-purple-400 text-left">
                      {report.summary.total_credit?.toLocaleString()}
                    </td>
                  </tr>
                </tfoot>
              </table>
            ) : (
              <div className="space-y-6">
                {report.table_data.map((section: any, idx: number) => (
                  <div key={idx} className="space-y-2">
                    <div className="flex items-center justify-between text-xs font-semibold text-emerald-300 bg-emerald-950/30 p-2.5 rounded-lg border border-emerald-800/40">
                      <span>{section.section}</span>
                      <span className="font-mono text-white">
                        {section.subtotal?.toLocaleString() || section.total?.toLocaleString()} ریال
                      </span>
                    </div>

                    <div className="border border-gray-800 rounded-lg overflow-hidden">
                      <table className="w-full text-right text-xs">
                        <tbody className="divide-y divide-gray-800/60 bg-[#131826]">
                          {section.items?.map((item: any, iIdx: number) => (
                            <tr key={iIdx} className="hover:bg-gray-800/20">
                              <td className="py-2 px-3 text-gray-300">{item.name}</td>
                              <td className="py-2 px-3 font-mono text-left text-gray-100">
                                {item.amount?.toLocaleString()} ریال
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Forecasting & Solutions Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-[#131826] border border-gray-800 rounded-xl p-4 space-y-2">
              <div className="flex items-center gap-2 text-xs font-semibold text-blue-400">
                <TrendingUp className="w-4 h-4" />
                <span>موتور پیش‌بینی مالی (Financial Forecasting Engine n1::n2)</span>
              </div>
              <div className="grid grid-cols-3 gap-2 pt-2">
                {Object.entries(report.forecast_projection || {}).map(([m, v]) => (
                  <div key={m} className="bg-[#0c0f17] p-2.5 rounded-lg border border-gray-800 text-center space-y-1">
                    <div className="text-[10px] text-gray-400 font-mono">{m.replace(/_/g, ' ')}</div>
                    <div className="text-xs font-bold text-white font-mono">
                      {typeof v === 'number' ? v.toLocaleString() : String(v)}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-[#131826] border border-gray-800 rounded-xl p-4 space-y-2">
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
                <CheckCircle2 className="w-4 h-4" />
                <span>راهکارهای پیشنهادی هوش مصنوعی (Solution Maker n1::n4)</span>
              </div>
              <ul className="space-y-1.5 pt-1 text-xs text-gray-300">
                {report.recommended_solutions?.map((sol, idx) => (
                  <li key={idx} className="flex items-start gap-2 bg-[#0c0f17] p-2 rounded-lg border border-gray-800">
                    <span className="text-emerald-400 font-bold">•</span>
                    <span>{sol}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
