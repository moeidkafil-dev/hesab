import React, { useState } from 'react';
import {
  Activity,
  AlertOctagon,
  ArrowDownToLine,
  CheckCircle2,
  Database,
  Play,
  RotateCcw,
  Shield,
  ShieldCheck,
  Wrench,
  Zap,
} from 'lucide-react';
import type { BackupSnapshot, BenchmarkSuite } from '../types';

interface ResilienceViewProps {
  backups: BackupSnapshot[];
  onCreateBackup: (label: string) => Promise<boolean>;
  onRestoreBackup: (id: string) => Promise<boolean>;
  onTriggerSelfHealing: () => Promise<any>;
  onRunBenchmark: () => Promise<BenchmarkSuite>;
}

export const ResilienceView: React.FC<ResilienceViewProps> = ({
  backups,
  onCreateBackup,
  onRestoreBackup,
  onTriggerSelfHealing,
  onRunBenchmark,
}) => {
  const [backupLabel, setBackupLabel] = useState('');
  const [isCreatingBackup, setIsCreatingBackup] = useState(false);
  const [isRestoring, setIsRestoring] = useState<string | null>(null);

  // Self healing state
  const [isHealing, setIsHealing] = useState(false);
  const [healingResult, setHealingResult] = useState<any>(null);

  // Benchmark state
  const [isRunningBench, setIsRunningBench] = useState(false);
  const [benchSuite, setBenchSuite] = useState<BenchmarkSuite | null>(null);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isCreatingBackup) return;
    setIsCreatingBackup(true);
    try {
      await onCreateBackup(backupLabel || 'Manual Production Snapshot');
      setBackupLabel('');
    } finally {
      setIsCreatingBackup(false);
    }
  };

  const handleRestore = async (id: string) => {
    if (!window.confirm('آیا از بازیابی این نسخه پشتیبان اطمینان دارید؟ نسخه فعلی به قرنطینه منتقل خواهد شد.')) return;
    setIsRestoring(id);
    try {
      await onRestoreBackup(id);
    } finally {
      setIsRestoring(null);
    }
  };

  const handleRunHealing = async () => {
    setIsHealing(true);
    try {
      const res = await onTriggerSelfHealing();
      setHealingResult(res);
    } finally {
      setIsHealing(false);
    }
  };

  const handleRunBenchmark = async () => {
    setIsRunningBench(true);
    try {
      const suite = await onRunBenchmark();
      setBenchSuite(suite);
    } finally {
      setIsRunningBench(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#131826] border border-gray-800 p-4 rounded-xl space-y-1">
        <h2 className="text-sm font-semibold text-white flex items-center gap-2">
          <Shield className="w-4 h-4 text-emerald-400" />
          <span>مرکز تاب‌آوری، پشتیبان‌گیری و بنچمارک مقیاس‌پذیری (Resilience & Benchmarks)</span>
        </h2>
        <p className="text-xs text-gray-400">
          پشتیبان‌گیری رمزنگاری شده با هش SHA-256، خودترمیمی خطاها و ارزیابی عملیاتی تحت بار
        </p>
      </div>

      {/* Grid: Backups & Self-Healing */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Automated Backups Manager */}
        <div className="lg:col-span-7 bg-[#131826] border border-gray-800 rounded-xl p-5 space-y-4 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm font-semibold text-white">
              <Database className="w-4 h-4 text-emerald-400" />
              <span>پشتیبان‌گیری و بازیابی پایگاه داده (Zero-Data-Loss Snapshots)</span>
            </div>
            <span className="text-xs text-gray-500 font-mono">SHA-256 Manifest</span>
          </div>

          <form onSubmit={handleCreate} className="flex gap-2">
            <input
              type="text"
              value={backupLabel}
              onChange={(e) => setBackupLabel(e.target.value)}
              placeholder="برچسب یا عنوان نسخه پشتیبان..."
              className="flex-1 bg-[#0c0f17] border border-gray-700 rounded-lg py-2 px-3 text-xs text-gray-200 placeholder-gray-500 focus:outline-none focus:border-emerald-500"
            />
            <button
              type="submit"
              disabled={isCreatingBackup}
              className="px-4 py-2 text-xs font-semibold text-emerald-950 bg-emerald-400 hover:bg-emerald-300 rounded-md transition-colors disabled:opacity-50 shrink-0"
            >
              {isCreatingBackup ? 'در حال ثبت...' : 'ایجاد نسخه پشتیبان'}
            </button>
          </form>

          <div className="border border-gray-800 rounded-lg overflow-hidden">
            <table className="w-full text-right text-xs">
              <thead className="bg-[#0c0f17] text-gray-400 border-b border-gray-800">
                <tr>
                  <th className="py-2.5 px-3 font-medium">تاریخ و زمان</th>
                  <th className="py-2.5 px-3 font-medium">برچسب</th>
                  <th className="py-2.5 px-3 font-medium font-mono text-left">هش SHA-256</th>
                  <th className="py-2.5 px-3 font-medium text-center">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800/80 bg-[#131826]">
                {backups.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="py-8 text-center text-gray-500 text-xs">
                      هیچ نسخه پشتیبانی ثبت نشده است.
                    </td>
                  </tr>
                ) : (
                  backups.map((b) => (
                    <tr key={b.id} className="hover:bg-gray-800/20">
                      <td className="py-2.5 px-3 text-gray-400 font-mono">
                        {new Date(b.created_at * 1000).toLocaleTimeString('fa-IR')}
                      </td>
                      <td className="py-2.5 px-3 font-medium text-gray-200">{b.label}</td>
                      <td className="py-2.5 px-3 font-mono text-gray-500 text-[11px] text-left">
                        {b.sha256_hash ? b.sha256_hash.substring(0, 14) + '...' : 'Verified'}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <button
                          onClick={() => handleRestore(b.id)}
                          disabled={isRestoring === b.id}
                          className="flex items-center gap-1 mx-auto text-xs text-amber-400 hover:text-amber-300 px-2 py-1 rounded bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 transition-colors disabled:opacity-50"
                        >
                          <RotateCcw className="w-3 h-3" />
                          <span>{isRestoring === b.id ? 'بازیابی...' : 'بازیابی'}</span>
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Self-Healing System */}
        <div className="lg:col-span-5 bg-[#131826] border border-gray-800 rounded-xl p-5 space-y-4 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm font-semibold text-white">
              <Wrench className="w-4 h-4 text-blue-400" />
              <span>موتور خودترمیمی (Self-Healing Subsystem)</span>
            </div>
            <span className="text-xs text-emerald-400 font-mono">Bounded Retry Engine</span>
          </div>

          <p className="text-xs text-gray-400 leading-relaxed">
            سیستم دارای تشخیص هوشمند خطاهای پایگاه داده و بن‌بست‌های همزمانی با استراتژی Exponential Backoff و بازیابی قطعی است.
          </p>

          <button
            onClick={handleRunHealing}
            disabled={isHealing}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 text-xs font-semibold text-blue-950 bg-blue-400 hover:bg-blue-300 rounded-lg transition-colors disabled:opacity-50 shadow-sm"
          >
            <Play className="w-3.5 h-3.5" />
            <span>{isHealing ? 'در حال شبیه‌سازی و تشخیص...' : 'شبیه‌سازی خودترمیمی خطا (Simulate Self-Healing)'}</span>
          </button>

          {healingResult && (
            <div className="bg-[#0c0f17] border border-gray-800 rounded-lg p-3 space-y-2 text-xs font-mono">
              <div className="flex items-center justify-between text-gray-400 font-sans">
                <span className="font-semibold">نتیجه تشخیص و ترمیم:</span>
                <span className="text-emerald-400">✓ HEALED</span>
              </div>
              <div className="text-gray-300">
                Action:{' '}
                <span className="text-blue-300">
                  {healingResult.healing_result?.action_taken || 'exponential_backoff_retry'}
                </span>
              </div>
              <div className="text-gray-500 text-[11px]">
                {healingResult.healing_result?.diagnosis || 'Transient connection contention resolved.'}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Multi-Tier Scale Benchmark Suite */}
      <div className="bg-[#131826] border border-gray-800 rounded-xl p-5 space-y-4 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <Activity className="w-4 h-4 text-amber-400" />
              <span>آزمون مقیاس‌پذیری و بار همزمان عامل‌ها (Multi-Agent Concurrency Benchmark)</span>
            </h3>
            <p className="text-xs text-gray-400">
              ارزیابی تاخیر p50/p95/p99، توان پردازش بر ثانیه (Ops/Sec) و تضمین ۱۰۰٪ توازن ریاضی
            </p>
          </div>

          <button
            onClick={handleRunBenchmark}
            disabled={isRunningBench}
            className="flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-emerald-950 bg-emerald-400 hover:bg-emerald-300 rounded-md transition-colors disabled:opacity-50 shrink-0 shadow-sm"
          >
            {isRunningBench ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-emerald-950 border-t-transparent rounded-full animate-spin" />
                <span>در حال اجرای آزمون مقیاس...</span>
              </>
            ) : (
              <>
                <Zap className="w-3.5 h-3.5" />
                <span>اجرای آزمون بنچمارک مقیاس</span>
              </>
            )}
          </button>
        </div>

        {benchSuite && (
          <div className="space-y-4 pt-2">
            {/* Timing KPI */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="bg-[#0c0f17] border border-gray-800 rounded-lg p-3 text-center space-y-1">
                <div className="text-[11px] text-gray-400">سرعت ثبت پشتیبان کامل</div>
                <div className="text-sm font-bold text-white font-mono">
                  {benchSuite.recovery_metrics?.backup_capture_ms} ms
                </div>
              </div>
              <div className="bg-[#0c0f17] border border-gray-800 rounded-lg p-3 text-center space-y-1">
                <div className="text-[11px] text-gray-400">سرعت بازیابی پایگاه داده</div>
                <div className="text-sm font-bold text-emerald-400 font-mono">
                  {benchSuite.recovery_metrics?.restore_time_ms} ms
                </div>
              </div>
              <div className="bg-[#0c0f17] border border-gray-800 rounded-lg p-3 text-center space-y-1">
                <div className="text-[11px] text-gray-400">سرعت تشخیص خودترمیمی</div>
                <div className="text-sm font-bold text-blue-400 font-mono">
                  {benchSuite.recovery_metrics?.self_healing_time_ms} ms
                </div>
              </div>
            </div>

            {/* Results Table */}
            <div className="border border-gray-800 rounded-lg overflow-hidden">
              <table className="w-full text-right text-xs">
                <thead className="bg-[#0c0f17] text-gray-400 border-b border-gray-800 font-mono">
                  <tr>
                    <th className="py-2.5 px-3 font-medium">تعداد عامل‌های همزمان</th>
                    <th className="py-2.5 px-3 font-medium text-left">کل عملیات</th>
                    <th className="py-2.5 px-3 font-medium text-left">توان عملیاتی (Ops/Sec)</th>
                    <th className="py-2.5 px-3 font-medium text-left">تاخیر p50</th>
                    <th className="py-2.5 px-3 font-medium text-left">تاخیر p95</th>
                    <th className="py-2.5 px-3 font-medium text-left">تاخیر p99</th>
                    <th className="py-2.5 px-3 font-medium text-left">نرخ حذف تکراری (Dedup)</th>
                    <th className="py-2.5 px-3 font-medium text-center">نمره قطعیت (Determinism)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-800/80 bg-[#131826] font-mono">
                  {benchSuite.results.map((r, idx) => (
                    <tr key={idx} className="hover:bg-gray-800/20">
                      <td className="py-2.5 px-3 font-bold text-gray-100">
                        {r.agent_count} Concurrent Agents
                      </td>
                      <td className="py-2.5 px-3 text-gray-300 text-left">{r.total_operations}</td>
                      <td className="py-2.5 px-3 font-bold text-emerald-400 text-left">
                        {r.throughput_ops_sec} ops/s
                      </td>
                      <td className="py-2.5 px-3 text-gray-300 text-left">{r.p50_latency_ms} ms</td>
                      <td className="py-2.5 px-3 text-gray-300 text-left">{r.p95_latency_ms} ms</td>
                      <td className="py-2.5 px-3 text-gray-300 text-left">{r.p99_latency_ms} ms</td>
                      <td className="py-2.5 px-3 text-blue-400 text-left">{r.dedup_hit_rate_pct}%</td>
                      <td className="py-2.5 px-3 text-center">
                        <span className="inline-block px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 text-[11px] font-semibold">
                          {r.determinism_score_pct}% Invariant
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
