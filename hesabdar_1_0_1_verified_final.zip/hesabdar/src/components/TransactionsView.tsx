import React, { useState } from 'react';
import {
  ArrowDownToLine,
  CheckCircle2,
  FileSpreadsheet,
  Filter,
  Layers,
  Search,
} from 'lucide-react';
import type { Transaction } from '../types';

interface TransactionsViewProps {
  transactions: Transaction[];
  onRefresh: () => void;
}

export const TransactionsView: React.FC<TransactionsViewProps> = ({ transactions, onRefresh }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filtered = transactions.filter((t) => {
    const descMatch = t.description.toLowerCase().includes(searchTerm.toLowerCase());
    const idMatch = t.id.toLowerCase().includes(searchTerm.toLowerCase());
    return descMatch || idMatch;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#131826] border border-gray-800 p-4 rounded-xl">
        <div className="space-y-1">
          <h2 className="text-sm font-semibold text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-emerald-400" />
            <span>دفتر روزنامه و اسناد حسابداری (Authoritative General Journal)</span>
          </h2>
          <p className="text-xs text-gray-400">
            تراکنش‌های قطعی ثبت شده در پایگاه داده با سطور تفکیکی بدهکار و بستانکار
          </p>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-gray-500 absolute right-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="جستجو در شرح یا شناسه سند..."
            className="w-full bg-[#0c0f17] border border-gray-700/80 rounded-lg py-2 pr-9 pl-3 text-xs text-gray-200 placeholder-gray-500 focus:outline-none focus:border-emerald-500"
          />
        </div>
      </div>

      {/* Transactions List */}
      <div className="space-y-4">
        {filtered.length === 0 ? (
          <div className="bg-[#131826] border border-gray-800 rounded-xl p-12 text-center text-gray-500 text-xs">
            هیچ سند حسابی یافت نشد.
          </div>
        ) : (
          filtered.map((txn) => (
            <div
              key={txn.id}
              className="bg-[#131826] border border-gray-800 rounded-xl overflow-hidden shadow-sm space-y-2"
            >
              {/* Transaction Header */}
              <div className="bg-[#0c0f17] p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-gray-800/80">
                <div className="space-y-0.5">
                  <div className="text-xs font-semibold text-gray-100 flex items-center gap-2">
                    <span>{txn.description}</span>
                    <span className="text-[10px] font-mono px-2 py-0.2 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                      POSTED
                    </span>
                  </div>
                  <div className="text-[11px] text-gray-500 font-mono">
                    ID: {txn.id} • تاریخ: {new Date(txn.created_at * 1000).toLocaleString('fa-IR')}
                    {txn.idempotency_key && (
                      <span className="mr-2 text-gray-600">| Key: {txn.idempotency_key}</span>
                    )}
                  </div>
                </div>

                <div className="text-left font-mono">
                  <div className="text-xs font-bold text-emerald-400">
                    {txn.total_amount?.toLocaleString()} <span className="text-[10px] text-gray-400">ریال</span>
                  </div>
                  <div className="text-[10px] text-gray-500">تراز دوطرفه ۱۰۰٪</div>
                </div>
              </div>

              {/* Transaction Lines */}
              <div className="p-3">
                <table className="w-full text-right text-xs">
                  <thead className="text-gray-500 text-[11px] border-b border-gray-800/60">
                    <tr>
                      <th className="pb-1.5 font-normal">کد و عنوان حساب</th>
                      <th className="pb-1.5 font-normal">طبقه</th>
                      <th className="pb-1.5 font-normal text-left font-mono">بدهکار (Debit)</th>
                      <th className="pb-1.5 font-normal text-left font-mono">بستانکار (Credit)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-800/40">
                    {txn.lines?.map((line, lIdx) => {
                      const deb = parseFloat(String(line.debit)) || 0;
                      const cred = parseFloat(String(line.credit)) || 0;
                      return (
                        <tr key={lIdx} className="hover:bg-gray-800/10">
                          <td className="py-2 text-gray-300 font-medium">
                            {line.account_name || line.account_id}
                          </td>
                          <td className="py-2 text-gray-500 text-[11px]">
                            {line.account_type || 'asset'}
                          </td>
                          <td className="py-2 font-mono text-left text-emerald-400">
                            {deb > 0 ? deb.toLocaleString() : '-'}
                          </td>
                          <td className="py-2 font-mono text-left text-purple-400">
                            {cred > 0 ? cred.toLocaleString() : '-'}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
