import React from 'react';
import { Database, ShieldCheck, Sparkles, RefreshCw } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  pendingApprovalsCount: number;
  onSeedData: () => void;
  onQuickBackup: () => void;
  isSeeding: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  pendingApprovalsCount,
  onSeedData,
  onQuickBackup,
  isSeeding,
}) => {
  const navItems = [
    { id: 'dashboard', label: 'پیشخوان / Overview' },
    { id: 'desk', label: 'میز کار اسناد / Desk' },
    { id: 'accounts', label: 'کدینگ و دفاتر / Ledger' },
    { id: 'reports', label: 'صورت‌های مالی / Reports' },
    { id: 'rules', label: 'قوانین و عامل‌ها / Agents' },
    { id: 'resilience', label: 'تاب‌آوری و بنچمارک / Ops' },
  ];

  return (
    <header className="sticky top-0 z-50 bg-[#0f1422] border-b border-gray-800/80 px-4 lg:px-8 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Brand Zone */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-9 h-9 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold text-lg">
            ح
          </div>
          <span className="font-semibold text-lg tracking-tight text-white whitespace-nowrap">
            HESABDAR <span className="text-xs font-normal text-emerald-400 px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-800/40">v1.0 OS</span>
          </span>
        </div>

        {/* Navigation Zone */}
        <nav className="hidden md:flex items-center gap-1.5 overflow-x-auto py-1">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`relative px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  isActive
                    ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                    : 'text-gray-400 hover:text-gray-200 hover:bg-gray-800/50'
                }`}
              >
                {item.label}
                {item.id === 'rules' && pendingApprovalsCount > 0 && (
                  <span className="ml-1.5 px-1.5 py-0.2 bg-amber-500/20 text-amber-300 rounded text-[10px] font-bold border border-amber-500/40">
                    {pendingApprovalsCount}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Primary Actions Zone */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onSeedData}
            disabled={isSeeding}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-gray-300 bg-gray-800/80 hover:bg-gray-700/80 border border-gray-700/60 rounded-md transition-colors whitespace-nowrap disabled:opacity-50"
            title="Seed standard business transactions for instant reporting"
          >
            <Sparkles className={`w-3.5 h-3.5 text-amber-400 ${isSeeding ? 'animate-spin' : ''}`} />
            <span>{isSeeding ? 'درج داده...' : 'داده نمونه'}</span>
          </button>

          <button
            onClick={onQuickBackup}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-emerald-950 bg-emerald-400 hover:bg-emerald-300 font-semibold rounded-md transition-colors whitespace-nowrap shadow-sm shadow-emerald-950"
          >
            <Database className="w-3.5 h-3.5" />
            <span>پشتیبان سریع</span>
          </button>
        </div>
      </div>
    </header>
  );
};
