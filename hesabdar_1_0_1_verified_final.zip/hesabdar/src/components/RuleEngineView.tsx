import React, { useState } from 'react';
import {
  Bot,
  CheckCircle2,
  Cpu,
  KeyRound,
  Plus,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import type { AccountingRule, PendingApproval } from '../types';

interface RuleEngineViewProps {
  rules: AccountingRule[];
  approvals: PendingApproval[];
  agents: any[];
  coreAgents: any[];
  onCreateRule: (data: any) => Promise<boolean>;
  onApproveItem: (id: string) => Promise<void>;
  onRejectItem: (id: string) => Promise<void>;
}

export const RuleEngineView: React.FC<RuleEngineViewProps> = ({
  rules,
  approvals,
  agents,
  coreAgents,
  onCreateRule,
  onApproveItem,
  onRejectItem,
}) => {
  const [activeTab, setActiveTab] = useState<'rules' | 'approvals' | 'agents'>('rules');
  const [showAddRule, setShowAddRule] = useState(false);

  // New Rule Form
  const [ruleName, setRuleName] = useState('');
  const [ruleCode, setRuleCode] = useState('');
  const [ruleCategory, setRuleCategory] = useState('expense');
  const [debitCode, setDebitCode] = useState('5040');
  const [creditCode, setCreditCode] = useState('1010');
  const [disposition, setDisposition] = useState('auto_post');
  const [ruleError, setRuleError] = useState<string | null>(null);

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setRuleError(null);
    if (!ruleName.trim()) {
      setRuleError('عنوان قانون الزامی است');
      return;
    }

    try {
      const ok = await onCreateRule({
        name: ruleName,
        code: ruleCode ? ruleCode : undefined,
        category: ruleCategory,
        debit_account_code: debitCode,
        credit_account_code: creditCode,
        disposition: disposition,
      });
      if (ok) {
        setShowAddRule(false);
        setRuleName('');
        setRuleCode('');
      }
    } catch (err: any) {
      setRuleError(err.message || 'خطا در ثبت قانون');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Subtabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#131826] border border-gray-800 p-4 rounded-xl">
        <div className="space-y-1">
          <h2 className="text-sm font-semibold text-white flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>موتور قوانین حسابداری و عامل‌های هوشمند (Rule & Agent Engine)</span>
          </h2>
          <p className="text-xs text-gray-400">
            تطبیق مسیر سریع (Fast Path) و کارتابل تاییدیه سرپرست برای تغییرات قوانین
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex bg-[#0c0f17] p-1 rounded-lg border border-gray-800">
            <button
              onClick={() => setActiveTab('rules')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeTab === 'rules' ? 'bg-emerald-500/20 text-emerald-300' : 'text-gray-400'
              }`}
            >
              قوانین فعال ({rules.length})
            </button>
            <button
              onClick={() => setActiveTab('approvals')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors relative ${
                activeTab === 'approvals' ? 'bg-emerald-500/20 text-emerald-300' : 'text-gray-400'
              }`}
            >
              کارتابل تایید ({approvals.length})
              {approvals.length > 0 && (
                <span className="ml-1 w-2 h-2 rounded-full bg-amber-400 inline-block" />
              )}
            </button>
            <button
              onClick={() => setActiveTab('agents')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeTab === 'agents' ? 'bg-emerald-500/20 text-emerald-300' : 'text-gray-400'
              }`}
            >
              عامل‌های احراز هویت شده ({coreAgents.length + agents.length})
            </button>
          </div>

          <button
            onClick={() => setShowAddRule(true)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-emerald-950 bg-emerald-400 hover:bg-emerald-300 rounded-md shrink-0 shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>قانون جدید</span>
          </button>
        </div>
      </div>

      {activeTab === 'rules' && (
        <div className="bg-[#131826] border border-gray-800 rounded-xl overflow-hidden shadow-sm">
          <table className="w-full text-right text-xs">
            <thead className="bg-[#0c0f17] text-gray-400 border-b border-gray-800">
              <tr>
                <th className="py-3 px-4 font-medium">کد قانون</th>
                <th className="py-3 px-4 font-medium">نام و توصیف قانون</th>
                <th className="py-3 px-4 font-medium">دسته‌بندی</th>
                <th className="py-3 px-4 font-medium">اولویت</th>
                <th className="py-3 px-4 font-medium">نگاشت بدهکار / بستانکار</th>
                <th className="py-3 px-4 font-medium">سیاست ثبت</th>
                <th className="py-3 px-4 font-medium text-center">وضعیت</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800/80">
              {rules.map((r) => (
                <tr key={r.id} className="hover:bg-gray-800/20">
                  <td className="py-3 px-4 font-mono font-semibold text-emerald-400">
                    {r.code}
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-medium text-gray-200">{r.name}</div>
                    <div className="text-[11px] text-gray-500">{r.description}</div>
                  </td>
                  <td className="py-3 px-4 text-gray-300 capitalize">{r.category}</td>
                  <td className="py-3 px-4 font-mono text-gray-400">{r.priority}</td>
                  <td className="py-3 px-4 font-mono text-xs">
                    <span className="text-emerald-400">Deb: {r.action?.debit_account_code || '5040'}</span>
                    <span className="mx-1 text-gray-600">/</span>
                    <span className="text-purple-400">Cred: {r.action?.credit_account_code || '1010'}</span>
                  </td>
                  <td className="py-3 px-4 text-[11px]">
                    <span className="px-2 py-0.5 rounded bg-gray-800 font-mono text-gray-300">
                      {r.action?.disposition || 'auto_post'}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="inline-flex items-center gap-1 text-[11px] px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 font-medium">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>فعال</span>
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'approvals' && (
        <div className="bg-[#131826] border border-gray-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white">کارتابل تاییدیه سرپرست مالی (Human Approval Gate)</h3>
            <span className="text-xs text-gray-400">
              تراکنش‌های مشکوک، با ریسک بالا یا قوانین پیشنهادی جدید
            </span>
          </div>

          {approvals.length === 0 ? (
            <div className="py-12 text-center text-gray-500 text-xs flex flex-col items-center justify-center space-y-2">
              <CheckCircle2 className="w-8 h-8 text-emerald-500/40" />
              <div>هیچ موردی در صف تایید سرپرست وجود ندارد. تمامی عملیات طبق قوانین فعال ثبت شده‌اند.</div>
            </div>
          ) : (
            <div className="space-y-3">
              {approvals.map((appr) => (
                <div
                  key={appr.id}
                  className="bg-[#0c0f17] border border-gray-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                        {appr.status}
                      </span>
                      <span className="text-xs font-semibold text-gray-200">{appr.prompt}</span>
                    </div>
                    <div className="text-xs text-gray-400">دلیل نیاز به تایید: {appr.reason}</div>
                    <div className="text-[11px] text-gray-500 font-mono">
                      Task: {appr.task_id} • {new Date(appr.created_at * 1000).toLocaleString('fa-IR')}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => onRejectItem(appr.id)}
                      className="px-3.5 py-1.5 text-xs font-medium text-rose-400 hover:text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 rounded-md"
                    >
                      رد درخواست
                    </button>
                    <button
                      onClick={() => onApproveItem(appr.id)}
                      className="px-4 py-1.5 text-xs font-semibold text-emerald-950 bg-emerald-400 hover:bg-emerald-300 rounded-md shadow-sm"
                    >
                      تایید و اعمال در سیستم
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {activeTab === 'agents' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-[#131826] border border-gray-800 rounded-xl p-5 space-y-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-white">
              <Cpu className="w-4 h-4 text-emerald-400" />
              <span>عامل‌های هسته حسابداری (Specialized Core Agents)</span>
            </div>
            <div className="space-y-2">
              {coreAgents.map((ca, idx) => (
                <div key={idx} className="bg-[#0c0f17] border border-gray-800/80 rounded-lg p-3 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-medium text-gray-200">{ca.agent_id}</div>
                    <div className="text-[11px] text-gray-500">{ca.role}</div>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                    {ca.algorithm}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-[#131826] border border-gray-800 rounded-xl p-5 space-y-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-white">
              <KeyRound className="w-4 h-4 text-blue-400" />
              <span>احراز هویت و کلیدهای دیجیتال Ed25519 Bus</span>
            </div>
            <div className="space-y-2">
              {agents.map((ag, idx) => (
                <div key={idx} className="bg-[#0c0f17] border border-gray-800/80 rounded-lg p-3 space-y-1">
                  <div className="flex items-center justify-between">
                    <div className="text-xs font-medium text-gray-200 font-mono">{ag.agent_id}</div>
                    <span className="text-[10px] text-blue-300 bg-blue-950/80 px-2 py-0.5 rounded border border-blue-800/40">
                      {ag.status}
                    </span>
                  </div>
                  <div className="text-[10px] font-mono text-gray-500 break-all">
                    Public Key: {ag.public_key_hex}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Propose Rule Modal */}
      {showAddRule && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="bg-[#131826] border border-gray-800 rounded-xl w-full max-w-lg p-5 space-y-4 shadow-2xl">
            <h3 className="text-sm font-semibold text-white pb-2 border-b border-gray-800">
              پیشنهاد قانون جدید حسابداری (Rule Proposal)
            </h3>

            <form onSubmit={handleCreateSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-medium text-gray-300">عنوان قانون:</label>
                <input
                  type="text"
                  value={ruleName}
                  onChange={(e) => setRuleName(e.target.value)}
                  placeholder="مثال: هزینه مشاوره حقوقی"
                  className="w-full bg-[#0c0f17] border border-gray-700 rounded-lg p-2.5 text-xs text-gray-200"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="block text-xs font-medium text-gray-300">کد سرفصل بدهکار:</label>
                  <input
                    type="text"
                    value={debitCode}
                    onChange={(e) => setDebitCode(e.target.value)}
                    className="w-full bg-[#0c0f17] border border-gray-700 rounded-lg p-2.5 text-xs text-gray-200 font-mono"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="block text-xs font-medium text-gray-300">کد سرفصل بستانکار:</label>
                  <input
                    type="text"
                    value={creditCode}
                    onChange={(e) => setCreditCode(e.target.value)}
                    className="w-full bg-[#0c0f17] border border-gray-700 rounded-lg p-2.5 text-xs text-gray-200 font-mono"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-medium text-gray-300">سیاست اعمال:</label>
                <select
                  value={disposition}
                  onChange={(e) => setDisposition(e.target.value)}
                  className="w-full bg-[#0c0f17] border border-gray-700 rounded-lg p-2.5 text-xs text-gray-200"
                >
                  <option value="auto_post">ثبت خودکار قطعی (Auto Post)</option>
                  <option value="require_human_approval">توقف جهت تایید ناظر (Require Approval)</option>
                  <option value="reject">رد سیستمی (Reject)</option>
                </select>
              </div>

              {ruleError && (
                <div className="text-xs text-rose-400 bg-rose-500/10 p-2 rounded border border-rose-500/30">
                  {ruleError}
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddRule(false)}
                  className="px-3.5 py-1.5 text-xs text-gray-400 hover:text-gray-200 rounded-md"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold text-emerald-950 bg-emerald-400 hover:bg-emerald-300 rounded-md"
                >
                  ثبت پیشنهاد قانون
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
