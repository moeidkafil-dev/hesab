import React, { useState } from 'react';
import {
  AlertCircle,
  ArrowRightLeft,
  Bot,
  CheckCircle2,
  FileCheck,
  Layers,
  Plus,
  Send,
  Sparkles,
  Trash2,
  Zap,
} from 'lucide-react';
import type { Account, Transaction } from '../types';

interface TransactionDeskViewProps {
  accounts: Account[];
  onExecuteAITask: (prompt: string) => Promise<any>;
  onPostManualEntry: (data: {
    description: string;
    lines: Array<{ account_id: string; debit: number | string; credit: number | string }>;
    idempotency_key?: string;
  }) => Promise<boolean>;
  isProcessing: boolean;
}

export const TransactionDeskView: React.FC<TransactionDeskViewProps> = ({
  accounts,
  onExecuteAITask,
  onPostManualEntry,
  isProcessing,
}) => {
  const [activeMode, setActiveMode] = useState<'ai' | 'manual'>('ai');

  // AI Task State
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiResult, setAiResult] = useState<any>(null);

  // Manual Journal Entry State
  const [manualDescription, setManualDescription] = useState('');
  const [manualLines, setManualLines] = useState<
    Array<{ account_id: string; debit: string; credit: string }>
  >([
    { account_id: accounts[0]?.id || 'acc_1010', debit: '1000000', credit: '0' },
    { account_id: accounts.find((a) => a.account_type === 'revenue')?.id || 'acc_4010', debit: '0', credit: '1000000' },
  ]);
  const [manualError, setManualError] = useState<string | null>(null);
  const [manualSuccess, setManualSuccess] = useState<string | null>(null);

  const handleRunAI = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiPrompt.trim() || isProcessing) return;
    try {
      const res = await onExecuteAITask(aiPrompt);
      setAiResult(res);
    } catch (err: any) {
      setAiResult({ ok: false, error: err.message });
    }
  };

  const handleAddLine = () => {
    setManualLines([
      ...manualLines,
      { account_id: accounts[0]?.id || 'acc_1010', debit: '0', credit: '0' },
    ]);
  };

  const handleRemoveLine = (idx: number) => {
    if (manualLines.length <= 2) return;
    setManualLines(manualLines.filter((_, i) => i !== idx));
  };

  const handleLineChange = (idx: number, field: 'account_id' | 'debit' | 'credit', val: string) => {
    const next = [...manualLines];
    next[idx] = { ...next[idx], [field]: val };
    setManualLines(next);
  };

  const totalDebit = manualLines.reduce((acc, l) => acc + (parseFloat(l.debit) || 0), 0);
  const totalCredit = manualLines.reduce((acc, l) => acc + (parseFloat(l.credit) || 0), 0);
  const diff = Math.round((totalDebit - totalCredit) * 100) / 100;
  const isBalanced = Math.abs(diff) < 0.01 && totalDebit > 0;

  const handleAutoBalance = () => {
    if (manualLines.length < 2) return;
    const next = [...manualLines];
    const lastIdx = next.length - 1;
    const sumDebitExcludingLast = next.slice(0, lastIdx).reduce((acc, l) => acc + (parseFloat(l.debit) || 0), 0);
    const sumCreditExcludingLast = next.slice(0, lastIdx).reduce((acc, l) => acc + (parseFloat(l.credit) || 0), 0);

    if (sumDebitExcludingLast > sumCreditExcludingLast) {
      next[lastIdx].credit = (sumDebitExcludingLast - sumCreditExcludingLast).toString();
      next[lastIdx].debit = '0';
    } else {
      next[lastIdx].debit = (sumCreditExcludingLast - sumDebitExcludingLast).toString();
      next[lastIdx].credit = '0';
    }
    setManualLines(next);
  };

  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setManualError(null);
    setManualSuccess(null);

    if (!manualDescription.trim()) {
      setManualError('شرح سند حسابداری الزامی است.');
      return;
    }

    if (!isBalanced) {
      setManualError(`سند تراز نیست! اختلاف بدهکار و بستانکار: ${diff.toLocaleString()} ریال`);
      return;
    }

    const payloadLines = manualLines.map((l) => ({
      account_id: l.account_id,
      debit: parseFloat(l.debit) || 0,
      credit: parseFloat(l.credit) || 0,
    }));

    try {
      const ok = await onPostManualEntry({
        description: manualDescription,
        lines: payloadLines,
        idempotency_key: `man_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      });

      if (ok) {
        setManualSuccess('سند حسابداری با موفقیت در پایگاه داده قطعی دفتر کل ثبت شد.');
        setManualDescription('');
      }
    } catch (err: any) {
      setManualError(err.message || 'خطا در ثبت سند');
    }
  };

  return (
    <div className="space-y-6">
      {/* Mode Switcher */}
      <div className="flex items-center justify-between bg-[#131826] border border-gray-800 p-2 rounded-xl">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveMode('ai')}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-colors ${
              activeMode === 'ai'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            <Bot className="w-4 h-4" />
            <span>پردازش هوشمند چندعامله (AI Natural Language)</span>
          </button>

          <button
            onClick={() => setActiveMode('manual')}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-colors ${
              activeMode === 'manual'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            <ArrowRightLeft className="w-4 h-4" />
            <span>ثبت دستی سند حسابداری دوطرفه (Double-Entry Form)</span>
          </button>
        </div>

        <div className="text-xs text-gray-500 font-mono hidden md:block">
          Exact Decimal Arithmetic Invariant: $\sum Debit == \sum Credit$
        </div>
      </div>

      {activeMode === 'ai' ? (
        /* AI Natural Language Desk */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 space-y-4">
            <div className="bg-[#131826] border border-gray-800 rounded-xl p-5 space-y-4">
              <div className="flex items-center gap-2 text-sm font-semibold text-white">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>تحلیل و اعمال سند با عامل‌های خودمختار</span>
              </div>
              <p className="text-xs text-gray-400 leading-relaxed">
                متن فاکتور، پرداخت، دریافت، حقوق یا خرید را به زبان طبیعی بنویسید. سیستم با استفاده از طبقه‌بندی هوشمند، قوانین Fast Path و ارزیابی Critic، سند را به صورت قطعی ثبت می‌کند.
              </p>

              <form onSubmit={handleRunAI} className="space-y-3">
                <textarea
                  rows={4}
                  value={aiPrompt}
                  onChange={(e) => setAiPrompt(e.target.value)}
                  placeholder="مثال: خرید قطعات یدکی و سرور به مبلغ ۱۲,۰۰۰,۰۰۰ تومان از حساب بانک تجارت..."
                  className="w-full bg-[#0c0f17] border border-gray-700/80 rounded-lg p-3 text-sm text-gray-100 placeholder-gray-500 focus:outline-none focus:border-emerald-500/60 focus:ring-1 focus:ring-emerald-500/40"
                  disabled={isProcessing}
                />

                <div className="flex items-center justify-between">
                  <div className="text-[11px] text-gray-500">
                    پشتیبانی کامل از سرفصل‌های استاندارد حسابداری
                  </div>

                  <button
                    type="submit"
                    disabled={!aiPrompt.trim() || isProcessing}
                    className="flex items-center gap-2 px-5 py-2 text-xs font-semibold text-emerald-950 bg-emerald-400 hover:bg-emerald-300 rounded-md transition-colors disabled:opacity-40"
                  >
                    {isProcessing ? (
                      <>
                        <div className="w-3.5 h-3.5 border-2 border-emerald-950 border-t-transparent rounded-full animate-spin" />
                        <span>در حال تحلیل و ثبت...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-3.5 h-3.5" />
                        <span>تحلیل و ثبت سند</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>

            {/* AI Presets */}
            <div className="bg-[#131826] border border-gray-800 rounded-xl p-4 space-y-2">
              <div className="text-xs font-medium text-gray-400">سناریوهای آماده جهت تست سریع:</div>
              <div className="space-y-1.5">
                {[
                  'فروش خدمات پشتیبانی فنی به مبلغ ۲۴,۰۰۰,۰۰۰ ریال نقدی با مالیات',
                  'پرداخت قبوض اینترنت و هاستینگ ابری به مبلغ ۶,۵۰۰,۰۰۰ ریال',
                  'خرید اقلام مصرفی اداری به مبلغ ۳,۲۰۰,۰۰۰ ریال',
                ].map((txt, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setAiPrompt(txt)}
                    className="w-full text-right text-xs text-gray-300 hover:text-emerald-300 bg-[#0c0f17] hover:bg-gray-800/80 p-2.5 rounded-lg border border-gray-800/60 transition-colors"
                  >
                    {txt}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* AI Result Trace View */}
          <div className="lg:col-span-6">
            <div className="bg-[#131826] border border-gray-800 rounded-xl p-5 space-y-4 h-full">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm font-semibold text-white">
                  <Layers className="w-4 h-4 text-blue-400" />
                  <span>ردگیری اجرای چندمرحله‌ای (Execution Trace)</span>
                </div>
                {aiResult && (
                  <span
                    className={`text-[11px] px-2 py-0.5 rounded font-mono font-medium ${
                      aiResult.ok
                        ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                        : 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                    }`}
                  >
                    {aiResult.ok ? 'SUCCESS' : 'FAILED'}
                  </span>
                )}
              </div>

              {!aiResult ? (
                <div className="flex flex-col items-center justify-center py-16 text-center text-gray-500 text-xs space-y-2">
                  <Bot className="w-8 h-8 text-gray-600 animate-pulse" />
                  <p>یک تراکنش را برای پردازش ارسال کنید تا ردگیری دقیق عامل‌ها نمایش داده شود.</p>
                </div>
              ) : (
                <div className="space-y-3 font-mono text-xs">
                  <div className="bg-[#0c0f17] border border-gray-800 rounded-lg p-3 space-y-2">
                    <div className="text-gray-400 font-sans text-xs font-semibold">1. Task Analysis & Routing:</div>
                    <div className="text-gray-200">
                      Path:{' '}
                      <span className="text-emerald-400">
                        {aiResult.result?.path_taken || 'deterministic_fast_path'}
                      </span>
                    </div>
                    <div className="text-gray-400 text-[11px]">
                      Task ID: {aiResult.result?.task_id || 'N/A'}
                    </div>
                  </div>

                  <div className="bg-[#0c0f17] border border-gray-800 rounded-lg p-3 space-y-2">
                    <div className="text-gray-400 font-sans text-xs font-semibold">2. Critic 4-Layer Verification:</div>
                    <div className="text-emerald-400 flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Structural & Balance Invariant Passed</span>
                    </div>
                  </div>

                  <div className="bg-[#0c0f17] border border-gray-800 rounded-lg p-3 space-y-2">
                    <div className="text-gray-400 font-sans text-xs font-semibold">3. Database Authority State:</div>
                    <pre className="text-gray-300 text-[11px] overflow-x-auto whitespace-pre-wrap">
                      {JSON.stringify(aiResult.result || aiResult, null, 2)}
                    </pre>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        /* Manual Double-Entry Form */
        <div className="bg-[#131826] border border-gray-800 rounded-xl p-5 space-y-6">
          <form onSubmit={handleManualSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="block text-xs font-medium text-gray-300">
                شرح سند حسابداری (Journal Entry Description):
              </label>
              <input
                type="text"
                value={manualDescription}
                onChange={(e) => setManualDescription(e.target.value)}
                placeholder="مثال: خرید ملزومات اداری و تسویه نقدی با فروشنده..."
                className="w-full bg-[#0c0f17] border border-gray-700/80 rounded-lg py-2.5 px-3.5 text-sm text-gray-100 placeholder-gray-500 focus:outline-none focus:border-emerald-500/60"
              />
            </div>

            {/* Split Lines Table */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-gray-200">سطور آرتیکل‌های سند (Debit & Credit Lines):</span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleAutoBalance}
                    className="text-xs text-amber-400 hover:text-amber-300 font-medium px-2.5 py-1 rounded bg-amber-500/10 border border-amber-500/30"
                  >
                    تراز خودکار سطر نهایی
                  </button>
                  <button
                    type="button"
                    onClick={handleAddLine}
                    className="flex items-center gap-1 text-xs text-emerald-400 hover:text-emerald-300 font-medium px-2.5 py-1 rounded bg-emerald-500/10 border border-emerald-500/30"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>افزودن سطر</span>
                  </button>
                </div>
              </div>

              <div className="border border-gray-800 rounded-lg overflow-hidden">
                <table className="w-full text-right text-xs">
                  <thead className="bg-[#0c0f17] text-gray-400 border-b border-gray-800">
                    <tr>
                      <th className="py-2.5 px-3 font-medium">سرفصل حساب (Account)</th>
                      <th className="py-2.5 px-3 font-medium w-44">بدهکار (Debit) - ریال</th>
                      <th className="py-2.5 px-3 font-medium w-44">بستانکار (Credit) - ریال</th>
                      <th className="py-2.5 px-2 font-medium w-12 text-center">حذف</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-800/80 bg-[#131826]">
                    {manualLines.map((line, idx) => (
                      <tr key={idx}>
                        <td className="p-2.5">
                          <select
                            value={line.account_id}
                            onChange={(e) => handleLineChange(idx, 'account_id', e.target.value)}
                            className="w-full bg-[#0c0f17] border border-gray-700/60 rounded-md py-1.5 px-2.5 text-xs text-gray-200 focus:outline-none focus:border-emerald-500/60"
                          >
                            {accounts.map((acc) => (
                              <option key={acc.id} value={acc.id}>
                                {acc.name} ({acc.account_type})
                              </option>
                            ))}
                          </select>
                        </td>
                        <td className="p-2.5">
                          <input
                            type="number"
                            min="0"
                            step="any"
                            value={line.debit}
                            onChange={(e) => handleLineChange(idx, 'debit', e.target.value)}
                            className="w-full bg-[#0c0f17] border border-gray-700/60 rounded-md py-1.5 px-2.5 text-xs text-emerald-400 font-mono text-left focus:outline-none focus:border-emerald-500/60"
                          />
                        </td>
                        <td className="p-2.5">
                          <input
                            type="number"
                            min="0"
                            step="any"
                            value={line.credit}
                            onChange={(e) => handleLineChange(idx, 'credit', e.target.value)}
                            className="w-full bg-[#0c0f17] border border-gray-700/60 rounded-md py-1.5 px-2.5 text-xs text-purple-400 font-mono text-left focus:outline-none focus:border-emerald-500/60"
                          />
                        </td>
                        <td className="p-2.5 text-center">
                          <button
                            type="button"
                            onClick={() => handleRemoveLine(idx)}
                            disabled={manualLines.length <= 2}
                            className="text-gray-500 hover:text-rose-400 disabled:opacity-30"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="bg-[#0c0f17] border-t border-gray-800 font-mono text-xs">
                    <tr>
                      <td className="py-3 px-3 font-semibold text-gray-300 font-sans">
                        مجموع مبالغ و وضعیت تراز:
                      </td>
                      <td className="py-3 px-3 font-bold text-emerald-400 text-left">
                        {totalDebit.toLocaleString()}
                      </td>
                      <td className="py-3 px-3 font-bold text-purple-400 text-left">
                        {totalCredit.toLocaleString()}
                      </td>
                      <td className="py-3 px-2 text-center">
                        {isBalanced ? (
                          <span title="سند تراز است">
                            <CheckCircle2 className="w-4 h-4 text-emerald-400 mx-auto" />
                          </span>
                        ) : (
                          <span title="سند تراز نیست">
                            <AlertCircle className="w-4 h-4 text-rose-400 mx-auto" />
                          </span>
                        )}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>

            {/* Status alerts */}
            {manualError && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs rounded-lg flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{manualError}</span>
              </div>
            )}

            {manualSuccess && (
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs rounded-lg flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{manualSuccess}</span>
              </div>
            )}

            <div className="flex items-center justify-between pt-2">
              <div className="text-xs font-mono">
                {isBalanced ? (
                  <span className="text-emerald-400 font-semibold">
                    ✓ تراز سند کامل است (تفاوت: ۰ ریال)
                  </span>
                ) : (
                  <span className="text-rose-400 font-semibold">
                    ✕ اختلاف تراز: {Math.abs(diff).toLocaleString()} ریال
                  </span>
                )}
              </div>

              <button
                type="submit"
                disabled={!isBalanced || isProcessing}
                className="flex items-center gap-2 px-6 py-2.5 text-xs font-semibold text-emerald-950 bg-emerald-400 hover:bg-emerald-300 rounded-md transition-colors disabled:opacity-40 disabled:cursor-not-allowed shadow-sm"
              >
                <FileCheck className="w-4 h-4" />
                <span>ثبت قطعی در دفتر روزنامه و کل</span>
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
