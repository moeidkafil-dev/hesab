import React, { useState } from 'react';
import {
  Activity,
  AlertTriangle,
  ArrowUpRight,
  Bot,
  CheckCircle2,
  Cpu,
  Database,
  DollarSign,
  FileSpreadsheet,
  FileText,
  Layers,
  Send,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import type { SystemStatus, Transaction } from '../types';

interface DashboardViewProps {
  status: SystemStatus | null;
  transactions: Transaction[];
  onExecuteTask: (prompt: string) => Promise<void>;
  onNavigate: (tab: string) => void;
  isExecuting: boolean;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  status,
  transactions,
  onExecuteTask,
  onNavigate,
  isExecuting,
}) => {
  const [promptInput, setPromptInput] = useState('');

  const samplePrompts = [
    'خرید اقلام مصرفی و لوازم التحریر به مبلغ ۴۵۰,۰۰۰ تومان نقدی',
    'صدور صورتحساب فروش نرم‌افزار سازمانی به مبلغ ۵۵,۰۰۰,۰۰۰ تومان با احتساب ۱۰٪ مالیات ارزش افزوده',
    'پرداخت ماهانه اجاره دفتر مرکزی به مبلغ ۲۵,۰۰۰,۰۰۰ تومان از حساب بانک',
    'پرداخت حقوق پرسنل فنی به مبلغ ۴۰,۰۰۰,۰۰۰ تومان با کسر ۷٪ مالیات تکلیفی',
  ];

  const handleQuickSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promptInput.trim() || isExecuting) return;
    onExecuteTask(promptInput);
    setPromptInput('');
  };

  const dbHealthy = status?.health.db_health.ok ?? true;
  const pendingApprovals = status?.pending_approvals.length ?? 0;

  return (
    <div className="space-y-6">
      {/* Top Banner / Status Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#131826] border border-gray-800 rounded-xl p-4 flex items-center justify-between">
          <div className="space-y-1">
            <div className="text-xs font-medium text-gray-400">وضعیت پایگاه داده قطعی (DB Manager)</div>
            <div className="flex items-center gap-2">
              <span className={`w-2.5 h-2.5 rounded-full ${dbHealthy ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'}`} />
              <span className="text-sm font-semibold text-white">
                {dbHealthy ? 'تایید صحت PRAGMA (سالم)' : 'نیاز به بازیابی'}
              </span>
            </div>
            <div className="text-[11px] text-gray-500 font-mono">SQLite + WAL Mode (ACID)</div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
            <Database className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#131826] border border-gray-800 rounded-xl p-4 flex items-center justify-between">
          <div className="space-y-1">
            <div className="text-xs font-medium text-gray-400">عامل‌های فعال و احراز هویت شده</div>
            <div className="text-xl font-bold text-white tracking-tight">
              {status?.health.registered_agents ?? 2} <span className="text-xs font-normal text-gray-400">عامل امضادار</span>
            </div>
            <div className="text-[11px] text-gray-500 font-mono">Ed25519 Cryptographic Bus</div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
            <Bot className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#131826] border border-gray-800 rounded-xl p-4 flex items-center justify-between">
          <div className="space-y-1">
            <div className="text-xs font-medium text-gray-400">تراکنش‌های ثبت شده در دفتر کل</div>
            <div className="text-xl font-bold text-white tracking-tight">
              {transactions.length} <span className="text-xs font-normal text-gray-400">سند حسابداری</span>
            </div>
            <div className="text-[11px] text-emerald-400 font-mono">توازن بدهکار / بستانکار ۱۰۰٪</div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
            <FileSpreadsheet className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#131826] border border-gray-800 rounded-xl p-4 flex items-center justify-between">
          <div className="space-y-1">
            <div className="text-xs font-medium text-gray-400">تاییدیه سرپرست و قوانین فعال</div>
            <div className="flex items-center gap-2">
              <span className="text-xl font-bold text-white">{status?.health.active_rules_count ?? 6}</span>
              {pendingApprovals > 0 ? (
                <span className="px-2 py-0.5 text-xs font-semibold bg-amber-500/20 text-amber-300 rounded-full border border-amber-500/40">
                  {pendingApprovals} در انتظار تایید
                </span>
              ) : (
                <span className="px-2 py-0.5 text-xs font-medium bg-emerald-500/15 text-emerald-300 rounded-full border border-emerald-500/30">
                  بدون معطلی
                </span>
              )}
            </div>
            <div className="text-[11px] text-gray-500 font-mono">Human-in-the-Loop Gate</div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
            <ShieldCheck className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* AI Task Dispatcher Console */}
      <div className="bg-[#131826] border border-gray-800 rounded-xl p-5 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-400" />
            <h2 className="text-sm font-semibold text-white">پردازشگر هوشمند تراکنش‌های مالی (AI Multi-Agent Dispatcher)</h2>
          </div>
          <span className="text-xs text-gray-400 font-mono">
            Fast Rule Path (Deterministic) + Research Path (Probabilistic)
          </span>
        </div>

        <form onSubmit={handleQuickSubmit} className="space-y-3">
          <div className="relative flex items-center">
            <input
              type="text"
              value={promptInput}
              onChange={(e) => setPromptInput(e.target.value)}
              placeholder="توصیف تراکنش یا رویداد مالی به زبان طبیعی فارسی یا انگلیسی... (مثال: خرید ملزومات نقدی ۵۰۰,۰۰۰)"
              className="w-full bg-[#0c0f17] border border-gray-700/80 rounded-lg py-3 px-4 text-sm text-gray-100 placeholder-gray-500 focus:outline-none focus:border-emerald-500/60 focus:ring-1 focus:ring-emerald-500/40 transition-colors"
              disabled={isExecuting}
            />
            <button
              type="submit"
              disabled={!promptInput.trim() || isExecuting}
              className="absolute left-2.5 flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold text-emerald-950 bg-emerald-400 hover:bg-emerald-300 rounded-md transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
            >
              {isExecuting ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-emerald-950 border-t-transparent rounded-full animate-spin" />
                  <span>در حال تحلیل...</span>
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  <span>پردازش و ثبت</span>
                </>
              )}
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-1.5 pt-1">
            <span className="text-xs text-gray-500">پیشنهادات سریع:</span>
            {samplePrompts.map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setPromptInput(p)}
                className="text-[11px] text-gray-400 hover:text-emerald-300 bg-gray-800/60 hover:bg-gray-800 px-2.5 py-1 rounded border border-gray-700/50 transition-colors"
              >
                {p}
              </button>
            ))}
          </div>
        </form>
      </div>

      {/* Architecture Pipeline Visualization */}
      <div className="bg-[#131826] border border-gray-800 rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="text-sm font-semibold text-white">معماری سیستم عامل حسابداری چند عامله (Agent Orchestration Flow)</div>
          <span className="text-xs text-emerald-400 font-mono">۴ لایه اعتبارسنجی مستقل</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div className="bg-[#0c0f17] border border-gray-800/80 rounded-lg p-3.5 space-y-1.5">
            <div className="flex items-center gap-2 text-xs font-semibold text-blue-400">
              <Cpu className="w-4 h-4" />
              <span>1. CEO Orchestrator</span>
            </div>
            <p className="text-xs text-gray-400 leading-relaxed">
              هسته مدیریت، پیش‌بینی وظایف مالی، تخصیص منابع و گیت‌های تایید انسانی.
            </p>
          </div>

          <div className="bg-[#0c0f17] border border-gray-800/80 rounded-lg p-3.5 space-y-1.5">
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
              <Zap className="w-4 h-4" />
              <span>2. Accounting Engine</span>
            </div>
            <p className="text-xs text-gray-400 leading-relaxed">
              تطبیق قوانین قطعی (Fast Path) و تحقیق تحلیلی هوش مصنوعی (Research Path).
            </p>
          </div>

          <div className="bg-[#0c0f17] border border-gray-800/80 rounded-lg p-3.5 space-y-1.5">
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-400">
              <ShieldCheck className="w-4 h-4" />
              <span>3. Critic Final Checker</span>
            </div>
            <p className="text-xs text-gray-400 leading-relaxed">
              ۴ لایه بررسی ساختاری، بررسی تطبیق قانونی، تحلیل آماری ناهنجاری و توازن کامل.
            </p>
          </div>

          <div className="bg-[#0c0f17] border border-gray-800/80 rounded-lg p-3.5 space-y-1.5">
            <div className="flex items-center gap-2 text-xs font-semibold text-purple-400">
              <Database className="w-4 h-4" />
              <span>4. Authoritative DB</span>
            </div>
            <p className="text-xs text-gray-400 leading-relaxed">
              تنها نویسنده مجاز، دقت دهدهی بدون تقریب اعشاری و تضمین یکپارچگی تراکنش‌ها.
            </p>
          </div>
        </div>
      </div>

      {/* Two-Column Activity & Super Logs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Transactions */}
        <div className="bg-[#131826] border border-gray-800 rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-white">آخرین اسناد ثبت شده در دفتر روزنامه</h3>
            <button
              onClick={() => onNavigate('accounts')}
              className="text-xs text-emerald-400 hover:text-emerald-300 flex items-center gap-1 font-medium"
            >
              <span>مشاهده همه</span>
              <ArrowUpRight className="w-3 h-3" />
            </button>
          </div>

          {transactions.length === 0 ? (
            <div className="text-center py-8 text-gray-500 text-xs">
              هنوز سندی ثبت نشده است. از دکمه "داده نمونه" در بالا استفاده کنید.
            </div>
          ) : (
            <div className="space-y-2.5">
              {transactions.slice(0, 5).map((txn) => (
                <div
                  key={txn.id}
                  className="bg-[#0c0f17] border border-gray-800/60 rounded-lg p-3 flex items-start justify-between gap-3"
                >
                  <div className="space-y-1">
                    <div className="text-xs font-medium text-gray-200 line-clamp-1">{txn.description}</div>
                    <div className="flex items-center gap-2 text-[11px] text-gray-500 font-mono">
                      <span>{new Date(txn.created_at * 1000).toLocaleTimeString('fa-IR')}</span>
                      <span>•</span>
                      <span>{txn.lines?.length || 2} سطر دفتر</span>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-xs font-bold text-emerald-400 font-mono">
                      {txn.total_amount?.toLocaleString()} <span className="text-[10px] text-gray-500">ریال</span>
                    </div>
                    <div className="text-[10px] text-gray-500 font-mono">تراز ۱۰۰٪</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Super Logs / Audit Feed */}
        <div className="bg-[#131826] border border-gray-800 rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-white">ثبت وقایع نظارتی (Super Logs)</h3>
            <button
              onClick={() => onNavigate('resilience')}
              className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1 font-medium"
            >
              <span>کنسول ردگیری</span>
              <ArrowUpRight className="w-3 h-3" />
            </button>
          </div>

          {(!status?.recent_logs || status.recent_logs.length === 0) ? (
            <div className="text-center py-8 text-gray-500 text-xs">
              گزارش وقایع در حال دریافت از هسته...
            </div>
          ) : (
            <div className="space-y-2.5">
              {status.recent_logs.slice(0, 5).map((log) => (
                <div
                  key={log.id}
                  className="bg-[#0c0f17] border border-gray-800/60 rounded-lg p-3 flex items-start justify-between gap-2"
                >
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-blue-950/80 text-blue-300 border border-blue-800/40">
                        {log.agent_role || 'agent'}
                      </span>
                      <span className="text-xs text-gray-300 truncate">{log.prompt}</span>
                    </div>
                    <div className="text-[11px] text-gray-500 truncate">{log.output}</div>
                  </div>
                  <div className="text-[10px] text-gray-500 font-mono shrink-0">
                    {new Date(log.timestamp * 1000).toLocaleTimeString('fa-IR')}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
