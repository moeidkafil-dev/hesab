import React, { useState, useEffect, useCallback } from 'react';
import { api } from './services/api';
import type {
  Account,
  AccountingRule,
  BackupSnapshot,
  FinancialReport,
  PendingApproval,
  SystemStatus,
  Transaction,
} from './types';
import { Header } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { TransactionDeskView } from './components/TransactionDeskView';
import { AccountsView } from './components/AccountsView';
import { TransactionsView } from './components/TransactionsView';
import { ReportsView } from './components/ReportsView';
import { RuleEngineView } from './components/RuleEngineView';
import { ResilienceView } from './components/ResilienceView';
import { AlertCircle, CheckCircle2 } from 'lucide-react';

export function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Core system state
  const [status, setStatus] = useState<SystemStatus | null>(null);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [rules, setRules] = useState<AccountingRule[]>([]);
  const [approvals, setApprovals] = useState<PendingApproval[]>([]);
  const [agents, setAgents] = useState<any[]>([]);
  const [coreAgents, setCoreAgents] = useState<any[]>([]);
  const [backups, setBackups] = useState<BackupSnapshot[]>([]);

  // Sub-state
  const [selectedLedger, setSelectedLedger] = useState<any | null>(null);
  const [isLoadingLedger, setIsLoadingLedger] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSeeding, setIsSeeding] = useState(false);

  // Toast notifications
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  const loadAllData = useCallback(async () => {
    try {
      const [
        statusRes,
        accountsRes,
        txnsRes,
        rulesRes,
        approvalsRes,
        agentsRes,
        backupsRes,
      ] = await Promise.all([
        api.getStatus().catch(() => null),
        api.listAccounts().catch(() => ({ ok: false, accounts: [] })),
        api.listTransactions(50).catch(() => ({ ok: false, transactions: [] })),
        api.listRules().catch(() => ({ ok: false, rules: [] })),
        api.listApprovals().catch(() => ({ ok: false, approvals: [] })),
        api.listAgents().catch(() => ({ ok: false, agents: [], core_agents: [] })),
        api.listBackups().catch(() => ({ ok: false, backups: [] })),
      ]);

      if (statusRes) setStatus(statusRes);
      if (accountsRes.ok) setAccounts(accountsRes.accounts || []);
      if (txnsRes.ok) setTransactions(txnsRes.transactions || []);
      if (rulesRes.ok) setRules(rulesRes.rules || []);
      if (approvalsRes.ok) setApprovals(approvalsRes.approvals || []);
      if (agentsRes.ok) {
        setAgents(agentsRes.agents || []);
        setCoreAgents(agentsRes.core_agents || []);
      }
      if (backupsRes.ok) setBackups(backupsRes.backups || []);
    } catch (e) {
      console.error('Failed to load Hesabdar data:', e);
    }
  }, []);

  useEffect(() => {
    loadAllData();
  }, [loadAllData]);

  // Actions
  const handleExecuteAITask = async (prompt: string) => {
    setIsProcessing(true);
    try {
      const res = await api.executeTask(prompt);
      showToast('تراکنش با موفقیت توسط عامل‌های هوشمند پردازش شد.', 'success');
      await loadAllData();
      return res;
    } catch (err: any) {
      showToast(err.message || 'خطا در اجرای وظیفه حسابداری', 'error');
      throw err;
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePostManualEntry = async (data: any) => {
    setIsProcessing(true);
    try {
      const res = await api.postJournalEntry(data);
      if (res.ok) {
        showToast('سند حسابداری با تراز کامل در دفتر کل ثبت شد.', 'success');
        await loadAllData();
        return true;
      } else {
        showToast(res.error || 'خطا در ثبت سند', 'error');
        return false;
      }
    } catch (err: any) {
      showToast(err.message || 'خطا در ارتباط با سرور', 'error');
      return false;
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCreateAccount = async (data: any) => {
    try {
      const res = await api.createAccount(data);
      if (res.ok) {
        showToast('سرفصل حساب جدید با موفقیت ایجاد شد.', 'success');
        await loadAllData();
        return true;
      } else {
        showToast(res.error || 'خطا در ایجاد حساب', 'error');
        return false;
      }
    } catch (err: any) {
      showToast(err.message || 'خطا در ایجاد حساب', 'error');
      return false;
    }
  };

  const handleViewLedger = async (accountId: string) => {
    setIsLoadingLedger(true);
    try {
      const res = await api.getAccountLedger(accountId);
      if (res.ok) {
        setSelectedLedger(res.ledger);
      }
    } finally {
      setIsLoadingLedger(false);
    }
  };

  const handleCreateRule = async (data: any) => {
    try {
      const res = await api.createRule(data);
      if (res.ok) {
        showToast('پیشنهاد قانون جدید ثبت شد و به کارتابل تاییدیه ارسال گردید.', 'success');
        await loadAllData();
        return true;
      }
      return false;
    } catch (err: any) {
      showToast(err.message || 'خطا در ثبت قانون', 'error');
      return false;
    }
  };

  const handleApproveItem = async (approvalId: string) => {
    try {
      const res = await api.approveItem(approvalId);
      if (res.ok) {
        showToast('مورد تایید شد و در سیستم اعمال گردید.', 'success');
        await loadAllData();
      }
    } catch (err: any) {
      showToast(err.message || 'خطا در تایید', 'error');
    }
  };

  const handleRejectItem = async (approvalId: string) => {
    try {
      const res = await api.rejectItem(approvalId);
      if (res.ok) {
        showToast('درخواست توسط سرپرست رد شد.', 'success');
        await loadAllData();
      }
    } catch (err: any) {
      showToast(err.message || 'خطا در رد درخواست', 'error');
    }
  };

  const handleGenerateReport = async (reportType: string) => {
    const res = await api.generateReport(reportType);
    return res.report;
  };

  const handleCreateBackup = async (label: string) => {
    try {
      const res = await api.createBackup(label);
      if (res.ok) {
        showToast('نسخه پشتیبان قطعی با هش SHA-256 ایجاد شد.', 'success');
        await loadAllData();
        return true;
      }
      return false;
    } catch (err: any) {
      showToast(err.message || 'خطا در ایجاد پشتیبان', 'error');
      return false;
    }
  };

  const handleRestoreBackup = async (id: string) => {
    try {
      const res = await api.restoreBackup(id);
      if (res.ok) {
        showToast('پایگاه داده با موفقیت از نسخه پشتیبان بازیابی شد.', 'success');
        await loadAllData();
        return true;
      }
      return false;
    } catch (err: any) {
      showToast(err.message || 'خطا در بازیابی', 'error');
      return false;
    }
  };

  const handleTriggerSelfHealing = async () => {
    try {
      const res = await api.triggerSelfHealing();
      showToast('عملیات خودترمیمی با موفقیت تشخیص داده شد و اعمال شد.', 'success');
      return res;
    } catch (err: any) {
      showToast(err.message || 'خطا در خودترمیمی', 'error');
      throw err;
    }
  };

  const handleRunBenchmark = async () => {
    try {
      const res = await api.runBenchmark([1, 2, 5, 10, 25]);
      showToast('آزمون مقیاس‌پذیری با موفقیت ۱۰۰٪ توازن اجرا شد.', 'success');
      return res.benchmark;
    } catch (err: any) {
      showToast(err.message || 'خطا در بنچمارک', 'error');
      throw err;
    }
  };

  const handleSeedData = async () => {
    setIsSeeding(true);
    try {
      const res = await api.seedSampleData();
      if (res.ok) {
        showToast(`تعداد ${res.seeded_count} تراکنش استاندارد کسب‌وکار با موفقیت درج شد.`, 'success');
        await loadAllData();
      }
    } catch (err: any) {
      showToast(err.message || 'خطا در درج داده', 'error');
    } finally {
      setIsSeeding(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0c0f17] text-gray-100 flex flex-col font-sans" dir="rtl">
      {/* Toast Notification */}
      {toast && (
        <div
          className={`fixed bottom-6 left-6 z-50 flex items-center gap-2 px-4 py-3 rounded-lg border text-xs font-medium shadow-xl transition-all ${
            toast.type === 'success'
              ? 'bg-emerald-950 border-emerald-500/40 text-emerald-300'
              : 'bg-rose-950 border-rose-500/40 text-rose-300'
          }`}
        >
          {toast.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          ) : (
            <AlertCircle className="w-4 h-4 text-rose-400" />
          )}
          <span>{toast.message}</span>
        </div>
      )}

      {/* 3-Zone Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        pendingApprovalsCount={approvals.length}
        onSeedData={handleSeedData}
        onQuickBackup={() => handleCreateBackup('Quick Backup Snapshot')}
        isSeeding={isSeeding}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 lg:p-8 space-y-6">
        {activeTab === 'dashboard' && (
          <DashboardView
            status={status}
            transactions={transactions}
            onExecuteTask={handleExecuteAITask}
            onNavigate={setActiveTab}
            isExecuting={isProcessing}
          />
        )}

        {activeTab === 'desk' && (
          <TransactionDeskView
            accounts={accounts}
            onExecuteAITask={handleExecuteAITask}
            onPostManualEntry={handlePostManualEntry}
            isProcessing={isProcessing}
          />
        )}

        {activeTab === 'accounts' && (
          <AccountsView
            accounts={accounts}
            onCreateAccount={handleCreateAccount}
            onViewLedger={handleViewLedger}
            selectedLedger={selectedLedger}
            onCloseLedger={() => setSelectedLedger(null)}
            isLoadingLedger={isLoadingLedger}
          />
        )}

        {activeTab === 'reports' && (
          <ReportsView onGenerateReport={handleGenerateReport} />
        )}

        {activeTab === 'rules' && (
          <RuleEngineView
            rules={rules}
            approvals={approvals}
            agents={agents}
            coreAgents={coreAgents}
            onCreateRule={handleCreateRule}
            onApproveItem={handleApproveItem}
            onRejectItem={handleRejectItem}
          />
        )}

        {activeTab === 'resilience' && (
          <ResilienceView
            backups={backups}
            onCreateBackup={handleCreateBackup}
            onRestoreBackup={handleRestoreBackup}
            onTriggerSelfHealing={handleTriggerSelfHealing}
            onRunBenchmark={handleRunBenchmark}
          />
        )}
      </main>

      {/* Minimal Footer */}
      <footer className="border-t border-gray-900 py-4 px-4 text-center text-xs text-gray-600 font-mono">
        HESABDAR Multi-Agent Autonomous Accounting Operating System • Strict Double-Entry Decimal Engine
      </footer>
    </div>
  );
}

export default App;
