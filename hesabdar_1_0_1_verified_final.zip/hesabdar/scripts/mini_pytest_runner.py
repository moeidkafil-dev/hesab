"""
Minimal pytest-compatible test runner.

Why this exists: `tests/test_api_server.py`, `tests/test_concurrency_invariants.py`,
and `tests/test_repair_regressions.py` use `@pytest.fixture`, `pytest.raises`,
and the built-in `tmp_path` fixture. If you have real pytest installed
(`pip install pytest`), just use that instead -- it's a strict superset of
what this script does. This script exists only for environments without
network access to install pytest; it reproduces pytest's fixture-resolution
behavior closely enough to run this repo's test suite correctly.

Usage:
    export PYTHONPATH=.
    export HESABDAR_LLM_PROVIDER=mock
    python3 scripts/mini_pytest_runner.py tests.test_api_server \
        tests.test_concurrency_invariants tests.test_repair_regressions
"""
from __future__ import annotations

import contextlib
import importlib
import inspect
import os
import pathlib
import sys
import tempfile
import traceback
import types

# ---- minimal `pytest` shim -------------------------------------------------
_fixture_registry: dict[str, dict] = {}  # name -> {func, scope, autouse}


def fixture(func=None, *, scope="function", autouse=False):
    def register(f):
        _fixture_registry[f.__name__] = {
            "func": f, "scope": scope, "autouse": autouse,
        }
        return f
    if func is not None:
        return register(func)
    return register


@contextlib.contextmanager
def raises(exc_type):
    try:
        yield
    except exc_type:
        return
    else:
        raise AssertionError(f"Did not raise {exc_type}")


pytest_shim = types.ModuleType("pytest")
pytest_shim.fixture = fixture
pytest_shim.raises = raises
sys.modules["pytest"] = pytest_shim

# ---- built-in fixtures ------------------------------------------------------
_session_cache: dict[str, object] = {}


def _make_tmp_path():
    d = tempfile.mkdtemp(prefix="hesabdar_tmp_path_")
    return pathlib.Path(d)


def resolve_fixture(name: str):
    if name == "tmp_path":
        return _make_tmp_path()
    if name not in _fixture_registry:
        raise LookupError(f"Unknown fixture: {name}")
    entry = _fixture_registry[name]
    if entry["scope"] == "session" and name in _session_cache:
        return _session_cache[name]
    func = entry["func"]
    params = list(inspect.signature(func).parameters)
    kwargs = {p: resolve_fixture(p) for p in params}
    result = func(**kwargs)
    if inspect.isgenerator(result):
        value = next(result)
        import atexit
        atexit.register(lambda gen=result: next(gen, None))
        result = value
    if entry["scope"] == "session":
        _session_cache[name] = result
    return result


def run_test_callable(fn, extra_self=None):
    sig = inspect.signature(fn)
    kwargs = {}
    for pname in sig.parameters:
        if pname == "self":
            continue
        kwargs[pname] = resolve_fixture(pname)
    if extra_self is not None:
        fn(extra_self, **kwargs)
    else:
        fn(**kwargs)


def run_module(modpath: str):
    passed, failed = 0, []
    mod = importlib.import_module(modpath)
    for name, entry in _fixture_registry.items():
        if entry["autouse"]:
            resolve_fixture(name)

    for attr_name in dir(mod):
        obj = getattr(mod, attr_name)
        if inspect.isfunction(obj) and attr_name.startswith("test_") and obj.__module__ == mod.__name__:
            try:
                run_test_callable(obj)
                passed += 1
                print(f"  PASS  {modpath}::{attr_name}")
            except Exception:
                failed.append((f"{modpath}::{attr_name}", traceback.format_exc()))
                print(f"  FAIL  {modpath}::{attr_name}")
        elif inspect.isclass(obj) and attr_name.startswith("Test") and obj.__module__ == mod.__name__:
            for meth_name in dir(obj):
                if meth_name.startswith("test_"):
                    instance = obj()
                    meth = getattr(instance, meth_name)
                    try:
                        run_test_callable(meth)
                        passed += 1
                        print(f"  PASS  {modpath}::{attr_name}::{meth_name}")
                    except Exception:
                        failed.append((f"{modpath}::{attr_name}::{meth_name}", traceback.format_exc()))
                        print(f"  FAIL  {modpath}::{attr_name}::{meth_name}")
    return passed, failed


if __name__ == "__main__":
    os.environ.setdefault("HESABDAR_LLM_PROVIDER", "mock")
    tmp_data_dir = tempfile.mkdtemp(prefix="hesabdar_test_data_")
    os.environ["HESABDAR_DATA_DIR"] = tmp_data_dir

    sys.path.insert(0, "tests")
    import conftest  # noqa: F401  (registers the autouse session fixture)

    total_passed = 0
    total_failed = []
    for modname in sys.argv[1:]:
        p, f = run_module(modname)
        total_passed += p
        total_failed.extend(f)

    print(f"\n{total_passed} passed, {len(total_failed)} failed")
    for name, tb in total_failed:
        print(f"\n--- {name} ---\n{tb}")
    sys.exit(1 if total_failed else 0)
