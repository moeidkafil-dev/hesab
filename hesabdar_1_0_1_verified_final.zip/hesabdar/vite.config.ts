import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import { execFile } from 'child_process';
import path from 'path';
import type { Plugin } from 'vite';
import { defineConfig } from 'vite';

function hesabdarApiPlugin(): Plugin {
  return {
    name: 'hesabdar-api-bridge',
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        if (!req.url?.startsWith('/api/')) {
          return next();
        }

        const endpoint = req.url.replace('/api/', '').split('?')[0];
        let body = '';

        req.on('data', (chunk) => {
          body += chunk;
        });

        req.on('end', () => {
          let payload = {};
          if (body) {
            try {
              payload = JSON.parse(body);
            } catch (e) {
              payload = {};
            }
          }

          execFile(
            'python3',
            ['-m', 'hesabdar.api_server', endpoint, JSON.stringify(payload)],
            { cwd: path.resolve(__dirname), maxBuffer: 10 * 1024 * 1024 },
            (err, stdout, stderr) => {
              res.setHeader('Content-Type', 'application/json; charset=utf-8');
              if (err && !stdout) {
                res.statusCode = 500;
                res.end(
                  JSON.stringify({
                    ok: false,
                    error: err.message,
                    stderr: stderr.toString(),
                  })
                );
                return;
              }

              res.statusCode = 200;
              res.end(stdout.trim() || JSON.stringify({ ok: true }));
            }
          );
        });
      });
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss(), hesabdarApiPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      port: 3000,
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
