import express from 'express';
import path from 'path';
import { execFile } from 'child_process';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// API handler routing to Hesabdar Python Engine
app.post('/api/:endpoint', (req, res) => {
  const endpoint = req.params.endpoint;
  const payload = req.body || {};

  execFile(
    'python3',
    ['-m', 'hesabdar.api_server', endpoint, JSON.stringify(payload)],
    { cwd: __dirname, maxBuffer: 10 * 1024 * 1024 },
    (err, stdout, stderr) => {
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      if (err && !stdout) {
        return res.status(500).json({
          ok: false,
          error: err.message,
          stderr: stderr.toString(),
        });
      }
      try {
        const jsonRes = JSON.parse(stdout.trim() || '{}');
        res.json(jsonRes);
      } catch (e) {
        res.send(stdout.trim());
      }
    }
  );
});

// Serve static assets in production
app.use(express.static(path.resolve(__dirname, 'dist')));

app.get('*', (req, res) => {
  res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Hesabdar OS server listening on port ${PORT}`);
});
