"""
n14::n0::n0-n5 "excel command maker / excel vbs maker / file injector /
excel file reader / excel file writer / excel file maker". Sheet
manipulation via openpyxl for the reader/writer/maker triad; the
command/vbs-maker nodes are exposed as text generators only (they produce
a command/VBS *string* — actually executing a `.vbs` file is a Windows-only
concern well outside this Kali-based stack, so `file_injector` here just
writes that generated script to disk via FileTool for the user to run
themselves on a machine that has Excel/VBA, rather than attempting to run
cscript in a Linux sandbox).
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

import openpyxl

from hesabdar.tools.file_tool import FileTool


class ExcelTool:
    def __init__(self, sandbox_root: Optional[str] = None):
        self.file_tool = FileTool(sandbox_root=sandbox_root)

    def excel_command_maker(self, instruction: str) -> str:
        """Produces a human/agent-readable description of the intended
        edit — the deterministic reader/writer methods below are what
        actually execute it; this exists so a plan step can be logged and
        reviewed before excel_file_writer runs."""
        return f"EXCEL_OP: {instruction}"

    def excel_vbs_maker(self, macro_body: str, sub_name: str = "HesabdarMacro") -> str:
        """command to file — generates VBS/VBA source text only."""
        return f'Sub {sub_name}()\n{macro_body}\nEnd Sub\n'

    def file_injector(self, path: str, script_text: str) -> str:
        return self.file_tool.file_maker(path, script_text)

    def excel_file_maker(self, path: str, headers: Optional[list[str]] = None) -> str:
        resolved = self.file_tool._resolve(path)
        resolved.parent.mkdir(parents=True, exist_ok=True)
        wb = openpyxl.Workbook()
        ws = wb.active
        if headers:
            ws.append(headers)
        wb.save(resolved)
        return str(resolved)

    def excel_file_reader(self, path: str, sheet: Optional[str] = None) -> list[list[Any]]:
        resolved = self.file_tool._resolve(path)
        wb = openpyxl.load_workbook(resolved, data_only=True)
        ws = wb[sheet] if sheet else wb.active
        return [list(row) for row in ws.iter_rows(values_only=True)]

    def excel_file_writer(self, path: str, rows: list[list[Any]], sheet: Optional[str] = None,
                           append: bool = True) -> str:
        resolved = self.file_tool._resolve(path)
        if resolved.exists():
            wb = openpyxl.load_workbook(resolved)
            ws = wb[sheet] if sheet else wb.active
            if not append:
                ws.delete_rows(1, ws.max_row)
        else:
            wb = openpyxl.Workbook()
            ws = wb.active
            if sheet:
                ws.title = sheet
        for row in rows:
            ws.append(row)
        wb.save(resolved)
        return str(resolved)
