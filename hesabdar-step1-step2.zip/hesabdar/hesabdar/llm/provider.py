"""
Every `llm` node in the diagram (n5::n5::n0, n5::n6::n4, n5::n7::n5,
n13::n0::n4::n9, ...) is, in code, a single call to get_llm().complete(...).
This is the one place the system knows whether it's talking to a local
Ollama model (gemma2, per current setup) or a hosted API — nothing else in
the codebase should import ollama/anthropic/openai directly.
"""
from __future__ import annotations

import abc
import json
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Optional

from hesabdar.config import LLM, LLMConfig


@dataclass
class LLMResponse:
    text: str
    provider: str
    model: str
    raw: Optional[dict] = None


class LLMProvider(abc.ABC):
    @abc.abstractmethod
    def complete(self, prompt: str, system: str = "", temperature: Optional[float] = None) -> LLMResponse:
        ...


class OllamaProvider(LLMProvider):
    """Local inference via Ollama's HTTP API. No extra SDK dependency —
    plain HTTP so this works the moment `ollama serve` is up, with gemma2
    pulled (`ollama pull gemma2`)."""

    def __init__(self, cfg: LLMConfig):
        self.cfg = cfg

    def complete(self, prompt: str, system: str = "", temperature: Optional[float] = None) -> LLMResponse:
        url = f"{self.cfg.ollama_host.rstrip('/')}/api/generate"
        payload = {
            "model": self.cfg.model,
            "prompt": prompt,
            "system": system or None,
            "stream": False,
            "options": {"temperature": temperature if temperature is not None else self.cfg.temperature},
        }
        payload = {k: v for k, v in payload.items() if v is not None}
        req = urllib.request.Request(
            url, data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"}, method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except urllib.error.URLError as exc:
            raise ConnectionError(
                f"Could not reach Ollama at {url}. Is `ollama serve` running "
                f"and is `{self.cfg.model}` pulled (`ollama pull {self.cfg.model}`)?"
            ) from exc
        return LLMResponse(text=data.get("response", ""), provider="ollama", model=self.cfg.model, raw=data)


class AnthropicProvider(LLMProvider):
    def __init__(self, cfg: LLMConfig):
        self.cfg = cfg
        if not cfg.anthropic_api_key:
            raise ValueError("ANTHROPIC_API_KEY not set")

    def complete(self, prompt: str, system: str = "", temperature: Optional[float] = None) -> LLMResponse:
        import anthropic  # local import: optional dependency, only needed for this provider

        client = anthropic.Anthropic(api_key=self.cfg.anthropic_api_key)
        msg = client.messages.create(
            model=self.cfg.model,
            max_tokens=self.cfg.max_tokens,
            system=system or "",
            temperature=temperature if temperature is not None else self.cfg.temperature,
            messages=[{"role": "user", "content": prompt}],
        )
        text = "".join(block.text for block in msg.content if getattr(block, "type", "") == "text")
        return LLMResponse(text=text, provider="anthropic", model=self.cfg.model, raw=msg.model_dump())


class OpenAIProvider(LLMProvider):
    def __init__(self, cfg: LLMConfig):
        self.cfg = cfg
        if not cfg.openai_api_key:
            raise ValueError("OPENAI_API_KEY not set")

    def complete(self, prompt: str, system: str = "", temperature: Optional[float] = None) -> LLMResponse:
        import openai  # local import: optional dependency, only needed for this provider

        client = openai.OpenAI(api_key=self.cfg.openai_api_key)
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        resp = client.chat.completions.create(
            model=self.cfg.model, messages=messages,
            temperature=temperature if temperature is not None else self.cfg.temperature,
        )
        return LLMResponse(text=resp.choices[0].message.content or "", provider="openai",
                            model=self.cfg.model, raw=resp.model_dump())


class MockProvider(LLMProvider):
    """Deterministic offline stand-in, used by the test suite and by any
    node that needs to run before Ollama/an API key is configured."""

    def complete(self, prompt: str, system: str = "", temperature: Optional[float] = None) -> LLMResponse:
        return LLMResponse(text=f"[mock-llm reply to: {prompt[:60]!r}]", provider="mock", model="mock")


_PROVIDERS = {
    "ollama": OllamaProvider,
    "anthropic": AnthropicProvider,
    "openai": OpenAIProvider,
    "mock": MockProvider,
}


def get_llm(cfg: LLMConfig = LLM) -> LLMProvider:
    cls = _PROVIDERS.get(cfg.provider)
    if cls is None:
        raise ValueError(f"Unknown LLM provider {cfg.provider!r}; choose one of {list(_PROVIDERS)}")
    return cls(cfg) if cls is not MockProvider else cls()
