"""
n13::n1 "DB manager agent architecture" == n6 in the overview doc.
Exact pipeline per docs/09-tooling-and-data-management.md §9.2:

    messages receiver -> messages compile -> messages reader -> messages analyser
    -> executor -> DB analyser -> DB Situation analyser -> DB log maker
    -> result maker -> log maker -> result sender -> log sender

This is the sole authorized writer to the production DB (§9.2) — every
other agent reaches it only via an authenticated Channel (hesabdar.messaging),
never with direct DB credentials.
"""
from __future__ import annotations

import sqlite3
import time
import uuid
from dataclasses import dataclass
from typing import Any, Optional

from hesabdar.config import PRODUCTION_DB_PATH
from hesabdar.db_manager.schema import SCHEMA
from hesabdar.messaging.message import Message


@dataclass
class DBResult:
    ok: bool
    result: Any
    log: str


class DBManagerAgent:
    def __init__(self, db_path=PRODUCTION_DB_PATH):
        self.conn = sqlite3.connect(str(db_path))
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    # ---- the exact §9.2 pipeline, one authenticated Message in, one DBResult out
    def handle(self, message: Message) -> DBResult:
        m = self.messages_receiver(message)
        m = self.messages_compile(m)
        parsed = self.messages_reader(m)
        analysis = self.messages_analyser(parsed)
        exec_result = self.executor(parsed, analysis)
        db_state = self.db_analyser(exec_result)
        situation = self.db_situation_analyser(exec_result, db_state)
        self.db_log_maker(message, exec_result, situation)
        result = self.result_maker(exec_result, situation)
        log_entry = self.log_maker(message, result, situation)
        sent_result = self.result_sender(result)
        self.log_sender(log_entry)
        return sent_result

    def messages_receiver(self, message: Message) -> Message:
        return message

    def messages_compile(self, message: Message) -> Message:
        return message

    def messages_reader(self, message: Message) -> dict:
        """Expects payload shape: {"op": "...", "args": {...}}"""
        return message.payload

    def messages_analyser(self, parsed: dict) -> dict:
        op = parsed.get("op")
        known_ops = {"create_account", "post_transaction", "query_balance", "list_transactions"}
        return {"op": op, "known": op in known_ops}

    def executor(self, parsed: dict, analysis: dict) -> DBResult:
        if not analysis["known"]:
            return DBResult(False, None, f"unknown op {parsed.get('op')!r}")
        op = analysis["op"]
        args = parsed.get("args", {})
        try:
            handler = getattr(self, f"_op_{op}")
            result = handler(**args)
            return DBResult(True, result, f"{op} ok")
        except Exception as exc:  # noqa: BLE001 - surfaced via DBResult, not raised
            return DBResult(False, None, f"{op} failed: {exc}")

    def db_analyser(self, exec_result: DBResult) -> dict:
        """Informs the operation's own correctness (§9.2: distinct from
        db_situation_analyser, which checks the *outcome*)."""
        return {"ok": exec_result.ok}

    def db_situation_analyser(self, exec_result: DBResult, db_state: dict) -> dict:
        """Generator/critic split (§4.4/§9.2): did the write leave the DB in
        the state actually expected? Cheap self-check via a fresh query."""
        if not exec_result.ok:
            return {"consistent": False, "reason": exec_result.log}
        try:
            self.conn.execute("PRAGMA integrity_check").fetchone()
            return {"consistent": True}
        except sqlite3.DatabaseError as exc:
            return {"consistent": False, "reason": str(exc)}

    def db_log_maker(self, message: Message, exec_result: DBResult, situation: dict) -> None:
        self.conn.execute(
            "INSERT INTO db_operation_log VALUES (?,?,?,?,?)",
            (str(uuid.uuid4()), message.payload.get("op", "?"), int(exec_result.ok),
             f"{exec_result.log} | situation={situation}", time.time()),
        )
        self.conn.commit()

    def result_maker(self, exec_result: DBResult, situation: dict) -> DBResult:
        ok = exec_result.ok and situation.get("consistent", False)
        return DBResult(ok=ok, result=exec_result.result, log=exec_result.log)

    def log_maker(self, message: Message, result: DBResult, situation: dict) -> dict:
        return {"message_id": message.id, "sender": message.sender, "ok": result.ok,
                "log": result.log, "situation": situation, "at": time.time()}

    def result_sender(self, result: DBResult) -> DBResult:
        return result  # in-process; a networked deployment would post this back over a Channel

    def log_sender(self, log_entry: dict) -> dict:
        return log_entry  # forwarded to CEO's Log Input Manager (n5::n0) in the full loop

    # ---- concrete ops (deliberately small; extend as the domain engine grows)
    def _op_create_account(self, name: str, account_type: str) -> str:
        acc_id = str(uuid.uuid4())
        self.conn.execute("INSERT INTO accounts VALUES (?,?,?,?)", (acc_id, name, account_type, time.time()))
        self.conn.commit()
        return acc_id

    def _op_post_transaction(self, description: str, lines: list[dict], source_message_id: Optional[str] = None) -> str:
        """lines: [{"account_id": ..., "debit": x, "credit": y}, ...] — must balance."""
        total_debit = sum(l.get("debit", 0) for l in lines)
        total_credit = sum(l.get("credit", 0) for l in lines)
        if round(total_debit, 2) != round(total_credit, 2):
            raise ValueError(f"unbalanced entry: debit={total_debit} credit={total_credit}")
        txn_id = str(uuid.uuid4())
        self.conn.execute("INSERT INTO transactions VALUES (?,?,?,?)",
                           (txn_id, description, time.time(), source_message_id))
        for line in lines:
            self.conn.execute("INSERT INTO transaction_lines VALUES (?,?,?,?,?)",
                               (str(uuid.uuid4()), txn_id, line["account_id"],
                                line.get("debit", 0), line.get("credit", 0)))
        self.conn.commit()
        return txn_id

    def _op_query_balance(self, account_id: str) -> float:
        row = self.conn.execute(
            "SELECT COALESCE(SUM(debit),0) - COALESCE(SUM(credit),0) AS bal "
            "FROM transaction_lines WHERE account_id=?", (account_id,),
        ).fetchone()
        return row["bal"]

    def _op_list_transactions(self, limit: int = 50) -> list[dict]:
        rows = self.conn.execute(
            "SELECT * FROM transactions ORDER BY created_at DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]
