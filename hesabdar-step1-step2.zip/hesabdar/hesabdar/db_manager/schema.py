"""
Production database (n12::n8 / n7::n8) — written to *only* through
DBManagerAgent (§9.2: "sole authorized writer to the production database").
Minimal double-entry-friendly accounting schema; extend per the Accounting
Domain Engine's needs as step 3+ is built.
"""
SCHEMA = """
CREATE TABLE IF NOT EXISTS accounts (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    account_type TEXT NOT NULL,   -- asset / liability / equity / revenue / expense
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    description TEXT,
    created_at REAL NOT NULL,
    source_message_id TEXT        -- traces back to the signed Message that caused this write
);

CREATE TABLE IF NOT EXISTS transaction_lines (
    id TEXT PRIMARY KEY,
    transaction_id TEXT NOT NULL REFERENCES transactions(id),
    account_id TEXT NOT NULL REFERENCES accounts(id),
    debit REAL NOT NULL DEFAULT 0,
    credit REAL NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS db_operation_log (
    id TEXT PRIMARY KEY,
    op TEXT NOT NULL,
    ok INTEGER NOT NULL,
    detail TEXT,
    created_at REAL NOT NULL
);
"""
