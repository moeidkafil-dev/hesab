"""
Central configuration. Everything is env-driven with sane local defaults so
the system runs out of the box against a local Ollama/gemma2 instance, and
can be pointed at a hosted API provider by changing two env vars.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get("HESABDAR_DATA_DIR", PROJECT_ROOT / "data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)

KEYS_DIR = DATA_DIR / "keys"
KEYS_DIR.mkdir(parents=True, exist_ok=True)

MEMORY_DB_PATH = DATA_DIR / "memory.sqlite3"
PRODUCTION_DB_PATH = DATA_DIR / "production.sqlite3"
AUDIT_LOG_PATH = DATA_DIR / "audit_chain.jsonl"


@dataclass
class LLMConfig:
    """
    provider: "ollama" | "anthropic" | "openai"
    Defaults to local Ollama running gemma2, per current setup.
    Switching to a hosted API is a one-line env change, no code change,
    since every agent talks to hesabdar.llm.provider.get_llm() only.
    """
    provider: str = field(default_factory=lambda: os.environ.get("HESABDAR_LLM_PROVIDER", "ollama"))
    model: str = field(default_factory=lambda: os.environ.get("HESABDAR_LLM_MODEL", "gemma2"))
    ollama_host: str = field(default_factory=lambda: os.environ.get("OLLAMA_HOST", "http://localhost:11434"))
    anthropic_api_key: str = field(default_factory=lambda: os.environ.get("ANTHROPIC_API_KEY", ""))
    openai_api_key: str = field(default_factory=lambda: os.environ.get("OPENAI_API_KEY", ""))
    temperature: float = 0.2
    max_tokens: int = 2048


@dataclass
class ResourceConfig:
    """
    Enforcement knobs for the CEO's Resource Distributor (n5::n7),
    per §4.5 of 04-orchestration-and-ceo-agent.md.
    """
    max_concurrent_agents: int = int(os.environ.get("HESABDAR_MAX_AGENTS", "5"))
    max_io_retries: int = int(os.environ.get("HESABDAR_MAX_RETRIES", "3"))
    # Deterministic paths are preferred to probabilistic ones when both are
    # available (§4.5 rule 2) -> Accounting Domain Engine tries rule_manager
    # before ever falling back to an LLM research path.
    prefer_deterministic: bool = True
    # Operational telemetry is elastic; financial/decision telemetry is not
    # (§4.5 rule 1, mirrored in §3.5 for memory retention).
    financial_logs_are_permanent: bool = True


LLM = LLMConfig()
RESOURCES = ResourceConfig()
