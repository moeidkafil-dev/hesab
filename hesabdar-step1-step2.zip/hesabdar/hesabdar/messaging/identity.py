"""
Per-agent cryptographic identity. Backs `sign maker` / `rule signer`
(n5::n2::n2, n5::n2::n7) at agent-creation time, and the `sign reader`
stage repeated in every n10 channel.

docs/07-messaging-and-security.md §7.4: "message authentication ... uses
keyed constructions ... or a digital signature scheme such as Ed25519 for
cross-organization message exchange" — Ed25519 is used here for every
message, which is the strictly stronger of the two options the doc allows.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization
from cryptography.exceptions import InvalidSignature

from hesabdar.config import KEYS_DIR


@dataclass
class AgentIdentity:
    agent_id: str
    private_key: Ed25519PrivateKey
    public_key: Ed25519PublicKey

    def sign(self, payload: bytes) -> bytes:
        return self.private_key.sign(payload)

    def public_bytes(self) -> bytes:
        return self.public_key.public_bytes(
            encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
        )

    @classmethod
    def create(cls, agent_id: str, persist: bool = True) -> "AgentIdentity":
        priv = Ed25519PrivateKey.generate()
        identity = cls(agent_id=agent_id, private_key=priv, public_key=priv.public_key())
        if persist:
            identity._save()
        return identity

    @classmethod
    def load_or_create(cls, agent_id: str) -> "AgentIdentity":
        path = KEYS_DIR / f"{agent_id}.key"
        if path.exists():
            priv = Ed25519PrivateKey.from_private_bytes(path.read_bytes())
            return cls(agent_id=agent_id, private_key=priv, public_key=priv.public_key())
        return cls.create(agent_id, persist=True)

    def _save(self) -> None:
        path = KEYS_DIR / f"{self.agent_id}.key"
        raw = self.private_key.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        )
        path.write_bytes(raw)
        path.chmod(0o600)


class IdentityRegistry:
    """Tracks known agents' public keys so a `sign reader` stage can verify
    a message claiming to be from any registered agent, per §7.3's
    'Identity' property (which agent is this purportedly from)."""

    def __init__(self):
        self._public_keys: dict[str, Ed25519PublicKey] = {}

    def register(self, identity: AgentIdentity) -> None:
        self._public_keys[identity.agent_id] = identity.public_key

    def is_registered(self, agent_id: str) -> bool:
        return agent_id in self._public_keys

    def verify(self, agent_id: str, payload: bytes, signature: bytes) -> bool:
        pub = self._public_keys.get(agent_id)
        if pub is None:
            return False
        try:
            pub.verify(signature, payload)
            return True
        except InvalidSignature:
            return False
