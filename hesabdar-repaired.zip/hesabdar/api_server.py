"""
JSON API Server Bridge for HESABDAR Multi-Agent Accounting Operating System.
Provides structured JSON endpoints for the web UI and external systems.
"""
from __future__ import annotations

import json
import sys
import time
from dataclasses import asdict
from typing import Any

from hesabdar.accounting.rule_manager import RuleStatus
from hesabdar.benchmarks.runner import BenchmarkRunner
from hesabdar.ceo.orchestrator import CEOAgentArchitecture
from hesabdar.reporting.pipeline import ReportType


class HesabdarAPI:
    def __init__(self):
        self.ceo = CEOAgentArchitecture()

    def handle(self, endpoint: str, payload: dict[str, Any]) -> dict[str, Any]:
        if endpoint == "status":
            health = self.ceo.get_system_health()
            accounts = self.ceo.db_manager.get_accounts()
            recent_logs = self.ceo.super_logs.query(limit=15)
            pending = self.ceo.list_pending_approvals()
            return {
                "ok": True,
                "health": health,
                "accounts_count": len(accounts),
                "recent_logs": [asdict(l) for l in recent_logs],
                "pending_approvals": pending,
            }

        elif endpoint == "execute_task":
            prompt = payload.get("prompt", "")
            raw_payload = payload.get("payload")
            result = self.ceo.execute_accounting_task(prompt, raw_payload=raw_payload)
            return {"ok": True, "result": result}

        elif endpoint == "list_accounts":
            accounts = self.ceo.db_manager.get_accounts()
            transactions = self.ceo.db_manager._op_list_transactions(limit=30)
            return {
                "ok": True,
                "accounts": accounts,
                "transactions": transactions,
            }

        elif endpoint == "list_rules":
            rules = self.ceo.rule_manager.list_rules()
            return {
                "ok": True,
                "rules": [r.to_dict() for r in rules],
            }

        elif endpoint == "list_skills":
            skills = self.ceo.skill_registry.list_skills()
            return {
                "ok": True,
                "skills": [s.to_dict() for s in skills],
            }

        elif endpoint == "list_agents":
            agents = []
            for aid, pk in self.ceo.registry._public_keys.items():
                agents.append({
                    "agent_id": aid,
                    "public_key_hex": pk.hex()[:16] + "...",
                    "status": "authenticated",
                    "algorithm": "Ed25519",
                })
            return {"ok": True, "agents": agents}

        elif endpoint == "list_logs":
            limit = payload.get("limit", 30)
            errors_only = payload.get("errors_only", False)
            logs = self.ceo.super_logs.query(has_error=True if errors_only else None, limit=limit)
            return {"ok": True, "logs": [asdict(l) for l in logs]}

        elif endpoint == "list_approvals":
            pending = self.ceo.list_pending_approvals()
            return {"ok": True, "approvals": pending}

        elif endpoint == "approve_item":
            appr_id = payload.get("approval_id", "")
            approver = payload.get("approver", "human_supervisor")
            ok = self.ceo.approve_item(appr_id, approver=approver)
            return {"ok": ok, "approval_id": appr_id}

        elif endpoint == "reject_item":
            appr_id = payload.get("approval_id", "")
            reason = payload.get("reason", "Rejected by human supervisor")
            ok = self.ceo.reject_item(appr_id, reason=reason)
            return {"ok": ok, "approval_id": appr_id}

        elif endpoint == "generate_report":
            report_type_str = payload.get("report_type", "trial_balance")
            rep = self.ceo.generate_financial_report(report_type_str)
            return {"ok": True, "report": rep.to_dict()}

        elif endpoint == "create_backup":
            label = payload.get("label", "Manual UI Snapshot")
            snap = self.ceo.backup_system.create_backup(label)
            return {"ok": True, "snapshot": asdict(snap)}

        elif endpoint == "list_backups":
            backups = self.ceo.backup_system.list_backups()
            return {"ok": True, "backups": [asdict(b) for b in backups]}

        elif endpoint == "restore_backup":
            backup_id = payload.get("backup_id", "")
            res = self.ceo.recovery_system.restore_from_backup(backup_id)
            return {"ok": res.ok, "details": res.details}

        elif endpoint == "trigger_self_healing":
            task_id = payload.get("task_id", "simulated_task")
            error_msg = payload.get("error", "Simulated database connection lock timeout")
            res = self.ceo.self_healing.diagnose_and_heal(task_id, error_msg, {})
            return {"ok": res.ok, "healing_result": asdict(res)}

        elif endpoint == "run_benchmark":
            tiers = payload.get("tiers", [1, 2, 5, 10, 25])
            runner = BenchmarkRunner(ceo=self.ceo)
            res = runner.run_full_suite(tiers=tiers)
            return {"ok": True, "benchmark": res.to_dict()}

        return {"ok": False, "error": f"Unknown endpoint: {endpoint}"}


def main():
    if len(sys.argv) < 2:
        print(json.dumps({"ok": False, "error": "Missing endpoint argument"}))
        return

    endpoint = sys.argv[1]
    payload = {}
    if len(sys.argv) > 2:
        try:
            payload = json.loads(sys.argv[2])
        except Exception:
            payload = {}

    api = HesabdarAPI()
    result = api.handle(endpoint, payload)
    print(json.dumps(result, ensure_ascii=False, default=str))


if __name__ == "__main__":
    main()
