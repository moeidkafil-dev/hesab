#!/usr/bin/env python3
"""
End-to-end demonstration of the HESABDAR pipeline (PRD S39,
"Demonstration"): deterministic accounting flow, no external LLM
required (HESABDAR_LLM_PROVIDER=mock works offline).

Run:
    python3 main.py

Repair note: this file previously called
`CEOAgentArchitecture(tool_manager=...)` and `ceo.handle_prompt(...)` /
`ceo.run_memory_maintenance()`, none of which exist on the current
CEOAgentArchitecture (it builds its own ToolManager internally from
`sandbox_root`, and the equivalent flows are `execute_accounting_task`
and the resilience subsystems). That mismatch was DEAD/OBSOLETE code
left over from an earlier snapshot merged into this repo - confirmed
by actually running it (TypeError at construction). This version calls
only methods that exist on the current orchestrator.
"""
from __future__ import annotations

import json

from hesabdar.ceo.orchestrator import CEOAgentArchitecture
from hesabdar.config import DATA_DIR


def main():
    print(f"[data dir] {DATA_DIR}")

    # CEOAgentArchitecture builds its own ToolManager (granted no tools by
    # default - §9.1's "nothing is permitted by default"); grant what this
    # demo's agent needs before we hand it a task.
    ceo = CEOAgentArchitecture(sandbox_root=str(DATA_DIR / "sandbox"))
    ceo.tool_manager.grant("accounting_domain_engine", ["file_make", "file_read", "excel_make", "excel_write"])

    print("\n== health check (S7: database integrity is checked at startup) ==")
    print(json.dumps(ceo.get_system_health(), indent=2, default=str))

    print("\n== provisioning an agent (agent_builder + new_agent_manager) ==")
    agent = ceo.provision_agent("accounting_domain_engine", role="rule_execution")
    print(f"provisioned: {agent.agent_id}")

    print("\n== deterministic accounting task, routed through prompt_manager -> CEO core -> critic ==")
    result = ceo.execute_accounting_task(
        "Cash sale of 100",
        raw_payload={"description": "cash sale", "amount": 100, "vendor": "walk-in customer"},
    )
    print(json.dumps(result, indent=2, ensure_ascii=False, default=str))

    print("\n== posting a transaction directly through the signed channel to db_manager_agent ==")
    cash = ceo.send_to_db("create_account", {"name": "Cash", "account_type": "asset"})
    revenue = ceo.send_to_db("create_account", {"name": "Sales Revenue", "account_type": "revenue"})
    print(f"accounts created: cash={cash.result} revenue={revenue.result}")

    txn = ceo.send_to_db("post_transaction", {
        "description": "cash sale",
        "lines": [
            {"account_id": cash.result, "debit": "100.00", "credit": 0},
            {"account_id": revenue.result, "debit": 0, "credit": "100.00"},
        ],
        # PRD S10: a retried request with the same idempotency_key must
        # not create a second authoritative transaction.
        "idempotency_key": "demo-cash-sale-1",
    })
    print(f"transaction posted: ok={txn.ok} id={txn.result}")

    balance = ceo.send_to_db("query_balance", {"account_id": cash.result})
    print(f"cash balance: {balance.result}")

    print("\n== using a step-2 tool through the authorized agent ==")
    ledger = ceo.tool_manager.invoke("accounting_domain_engine", "excel_make",
                                      path="ledger.xlsx", headers=["date", "desc", "debit", "credit"])
    print(f"ledger workbook: ok={ledger.ok} path={ledger.result}")
    write = ceo.tool_manager.invoke("accounting_domain_engine", "excel_write",
                                     path="ledger.xlsx", rows=[["2026-08-16", "cash sale", 100, 0]])
    print(f"ledger row written: ok={write.ok}")

    print("\n== verified backup snapshot (S34, backup/restore) ==")
    snap = ceo.backup_system.create_backup("demo run snapshot")
    print(f"backup: id={snap.id} verified={snap.verified} size_bytes={snap.size_bytes}")

    print("\n== retiring the agent (agent_killer -> summary_maker) ==")
    summary = ceo.retire_agent("accounting_domain_engine", notes="handled one cash-sale transaction end to end")
    print(f"summary: {summary}")

    print("\nDone. Inspect the data at:", DATA_DIR)


if __name__ == "__main__":
    main()
