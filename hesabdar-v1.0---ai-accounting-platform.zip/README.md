# حسابدار (Hesabdar) — Step 1 + Step 2

پیاده‌سازی مستقیم و node-به-node معماری `حسابدار.graphml`. نگاشت کامل هر
کلاس به node id در `MAPPING.md` هست.

## نصب

```bash
cd hesabdar
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## اجرا با LLM محلی (Ollama + gemma2) — پیش‌فرض

```bash
# روی کالی، اگه ollama نصب نیست:
curl -fsSL https://ollama.com/install.sh | sh
ollama pull gemma2
ollama serve &   # اگه به صورت سرویس بالا نیومده

python3 main.py
```

پیش‌فرض `HESABDAR_LLM_PROVIDER=ollama` و `HESABDAR_LLM_MODEL=gemma2` هست،
پس چیزی رو عوض نکنی همینجوری کار می‌کنه.

## سوییچ به یک API خارجی

هیچ‌جای کد به‌جز `hesabdar/llm/provider.py` مستقیم به ollama/anthropic/openai
اشاره نمی‌کنه — سوییچ فقط با env var:

```bash
export HESABDAR_LLM_PROVIDER=anthropic
export HESABDAR_LLM_MODEL=claude-sonnet-4-6   # یا هر مدل دیگه
export ANTHROPIC_API_KEY=sk-...
python3 main.py
```

یا OpenAI:
```bash
export HESABDAR_LLM_PROVIDER=openai
export HESABDAR_LLM_MODEL=gpt-4o
export OPENAI_API_KEY=sk-...
```

برای اجرای بدون هیچ LLM (تست/دیباگ):
```bash
export HESABDAR_LLM_PROVIDER=mock
```

## ساختار

```
hesabdar/
  config.py              تنظیمات env-driven (LLM, مسیر دیتا, retry/concurrency)
  llm/provider.py         انتزاع LLM — ollama/anthropic/openai/mock
  memory/                 n4, n5::n8, n13::n3  — تاکسونومی ۲۷ نوعی + write/maintenance path
  messaging/               n10, n13::n2         — پیام امضادار Ed25519 + audit hash-chain
  db_manager/              n6, n13::n1           — تنها نویسنده‌ی مجاز DB تولید
  ceo/                     n5 (۱۱ زیرگروه)       — CEOAgentArchitecture
  tools/                   n3, n14::n0            — ToolManager + bash/file/excel/web
main.py                    دمو end-to-end
MAPPING.md                 نگاشت کامل node-id -> کلاس/فایل
```

## چیزهایی که «طبق دیاگرام دقیق» رعایت شده

- **۲۷ نوع حافظه** دقیقاً طبق §3.2 مستندات، با قانون نگه‌داری دائمی برای
  Failure/Audit-History/Financial-Transaction (§3.5) — این‌ها هرگز توسط
  `tables_cleaner` پاک نمی‌شن، حتی زیر فشار منابع.
- **امضای پیام‌ها** Ed25519 (نه هش ساده) طبق §7.4، با یک hash-chain
  تمپرایوینت روی کل توالی پیام‌ها (§7.5)، نه فقط تک‌تک پیام‌ها.
- **generator/critic** جدا در سه سطح مختلف پیاده شده: پلن CEO
  (`planner` vs `plan_chcker`)، I/O checkpoint loop (`output_forecaster`
  vs `output_checker`)، و DB write (`db_analyser` vs `db_situation_analyser`)
  — دقیقاً طبق §4.4.
- **checkpoint loop به‌جای state machine کامل** طبق §4.3 — یک حلقه‌ی
  bounded-retry با شمارنده، نه یک ماشین حالت جداگانه.
- **مدیریت منابع** (§4.5): تله‌متری مالی/تصمیم هرگز suppress نمی‌شه؛
  مسیر deterministic (rule-matcher توی Domain Engine — هنوز نساختیم)
  همیشه روی مسیر probabilistic (LLM) اولویت داره.
- **DB manager تنها نویسنده‌ی مجاز** (§9.2) — همه‌ی نوشتن‌ها از طریق
  `CEOAgentArchitecture.send_to_db()` می‌رن که از یک Channel امضادار عبور
  می‌کنه؛ هیچ agent دیگه‌ای مستقیم credential دیتابیس نداره.
- **tool manager به‌عنوان تنها gatekeeper ابزارها** (§9.1) — هر ابزار
  (bash/file/excel/web) فقط از طریق `ToolManager.invoke(agent_id, ...)`
  صدا زده می‌شه و باید صریحاً برای اون agent با `grant()` مجاز شده باشه؛
  تلاش برای فرار از sandbox (`../../etc/passwd`) هم مسدود می‌شه.

## چیزی که هنوز نساختیم (step 3 به بعد)

طبق `README.md` اصلی پروژه: Accounting Domain Engine + rule manager (سند ۵)،
Reporting/Analytics pipeline (سند ۱۰)، final checker agent / critic (سند ۶)،
backup/recovery/debugger (سند ۸). این‌ها روی زیرساخت step1+2 که همین الان
ساخته شده سوار می‌شن — memory/messaging/db_manager/tool_manager بدون تغییر
باقی می‌مونن.
