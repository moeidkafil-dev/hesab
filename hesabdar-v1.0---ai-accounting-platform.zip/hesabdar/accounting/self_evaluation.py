"""
Accounting Self-Evaluation System (n17, PRD §27, Docs 05 §5.2).
Distinct from the system-wide Critic pattern, this node performs
rule-engine-scoped self-checks (e.g. verifying that a matched rule's
output type is consistent with what the transaction classifier expected,
and confirming debit/credit balance) before the result leaves the domain engine.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from hesabdar.accounting.classifier import ClassificationResult
from hesabdar.accounting.executor import ExecutionResult
from hesabdar.accounting.matcher import MatchResult


@dataclass
class EvaluationReport:
    passed: bool
    classification_consistent: bool
    rule_consistent: bool
    balance_valid: bool
    discrepancy_score: float = 0.0
    issues: list[str] = field(default_factory=list)


class AccountingSelfEvaluation:
    def evaluate(
        self,
        tx_data: dict[str, Any],
        classification: ClassificationResult,
        match: MatchResult,
        execution: ExecutionResult,
    ) -> EvaluationReport:
        issues = []
        classification_consistent = True
        rule_consistent = True
        balance_valid = True

        # 1. Check classification match
        if match.selected_rule:
            if classification.category != "unclassified" and match.selected_rule.category != classification.category:
                classification_consistent = False
                issues.append(
                    f"Classification category {classification.category!r} deviates from matched rule category {match.selected_rule.category!r}"
                )

        # 2. Check execution outcome consistency
        if execution.journal_entry:
            je = execution.journal_entry
            if not je.is_balanced:
                balance_valid = False
                issues.append(f"Double entry balance violation: Debit {je.total_debit} != Credit {je.total_credit}")

            if round(je.total_debit, 2) < round(float(tx_data.get("amount", 0)), 2):
                issues.append("Recorded entry debit is less than transaction nominal amount.")

        discrepancy_score = 0.0 if not issues else (0.5 if classification_consistent and balance_valid else 1.0)
        passed = len(issues) == 0

        return EvaluationReport(
            passed=passed,
            classification_consistent=classification_consistent,
            rule_consistent=rule_consistent,
            balance_valid=balance_valid,
            discrepancy_score=discrepancy_score,
            issues=issues,
        )
