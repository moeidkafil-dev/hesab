"""
Rule Executor (n17, PRD §26, Docs 05 §5.2).
Validates preconditions, calculates balanced debit/credit lines,
applies tax deductions, emits audit events, and routes writes
through the authoritative DB Manager boundary.
"""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Optional

from hesabdar.accounting.rule_manager import AccountingRule, RuleDisposition
from hesabdar.accounting.schema import JournalEntry, JournalEntryLine


@dataclass
class ExecutionResult:
    ok: bool
    status: str
    journal_entry: Optional[JournalEntry] = None
    transaction_id: Optional[str] = None
    disposition: RuleDisposition = RuleDisposition.AUTO_POST
    log: str = ""
    error: Optional[str] = None


class RuleExecutor:
    def __init__(self, db_manager_caller: Optional[Any] = None):
        self.db_manager_caller = db_manager_caller  # Function or channel to send_to_db

    def execute(
        self,
        tx_data: dict[str, Any],
        rule: AccountingRule,
        governing_disposition: RuleDisposition = RuleDisposition.AUTO_POST,
        source_message_id: Optional[str] = None,
    ) -> ExecutionResult:
        # Check governing disposition first
        if governing_disposition == RuleDisposition.REJECT:
            return ExecutionResult(
                ok=False,
                status="rejected",
                disposition=RuleDisposition.REJECT,
                log=f"Transaction rejected by rule {rule.code}.",
                error="Transaction rejected by policy rule constraint.",
            )

        if governing_disposition == RuleDisposition.REQUIRE_HUMAN_APPROVAL:
            return ExecutionResult(
                ok=True,
                status="pending_human_approval",
                disposition=RuleDisposition.REQUIRE_HUMAN_APPROVAL,
                log=f"Transaction held for human approval by rule {rule.code}.",
            )

        # Precondition checks
        amount = float(tx_data.get("amount", 0))
        if amount <= 0:
            return ExecutionResult(
                ok=False,
                status="precondition_failed",
                disposition=governing_disposition,
                error="Transaction amount must be strictly greater than zero.",
            )

        action = rule.action
        debit_code = action.debit_account_code or "5040"
        credit_code = action.credit_account_code or "1010"

        entry_id = str(uuid.uuid4())
        desc = tx_data.get("description", rule.description)

        lines: list[dict[str, Any]] = []

        if action.tax_rate > 0 and action.tax_account_code:
            tax_amount = round(amount * action.tax_rate, 2)
            if rule.category == "sale":
                # Sales VAT: Debit AR for total, Credit Revenue, Credit Tax Payable
                total_ar = round(amount + tax_amount, 2)
                lines.append({"account_id": debit_code, "debit": total_ar, "credit": 0.0})
                lines.append({"account_id": credit_code, "debit": 0.0, "credit": amount})
                lines.append({"account_id": action.tax_account_code, "debit": 0.0, "credit": tax_amount})
            elif rule.category == "payroll":
                # Payroll Withholding: Debit Salary Expense, Credit Tax Payable, Credit Bank
                net_pay = round(amount - tax_amount, 2)
                lines.append({"account_id": debit_code, "debit": amount, "credit": 0.0})
                lines.append({"account_id": credit_code, "debit": 0.0, "credit": net_pay})
                lines.append({"account_id": action.tax_account_code, "debit": 0.0, "credit": tax_amount})
            else:
                lines.append({"account_id": debit_code, "debit": amount, "credit": 0.0})
                lines.append({"account_id": credit_code, "debit": 0.0, "credit": amount})
        else:
            lines.append({"account_id": debit_code, "debit": amount, "credit": 0.0})
            lines.append({"account_id": credit_code, "debit": 0.0, "credit": amount})

        # Validate double-entry invariant
        total_debit = sum(l["debit"] for l in lines)
        total_credit = sum(l["credit"] for l in lines)
        if round(total_debit, 2) != round(total_credit, 2):
            return ExecutionResult(
                ok=False,
                status="invariant_violation",
                error=f"Unbalanced double-entry: Debit {total_debit} != Credit {total_credit}",
            )

        # Write to Database via authorized DB Manager caller if wired
        txn_id = entry_id
        if self.db_manager_caller is not None:
            try:
                db_res = self.db_manager_caller(
                    op="post_transaction",
                    args={"description": desc, "lines": lines, "source_message_id": source_message_id},
                )
                if isinstance(db_res, dict) and not db_res.get("ok", True):
                    return ExecutionResult(ok=False, status="db_write_failed", error=str(db_res.get("reason", "DB error")))
                if hasattr(db_res, "result") and db_res.result:
                    txn_id = str(db_res.result)
            except Exception as exc:
                return ExecutionResult(ok=False, status="db_exception", error=str(exc))

        # Build in-memory JournalEntry representation
        journal_lines = [
            JournalEntryLine(
                id=str(uuid.uuid4()),
                account_id=l["account_id"],
                account_code=l["account_id"],
                account_name=l["account_id"],
                debit=l["debit"],
                credit=l["credit"],
            )
            for l in lines
        ]

        entry = JournalEntry(
            id=txn_id,
            transaction_date=time.time(),
            description=desc,
            lines=journal_lines,
            rule_id_applied=rule.id,
            verified=True,
            source_message_id=source_message_id,
        )

        return ExecutionResult(
            ok=True,
            status="posted",
            journal_entry=entry,
            transaction_id=txn_id,
            disposition=RuleDisposition.AUTO_POST,
            log=f"Posted transaction {txn_id} using rule {rule.code} (Debit={total_debit}, Credit={total_credit})",
        )
