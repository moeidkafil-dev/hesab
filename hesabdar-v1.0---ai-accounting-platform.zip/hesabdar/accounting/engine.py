"""
Accounting Domain Engine (n10 / n16 / n17 / n18, PRD §21-§27, Docs 05).
Integrates:
- Fast Path (n17): Rule Manager -> Classifier -> Matcher -> Executor -> Self-Evaluation
- Research Path (n16): Knowledge Researcher -> Candidate Rule -> Human Approval Gate
- Rules Managers Group (n18): Unifies both paths with single convergence to Final Checker.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from hesabdar.accounting.classifier import ClassificationResult, TransactionClassifier
from hesabdar.accounting.executor import ExecutionResult, RuleExecutor
from hesabdar.accounting.matcher import MatchResult, RuleMatcher
from hesabdar.accounting.researcher import CandidateRuleResult, KnowledgeResearcher
from hesabdar.accounting.rule_manager import (
    AccountingRule,
    RuleDisposition,
    RuleManager,
    RuleStatus,
)
from hesabdar.accounting.self_evaluation import AccountingSelfEvaluation, EvaluationReport
from hesabdar.llm import LLMProvider, get_llm


@dataclass
class DomainEngineResult:
    ok: bool
    path_taken: str  # "fast_path" | "research_path" | "human_approval_gate"
    classification: ClassificationResult
    match: Optional[MatchResult] = None
    execution: Optional[ExecutionResult] = None
    evaluation: Optional[EvaluationReport] = None
    candidate_rule: Optional[AccountingRule] = None
    needs_human_approval: bool = False
    approval_reason: str = ""
    summary: str = ""


class AccountingDomainEngine:
    def __init__(
        self,
        rule_manager: Optional[RuleManager] = None,
        llm: Optional[LLMProvider] = None,
        db_manager_caller: Optional[Any] = None,
    ):
        self.llm = llm or get_llm()
        self.rule_manager = rule_manager or RuleManager()
        self.classifier = TransactionClassifier(llm=self.llm)
        self.matcher = RuleMatcher(self.rule_manager)
        self.executor = RuleExecutor(db_manager_caller=db_manager_caller)
        self.researcher = KnowledgeResearcher(llm=self.llm)
        self.evaluator = AccountingSelfEvaluation()

    def process_transaction(
        self,
        transaction_data: dict[str, Any],
        source_message_id: Optional[str] = None,
    ) -> DomainEngineResult:
        """Rule-First Pipeline per Docs 05 §5.4:
        1. Classify transaction.
        2. Attempt deterministic rule match.
        3. If match found -> Execute -> Self-Evaluate.
        4. If no match / ambiguous -> Invoke Research Path -> Generate Candidate Rule -> Request Human Approval.
        """
        # Step 1: Classification
        classification = self.classifier.classify(transaction_data)
        ctx = dict(transaction_data)
        ctx["category"] = classification.category
        ctx["sub_category"] = classification.sub_category

        # Step 2: Rule Matching
        match = self.matcher.match(ctx)

        # Step 3: Fast Path
        if match.matched and match.selected_rule is not None:
            rule = match.selected_rule

            # Check if rule requires human approval
            if match.governing_disposition == RuleDisposition.REQUIRE_HUMAN_APPROVAL:
                return DomainEngineResult(
                    ok=True,
                    path_taken="human_approval_gate",
                    classification=classification,
                    match=match,
                    needs_human_approval=True,
                    approval_reason=match.conflict_rationale or f"Rule {rule.code} requires human approval.",
                    summary=f"Transaction held for approval under policy rule {rule.code}.",
                )

            if match.governing_disposition == RuleDisposition.REJECT:
                return DomainEngineResult(
                    ok=False,
                    path_taken="fast_path",
                    classification=classification,
                    match=match,
                    summary=f"Transaction rejected under rule constraint {rule.code}.",
                )

            # Execute rule deterministically
            execution = self.executor.execute(
                tx_data=transaction_data,
                rule=rule,
                governing_disposition=match.governing_disposition,
                source_message_id=source_message_id,
            )

            # Local domain self-evaluation
            evaluation = self.evaluator.evaluate(
                tx_data=transaction_data,
                classification=classification,
                match=match,
                execution=execution,
            )

            return DomainEngineResult(
                ok=execution.ok and evaluation.passed,
                path_taken="fast_path",
                classification=classification,
                match=match,
                execution=execution,
                evaluation=evaluation,
                summary=f"Successfully processed via fast path rule {rule.code}.",
            )

        # Step 4: Research Path for ambiguous or missing rule
        research_result = self.researcher.research(
            transaction_data=transaction_data,
            ambiguity_reason="No production rule found matching transaction parameters.",
        )

        candidate = research_result.candidate_rule
        # Register candidate in RuleManager under pending_approval status
        self.rule_manager.add_candidate_rule(candidate)

        return DomainEngineResult(
            ok=True,
            path_taken="research_path",
            classification=classification,
            candidate_rule=candidate,
            needs_human_approval=True,
            approval_reason=f"Novel transaction required research. Proposed candidate rule {candidate.code} ({candidate.name}).",
            summary=f"Research completed. Candidate rule {candidate.code} created and routed to CEO for human sign-off.",
        )
