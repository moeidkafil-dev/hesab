"""
n13::n1 "DB manager agent architecture" == n6 in the overview doc.
Exact pipeline per docs/09-tooling-and-data-management.md S9.2:

    messages receiver -> messages compile -> messages reader -> messages analyser
    -> executor -> DB analyser -> DB Situation analyser -> DB log maker
    -> result maker -> log maker -> result sender -> log sender

This is the sole authorized writer to the production DB (S9.2) - every
other agent reaches it only via an authenticated Channel (hesabdar.messaging),
never with direct DB credentials.

Repair notes (PRD S3/S7/S8/S9/S10):
  - the connection goes through db_health.connect_with_recovery, so a
    malformed database file is never silently trusted (see db_health.py);
  - debit/credit are handled as Decimal end-to-end and persisted as
    canonical decimal strings, never binary float;
  - the debit == credit invariant is enforced with exact Decimal
    comparison (no float round()) immediately before persistence, and an
    unbalanced entry is rejected before any row is written;
  - post_transaction accepts an optional idempotency_key; a retried
    request with a key that was already committed returns the original
    transaction instead of creating a duplicate;
  - thread-safe multi-worker connection locks.
"""
from __future__ import annotations

import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass
from typing import Any, Optional

from hesabdar.accounting.money import money_to_str, sum_money, to_money
from hesabdar.config import PRODUCTION_DB_PATH
from hesabdar.db_health import connect_with_recovery, doctor
from hesabdar.db_manager.schema import SCHEMA
from hesabdar.messaging.message import Message


@dataclass
class DBResult:
    ok: bool
    result: Any
    log: str


class UnbalancedEntryError(ValueError):
    """Raised when a proposed journal entry's debits and credits do not match."""


class DBManagerAgent:
    def __init__(self, db_path=PRODUCTION_DB_PATH):
        self.db_path = db_path
        self._lock = threading.RLock()
        self.conn = connect_with_recovery(db_path, SCHEMA)

    def health(self) -> dict:
        """Doctor/health-check entry point (PRD S7: "at startup or through a
        doctor/health operation, provide a database integrity check")."""
        return doctor(self.db_path)

    # ---- the exact S9.2 pipeline, one authenticated Message in, one DBResult out
    def handle(self, message: Message) -> DBResult:
        m = self.messages_receiver(message)
        m = self.messages_compile(m)
        parsed = self.messages_reader(m)
        analysis = self.messages_analyser(parsed)
        exec_result = self.executor(parsed, analysis)
        db_state = self.db_analyser(exec_result)
        situation = self.db_situation_analyser(exec_result, db_state)
        self.db_log_maker(message, exec_result, situation)
        result = self.result_maker(exec_result, situation)
        log_entry = self.log_maker(message, result, situation)
        sent_result = self.result_sender(result)
        self.log_sender(log_entry)
        return sent_result

    def messages_receiver(self, message: Message) -> Message:
        return message

    def messages_compile(self, message: Message) -> Message:
        return message

    def messages_reader(self, message: Message) -> dict:
        """Expects payload shape: {"op": "...", "args": {...}}"""
        return message.payload

    def messages_analyser(self, parsed: dict) -> dict:
        op = parsed.get("op")
        known_ops = {
            "create_account",
            "post_transaction",
            "query_balance",
            "list_transactions",
            "list_accounts",
            "get_account_ledger",
            "list_transactions_detailed",
        }
        return {"op": op, "known": op in known_ops}

    def executor(self, parsed: dict, analysis: dict) -> DBResult:
        if not analysis["known"]:
            return DBResult(False, None, f"unknown op {parsed.get('op')!r}")
        op = analysis["op"]
        args = parsed.get("args", {})
        try:
            handler = getattr(self, f"_op_{op}")
            result = handler(**args)
            return DBResult(True, result, f"{op} ok")
        except Exception as exc:  # noqa: BLE001 - surfaced via DBResult, not raised
            return DBResult(False, None, f"{op} failed: {exc}")

    def db_analyser(self, exec_result: DBResult) -> dict:
        """Informs the operation's own correctness (S9.2: distinct from
        db_situation_analyser, which checks the *outcome*)."""
        return {"ok": exec_result.ok}

    def db_situation_analyser(self, exec_result: DBResult, db_state: dict) -> dict:
        """Generator/critic split (S4.4/S9.2): did the write leave the DB in
        the state actually expected? Cheap self-check via a fresh query."""
        if not exec_result.ok:
            return {"consistent": False, "reason": exec_result.log}
        try:
            with self._lock:
                self.conn.execute("PRAGMA integrity_check").fetchone()
            return {"consistent": True}
        except sqlite3.DatabaseError as exc:
            return {"consistent": False, "reason": str(exc)}

    def db_log_maker(self, message: Message, exec_result: DBResult, situation: dict) -> None:
        with self._lock:
            self.conn.execute(
                "INSERT INTO db_operation_log VALUES (?,?,?,?,?)",
                (str(uuid.uuid4()), message.payload.get("op", "?"), int(exec_result.ok),
                 f"{exec_result.log} | situation={situation}", time.time()),
            )
            self.conn.commit()

    def result_maker(self, exec_result: DBResult, situation: dict) -> DBResult:
        ok = exec_result.ok and situation.get("consistent", False)
        return DBResult(ok=ok, result=exec_result.result, log=exec_result.log)

    def log_maker(self, message: Message, result: DBResult, situation: dict) -> dict:
        return {"message_id": message.id, "sender": message.sender, "ok": result.ok,
                "log": result.log, "situation": situation, "at": time.time()}

    def result_sender(self, result: DBResult) -> DBResult:
        return result  # in-process; a networked deployment would post this back over a Channel

    def log_sender(self, log_entry: dict) -> dict:
        return log_entry  # forwarded to CEO's Log Input Manager (n5::n0) in the full loop

    # ---- concrete ops (deliberately small; extend as the domain engine grows)
    def _op_create_account(self, name: str, account_type: str, code: Optional[str] = None) -> str:
        acc_id = code or f"acc_{uuid.uuid4().hex[:6]}"
        with self._lock:
            self.conn.execute(
                "INSERT OR REPLACE INTO accounts VALUES (?,?,?,?)",
                (acc_id, name, account_type, time.time()),
            )
            self.conn.commit()
        return acc_id

    def _resolve_account_id(self, account_ref: str) -> str:
        """Resolves account_id from either exact id or code prefix or name."""
        with self._lock:
            row = self.conn.execute("SELECT id FROM accounts WHERE id = ?", (account_ref,)).fetchone()
            if row:
                return row["id"]
            row = self.conn.execute("SELECT id FROM accounts WHERE id = ?", (f"acc_{account_ref}",)).fetchone()
            if row:
                return row["id"]
            row = self.conn.execute("SELECT id FROM accounts WHERE name LIKE ?", (f"{account_ref}%",)).fetchone()
            if row:
                return row["id"]
        return account_ref

    def _op_post_transaction(
        self,
        description: str,
        lines: list[dict],
        source_message_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
    ) -> str:
        """lines: [{"account_id": ..., "debit": x, "credit": y}, ...] - must balance
        exactly (Decimal comparison, not float). If idempotency_key was already
        committed on a prior call, that same transaction id is returned instead
        of creating a duplicate authoritative transaction."""
        with self._lock:
            if idempotency_key:
                existing = self.conn.execute(
                    "SELECT id FROM transactions WHERE idempotency_key=?", (idempotency_key,)
                ).fetchone()
                if existing is not None:
                    return existing["id"]

            total_debit = sum_money(l.get("debit", 0) for l in lines)
            total_credit = sum_money(l.get("credit", 0) for l in lines)
            if total_debit != total_credit:
                raise UnbalancedEntryError(f"unbalanced entry: debit={total_debit} credit={total_credit}")
            if total_debit <= 0:
                raise UnbalancedEntryError("entry total must be strictly greater than zero")

            txn_id = str(uuid.uuid4())
            try:
                self.conn.execute(
                    "INSERT INTO transactions VALUES (?,?,?,?,?)",
                    (txn_id, description, time.time(), source_message_id, idempotency_key),
                )
                for line in lines:
                    acc_id = self._resolve_account_id(str(line["account_id"]))
                    self.conn.execute(
                        "INSERT INTO transaction_lines VALUES (?,?,?,?,?)",
                        (str(uuid.uuid4()), txn_id, acc_id,
                         money_to_str(line.get("debit", 0)), money_to_str(line.get("credit", 0))),
                    )
                self.conn.commit()
            except sqlite3.IntegrityError:
                self.conn.rollback()
                if idempotency_key:
                    existing = self.conn.execute(
                        "SELECT id FROM transactions WHERE idempotency_key=?", (idempotency_key,)
                    ).fetchone()
                    if existing is not None:
                        return existing["id"]
                raise
            return txn_id

    def _op_query_balance(self, account_id: str) -> str:
        acc_resolved = self._resolve_account_id(account_id)
        with self._lock:
            rows = self.conn.execute(
                "SELECT debit, credit FROM transaction_lines WHERE account_id=?", (acc_resolved,)
            ).fetchall()
        balance = sum_money(r["debit"] for r in rows) - sum_money(r["credit"] for r in rows)
        return money_to_str(balance)

    def _op_list_transactions(self, limit: int = 50) -> list[dict]:
        with self._lock:
            rows = self.conn.execute(
                "SELECT * FROM transactions ORDER BY created_at DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(r) for r in rows]

    def _op_list_transactions_detailed(self, limit: int = 50) -> list[dict]:
        txns = self._op_list_transactions(limit=limit)
        accounts_map = {a["id"]: a for a in self.get_accounts()}
        with self._lock:
            for txn in txns:
                line_rows = self.conn.execute(
                    "SELECT * FROM transaction_lines WHERE transaction_id=?", (txn["id"],)
                ).fetchall()
                lines = []
                for lr in line_rows:
                    ld = dict(lr)
                    acc = accounts_map.get(ld["account_id"], {})
                    ld["account_name"] = acc.get("name", ld["account_id"])
                    ld["account_type"] = acc.get("account_type", "")
                    lines.append(ld)
                txn["lines"] = lines
                txn["total_amount"] = sum(float(l["debit"]) for l in lines)
        return txns

    def _op_get_account_ledger(self, account_id: str) -> dict:
        acc_resolved = self._resolve_account_id(account_id)
        with self._lock:
            acc_row = self.conn.execute("SELECT * FROM accounts WHERE id=?", (acc_resolved,)).fetchone()
            if not acc_row:
                return {"error": "Account not found"}
            
            lines_rows = self.conn.execute(
                """
                SELECT tl.*, t.description as transaction_description, t.created_at as transaction_date
                FROM transaction_lines tl
                JOIN transactions t ON tl.transaction_id = t.id
                WHERE tl.account_id = ?
                ORDER BY t.created_at ASC
                """,
                (acc_resolved,),
            ).fetchall()

        running_balance = 0.0
        entries = []
        for r in lines_rows:
            d = float(r["debit"])
            c = float(r["credit"])
            running_balance += (d - c)
            entries.append({
                "line_id": r["id"],
                "transaction_id": r["transaction_id"],
                "description": r["transaction_description"],
                "date": r["transaction_date"],
                "debit": d,
                "credit": c,
                "running_balance": round(running_balance, 2),
            })

        return {
            "account": dict(acc_row),
            "current_balance": money_to_str(running_balance),
            "entries": entries,
        }

    def _op_list_accounts(self) -> list[dict]:
        with self._lock:
            rows = self.conn.execute("SELECT * FROM accounts ORDER BY account_type, name").fetchall()
        results = []
        for r in rows:
            acc_dict = dict(r)
            acc_dict["balance"] = self._op_query_balance(acc_dict["id"])
            acc_dict["category"] = acc_dict["account_type"]
            results.append(acc_dict)
        return results

    def get_accounts(self) -> list[dict]:
        return self._op_list_accounts()

    def create_account(self, account_id: str, name: str, category: str) -> str:
        with self._lock:
            self.conn.execute(
                "INSERT OR REPLACE INTO accounts VALUES (?,?,?,?)",
                (account_id, name, category, time.time()),
            )
            self.conn.commit()
        return account_id

    def seed_sample_business_data(self) -> int:
        """Seeds realistic sample Iranian/international SME business transactions."""
        sample_postings = [
            {
                "description": "آورده اولیه نقدی سهامداران / Initial Capital Contribution",
                "idempotency_key": "seed_init_capital_01",
                "lines": [
                    {"account_id": "acc_1010", "debit": "150000000.00", "credit": 0},
                    {"account_id": "acc_3010", "debit": 0, "credit": "150000000.00"},
                ],
            },
            {
                "description": "خرید موجودی کالا نقدی / Inventory Stock Purchase",
                "idempotency_key": "seed_inv_purchase_02",
                "lines": [
                    {"account_id": "acc_1200", "debit": "35000000.00", "credit": 0},
                    {"account_id": "acc_1010", "debit": 0, "credit": "35000000.00"},
                ],
            },
            {
                "description": "فروش محصولات نرم‌افزاری و خدمات / Software Services Sales Invoice",
                "idempotency_key": "seed_sales_inv_03",
                "lines": [
                    {"account_id": "acc_1100", "debit": "44000000.00", "credit": 0},
                    {"account_id": "acc_4010", "debit": 0, "credit": "40000000.00"},
                    {"account_id": "acc_2030", "debit": 0, "credit": "4000000.00"},  # 10% VAT
                ],
            },
            {
                "description": "دریافت مطالبات از مشتری به بانک / Cash Collection from Receivables",
                "idempotency_key": "seed_rec_collect_04",
                "lines": [
                    {"account_id": "acc_1010", "debit": "44000000.00", "credit": 0},
                    {"account_id": "acc_1100", "debit": 0, "credit": "44000000.00"},
                ],
            },
            {
                "description": "پرداخت اجاره دفتر مرکزی / Office Rent Monthly Payment",
                "idempotency_key": "seed_rent_pay_05",
                "lines": [
                    {"account_id": "acc_5030", "debit": "18000000.00", "credit": 0},
                    {"account_id": "acc_1010", "debit": 0, "credit": "18000000.00"},
                ],
            },
            {
                "description": "پرداخت حقوق و دستمزد پرسنل مهندسی / Engineering Payroll Disbursement",
                "idempotency_key": "seed_payroll_06",
                "lines": [
                    {"account_id": "acc_5020", "debit": "30000000.00", "credit": 0},
                    {"account_id": "acc_1010", "debit": 0, "credit": "27900000.00"},
                    {"account_id": "acc_2040", "debit": 0, "credit": "2100000.00"},  # 7% Tax Withholding
                ],
            },
            {
                "description": "خرید سرور و تجهیزات سخت‌افزاری / IT Hardware & Equipment",
                "idempotency_key": "seed_equip_07",
                "lines": [
                    {"account_id": "acc_1500", "debit": "22000000.00", "credit": 0},
                    {"account_id": "acc_1010", "debit": 0, "credit": "22000000.00"},
                ],
            },
            {
                "description": "هزینه اینترنت و اشتراک زیرساخت ابری / Cloud Subscriptions & Utilities",
                "idempotency_key": "seed_util_08",
                "lines": [
                    {"account_id": "acc_5040", "debit": "4500000.00", "credit": 0},
                    {"account_id": "acc_1010", "debit": 0, "credit": "4500000.00"},
                ],
            },
        ]

        count = 0
        for item in sample_postings:
            self._op_post_transaction(
                description=item["description"],
                lines=item["lines"],
                source_message_id="seed_initialization",
                idempotency_key=item["idempotency_key"],
            )
            count += 1
        return count
