"""
Message envelope + the audit hash-chain (n10::n32 "name and sign hasher",
n10::n33 "message maker"). Per docs/07-messaging-and-security.md §7.5, this
gives the sequence of financial decisions a tamper-evident ordering
(Haber & Stornetta linked-timestamping), not merely per-message authenticity.
"""
from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import dataclass, field, asdict
from typing import Any, Optional

from hesabdar.config import AUDIT_LOG_PATH


@dataclass
class Message:
    id: str
    sender: str
    recipient: str
    payload: dict
    created_at: float
    signature: Optional[bytes] = None
    prev_hash: Optional[str] = None
    this_hash: Optional[str] = None

    def canonical_bytes(self) -> bytes:
        """Deterministic serialization of everything except the signature
        itself and the hash-chain fields — this is exactly what gets signed
        and exactly what integrity-checking re-derives."""
        core = {"id": self.id, "sender": self.sender, "recipient": self.recipient,
                "payload": self.payload, "created_at": self.created_at}
        return json.dumps(core, sort_keys=True, ensure_ascii=False).encode("utf-8")

    def to_wire(self) -> dict:
        d = asdict(self)
        d["signature"] = self.signature.hex() if self.signature else None
        return d


def new_message(sender: str, recipient: str, payload: dict) -> Message:
    """n10 'massge maker' (n10::n33) — combines name hash + signature hash,
    per its own description: "پیام را با هش اسم ترکیب میکند و با هش امضا
    امضا میکند"."""
    return Message(id=str(uuid.uuid4()), sender=sender, recipient=recipient,
                    payload=payload, created_at=time.time())


class NameAndSignHasher:
    """n10::n32. Maintains a single hash-chained audit log across every
    signed message that has passed through the transport layer, appending
    to AUDIT_LOG_PATH so the sequence itself becomes tamper-evident, not
    just each individual message."""

    def __init__(self, log_path=AUDIT_LOG_PATH):
        self.log_path = log_path
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self._last_hash = self._read_last_hash()

    def _read_last_hash(self) -> Optional[str]:
        if not self.log_path.exists():
            return None
        last = None
        with open(self.log_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    last = json.loads(line)["this_hash"]
        return last

    def chain(self, message: Message) -> Message:
        message.prev_hash = self._last_hash
        digest_input = (message.prev_hash or "") + message.canonical_bytes().decode("utf-8") + \
            (message.signature.hex() if message.signature else "")
        message.this_hash = hashlib.sha256(digest_input.encode("utf-8")).hexdigest()
        self._last_hash = message.this_hash
        with open(self.log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps({
                "id": message.id, "sender": message.sender, "recipient": message.recipient,
                "prev_hash": message.prev_hash, "this_hash": message.this_hash,
                "created_at": message.created_at,
            }, ensure_ascii=False) + "\n")
        return message

    def verify_chain(self) -> bool:
        """Recomputes the chain from AUDIT_LOG_PATH and confirms no entry
        was reordered, inserted, or removed."""
        if not self.log_path.exists():
            return True
        prev = None
        with open(self.log_path, "r", encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue
                entry = json.loads(line)
                if entry["prev_hash"] != prev:
                    return False
                prev = entry["this_hash"]
        return True
