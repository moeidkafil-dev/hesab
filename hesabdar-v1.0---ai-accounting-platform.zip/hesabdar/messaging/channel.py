"""
n13::n2 "new massages architecture". The diagram instantiates the same
four-stage pattern (receiver -> compiler -> sign reader -> read) separately
for every pairing among CEO / main agent / self-healing / recovery /
backup / tool manager / DB manager agent (§7.2).

Includes Message Deduplication (PRD §13):
If multiple agents submit equivalent idempotent commands within a dedup window,
the command is executed once, and results are shared with all requesters while
preserving individual request logs and full audit trails.
"""
from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from hesabdar.messaging.identity import AgentIdentity, IdentityRegistry
from hesabdar.messaging.message import Message, NameAndSignHasher, new_message


class AuthenticationError(Exception):
    pass


@dataclass
class DeliveryResult:
    ok: bool
    message: Message
    reason: str = ""
    deduplicated: bool = False
    execution_id: Optional[str] = None


@dataclass
class DeduplicationRecord:
    command_hash: str
    execution_id: str
    first_requester: str
    requesters: list[str] = field(default_factory=list)
    request_ids: list[str] = field(default_factory=list)
    executed_at: float = field(default_factory=time.time)
    result: Any = None
    ok: bool = True
    error: Optional[str] = None


class CommandDeduplicator:
    """PRD §13: Deduplicates idempotent commands safely."""

    def __init__(self, window_seconds: float = 10.0):
        self.window_seconds = window_seconds
        self._cache: dict[str, DeduplicationRecord] = {}

    def compute_hash(self, payload: dict) -> str:
        # Canonical hash of operation and arguments
        op = payload.get("op", "")
        args = payload.get("args", {})
        norm = json.dumps({"op": op, "args": args}, sort_keys=True, ensure_ascii=False)
        return hashlib.sha256(norm.encode("utf-8")).hexdigest()

    def is_deduplicable(self, payload: dict) -> bool:
        # Read-only and idempotent operations are safe to deduplicate
        op = payload.get("op", "")
        idempotent_ops = {
            "query_balance",
            "list_transactions",
            "query_account",
            "read_rule",
            "match_rule",
            "get_status",
            "inspect_memory",
        }
        return op in idempotent_ops

    def get_or_register(self, message: Message) -> tuple[bool, Optional[DeduplicationRecord]]:
        if not self.is_deduplicable(message.payload):
            return False, None

        cmd_hash = self.compute_hash(message.payload)
        now = time.time()

        if cmd_hash in self._cache:
            record = self._cache[cmd_hash]
            if now - record.executed_at <= self.window_seconds:
                record.requesters.append(message.sender)
                record.request_ids.append(message.id)
                return True, record

        # Register new execution placeholder
        record = DeduplicationRecord(
            command_hash=cmd_hash,
            execution_id=message.id,
            first_requester=message.sender,
            requesters=[message.sender],
            request_ids=[message.id],
            executed_at=now,
        )
        self._cache[cmd_hash] = record
        return False, record

    def store_result(self, cmd_hash: str, ok: bool, result: Any, error: Optional[str] = None) -> None:
        if cmd_hash in self._cache:
            rec = self._cache[cmd_hash]
            rec.ok = ok
            rec.result = result
            rec.error = error


class Channel:
    """One transport pairing, e.g. Channel(ceo_identity, db_manager_registry)."""

    def __init__(
        self,
        local: AgentIdentity,
        registry: IdentityRegistry,
        hasher: Optional[NameAndSignHasher] = None,
        deduplicator: Optional[CommandDeduplicator] = None,
    ):
        self.local = local
        self.registry = registry
        self.hasher = hasher or NameAndSignHasher()
        self.deduplicator = deduplicator or CommandDeduplicator()

    # ------------------------------------------------------------- send side
    def system_authentication(self) -> None:
        """n13::n2::n0 — confirms local identity is registered."""
        if not self.registry.is_registered(self.local.agent_id):
            raise AuthenticationError(f"{self.local.agent_id} is not a registered identity")

    def aim_for_message(self, recipient: str, payload: dict) -> Message:
        """n13::n2::n1"""
        self.system_authentication()
        return new_message(self.local.agent_id, recipient, payload)

    def signner(self, message: Message) -> Message:
        """n13::n2::n2"""
        message.signature = self.local.sign(message.canonical_bytes())
        return message

    def sender(self, message: Message, outbox: "Channel") -> DeliveryResult:
        """n13::n2::n3 -> hands off to recipient's receiver."""
        message = self.hasher.chain(message)
        return outbox.receiver(message)

    def send(self, recipient: str, payload: dict, outbox: "Channel") -> DeliveryResult:
        message = self.aim_for_message(recipient, payload)
        message = self.signner(message)
        return self.sender(message, outbox)

    # ---------------------------------------------------------- receive side
    def receiver(self, message: Message) -> DeliveryResult:
        """n13::n2::n4"""
        return self.compiler(message)

    def compiler(self, message: Message) -> DeliveryResult:
        """n13::n2::n5 — normalizes envelope before verification."""
        return self.sign_reader(message)

    def sign_reader(self, message: Message) -> DeliveryResult:
        """n13::n2::n6 — signature verification."""
        if message.signature is None:
            return DeliveryResult(False, message, "missing signature")
        ok = self.registry.verify(message.sender, message.canonical_bytes(), message.signature)
        if not ok:
            return DeliveryResult(False, message, "signature verification failed")
        return self.read(message)

    def read(self, message: Message) -> DeliveryResult:
        """n13::n2::n7 — handoff to domain logic + deduplication check."""
        is_dup, record = self.deduplicator.get_or_register(message)
        if is_dup and record is not None:
            return DeliveryResult(
                ok=record.ok,
                message=message,
                reason=f"deduplicated: reusing execution {record.execution_id}",
                deduplicated=True,
                execution_id=record.execution_id,
            )
        return DeliveryResult(True, message, "authenticated", execution_id=message.id)
