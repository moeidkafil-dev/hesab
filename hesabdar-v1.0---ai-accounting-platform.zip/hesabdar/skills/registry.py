"""
Skill Registry and Security Validation Engine for HESABDAR (PRD §19, §20).
Skills are distinct from Agents, Tools, and Models.
Supports real Git repository URLs, README URLs, capability matching,
version pinning, checksum integrity, and strict permission gating.
"""
from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Optional


class SkillStatus(str, Enum):
    ACTIVE = "active"
    DISABLED = "disabled"
    REVOKED = "revoked"
    PENDING_REVIEW = "pending_review"


class SkillSecurityError(Exception):
    pass


@dataclass
class Skill:
    id: str
    name: str
    version: str
    repository: str
    readme: str
    documentation: str
    capabilities: list[str] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)
    permissions: list[str] = field(default_factory=list)
    compatible_agents: list[str] = field(default_factory=list)
    runtime_requirements: dict[str, Any] = field(default_factory=dict)
    checksum: str = ""
    status: SkillStatus = SkillStatus.ACTIVE
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    usage_count: int = 0
    handler: Optional[Callable[..., Any]] = field(default=None, repr=False)

    def calculate_checksum(self) -> str:
        data = {
            "id": self.id,
            "name": self.name,
            "version": self.version,
            "repository": self.repository,
            "capabilities": sorted(self.capabilities),
            "permissions": sorted(self.permissions),
        }
        raw = json.dumps(data, sort_keys=True).encode("utf-8")
        return hashlib.sha256(raw).hexdigest()

    def to_dict(self) -> dict:
        d = asdict(self)
        d.pop("handler", None)
        d["status"] = self.status.value
        return d


class SkillSecurityVerifier:
    """PRD §20: Source validation, checksum pinning, permission validation."""

    ALLOWED_PERMISSION_SCOPES = {
        "read_ledger",
        "write_ledger",
        "read_rules",
        "file_io",
        "web_access",
        "excel_io",
        "analytics_compute",
        "forecasting_model",
    }

    @classmethod
    def validate(cls, skill: Skill) -> tuple[bool, list[str]]:
        errors = []
        if not skill.id or not skill.name:
            errors.append("Skill must have a non-empty id and name.")

        if not skill.repository:
            errors.append("Skill must declare a source repository URL or identifier.")

        # Validate permissions
        for perm in skill.permissions:
            if perm not in cls.ALLOWED_PERMISSION_SCOPES and not perm.startswith("custom:"):
                errors.append(f"Permission {perm!r} is not in the recognized security scopes.")

        # Checksum integrity
        expected_cs = skill.calculate_checksum()
        if skill.checksum and skill.checksum != expected_cs:
            errors.append(f"Checksum mismatch for skill {skill.id}. Declared {skill.checksum}, computed {expected_cs}.")

        return len(errors) == 0, errors


class SkillExecutor:
    """Invokes skills within authorized agent boundaries."""

    def __init__(self, registry: "SkillRegistry"):
        self.registry = registry

    def execute(self, agent_id: str, skill_id: str, **kwargs) -> dict:
        skill = self.registry.get(skill_id)
        if skill is None:
            return {"ok": False, "error": f"Skill {skill_id!r} not found"}

        if skill.status != SkillStatus.ACTIVE:
            return {"ok": False, "error": f"Skill {skill_id!r} is currently {skill.status.value}"}

        # Check agent compatibility and permissions
        if skill.compatible_agents and "*" not in skill.compatible_agents and agent_id not in skill.compatible_agents:
            raise SkillSecurityError(f"Agent {agent_id!r} is not authorized for skill {skill_id!r}")

        skill.usage_count += 1
        skill.updated_at = time.time()

        try:
            if skill.handler:
                result = skill.handler(**kwargs)
            else:
                result = {"executed_skill": skill.name, "capabilities": skill.capabilities, "args": kwargs}
            return {"ok": True, "skill_id": skill_id, "result": result, "usage_count": skill.usage_count}
        except Exception as exc:
            return {"ok": False, "skill_id": skill_id, "error": str(exc)}


class SkillRegistry:
    """Manages the full lifecycle of Skills for CEO and worker agents."""

    def __init__(self):
        self._skills: dict[str, Skill] = {}
        self.verifier = SkillSecurityVerifier()
        self.executor = SkillExecutor(self)
        self._seed_default_skills()

    def _seed_default_skills(self) -> None:
        # Standard default skills for accounting OS
        default_skills = [
            Skill(
                id="financial_statement_analysis",
                name="Financial Statement Analysis Skill",
                version="1.0.0",
                repository="https://github.com/moeidkafil-dev/hessabdar-skills/financial-analysis",
                readme="https://github.com/moeidkafil-dev/hessabdar-skills/financial-analysis/README.md",
                documentation="https://hesabdar.internal/docs/skills/financial-analysis",
                capabilities=["balance_sheet_analysis", "cash_flow_forecasting", "variance_analysis"],
                permissions=["read_ledger", "analytics_compute"],
                compatible_agents=["ceo", "reporting_agent", "data_analyst"],
            ),
            Skill(
                id="tax_compliance_iran",
                name="Iran Statutory Tax Compliance Skill",
                version="2.1.0",
                repository="https://github.com/moeidkafil-dev/hessabdar-skills/tax-compliance-ir",
                readme="https://github.com/moeidkafil-dev/hessabdar-skills/tax-compliance-ir/README.md",
                documentation="https://hesabdar.internal/docs/skills/tax-iran",
                capabilities=["vat_calculation", "withholding_tax", "seasonal_tax_report"],
                permissions=["read_ledger", "read_rules", "analytics_compute"],
                compatible_agents=["ceo", "accounting_engine", "tax_agent"],
            ),
            Skill(
                id="double_entry_reconciler",
                name="Automated Double-Entry Reconciler Skill",
                version="1.2.0",
                repository="https://github.com/moeidkafil-dev/hessabdar-skills/double-entry-reconciler",
                readme="https://github.com/moeidkafil-dev/hessabdar-skills/double-entry-reconciler/README.md",
                documentation="https://hesabdar.internal/docs/skills/reconciler",
                capabilities=["bank_reconciliation", "trial_balance_check", "discrepancy_locator"],
                permissions=["read_ledger", "write_ledger", "analytics_compute"],
                compatible_agents=["ceo", "accounting_engine", "final_checker"],
            ),
            Skill(
                id="excel_financial_exporter",
                name="Excel Multi-Sheet Financial Model Exporter",
                version="1.1.0",
                repository="https://github.com/moeidkafil-dev/hessabdar-skills/excel-exporter",
                readme="https://github.com/moeidkafil-dev/hessabdar-skills/excel-exporter/README.md",
                documentation="https://hesabdar.internal/docs/skills/excel-export",
                capabilities=["multi_sheet_builder", "pivot_table_generation", "vba_formatting"],
                permissions=["read_ledger", "excel_io", "file_io"],
                compatible_agents=["ceo", "reporting_agent", "tool_manager"],
            ),
        ]
        for sk in default_skills:
            sk.checksum = sk.calculate_checksum()
            self.register(sk)

    def register(self, skill: Skill) -> tuple[bool, list[str]]:
        if not skill.checksum:
            skill.checksum = skill.calculate_checksum()
        valid, errors = self.verifier.validate(skill)
        if not valid:
            return False, errors
        self._skills[skill.id] = skill
        return True, []

    def get(self, skill_id: str) -> Optional[Skill]:
        return self._skills.get(skill_id)

    def list_skills(self, status: Optional[SkillStatus] = None) -> list[Skill]:
        if status is None:
            return list(self._skills.values())
        return [s for s in self._skills.values() if s.status == status]

    def find_skills_for_capability(self, capability: str) -> list[Skill]:
        return [s for s in self._skills.values() if s.status == SkillStatus.ACTIVE and capability in s.capabilities]

    def find_skills_for_agent(self, agent_id: str) -> list[Skill]:
        return [
            s
            for s in self._skills.values()
            if s.status == SkillStatus.ACTIVE
            and (not s.compatible_agents or "*" in s.compatible_agents or agent_id in s.compatible_agents)
        ]

    def set_status(self, skill_id: str, status: SkillStatus) -> bool:
        if skill_id in self._skills:
            self._skills[skill_id].status = status
            self._skills[skill_id].updated_at = time.time()
            return True
        return False
