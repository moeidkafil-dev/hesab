"""
Debugger Subsystem (PRD §40, §41).
Enables deterministic inspection, causality tracing, prompt/response analysis,
tool/skill call inspection, memory timeline tracking, and repair advice.
"""
from __future__ import annotations

import time
from dataclasses import asdict, dataclass, field
from typing import Any, Optional

from hesabdar.super_logs.manager import SuperLogEntry, SuperLogManager


@dataclass
class TraceReport:
    query_key: str
    query_value: str
    total_events: int
    events: list[dict[str, Any]] = field(default_factory=list)
    has_errors: bool = False
    error_summary: list[str] = field(default_factory=list)
    total_latency_ms: float = 0.0
    models_invoked: list[str] = field(default_factory=list)
    skills_invoked: list[str] = field(default_factory=list)
    tools_invoked: list[str] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


class DebuggerSystem:
    def __init__(self, super_logs: Optional[SuperLogManager] = None):
        self.super_logs = super_logs or SuperLogManager()

    def trace(
        self,
        task_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        correlation_id: Optional[str] = None,
    ) -> TraceReport:
        key = "task_id" if task_id else ("agent_id" if agent_id else "correlation_id")
        val = task_id or agent_id or correlation_id or ""

        entries = self.super_logs.query(
            task_id=task_id,
            agent_id=agent_id,
            correlation_id=correlation_id,
            limit=200,
        )

        events = []
        errors = []
        tot_lat = 0.0
        models = set()
        skills = set()
        tools = set()

        for e in entries:
            events.append(e.to_dict())
            if e.error:
                errors.append(f"[{e.agent_id or 'unknown'}]: {e.error}")
            tot_lat += e.latency_ms
            if e.model:
                models.add(e.model)
            if e.skill:
                skills.add(e.skill)
            if e.tool:
                tools.add(e.tool)

        recs = []
        if errors:
            recs.append("Detected runtime execution errors; check agent tool permissions or DB invariants.")
        if tot_lat > 5000:
            recs.append("High cumulative latency observed; check LLM response times or enable local caching.")

        return TraceReport(
            query_key=key,
            query_value=val,
            total_events=len(events),
            events=events,
            has_errors=len(errors) > 0,
            error_summary=errors,
            total_latency_ms=round(tot_lat, 2),
            models_invoked=sorted(models),
            skills_invoked=sorted(skills),
            tools_invoked=sorted(tools),
            recommendations=recs,
        )
