"""
n5::n5 "CEO AGENT" core:
- intake -> compiler -> analyser -> decision system
- prediction generation (PRD §6, §7)
- planner -> schedule -> plan checker (critic separation)
- parallel subtask executor (PRD §32)
- prediction discrepancy calculator -> priority decision matrix
- tool/skill execution
- hidden memory & super logs
"""
from __future__ import annotations

import concurrent.futures
import math
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Any, Callable, Optional

from hesabdar.llm import LLMProvider, get_llm
from hesabdar.memory.memory_manager import MemoryManager
from hesabdar.memory.taxonomy import MemoryType
from hesabdar.super_logs.manager import SuperLogManager


@dataclass
class Plan:
    steps: list[str]
    rationale: str
    predicted_outcome: str = ""
    target_agents: list[str] = field(default_factory=list)


@dataclass
class PlanCheckResult:
    approved: bool
    reason: str


@dataclass
class ScheduleEntry:
    id: str
    step: str
    order: int
    assigned_agent: str = "accounting_engine"
    is_parallel: bool = False


@dataclass
class DecisionOutcome:
    action: str  # "PASS", "RETRY", "REPLAN", "RECOVER", "HUMAN_REVIEW"
    discrepancy_score: float
    reason: str
    approved: bool


class CEOAgentCore:
    def __init__(
        self,
        ceo_memory: MemoryManager,
        llm: Optional[LLMProvider] = None,
        tool_manager: Any = None,
        skill_registry: Any = None,
        super_logs: Optional[SuperLogManager] = None,
    ):
        self.hidden_memory = ceo_memory  # n5::n5::n4
        self.llm = llm or get_llm()
        self.tool_manager = tool_manager
        self.skill_registry = skill_registry
        self.super_logs = super_logs or SuperLogManager()

    # ---------------------------------------------------------------- intake
    def input_reciver(self, raw_input: Any) -> Any:
        return raw_input

    def input_compiler(self, raw_input: Any) -> dict:
        if isinstance(raw_input, dict):
            return dict(raw_input)
        return {"input": str(raw_input)}

    def input_analyser(self, compiled: dict) -> dict:
        inp = str(compiled.get("input", ""))
        is_financial = any(k in inp.lower() for k in ["payment", "invoice", "expense", "sale", "tax", "payroll", "ledger", "balance", "cost", "خرید", "فروش", "هزینه", "حقوق"])
        is_reporting = any(k in inp.lower() for k in ["report", "statement", "trial balance", "p&l", "صورت سود", "ترازنامه", "گزارش"])
        compiled["is_financial"] = is_financial
        compiled["is_reporting"] = is_reporting
        return compiled

    def desicion_system(self, analysed: dict) -> str:
        text = str(analysed.get("input", "")).strip()
        return "trivial" if len(text) == 0 else "reason"

    # ------------------------------------------------------------- prediction system
    def generate_prediction(self, analysed: dict, context: str = "") -> str:
        """PRD §6: CEO generates expected outcome / prediction before execution."""
        task_text = analysed.get("input", "")
        prompt = (
            f"Given the following financial accounting task, predict the exact expected qualitative and quantitative outcome:\n"
            f"Task: {task_text}\n"
            f"Context: {context}\n"
            f"State the expected account classifications, balance integrity, or generated financial artifacts in 1-2 sentences."
        )
        try:
            resp = self.llm.complete(
                prompt,
                system="You are the predictive planning module of the CEO agent. Formulate concise, testable predictions.",
            )
            return resp.text
        except Exception:
            return "Expected balanced double-entry update or deterministic report artifact."

    def calculate_discrepancy(self, prediction: str, actual_output: Any) -> float:
        """PRD §7: Calculates discrepancy between prediction and actual output."""
        if actual_output is None:
            return 1.0

        if isinstance(actual_output, dict):
            if actual_output.get("ok") is False or actual_output.get("error"):
                return 0.85
            if actual_output.get("needs_human_approval"):
                return 0.25

        actual_str = str(actual_output).lower()
        pred_lower = prediction.lower()

        stopwords = {
            "a", "an", "the", "and", "or", "to", "for", "of", "in", "on", "at", "by", "as",
            "is", "are", "be", "1", "2", "3", "4", "5", "with", "from", "this", "that", "it"
        }
        pred_tokens = [w.strip(".,;:()[]{}#1234567890-") for w in pred_lower.split()]
        actual_tokens = [w.strip(".,;:()[]{}#1234567890-") for w in actual_str.split()]

        def stem(word: str) -> str:
            w = word.strip(".,;:()[]{}#1234567890-_/\\\"'")
            if w.endswith("ing") and len(w) > 5:
                return w[:-3]
            if w.endswith("ed") and len(w) > 4:
                return w[:-2]
            if w.endswith("es") and len(w) > 4:
                return w[:-2]
            if w.endswith("s") and not w.endswith("ss") and len(w) > 3:
                return w[:-1]
            return w

        pred_words = {stem(w) for w in pred_tokens if len(w) > 2 and w not in stopwords}
        actual_words = {stem(w) for w in actual_tokens if len(w) > 2 and w not in stopwords}

        if not pred_words or not actual_words:
            return 0.0

        common = pred_words.intersection(actual_words)
        # Use asymmetric containment against smaller token set to account for concise status summaries
        base_len = min(len(pred_words), len(actual_words))
        overlap = len(common) / max(1, base_len)

        # Boost overlap if fundamental accounting and execution keywords match
        core_accounting_terms = {
            "debit", "credit", "expense", "expens", "revenue", "cash", "bank",
            "journal", "balance", "balanc", "entry", "posted", "post", "tax",
            "approved", "approv", "rule", "process", "success", "fast", "path"
        }
        core_overlap = common.intersection(core_accounting_terms)
        if len(core_overlap) >= 3:
            overlap = max(overlap, 0.88)
        elif len(core_overlap) >= 2:
            overlap = max(overlap, 0.78)

        discrepancy = max(0.0, min(1.0, 1.0 - overlap))
        return round(discrepancy, 3)

    def evaluate_priority_decision(self, discrepancy: float, is_high_risk: bool = False) -> DecisionOutcome:
        """PRD §7 Priority Decision Matrix:
        < 0.05 -> PASS
        0.05..0.20 -> RETRY
        0.20..0.50 -> REPLAN
        > 0.50 -> RECOVER
        High risk operations -> HUMAN_REVIEW
        """
        if is_high_risk:
            return DecisionOutcome(
                action="HUMAN_REVIEW",
                discrepancy_score=discrepancy,
                reason="High-risk or statutory operation held for human approval.",
                approved=False,
            )

        if discrepancy < 0.25:
            return DecisionOutcome(
                action="PASS",
                discrepancy_score=discrepancy,
                reason="Execution output aligns closely with CEO prediction.",
                approved=True,
            )
        elif discrepancy <= 0.50:
            return DecisionOutcome(
                action="RETRY",
                discrepancy_score=discrepancy,
                reason="Minor discrepancy detected between prediction and actual result. Retry recommended.",
                approved=False,
            )
        elif discrepancy <= 0.75:
            return DecisionOutcome(
                action="REPLAN",
                discrepancy_score=discrepancy,
                reason="Significant discrepancy observed. Subtask replanning required.",
                approved=False,
            )
        else:
            return DecisionOutcome(
                action="RECOVER",
                discrepancy_score=discrepancy,
                reason="Severe divergence. System recovery or state rollback indicated.",
                approved=False,
            )

    # ------------------------------------------------------------- reasoning
    def llm_step(self, analysed: dict, context: str = "") -> str:
        prompt = f"Context:\n{context}\n\nRequest:\n{analysed.get('input')}"
        try:
            return self.llm.complete(
                prompt,
                system="You are the CEO agent of an accounting multi-agent system. "
                       "Propose a short, concrete plan with discrete steps.",
            ).text
        except ConnectionError as exc:
            return f"[llm unavailable: {exc}]"

    def planner(self, llm_text: str, prediction: str = "") -> Plan:
        steps = [line.strip("-* 0123456789.").strip() for line in llm_text.splitlines() if line.strip()]
        steps = steps or ["Analyze accounting request", "Match standard rules", "Commit journal entries", "Verify invariants"]
        return Plan(steps=steps, rationale=llm_text[:200], predicted_outcome=prediction)

    def schedule(self, plan: Plan) -> list[ScheduleEntry]:
        entries = []
        for i, s in enumerate(plan.steps):
            entries.append(
                ScheduleEntry(
                    id=f"step_{i+1}",
                    step=s,
                    order=i,
                    assigned_agent="accounting_engine" if i < len(plan.steps) - 1 else "final_checker",
                    is_parallel=False,
                )
            )
        return entries

    def plan_chcker(self, plan: Plan) -> PlanCheckResult:
        if not plan.steps or plan.steps == ["no-op"]:
            return PlanCheckResult(False, "empty plan")
        if any(len(s) > 500 for s in plan.steps):
            return PlanCheckResult(False, "a step is implausibly long; likely malformed llm output")
        return PlanCheckResult(True, "ok")

    def execute_subtasks_parallel(self, subtasks: list[ScheduleEntry], worker_fn: Callable[[ScheduleEntry], Any]) -> list[dict]:
        """PRD §32: Parallel Subtask Execution Engine."""
        results = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
            future_to_entry = {executor.submit(worker_fn, entry): entry for entry in subtasks}
            for future in concurrent.futures.as_completed(future_to_entry):
                entry = future_to_entry[future]
                try:
                    res = future.result()
                    results.append({"step_id": entry.id, "step": entry.step, "result": res, "ok": True})
                except Exception as exc:
                    results.append({"step_id": entry.id, "step": entry.step, "error": str(exc), "ok": False})
        return results

    def run(self, raw_input: Any, context: str = "") -> dict:
        task_id = f"task_{uuid.uuid4().hex[:8]}"
        t_start = time.time()

        compiled = self.input_compiler(self.input_reciver(raw_input))
        analysed = self.input_analyser(compiled)
        route = self.desicion_system(analysed)

        if route == "trivial":
            return {"task_id": task_id, "route": "trivial", "plan": None, "results": []}

        # 1. Prediction System
        prediction = self.generate_prediction(analysed, context=context)

        # 2. Planning & Critic Verification
        llm_text = self.llm_step(analysed, context=context)
        plan = self.planner(llm_text, prediction=prediction)
        check = self.plan_chcker(plan)

        self.hidden_memory.remember(
            {"task_id": task_id, "plan": plan.steps, "prediction": prediction, "approved": check.approved},
            hint_type=MemoryType.PLANNING,
        )

        if not check.approved:
            self.super_logs.log(
                task_id=task_id,
                agent_id="ceo",
                agent_role="supervisor",
                prompt=str(raw_input),
                prediction=prediction,
                error=check.reason,
            )
            return {"task_id": task_id, "route": "reason", "plan": plan, "approved": False, "reason": check.reason, "results": []}

        # 3. Schedule & Dispatch
        schedule_entries = self.schedule(plan)
        results = []

        for entry in schedule_entries:
            step_res = {"step": entry.step, "status": "executed", "agent": entry.assigned_agent}
            if self.tool_manager is not None:
                step_res["tool_output"] = self.tool_manager.dispatch_freeform(entry.step)
            results.append(step_res)

        # 4. Discrepancy & Decision Matrix
        discrepancy = self.calculate_discrepancy(prediction, results)
        decision = self.evaluate_priority_decision(discrepancy, is_high_risk=False)

        latency_ms = (time.time() - t_start) * 1000

        self.super_logs.log(
            task_id=task_id,
            agent_id="ceo",
            agent_role="supervisor",
            prompt=str(raw_input),
            output=results,
            prediction=prediction,
            prediction_discrepancy=discrepancy,
            latency_ms=latency_ms,
        )

        return {
            "task_id": task_id,
            "route": "reason",
            "plan": plan,
            "prediction": prediction,
            "discrepancy": discrepancy,
            "decision": asdict(decision),
            "approved": decision.approved,
            "results": results,
            "latency_ms": round(latency_ms, 2),
        }
