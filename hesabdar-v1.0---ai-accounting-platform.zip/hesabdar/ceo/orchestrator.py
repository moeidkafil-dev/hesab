"""
n5 "CEO agent architecture" — Comprehensive multi-agent orchestrator
connecting all 11 CEO subgroups, Accounting Domain Engine (n16/n17/n18),
Final Checker Critic (n14), Reporting Pipeline (n1/n2), Skill Registry (PRD §19),
Resilience & Self-Healing (n7/n8/n9), and Authoritative DB Manager Agent.
"""
from __future__ import annotations

import time
import uuid
from dataclasses import asdict
from typing import Any, Optional

from hesabdar.accounting.engine import AccountingDomainEngine
from hesabdar.accounting.rule_manager import RuleManager, RuleStatus
from hesabdar.accounting.schema import DEFAULT_CHART_OF_ACCOUNTS
from hesabdar.ceo.agent_builder import AgentBuilder
from hesabdar.ceo.agent_killer import AgentKiller
from hesabdar.ceo.agents_input_messages_manager import AgentsInputMessagesManager
from hesabdar.ceo.ceo_core import CEOAgentCore
from hesabdar.ceo.ceo_memory_manager import CEOMemoryManager
from hesabdar.ceo.input_output_manager import InputOutputManager
from hesabdar.ceo.log_input_manager import LogInputManager
from hesabdar.ceo.new_agent_manager import NewAgentManager
from hesabdar.ceo.prompt_manager import PolicyViolation, PromptManager
from hesabdar.ceo.resource_distributor import ResourceDistributor
from hesabdar.critic.final_checker import FinalCheckerAgent, VerificationDisposition
from hesabdar.db_manager.agent import DBManagerAgent
from hesabdar.llm import LLMProvider, get_llm
from hesabdar.messaging.channel import Channel
from hesabdar.messaging.identity import AgentIdentity, IdentityRegistry
from hesabdar.messaging.message import Message
from hesabdar.reporting.pipeline import ReportingPipeline, ReportType
from hesabdar.resilience.backup import BackupSystem
from hesabdar.resilience.debugger import DebuggerSystem
from hesabdar.resilience.recovery import RecoverySystem
from hesabdar.resilience.self_healing import SelfHealingSystem
from hesabdar.skills.registry import SkillRegistry, SkillStatus
from hesabdar.super_logs.manager import SuperLogManager
from hesabdar.tools.tool_manager import ToolManager


class CEOAgentArchitecture:
    def __init__(self, llm: Optional[LLMProvider] = None, sandbox_root: Optional[str] = None):
        self.llm = llm or get_llm()

        # 1. Identity & Cryptographic Registry
        self.registry = IdentityRegistry()
        self.identity = AgentIdentity.load_or_create("ceo")
        self.registry.register(self.identity)
        self.channel = Channel(self.identity, self.registry)

        # 2. Super Logs & Universal Traceability
        self.super_logs = SuperLogManager()

        # 3. CEO Memory & Taxonomies
        self.memory = CEOMemoryManager(llm=self.llm)

        # 4. Tool & Skill Infrastructure
        self.tool_manager = ToolManager(sandbox_root=sandbox_root)
        self.skill_registry = SkillRegistry()

        # 5. Core CEO Subgroups
        self.log_input_manager = LogInputManager()
        self.prompt_manager = PromptManager()
        self.new_agent_manager = NewAgentManager(self.registry)
        self.agent_killer = AgentKiller(self.new_agent_manager, self.memory, llm=self.llm)
        self.core = CEOAgentCore(
            self.memory,
            llm=self.llm,
            tool_manager=self.tool_manager,
            skill_registry=self.skill_registry,
            super_logs=self.super_logs,
        )
        self.inbound = AgentsInputMessagesManager(self.core)
        self.resource_distributor = ResourceDistributor()
        self.agent_builder = AgentBuilder(self.new_agent_manager, self.memory)
        self.io_manager = InputOutputManager()

        # 6. Authoritative DB Manager Agent
        self.db_manager = DBManagerAgent()
        self.db_identity = AgentIdentity.load_or_create("db_manager_agent")
        self.registry.register(self.db_identity)
        self.db_channel = Channel(self.db_identity, self.registry)

        # Seed initial accounts in DB if empty
        self._initialize_default_db_accounts()

        # 7. Accounting Domain Engine (n16, n17, n18)
        self.rule_manager = RuleManager()
        self.accounting_engine = AccountingDomainEngine(
            rule_manager=self.rule_manager,
            llm=self.llm,
            db_manager_caller=self.send_to_db,
        )

        # 8. Critic & Final Checker (n14)
        self.final_checker = FinalCheckerAgent(llm=self.llm, db_reader=self.db_manager)

        # 9. Reporting Pipeline (n1, n2)
        self.reporting_pipeline = ReportingPipeline(llm=self.llm, db_reader=self.db_manager)

        # 10. Resilience Subsystems (n7, n8, n9, Debugger)
        self.backup_system = BackupSystem()
        self.recovery_system = RecoverySystem(backup_system=self.backup_system)
        self.self_healing = SelfHealingSystem(super_logs=self.super_logs, llm=self.llm)
        self.debugger = DebuggerSystem(super_logs=self.super_logs)

        # 11. Human Approval Pending Queue
        self._pending_approvals: list[dict[str, Any]] = []

    def _initialize_default_db_accounts(self) -> None:
        try:
            existing = self.db_manager.get_accounts()
            if not existing:
                for acc in DEFAULT_CHART_OF_ACCOUNTS:
                    self.db_manager.create_account(
                        account_id=acc.id,
                        name=f"{acc.code} - {acc.name}",
                        category=acc.category.value,
                    )
        except Exception:
            pass

    # ---------------------------------------------------------------- Primary Task Execution
    def execute_accounting_task(self, prompt: str, raw_payload: Optional[dict[str, Any]] = None) -> dict[str, Any]:
        """Full end-to-end multi-agent execution pipeline:
        1. Prompt intake & security check.
        2. Prediction generation.
        3. Accounting domain engine (Fast Path or Research Path).
        4. Critic 4-layer verification.
        5. Prediction discrepancy evaluation.
        6. Super log recording.
        """
        task_id = f"task_{uuid.uuid4().hex[:8]}"
        t_start = time.time()

        # Step 1: Resource distribution & prompt policy
        alloc = self.resource_distributor.request_allocation("ceo_core", is_financial=True)
        if not alloc.granted:
            return {"ok": False, "task_id": task_id, "reason": alloc.reason}

        try:
            selection = self.prompt_manager.process(prompt)
        except PolicyViolation as exc:
            self.resource_distributor.release("ceo_core")
            return {"ok": False, "task_id": task_id, "reason": str(exc)}

        # Step 2: Prediction formulation
        prediction = self.core.generate_prediction({"input": prompt})

        # Step 3: Accounting Domain Processing
        tx_data = raw_payload or {"description": prompt, "amount": 0.0}
        domain_res = self.accounting_engine.process_transaction(tx_data, source_message_id=task_id)

        # Step 4: Handle Human Approval Gate
        if domain_res.needs_human_approval:
            approval_item = {
                "id": f"appr_{uuid.uuid4().hex[:8]}",
                "task_id": task_id,
                "prompt": prompt,
                "path_taken": domain_res.path_taken,
                "reason": domain_res.approval_reason,
                "candidate_rule": domain_res.candidate_rule.to_dict() if domain_res.candidate_rule else None,
                "created_at": time.time(),
                "status": "pending",
            }
            self._pending_approvals.append(approval_item)
            self.resource_distributor.release("ceo_core")

            self.super_logs.log(
                task_id=task_id,
                agent_id="ceo",
                agent_role="supervisor",
                prompt=prompt,
                prediction=prediction,
                human_approval_required=True,
            )

            return {
                "ok": True,
                "task_id": task_id,
                "status": "pending_human_approval",
                "approval_id": approval_item["id"],
                "reason": domain_res.approval_reason,
                "candidate_rule": approval_item["candidate_rule"],
                "prediction": prediction,
            }

        # Step 5: Independent Critic Verification (n14)
        target_item = (
            domain_res.execution.journal_entry
            if domain_res.execution and domain_res.execution.journal_entry
            else tx_data
        )
        critic_report = self.final_checker.check(target_item, input_task=prompt, expected_context=prediction)

        # Step 6: Prediction Discrepancy & Priority Evaluation
        discrepancy = self.core.calculate_discrepancy(prediction, domain_res.summary)
        decision = self.core.evaluate_priority_decision(
            discrepancy,
            is_high_risk=(critic_report.disposition == VerificationDisposition.HUMAN_REVIEW),
        )

        latency_ms = (time.time() - t_start) * 1000
        self.resource_distributor.release("ceo_core")

        # Step 7: Record to Super Logs
        self.super_logs.log(
            task_id=task_id,
            agent_id="ceo",
            agent_role="supervisor",
            prompt=prompt,
            output=domain_res.summary,
            prediction=prediction,
            prediction_discrepancy=discrepancy,
            latency_ms=latency_ms,
            error=domain_res.execution.error if domain_res.execution and not domain_res.execution.ok else None,
        )

        return {
            "ok": domain_res.ok and critic_report.passed,
            "task_id": task_id,
            "path_taken": domain_res.path_taken,
            "summary": domain_res.summary,
            "prediction": prediction,
            "discrepancy": discrepancy,
            "decision": asdict(decision),
            "critic_report": critic_report.to_dict(),
            "journal_entry": domain_res.execution.journal_entry if domain_res.execution else None,
            "latency_ms": round(latency_ms, 2),
        }

    # ---------------------------------------------------------------- Human Approval Controls
    def list_pending_approvals(self) -> list[dict[str, Any]]:
        return [a for a in self._pending_approvals if a["status"] == "pending"]

    def approve_item(self, approval_id: str, approver: str = "human_supervisor") -> bool:
        for item in self._pending_approvals:
            if item["id"] == approval_id and item["status"] == "pending":
                item["status"] = "approved"
                item["approver"] = approver
                if item.get("candidate_rule"):
                    rule_id = item["candidate_rule"]["id"]
                    self.rule_manager.approve_rule(rule_id, approver)
                self.super_logs.log(
                    task_id=item["task_id"],
                    agent_id="ceo",
                    agent_role="supervisor",
                    human_approval_required=True,
                    human_approver=approver,
                    human_decision="approved",
                )
                return True
        return False

    def reject_item(self, approval_id: str, reason: str = "Rejected by human supervisor") -> bool:
        for item in self._pending_approvals:
            if item["id"] == approval_id and item["status"] == "pending":
                item["status"] = "rejected"
                if item.get("candidate_rule"):
                    rule_id = item["candidate_rule"]["id"]
                    self.rule_manager.reject_rule(rule_id, reason)
                self.super_logs.log(
                    task_id=item["task_id"],
                    agent_id="ceo",
                    agent_role="supervisor",
                    human_approval_required=True,
                    human_decision="rejected",
                    error=reason,
                )
                return True
        return False

    # ---------------------------------------------------------------- DB Bridge
    def send_to_db(self, op: str, args: dict) -> Any:
        delivery = self.channel.send("db_manager_agent", {"op": op, "args": args}, self.db_channel)
        if not delivery.ok:
            return {"ok": False, "reason": delivery.reason}
        return self.db_manager.handle(delivery.message)

    # ---------------------------------------------------------------- Lifecycle & Management
    def provision_agent(self, agent_id: str, role: str, related_to: Optional[list[str]] = None):
        return self.agent_builder.build(agent_id, role, related_to=related_to)

    def retire_agent(self, agent_id: str, notes: str = "") -> str:
        return self.agent_killer.terminate(agent_id, session_notes=notes)

    def generate_financial_report(self, report_type: str = "income_statement"):
        rt = ReportType(report_type) if report_type in ReportType._value2member_map_ else ReportType.INCOME_STATEMENT
        return self.reporting_pipeline.build_full_report(rt)

    def get_system_health(self) -> dict[str, Any]:
        db_health = self.db_manager.health()
        memory_health = self.memory.store.health() if hasattr(self.memory, "store") else None
        return {
            # PRD S7/S40: health/readiness must surface a real database
            # integrity check, not just process-level liveness.
            "status": "healthy" if db_health.get("ok", False) else "degraded",
            "ceo_identity": self.identity.agent_id,
            "registered_agents": len(self.registry._public_keys),
            "active_rules": len(self.rule_manager.list_rules(status=RuleStatus.ACTIVE)),
            "active_skills": len(self.skill_registry.list_skills(status=SkillStatus.ACTIVE)),
            "super_logs_count": len(self.super_logs._entries),
            "pending_approvals": len(self.list_pending_approvals()),
            "production_db": db_health,
            "memory_db": memory_health,
            "timestamp": time.time(),
        }
