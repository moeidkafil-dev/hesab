"""
n5::n0 "log input manager": log reader -> log analyser -> situation analyser
-> References analyser -> Legible log.
Converts raw operational logs into something a decision process (human or
agent) can reason about (§4.2).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class LegibleLog:
    summary: str
    situation: str
    references: list[str] = field(default_factory=list)
    raw_count: int = 0


class LogInputManager:
    def log_reader(self, raw_logs: list[dict]) -> list[dict]:
        return raw_logs

    def log_analyser(self, logs: list[dict]) -> dict:
        errors = [l for l in logs if str(l.get("level", "")).lower() in ("error", "critical")]
        return {"total": len(logs), "errors": len(errors), "error_entries": errors}

    def situation_analyser(self, analysis: dict) -> str:
        if analysis["errors"] == 0:
            return "nominal"
        if analysis["errors"] < 3:
            return "degraded"
        return "critical"

    def references_analyser(self, logs: list[dict]) -> list[str]:
        return sorted({l.get("agent", "unknown") for l in logs})

    def legible_log(self, raw_logs: list[dict]) -> LegibleLog:
        logs = self.log_reader(raw_logs)
        analysis = self.log_analyser(logs)
        situation = self.situation_analyser(analysis)
        refs = self.references_analyser(logs)
        summary = f"{analysis['total']} entries, {analysis['errors']} errors, situation={situation}"
        return LegibleLog(summary=summary, situation=situation, references=refs, raw_count=len(logs))
