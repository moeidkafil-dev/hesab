"""
n5::n2 "new agent manager": agent registerer -> rule maker -> rule signer ->
messenger maker -> message sender -> getting relationship -> greeting system
-> sign maker.

Provisions a new agent, including the cryptographic material (`rule signer`,
`sign maker`) the messaging layer (§7) later uses to authenticate that
agent's traffic.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from hesabdar.messaging.identity import AgentIdentity, IdentityRegistry
from hesabdar.messaging.channel import Channel


@dataclass
class ProvisionedAgent:
    agent_id: str
    identity: AgentIdentity
    channel: Channel
    rules: list[str]
    relationships: list[str]


class NewAgentManager:
    def __init__(self, registry: IdentityRegistry):
        self.registry = registry
        self._agents: dict[str, ProvisionedAgent] = {}

    def agent_registerer(self, agent_id: str) -> str:
        if agent_id in self._agents:
            raise ValueError(f"agent {agent_id} already registered")
        return agent_id

    def rule_maker(self, agent_id: str, role: str) -> list[str]:
        """Baseline rule set every new agent gets; role-specific rules are
        layered on by the caller (e.g. only accounting_domain_engine gets
        write-adjacent rules — actual DB writes still only ever happen
        through DBManagerAgent, per §9.2)."""
        base = [f"{agent_id} may only act within role={role}",
                f"{agent_id} must route all persistence through db_manager_agent"]
        return base

    def rule_signer(self, identity: AgentIdentity, rules: list[str]) -> list[bytes]:
        return [identity.sign(r.encode("utf-8")) for r in rules]

    def messenger_maker(self, identity: AgentIdentity) -> Channel:
        return Channel(identity, self.registry)

    def message_sender(self, channel: Channel, recipient: str, payload: dict, recipient_channel: Channel):
        return channel.send(recipient, payload, recipient_channel)

    def getting_relationship(self, agent_id: str, related_to: Optional[list[str]] = None) -> list[str]:
        return related_to or []

    def greeting_system(self, agent_id: str) -> str:
        return f"{agent_id} registered and online"

    def sign_maker(self, identity: AgentIdentity) -> bytes:
        return identity.public_bytes()

    def provision(self, agent_id: str, role: str, related_to: Optional[list[str]] = None) -> ProvisionedAgent:
        self.agent_registerer(agent_id)
        identity = AgentIdentity.load_or_create(agent_id)
        self.registry.register(identity)
        rules = self.rule_maker(agent_id, role)
        self.rule_signer(identity, rules)
        channel = self.messenger_maker(identity)
        relationships = self.getting_relationship(agent_id, related_to)
        self.greeting_system(agent_id)
        self.sign_maker(identity)
        agent = ProvisionedAgent(agent_id, identity, channel, rules, relationships)
        self._agents[agent_id] = agent
        return agent

    def get(self, agent_id: str) -> Optional[ProvisionedAgent]:
        return self._agents.get(agent_id)

    def all_agents(self) -> list[str]:
        return list(self._agents.keys())
