"""
n5::n6 "agents intpu massages manager" — structurally near-identical to the
CEO core (§4.2), and exists specifically to shield the CEO's own reasoning
loop from directly parsing untrusted inbound agent traffic: inbound
messages are received, compiled, and analysed by this dedicated pipeline
*before* CEOAgentCore.run() ever sees them.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from hesabdar.ceo.ceo_core import CEOAgentCore
from hesabdar.messaging.message import Message


@dataclass
class InboundDecision:
    forward_to_ceo: bool
    reason: str


class AgentsInputMessagesManager:
    def __init__(self, ceo_core: CEOAgentCore):
        self.ceo_core = ceo_core

    def input_reciver(self, message: Message) -> Message:
        return message

    def input_compiler(self, message: Message) -> dict:
        return {"sender": message.sender, "payload": message.payload}

    def input_analyser(self, compiled: dict) -> dict:
        payload = compiled["payload"]
        suspicious = not isinstance(payload, dict) or "op" not in payload and "text" not in payload
        return {**compiled, "suspicious": suspicious}

    def desicion_system(self, analysed: dict) -> InboundDecision:
        if analysed["suspicious"]:
            return InboundDecision(False, "malformed payload shape, not forwarded to CEO core")
        return InboundDecision(True, "ok")

    def handle(self, message: Message) -> dict:
        """Only ever called with an already-authenticated Message — the
        `sign_reader` stage of hesabdar.messaging.Channel is what earns a
        message the right to reach this pipeline at all (§7.2)."""
        compiled = self.input_compiler(self.input_reciver(message))
        analysed = self.input_analyser(compiled)
        decision = self.desicion_system(analysed)
        if not decision.forward_to_ceo:
            return {"forwarded": False, "reason": decision.reason}
        text = analysed["payload"].get("text") or str(analysed["payload"])
        result = self.ceo_core.run(text, context=f"inbound from {analysed['sender']}")
        return {"forwarded": True, "ceo_result": result}
