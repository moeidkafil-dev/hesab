"""
n14::n0 "tool manager" — the single mediation point for every effectful
tool in the system, per docs/09-tooling-and-data-management.md §9.1:

"Every one of these tools is capable of an irreversible or high-impact
action ... Routing all of them through tool manager is what makes it
architecturally possible to apply a single, consistent authorization
policy across every tool a given agent is permitted to invoke, rather
than needing to separately secure eighteen different execution surfaces."

Concretely: no agent ever imports bash_tool / file_tool / excel_tool /
web_tool directly. Everything goes through ToolManager.invoke(agent_id, ...),
which checks a per-agent allow-list before dispatching.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from hesabdar.tools.bash_tool import BashTool
from hesabdar.tools.file_tool import FileTool
from hesabdar.tools.excel_tool import ExcelTool
from hesabdar.tools.web_tool import WebTool


class AuthorizationError(Exception):
    pass


@dataclass
class ToolCallResult:
    ok: bool
    tool: str
    result: Any
    log: str


class ToolManager:
    def __init__(self, sandbox_root: Optional[str] = None, policy: Optional[dict[str, set[str]]] = None):
        self.bash = BashTool(sandbox_root=sandbox_root)
        self.file = FileTool(sandbox_root=sandbox_root)
        self.excel = ExcelTool(sandbox_root=sandbox_root)
        self.web = WebTool()

        # policy[agent_id] = set of allowed tool names. '*' = wildcard agent.
        # Nothing is permitted by default — an agent must be explicitly
        # granted a tool, per §9.1's "single, consistent authorization policy".
        self.policy: dict[str, set[str]] = policy or {}

        self._dispatch: dict[str, Callable[..., Any]] = {
            "bash_run": self.bash.run,
            "file_make": self.file.file_maker,
            "file_read": self.file.file_reader,
            "file_delete": self.file.file_deleter,
            "file_change": self.file.file_changer_runner,
            "excel_read": self.excel.excel_file_reader,
            "excel_write": self.excel.excel_file_writer,
            "excel_make": self.excel.excel_file_maker,
            "web_fetch": self.web.page_html_exporter,
        }

    def grant(self, agent_id: str, tool_names: list[str]) -> None:
        self.policy.setdefault(agent_id, set()).update(tool_names)

    def is_authorized(self, agent_id: str, tool_name: str) -> bool:
        allowed = self.policy.get(agent_id, set()) | self.policy.get("*", set())
        return tool_name in allowed

    def invoke(self, agent_id: str, tool_name: str, **kwargs) -> ToolCallResult:
        if not self.is_authorized(agent_id, tool_name):
            raise AuthorizationError(f"{agent_id} is not authorized to invoke {tool_name!r}")
        handler = self._dispatch.get(tool_name)
        if handler is None:
            return ToolCallResult(False, tool_name, None, f"unknown tool {tool_name!r}")
        try:
            result = handler(**kwargs)
            return ToolCallResult(True, tool_name, result, "ok")
        except Exception as exc:  # noqa: BLE001 - surfaced via ToolCallResult, not raised
            return ToolCallResult(False, tool_name, None, f"{type(exc).__name__}: {exc}")

    def dispatch_freeform(self, step_description: str) -> dict:
        """Called from CEOAgentCore.tool_manager_step for plan steps that
        haven't been resolved to a specific tool call yet. Deliberately
        conservative: it never executes anything on a free-text step —
        that would defeat the authorization model above. It only reports
        that the step needs an explicit tool_name + agent_id + kwargs
        before ToolManager.invoke() can run it."""
        return {"step": step_description, "status": "needs explicit invoke(agent_id, tool_name, **kwargs) call"}
