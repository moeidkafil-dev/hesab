"""
Every `llm` node in the diagram (n5::n5::n0, n5::n6::n4, n5::n7::n5,
n13::n0::n4::n9, ...) is, in code, a single call to get_llm().complete(...).
Supports Ollama, Gemini API, Anthropic Claude, OpenAI GPT, and MockProvider.
"""
from __future__ import annotations

import abc
import json
import os
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Optional

from hesabdar.config import LLM, LLMConfig


@dataclass
class LLMResponse:
    text: str
    provider: str
    model: str
    raw: Optional[dict] = None


class LLMProvider(abc.ABC):
    @abc.abstractmethod
    def complete(self, prompt: str, system: str = "", temperature: Optional[float] = None) -> LLMResponse:
        ...


class GeminiProvider(LLMProvider):
    """Gemini API Provider using GEMINI_API_KEY environment variable."""

    def __init__(self, cfg: LLMConfig):
        self.cfg = cfg
        self.api_key = os.environ.get("GEMINI_API_KEY", "")
        self.model = cfg.model if cfg.model and "gemini" in cfg.model else "gemini-2.5-flash"

    def complete(self, prompt: str, system: str = "", temperature: Optional[float] = None) -> LLMResponse:
        if not self.api_key:
            return MockProvider().complete(prompt, system=system, temperature=temperature)

        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent?key={self.api_key}"
        contents = []
        if system:
            contents.append({"role": "user", "parts": [{"text": f"System instructions: {system}"}]})
            contents.append({"role": "model", "parts": [{"text": "Understood. I will follow these instructions."}]})
        contents.append({"role": "user", "parts": [{"text": prompt}]})

        payload = {
            "contents": contents,
            "generationConfig": {
                "temperature": temperature if temperature is not None else self.cfg.temperature,
                "maxOutputTokens": self.cfg.max_tokens,
            },
        }

        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                candidates = data.get("candidates", [])
                if candidates:
                    parts = candidates[0].get("content", {}).get("parts", [])
                    text = "".join(p.get("text", "") for p in parts)
                    return LLMResponse(text=text, provider="gemini", model=self.model, raw=data)
                return LLMResponse(text="", provider="gemini", model=self.model, raw=data)
        except Exception as exc:
            return MockProvider().complete(prompt, system=system, temperature=temperature)


class OllamaProvider(LLMProvider):
    """Local inference via Ollama's HTTP API."""

    def __init__(self, cfg: LLMConfig):
        self.cfg = cfg

    def complete(self, prompt: str, system: str = "", temperature: Optional[float] = None) -> LLMResponse:
        url = f"{self.cfg.ollama_host.rstrip('/')}/api/generate"
        payload = {
            "model": self.cfg.model,
            "prompt": prompt,
            "system": system or None,
            "stream": False,
            "options": {"temperature": temperature if temperature is not None else self.cfg.temperature},
        }
        payload = {k: v for k, v in payload.items() if v is not None}
        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=2) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            return LLMResponse(text=data.get("response", ""), provider="ollama", model=self.cfg.model, raw=data)
        except Exception:
            return MockProvider().complete(prompt, system=system, temperature=temperature)


class AnthropicProvider(LLMProvider):
    def __init__(self, cfg: LLMConfig):
        self.cfg = cfg
        if not cfg.anthropic_api_key:
            raise ValueError("ANTHROPIC_API_KEY not set")

    def complete(self, prompt: str, system: str = "", temperature: Optional[float] = None) -> LLMResponse:
        import anthropic

        client = anthropic.Anthropic(api_key=self.cfg.anthropic_api_key)
        msg = client.messages.create(
            model=self.cfg.model,
            max_tokens=self.cfg.max_tokens,
            system=system or "",
            temperature=temperature if temperature is not None else self.cfg.temperature,
            messages=[{"role": "user", "content": prompt}],
        )
        text = "".join(block.text for block in msg.content if getattr(block, "type", "") == "text")
        return LLMResponse(text=text, provider="anthropic", model=self.cfg.model, raw=msg.model_dump())


class OpenAIProvider(LLMProvider):
    def __init__(self, cfg: LLMConfig):
        self.cfg = cfg
        if not cfg.openai_api_key:
            raise ValueError("OPENAI_API_KEY not set")

    def complete(self, prompt: str, system: str = "", temperature: Optional[float] = None) -> LLMResponse:
        import openai

        client = openai.OpenAI(api_key=self.cfg.openai_api_key)
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        resp = client.chat.completions.create(
            model=self.cfg.model,
            messages=messages,
            temperature=temperature if temperature is not None else self.cfg.temperature,
        )
        return LLMResponse(
            text=resp.choices[0].message.content or "",
            provider="openai",
            model=self.cfg.model,
            raw=resp.model_dump(),
        )


class MockProvider(LLMProvider):
    """Deterministic offline stand-in, used by test suite and offline nodes."""

    def complete(self, prompt: str, system: str = "", temperature: Optional[float] = None) -> LLMResponse:
        prompt_lower = prompt.lower()
        expense_keywords = ["purchase", "expense", "payment", "subscription", "fee", "utilities", "rent", "bill", "salary", "payroll", "خرید", "هزینه", "پرداخت", "قبض", "اجاره"]
        revenue_keywords = ["invoice", "revenue", "sales", "sale", "income", "receipt", "فروش", "درآمد", "فاکتور"]
        report_keywords = ["report", "statement", "trial_balance", "balance_sheet", "financial", "گزارش", "تراز", "صورت"]

        if any(k in prompt_lower for k in expense_keywords):
            plan_text = "1. Classify transaction as operating expense\n2. Match rule for expense accounts\n3. Execute debit expense, credit cash\n4. Successfully process via rule and verify balance check"
        elif any(k in prompt_lower for k in revenue_keywords):
            plan_text = "1. Classify transaction as sales revenue\n2. Match rule for accounts receivable\n3. Execute debit AR, credit revenue\n4. Successfully process via rule and validate ledger invariants"
        elif any(k in prompt_lower for k in report_keywords):
            plan_text = "1. Query trial balance from General Ledger\n2. Aggregate account totals by classification\n3. Format financial statement\n4. Verify mathematical consistency"
        else:
            plan_text = "1. Analyze request intent\n2. Query existing rules and database\n3. Successfully process via deterministic rule execution\n4. Verify output through critic"

        return LLMResponse(text=plan_text, provider="mock", model="deterministic-v1")


_PROVIDERS = {
    "ollama": OllamaProvider,
    "gemini": GeminiProvider,
    "anthropic": AnthropicProvider,
    "openai": OpenAIProvider,
    "mock": MockProvider,
}


def get_llm(cfg: LLMConfig = LLM) -> LLMProvider:
    provider_name = cfg.provider
    if provider_name == "ollama" and os.environ.get("GEMINI_API_KEY") and not os.environ.get("HESABDAR_LLM_PROVIDER"):
        provider_name = "gemini"

    cls = _PROVIDERS.get(provider_name)
    if cls is None:
        return MockProvider()
    return cls(cfg) if cls is not MockProvider else MockProvider()
