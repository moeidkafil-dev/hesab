"""Integration tests for Hesabdar JSON API server endpoints (PRD §24, §47)."""

import json
import pytest
from hesabdar.api_server import HesabdarAPI


@pytest.fixture
def api():
    return HesabdarAPI()


class TestHesabdarAPI:
    def test_status_endpoint(self, api):
        res = api.handle("status", {})
        assert res["ok"] is True
        assert "health" in res
        assert "accounts_count" in res
        assert res["health"]["status"] in ["healthy", "degraded"]

    def test_list_accounts(self, api):
        res = api.handle("list_accounts", {})
        assert res["ok"] is True
        assert len(res["accounts"]) >= 20

    def test_create_custom_account(self, api):
        res = api.handle("create_account", {
            "name": "Custom Investment Account",
            "account_type": "asset",
            "code": "acc_1990",
        })
        assert res["ok"] is True
        assert res["account_id"] == "acc_1990"

    def test_post_journal_entry_balanced(self, api):
        lines = [
            {"account_id": "acc_1010", "debit": "7500.00", "credit": 0},
            {"account_id": "acc_4010", "debit": 0, "credit": "7500.00"},
        ]
        res = api.handle("post_journal_entry", {
            "description": "Consulting Fee Direct Deposit",
            "lines": lines,
            "idempotency_key": "api_test_consulting_01",
        })
        assert res["ok"] is True
        assert "transaction_id" in res

    def test_post_journal_entry_unbalanced_rejected(self, api):
        lines = [
            {"account_id": "acc_1010", "debit": "7500.00", "credit": 0},
            {"account_id": "acc_4010", "debit": 0, "credit": "7499.00"},
        ]
        res = api.handle("post_journal_entry", {
            "description": "Invalid Unbalanced Entry",
            "lines": lines,
            "idempotency_key": "api_test_unbalanced_01",
        })
        assert res["ok"] is False
        assert "unbalanced" in res["error"].lower()

    def test_generate_all_financial_reports(self, api):
        for rep_type in ["trial_balance", "income_statement", "balance_sheet", "cash_flow", "expense_analysis"]:
            res = api.handle("generate_report", {"report_type": rep_type})
            assert res["ok"] is True
            assert "report" in res
            assert res["report"]["report_type"] == rep_type

    def test_create_and_restore_backup(self, api):
        backup_res = api.handle("create_backup", {"label": "API Test Backup"})
        assert backup_res["ok"] is True
        backup_id = backup_res["snapshot"]["id"]

        restore_res = api.handle("restore_backup", {"backup_id": backup_id})
        assert restore_res["ok"] is True

    def test_self_healing_trigger(self, api):
        res = api.handle("trigger_self_healing", {
            "task_id": "api_test_task",
            "error": "Simulated connection timeout",
        })
        assert res["ok"] is True
        assert "healing_result" in res

    def test_run_benchmark_tier(self, api):
        res = api.handle("run_benchmark", {"tiers": [1, 2]})
        assert res["ok"] is True
        assert "benchmark" in res
        assert len(res["benchmark"]["results"]) == 2
        assert res["benchmark"]["results"][0]["determinism_score_pct"] == 100.0
