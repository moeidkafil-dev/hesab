import shutil
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from hesabdar.memory import MemoryManager, MemoryType, MemoryStore


class TestMemory(unittest.TestCase):
    def setUp(self):
        self.temp_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_permanent_types_survive_maintenance(self):
        store = MemoryStore(db_path=self.temp_dir / "mem.sqlite3")
        mm = MemoryManager(scope="test", store=store)
        mm.remember({"txn": "debit cash 100"}, hint_type=MemoryType.FINANCIAL_TRANSACTION)
        mm.remember("this is low value fluff", hint_type=None)

        report = mm.being_in_sleep_mode()
        remaining = store.read("test", memory_type=MemoryType.FINANCIAL_TRANSACTION)
        self.assertEqual(len(remaining), 1, "financial transaction memory must never be pruned")

    def test_write_path_classifies_failure(self):
        store = MemoryStore(db_path=self.temp_dir / "mem2.sqlite3")
        mm = MemoryManager(scope="test2", store=store)
        decision = mm.input_analyser("خطا در اجرای rule engine")
        self.assertEqual(decision.memory_type, MemoryType.FAILURE)


if __name__ == "__main__":
    unittest.main()
