import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from hesabdar.accounting import (
    AccountingDomainEngine,
    AccountingRule,
    RuleAction,
    RuleCondition,
    RuleDisposition,
    RuleManager,
    RuleScope,
    RuleStatus,
    TransactionClassifier,
    RuleMatcher,
    RuleExecutor,
    AccountingSelfEvaluation,
)


class TestAccountingDomainEngine(unittest.TestCase):
    def setUp(self):
        self.rule_manager = RuleManager()
        self.engine = AccountingDomainEngine(rule_manager=self.rule_manager)

    def test_deterministic_expense_classification_and_execution(self):
        tx = {
            "description": "Monthly internet and cloud server fee",
            "amount": 1500000.0,
            "category": "expense",
            "sub_category": "utilities",
        }
        res = self.engine.process_transaction(tx)
        self.assertTrue(res.ok)
        self.assertEqual(res.path_taken, "fast_path")
        self.assertIsNotNone(res.execution)
        self.assertIsNotNone(res.execution.journal_entry)
        self.assertTrue(res.execution.journal_entry.is_balanced)
        self.assertEqual(res.execution.journal_entry.total_debit, 1500000.0)

    def test_conservative_conflict_resolution_most_restrictive_rule_wins(self):
        # Add high-risk restricted vendor rule
        tx = {
            "description": "Payment to high risk vendor for supplies",
            "amount": 200000.0,
            "vendor": "Vendor_X",
            "category": "expense",
            "sub_category": "office_supplies",
        }
        res = self.engine.process_transaction(tx)
        # Conservative policy (§5.5) dictates REQUIRE_HUMAN_APPROVAL prevails over auto-post
        self.assertTrue(res.needs_human_approval)
        self.assertEqual(res.path_taken, "human_approval_gate")

    def test_research_path_for_novel_unclassified_transaction(self):
        tx = {
            "description": "Autonomous drone satellite navigation license payment",
            "amount": 8500000.0,
        }
        res = self.engine.process_transaction(tx)
        self.assertTrue(res.ok)
        self.assertEqual(res.path_taken, "research_path")
        self.assertTrue(res.needs_human_approval)
        self.assertIsNotNone(res.candidate_rule)
        self.assertEqual(res.candidate_rule.status, RuleStatus.PENDING_APPROVAL)

    def test_double_entry_balance_invariant(self):
        evaluator = AccountingSelfEvaluation()
        tx = {"amount": 1000.0}
        classification = self.engine.classifier.classify(tx)
        match = self.engine.matcher.match({"category": "expense", "sub_category": "office_supplies"})
        # Valid execution
        exec_res = self.engine.executor.execute(tx, match.selected_rule)
        eval_report = evaluator.evaluate(tx, classification, match, exec_res)
        self.assertTrue(eval_report.passed)
        self.assertTrue(eval_report.balance_valid)


if __name__ == "__main__":
    unittest.main()
