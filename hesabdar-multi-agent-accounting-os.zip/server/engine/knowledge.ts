import { generateAIText } from '../gemini.js';

export interface StandardArticle {
  id: string;
  category: 'standard' | 'tax_law' | 'vat_law' | 'ifrs';
  code: string;
  titleFa: string;
  titleEn: string;
  summaryFa: string;
  keyPoints: string[];
}

export class StudyKnowledgeAgent {
  private articles: StandardArticle[] = [
    {
      id: 'std_01',
      category: 'standard',
      code: 'استاندارد حسابداری شماره ۱',
      titleFa: 'نحوه ارائه صورت‌های مالی',
      titleEn: 'Presentation of Financial Statements',
      summaryFa: 'مبنای تهیه و ارائه صورت‌های مالی با مقاصد عمومی، شامل ترازنامه، صورت سود و زیان، صورت جریان وجوه نقد و یادداشت‌های توضیحی.',
      keyPoints: [
        'رعایت اصل تداوم فعالیت، ثبات رویه و تطابق درآمد و هزینه',
        'تفکیک دارایی‌ها و بدهی‌ها به جاری و غیرجاری بر مبنای چرخه عملیاتی ۱۲ ماهه',
        'ممنوعیت تهاتر دارایی‌ها و بدهی‌ها مگر با الزام استاندارد خاص',
      ],
    },
    {
      id: 'std_03',
      category: 'standard',
      code: 'استاندارد حسابداری شماره ۳',
      titleFa: 'درآمد عملیاتی',
      titleEn: 'Revenue Recognition',
      summaryFa: 'معیارهای شناخت درآمد حاصل از فروش کالا، ارائه خدمات و استفاده دیگران از دارایی‌های واحد تجاری.',
      keyPoints: [
        'انتقال مزایا و مخاطرات عمده مالکیت به خریدار',
        'قابلیت اندازه‌گیری اتکاپذیر مبالغ درآمد و بهای تمام شده',
        'جریان یافتن منافع اقتصادی به درون واحد تجاری',
      ],
    },
    {
      id: 'tax_131',
      category: 'tax_law',
      code: 'ماده ۱۳۱ ق.م.م',
      titleFa: 'نرخ مالیات بر درآمد حقوق و اشخاص حقیقی',
      titleEn: 'Direct Tax Act - Article 131',
      summaryFa: 'جدول نرخ‌های مالیاتی پلکانی برای درآمدهای حقوق و عملکرد اشخاص حقیقی.',
      keyPoints: [
        'تا سقف معافیت سالانه با نرخ صفر',
        'مازاد تا سقف معین با نرخ ۱۰ الی ۲۵ درصد پلکانی',
        'تکلیف کارفرما به کسر و واریز ماهانه تا پایان ماه بعد',
      ],
    },
    {
      id: 'vat_law',
      category: 'vat_law',
      code: 'قانون مالیات بر ارزش افزوده',
      titleFa: 'مالیات و عوارض بر ارزش افزوده کالاها و خدمات',
      titleEn: 'Value Added Tax (VAT) Law',
      summaryFa: 'نرخ استاندارد ۱۰ درصد مالیات بر ارزش افزوده و نحوه اعمال اعتبار مالیاتی خرید در اظهارنامه فصلی.',
      keyPoints: [
        'نرخ استاندارد ۱۰ درصد (شامل مالیات و عوارض)',
        'تکلیف ثبت در سامانه مودیان و صدور صورتحساب الکترونیکی',
        'قابلیت تهاتر مالیات خرید (اعتبار) با مالیات فروش (خروجی)',
      ],
    },
    {
      id: 'ifrs_16',
      category: 'ifrs',
      code: 'IFRS 16',
      titleFa: 'استاندارد بین‌المللی اجاره‌ها',
      titleEn: 'Leases',
      summaryFa: 'حذف تمایز بین اجاره‌های عملیاتی و سرمایه‌ای برای مستاجر و شناسایی دارایی حق استفاده (ROU) و بدهی اجاره.',
      keyPoints: [
        'شناسایی Right-of-Use Asset در ترازنامه',
        'محاسبه استهلاک دارایی و بهره بدهی اجاره در صورت سود و زیان',
      ],
    },
  ];

  public listArticles(): StandardArticle[] {
    return this.articles;
  }

  public async researchQuestion(query: string): Promise<{
    query: string;
    matchedArticles: StandardArticle[];
    synthesizedAnswer: string;
  }> {
    const q = query.toLowerCase();
    const matched = this.articles.filter(
      (a) =>
        a.titleFa.toLowerCase().includes(q) ||
        a.code.toLowerCase().includes(q) ||
        a.summaryFa.toLowerCase().includes(q) ||
        a.keyPoints.some((k) => k.toLowerCase().includes(q))
    );

    const prompt = `User Query on Accounting Standards / Tax: "${query}"
Matched Knowledge References:
${matched.map((m) => `[${m.code}] ${m.titleFa}: ${m.summaryFa}\nPoints: ${m.keyPoints.join('; ')}`).join('\n\n')}

Provide an authoritative, detailed Persian accounting explanation referencing standard rules, double-entry vouchers, and compliance requirements.`;

    const answer = await generateAIText(prompt, 'You are the Chief Accounting Standards Research Agent. Provide clear, accurate compliance guidance.');

    return {
      query,
      matchedArticles: matched.length > 0 ? matched : this.articles.slice(0, 2),
      synthesizedAnswer: answer,
    };
  }
}

export const globalKnowledgeAgent = new StudyKnowledgeAgent();
