export interface ArchitectureNode {
  id: string;
  label: string;
  labelFa: string;
  group: string;
  role: string;
  docChapter: string;
  sourceCodeRef: string;
  description: string;
  isDeterministic: boolean;
}

export const ARCHITECTURE_NODES: ArchitectureNode[] = [
  // CEO Supervisory Kernel (n5)
  {
    id: 'n5',
    label: 'CEO Agent Architecture',
    labelFa: 'معماری و هسته نظارتی مدیر ارشد (CEO)',
    group: 'CEO & Orchestration',
    role: 'Supervisory Kernel & Agent Lifecycle',
    docChapter: '04-ceo-agent-architecture.md',
    sourceCodeRef: 'hesabdar.ceo.orchestrator / server/engine/ceo.ts',
    description: 'Central supervisory kernel with exclusive authority over agent lifecycle, resource allocation, and bounded-retry checkpoint orchestration.',
    isDeterministic: true,
  },
  {
    id: 'n5::n0',
    label: 'Log Input Manager',
    labelFa: 'مدیریت ورودی لاگ‌ها',
    group: 'CEO & Orchestration',
    role: 'Log Reader -> Analyser -> Situation Analyser',
    docChapter: '04-ceo-agent-architecture.md',
    sourceCodeRef: 'CEOAgentArchitecture.logInputManager',
    description: 'Ingests agent logs, evaluates system operational frames, and maintains supervisory state awareness.',
    isDeterministic: true,
  },
  {
    id: 'n5::n1',
    label: 'Prompt Manager & Policy Checker',
    labelFa: 'مدیریت پرامپت و تطبیق با سیاست‌ها',
    group: 'CEO & Orchestration',
    role: 'Intent Classification & Policy Enforcement',
    docChapter: '04-ceo-agent-architecture.md',
    sourceCodeRef: 'CEOAgentArchitecture.analyzePrompt',
    description: 'Translates user intent, validates requests against enterprise accounting policies, and routes to suitable sub-agents.',
    isDeterministic: true,
  },
  {
    id: 'n5::n2',
    label: 'New Agent Manager',
    labelFa: 'مدیریت راه‌اندازی عامل‌های جدید',
    group: 'CEO & Orchestration',
    role: 'Agent Provisioning & Identity Verification',
    docChapter: '04-ceo-agent-architecture.md',
    sourceCodeRef: 'IdentityRegistry.registerAgent',
    description: 'Generates Ed25519 identity keypairs and assigns constrained capability manifests to new agents.',
    isDeterministic: true,
  },
  {
    id: 'n5::n3',
    label: 'Agent Killer & Summary Maker',
    labelFa: 'خاتمه عامل و تدوین خلاصه عملکرد',
    group: 'CEO & Orchestration',
    role: 'Graceful Retirement & Reflection Extraction',
    docChapter: '04-ceo-agent-architecture.md',
    sourceCodeRef: 'CEOAgentArchitecture.retireAgent',
    description: 'Decommissions completed agents, compiles institutional reflection memories, and revokes key privileges.',
    isDeterministic: true,
  },

  // 27-Type Memory Manager (n13)
  {
    id: 'n13',
    label: '27-Type Memory Matrix',
    labelFa: 'ماتریس ۲۷ نوع حافظه تخصصی',
    group: 'Memory Subsystem',
    role: '7 Families / Dual-Path Storage Engine',
    docChapter: '03-memory-management-and-27-taxonomy.md',
    sourceCodeRef: 'hesabdar.memory.taxonomy / server/engine/memory.ts',
    description: 'Complete 27-memory-type hierarchy across 7 families with sleep-mode pruning and immutable financial/failure preservation.',
    isDeterministic: true,
  },
  {
    id: 'n13::n3::n0',
    label: 'Memory Types Taxonomy',
    labelFa: 'طبقه‌بندی ساختاری انواع حافظه',
    group: 'Memory Subsystem',
    role: 'Type Registry & Schema Validator',
    docChapter: '03-memory-management-and-27-taxonomy.md',
    sourceCodeRef: 'MemoryType Enum',
    description: 'Defines working, episodic, semantic, procedural, reflection, financial/audit, and system configuration memory classes.',
    isDeterministic: true,
  },
  {
    id: 'n13::n3::n1',
    label: 'Maintenance Path (being_in_sleep_mode)',
    labelFa: 'مسیر نگهداری و حالت خواب سیستم',
    group: 'Memory Subsystem',
    role: 'Eviction & Compaction Sweep',
    docChapter: '03-memory-management-and-27-taxonomy.md',
    sourceCodeRef: 'MemoryStore.runSleepModeMaintenance',
    description: 'Prunes stale transient scratchpads while guaranteeing absolute permanence for financial transactions, audit logs, and failure records.',
    isDeterministic: true,
  },

  // Authoritative DB Manager (n6)
  {
    id: 'n6',
    label: 'DB Manager Agent',
    labelFa: 'عامل مدیریت دیتابیس و دفتر کل',
    group: 'Database & Ledger',
    role: 'Exclusive Authoritative Ledger Writer',
    docChapter: '09-database-manager-agent-and-persistence.md',
    sourceCodeRef: 'hesabdar.db.manager / server/engine/dbManager.ts',
    description: 'The sole authorized entity permitted to mutate production financial records. Features DB Analyser vs DB Situation Analyser verification.',
    isDeterministic: true,
  },

  // Cryptographic Messaging (n10)
  {
    id: 'n10',
    label: 'Cryptographic Messaging Channel',
    labelFa: 'کانال ارتباطات رمزنگاری شده عامل‌ها',
    group: 'Security & Messaging',
    role: 'Ed25519 Signing & Haber-Stornetta Audit Chain',
    docChapter: '07-inter-agent-messaging-and-security.md',
    sourceCodeRef: 'hesabdar.messaging / server/engine/messaging.ts',
    description: '4-stage pipeline (receiver, compiler, sign-reader, read) with tamper-evident hash-linked message history.',
    isDeterministic: true,
  },

  // Accounting Domain Engine (n16)
  {
    id: 'n16',
    label: 'Accounting Domain Engine',
    labelFa: 'موتور قوانین و محاسبات حسابداری',
    group: 'Accounting Domain',
    role: 'Dual-Path Transaction Classifier & Calculator',
    docChapter: '05-accounting-domain-engine.md',
    sourceCodeRef: 'hesabdar.domain / server/engine/domainEngine.ts',
    description: 'Deterministic rule executor for VAT 10%, straight-line depreciation, payroll withholding, and inventory FIFO with LLM research fallback.',
    isDeterministic: true,
  },

  // Rule Manager (n17)
  {
    id: 'n17',
    label: 'Accounting Rule Manager & Human Gate',
    labelFa: 'مدیر قوانین و گیت تایید انسانی',
    group: 'Accounting Domain',
    role: 'Rule Lifecycle & Human Approval Gate',
    docChapter: '12-rule-manager-and-governance.md',
    sourceCodeRef: 'AccountingDomainEngine.reviewProposedRule',
    description: 'Manages rule compilation, versioning, and client customizations. Strict policy: no AI-proposed rule is active without human sign-off.',
    isDeterministic: true,
  },

  // QA Critic Pattern (n8 / Final Checker Agent)
  {
    id: 'n8',
    label: 'Final Checker Agent (QA Critic)',
    labelFa: 'عامل کنترل نهایی و بازرس کیفیت',
    group: 'Quality Assurance',
    role: '4-Layer Verification & Anomaly Detector',
    docChapter: '06-quality-assurance-and-critic-pattern.md',
    sourceCodeRef: 'hesabdar.critic / server/engine/critic.ts',
    description: 'Validates structural debit=credit identity, cross-references Chart of Accounts, detects statistical z-score outliers, and routes dispositions.',
    isDeterministic: true,
  },

  // Reporting & Analytics (n2)
  {
    id: 'n2',
    label: 'Report Maker & Analytics Pipeline',
    labelFa: 'سامانه تهیه گزارشات مالی و تحلیلی',
    group: 'Reporting & Analytics',
    role: 'Balance Sheet, P&L, Cash Flow & Forecasting',
    docChapter: '10-reporting-and-analytics-pipeline.md',
    sourceCodeRef: 'hesabdar.reporting / server/engine/reporting.ts',
    description: 'Generates standard financial statements, computes forward-looking forecasting runway, and synthesizes executive AI commentary.',
    isDeterministic: true,
  },

  // Tool Manager Sandbox (n14)
  {
    id: 'n14',
    label: 'Tool Manager & Sandbox Gatekeeper',
    labelFa: 'مدیریت ابزارها و گیت‌کیپر محیط ایزوله',
    group: 'Tools & Execution',
    role: 'Capability Authorization & Path Containment',
    docChapter: '02-tool-manager-and-sandbox.md',
    sourceCodeRef: 'hesabdar.tools.tool_manager / server/engine/tools.ts',
    description: 'Sole gatekeeper for external effects: Bash runner, File manager, Excel calculation engine, and Web research tools.',
    isDeterministic: true,
  },

  // Study & Knowledge Agent (n11)
  {
    id: 'n11',
    label: 'Study & Knowledge Agent',
    labelFa: 'عامل تحقیق و استانداردهای حسابداری',
    group: 'Knowledge & Research',
    role: 'Regulatory, Iranian Standards & Tax Code Lookup',
    docChapter: '11-study-knowledge-agent.md',
    sourceCodeRef: 'hesabdar.knowledge / server/engine/knowledge.ts',
    description: 'Knowledge base of Iranian National Accounting Standards, Direct Tax Act (Article 131), and Value Added Tax guidelines.',
    isDeterministic: false,
  },

  // Resilience & Self-Healing (n3, n4, n5)
  {
    id: 'n3',
    label: 'Backup & State Snapshots System',
    labelFa: 'سامانه پشتیبان‌گیری و اسنپ‌شات وضعیت',
    group: 'Resilience Engineering',
    role: 'Point-in-Time State Capture',
    docChapter: '08-resilience-engineering-and-self-healing.md',
    sourceCodeRef: 'ResilienceEngine.createSnapshot',
    description: 'Captures full ledger state, memory stores, and cryptographic chains for point-in-time recovery.',
    isDeterministic: true,
  },
  {
    id: 'n4',
    label: 'Root Debugger & Self-Healing System',
    labelFa: 'دیباگر ریشه‌ای و سامانه خودترمیمی',
    group: 'Resilience Engineering',
    role: 'Automated Integrity Diagnostics',
    docChapter: '08-resilience-engineering-and-self-healing.md',
    sourceCodeRef: 'ResilienceEngine.runDiagnostics',
    description: 'Continuously validates double-entry equilibrium, hash chain links, and memory invariants to prevent silent corruption.',
    isDeterministic: true,
  },
];

export const ARCHITECTURE_CHAPTERS = [
  { id: '01', file: '01-system-overview.md', title: 'System Overview & Core Philosophy', titleFa: 'نمای کلی سیستم و اصول بنیادین' },
  { id: '02', file: '02-tool-manager-and-sandbox.md', title: 'Tool Manager & Execution Sandbox', titleFa: 'مدیریت ابزارها و محیط ایزوله' },
  { id: '03', file: '03-memory-management-and-27-taxonomy.md', title: 'Memory Management & 27 Taxonomy', titleFa: 'ماتریس ۲۷ گانه حافظه و طبقه‌بندی ۷ خانواده' },
  { id: '04', file: '04-ceo-agent-architecture.md', title: 'CEO Agent Supervisory Kernel', titleFa: 'معماری و هسته نظارتی مدیر ارشد (CEO)' },
  { id: '05', file: '05-accounting-domain-engine.md', title: 'Accounting Domain Engine (Dual-Path)', titleFa: 'موتور محاسبات و دامنه حسابداری' },
  { id: '06', file: '06-quality-assurance-and-critic-pattern.md', title: 'Quality Assurance & Critic Pattern', titleFa: 'کنترل کیفیت و الگوی منتقد نهایی' },
  { id: '07', file: '07-inter-agent-messaging-and-security.md', title: 'Inter-Agent Messaging & Ed25519 Security', titleFa: 'ارتباطات امن عامل‌ها و زنجیره هش' },
  { id: '08', file: '08-resilience-engineering-and-self-healing.md', title: 'Resilience Engineering & Self-Healing', titleFa: 'مهندسی تاب‌آوری و سامانه خودترمیمی' },
  { id: '09', file: '09-database-manager-agent-and-persistence.md', title: 'DB Manager Agent & Persistence', titleFa: 'عامل مدیریت پایگاه داده و دفتر کل' },
  { id: '10', file: '10-reporting-and-analytics-pipeline.md', title: 'Reporting & Analytics Pipeline', titleFa: 'خط لوله گزارشات مالی و پیش‌بینی' },
  { id: '11', file: '11-study-knowledge-agent.md', title: 'Study & Knowledge Agent', titleFa: 'عامل مطالعه و استانداردهای حسابداری' },
  { id: '12', file: '12-rule-manager-and-governance.md', title: 'Rule Manager & Governance', titleFa: 'مدیریت قوانین، نسخه گذاری و گیت انسانی' },
];
