import { CriticVerificationResult, JournalLine } from '../types.js';
import { globalDBManager } from './dbManager.js';
import { globalMemoryStore } from './memory.js';
import { MemoryType } from '../types.js';

export class FinalCheckerAgent {
  /**
   * 4-Layer Verification Pipeline (§6.3):
   * Layer 1: Structural verification (debit == credit, positive values)
   * Layer 2: Cross-referential verification (accounts exist, normal balances)
   * Layer 3: Historical/statistical verification (z-score anomaly on amount)
   * Layer 4: Confidence aggregation and routing (auto_release | escalate_to_human | reject)
   */
  public verifyVoucherCandidate(voucherData: {
    description: string;
    lines: Array<{ accountId: string; debit: number; credit: number }>;
  }): CriticVerificationResult {
    const lines = voucherData.lines || [];
    const totalDebit = lines.reduce((s, l) => s + (Number(l.debit) || 0), 0);
    const totalCredit = lines.reduce((s, l) => s + (Number(l.credit) || 0), 0);

    // --- Layer 1: Structural Verification ---
    const debitCreditBalance = Math.abs(totalDebit - totalCredit) < 0.001 && totalDebit > 0;
    const layer1Passed = debitCreditBalance && lines.length >= 2;
    const layer1Details = layer1Passed
      ? `Structural verification passed: Sum(Debit) = Sum(Credit) = ${totalDebit.toLocaleString()}`
      : `Structural failure: Debit (${totalDebit}) != Credit (${totalCredit}) or insufficient lines (${lines.length})`;

    // --- Layer 2: Cross-Referential Verification ---
    let accountsExist = true;
    let missingAccounts: string[] = [];
    for (const l of lines) {
      const acc = globalDBManager.getAccount(l.accountId);
      if (!acc) {
        accountsExist = false;
        missingAccounts.push(l.accountId);
      }
    }
    const layer2Passed = accountsExist;
    const layer2Details = layer2Passed
      ? `Cross-referential check passed: All ${lines.length} accounts verified against authoritative Chart of Accounts`
      : `Cross-referential failure: Accounts not found in DB: ${missingAccounts.join(', ')}`;

    // --- Layer 3: Historical & Statistical Verification ---
    const pastVouchers = globalDBManager.listVouchers();
    const amounts = pastVouchers.map((v) => v.totalDebit);
    let zScore = 0;
    let isAnomaly = false;

    if (amounts.length >= 2) {
      const mean = amounts.reduce((a, b) => a + b, 0) / amounts.length;
      const variance = amounts.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / amounts.length;
      const stdDev = Math.sqrt(variance) || 1;
      zScore = Math.abs((totalDebit - mean) / stdDev);

      // Flag if transaction exceeds 3 standard deviations
      if (zScore > 3.0) {
        isAnomaly = true;
      }
    }

    const layer3Passed = !isAnomaly;
    const layer3Details = isAnomaly
      ? `Statistical anomaly detected (Z-Score: ${zScore.toFixed(2)} > 3.0): Transaction size is unusually large relative to historical patterns`
      : `Statistical verification passed (Z-Score: ${zScore.toFixed(2)} <= 3.0): Transaction amount conforms to normal operational distribution`;

    // --- Layer 4: Confidence Aggregation and Disposition Routing ---
    let score = 100;
    if (!layer1Passed) score -= 60;
    if (!layer2Passed) score -= 30;
    if (isAnomaly) score -= 25;

    let routing: 'auto_release' | 'escalate_to_human' | 'reject' = 'auto_release';
    let rationale = '';

    if (!layer1Passed || !layer2Passed) {
      routing = 'reject';
      rationale = 'Rejected at structural or cross-referential checkpoint. Mathematical/schema invariants violated.';
    } else if (isAnomaly || score < 80) {
      routing = 'escalate_to_human';
      rationale = 'Escalated to human supervisor via CEO. Structurally sound, but statistical anomaly requires human review.';
    } else {
      routing = 'auto_release';
      rationale = 'All 4 verification layers passed with high confidence. Approved for automated posting to production ledger.';
    }

    const result: CriticVerificationResult = {
      passed: routing !== 'reject',
      score: Math.max(0, score),
      disposition: routing,
      layers: {
        layer1_structural: {
          passed: layer1Passed,
          details: layer1Details,
          debitCreditBalance,
        },
        layer2_crossReferential: {
          passed: layer2Passed,
          details: layer2Details,
          accountsExist,
        },
        layer3_historicalStatistical: {
          passed: layer3Passed,
          details: layer3Details,
          zScore: Number(zScore.toFixed(2)),
          isAnomaly,
        },
        layer4_confidenceAggregation: {
          score: Math.max(0, score),
          routing,
          rationale,
        },
      },
    };

    // Log check to Memory
    globalMemoryStore.write(
      'final_checker_agent',
      isAnomaly ? MemoryType.INCIDENT_ANOMALY_LOG : MemoryType.CHECKPOINT_RECORD,
      {
        description: voucherData.description,
        score: result.score,
        disposition: result.disposition,
        zScore,
      },
      { tags: ['critic_qa', result.disposition], importance: isAnomaly ? 9 : 5 }
    );

    return result;
  }
}

export const globalCritic = new FinalCheckerAgent();
