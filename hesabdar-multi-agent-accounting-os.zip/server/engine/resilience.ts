import { globalMemoryStore } from './memory.js';
import { globalDBManager } from './dbManager.js';
import { globalAuditHashChain } from './messaging.js';
import { globalDomainEngine } from './domainEngine.js';
import { MemoryType } from '../types.js';

export interface SystemSnapshot {
  id: string;
  timestamp: string;
  accountsCount: number;
  vouchersCount: number;
  memoriesCount: number;
  chainLength: number;
  rulesCount: number;
  totalLedgerBalance: number;
  hash: string;
}

export class ResilienceEngine {
  private snapshots: SystemSnapshot[] = [];

  constructor() {
    this.createSnapshot('Initial System Boot Snapshot');
  }

  public createSnapshot(label: string = 'Automated Periodic Snapshot'): SystemSnapshot {
    const accounts = globalDBManager.listAccounts();
    const vouchers = globalDBManager.listVouchers();
    const memories = globalMemoryStore.query();
    const chain = globalAuditHashChain.getChain();
    const rules = globalDomainEngine.listRules();

    const snapshot: SystemSnapshot = {
      id: `snap_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
      accountsCount: accounts.length,
      vouchersCount: vouchers.length,
      memoriesCount: memories.length,
      chainLength: chain.length,
      rulesCount: rules.length,
      totalLedgerBalance: accounts.reduce((s, a) => s + Math.abs(a.balance), 0),
      hash: `snap_hash_${Math.random().toString(36).substring(2, 10)}`,
    };

    this.snapshots.push(snapshot);

    globalMemoryStore.write(
      'self_healing_system',
      MemoryType.CHECKPOINT_RECORD,
      { label, snapshotId: snapshot.id, state: snapshot },
      { tags: ['resilience', 'snapshot', 'checkpoint'], importance: 7 }
    );

    return snapshot;
  }

  public listSnapshots(): SystemSnapshot[] {
    return [...this.snapshots].reverse();
  }

  public runDiagnostics(): {
    isHealthy: boolean;
    checks: Array<{ name: string; status: 'passed' | 'warning' | 'failed'; details: string }>;
    score: number;
  } {
    const checks: Array<{ name: string; status: 'passed' | 'warning' | 'failed'; details: string }> = [];

    // Check 1: Trial balance equality (Debit == Credit)
    const tb = globalDBManager.getTrialBalance();
    checks.push({
      name: 'Double-Entry Mathematical Balance',
      status: tb.isBalanced ? 'passed' : 'failed',
      details: tb.isBalanced
        ? `Trial balance perfectly in equilibrium. Total: ${tb.totalDebit.toLocaleString()}`
        : `Imbalance detected! Debit: ${tb.totalDebit} != Credit: ${tb.totalCredit}`,
    });

    // Check 2: Cryptographic Haber-Stornetta Hash Chain Integrity
    const chainCheck = globalAuditHashChain.verifyChainIntegrity();
    checks.push({
      name: 'Tamper-Evident Audit Hash Chain',
      status: chainCheck.isValid ? 'passed' : 'failed',
      details: chainCheck.details,
    });

    // Check 3: Memory Store Persistence Invariants (§3.5)
    const stats = globalMemoryStore.getStats();
    const hasPermanent = stats.permanentCount > 0;
    checks.push({
      name: 'Immutable Memory Storage Compliance (§3.5)',
      status: hasPermanent ? 'passed' : 'warning',
      details: `Stored ${stats.total} total items (${stats.permanentCount} permanent/immutable logs protected from eviction)`,
    });

    // Check 4: Domain Rules Active Configuration
    const rules = globalDomainEngine.listRules();
    const approved = rules.filter((r) => r.isApproved);
    checks.push({
      name: 'Accounting Domain Rule Set Coverage',
      status: approved.length >= 4 ? 'passed' : 'warning',
      details: `${approved.length} approved production rules active across VAT, Depreciation, COGS, and Payroll.`,
    });

    const failedCount = checks.filter((c) => c.status === 'failed').length;
    const warnCount = checks.filter((c) => c.status === 'warning').length;
    const score = Math.max(0, 100 - failedCount * 40 - warnCount * 10);

    return {
      isHealthy: failedCount === 0,
      checks,
      score,
    };
  }
}

export const globalResilienceEngine = new ResilienceEngine();
