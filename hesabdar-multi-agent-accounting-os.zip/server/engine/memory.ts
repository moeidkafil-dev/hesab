import { MemoryEntry, MemoryFamily, MemoryType } from '../types.js';

export function getFamilyForType(type: MemoryType): MemoryFamily {
  switch (type) {
    case MemoryType.IMMEDIATE_CONTEXT:
    case MemoryType.SHORT_TERM_SCRATCHPAD:
    case MemoryType.OPERATIONAL_STATE:
      return 'working';
    case MemoryType.DAILY_ACTIVITY_LOG:
    case MemoryType.AGENT_INTERACTION_HISTORY:
    case MemoryType.INCIDENT_ANOMALY_LOG:
    case MemoryType.CHECKPOINT_RECORD:
      return 'episodic';
    case MemoryType.ACCOUNTING_RULE_BASE:
    case MemoryType.CHART_OF_ACCOUNTS_REF:
    case MemoryType.STANDARD_OPERATING_PROCEDURE:
    case MemoryType.DOMAIN_KNOWLEDGE:
      return 'semantic';
    case MemoryType.WORKFLOW_TEMPLATE:
    case MemoryType.EXECUTION_STRATEGY:
    case MemoryType.TOOL_PATTERN:
      return 'procedural';
    case MemoryType.POST_MORTEM_REFLECTION:
    case MemoryType.AGENT_PERFORMANCE_METRIC:
    case MemoryType.SYSTEM_EVOLUTION_INSIGHT:
    case MemoryType.STRATEGY_REFINEMENT_LOG:
      return 'reflection';
    case MemoryType.FINANCIAL_TRANSACTION:
    case MemoryType.AUDIT_TRAIL_CHAIN:
    case MemoryType.GENERAL_LEDGER_CACHE:
    case MemoryType.REGULATORY_COMPLIANCE:
      return 'financial_audit';
    case MemoryType.SYSTEM_CONFIGURATION:
    case MemoryType.AGENT_PERMISSION_MANIFEST:
    case MemoryType.CRYPTOGRAPHIC_KEYRING:
    case MemoryType.RESOURCE_ALLOCATION_PROFILE:
    case MemoryType.FAILURE:
    default:
      return 'system_config';
  }
}

export function isPermanentMemoryType(type: MemoryType): boolean {
  // Document §3.5: Financial transactions, Audit histories, and Failures MUST NEVER be pruned
  return (
    type === MemoryType.FINANCIAL_TRANSACTION ||
    type === MemoryType.AUDIT_TRAIL_CHAIN ||
    type === MemoryType.FAILURE ||
    type === MemoryType.ACCOUNTING_RULE_BASE ||
    type === MemoryType.REGULATORY_COMPLIANCE
  );
}

export class MemoryStore {
  private entries: Map<string, MemoryEntry> = new Map();

  constructor() {
    this.seedInitialKnowledge();
  }

  private seedInitialKnowledge() {
    const defaultEntries: Array<{ type: MemoryType; content: any; tags: string[]; importance: number }> = [
      {
        type: MemoryType.ACCOUNTING_RULE_BASE,
        content: {
          standard: 'Iranian National Accounting Standards & IFRS',
          vatRate: 0.10,
          principle: 'Double-entry matching principle: Sum(Debits) == Sum(Credits)',
        },
        tags: ['standards', 'core_rule', 'vat'],
        importance: 10,
      },
      {
        type: MemoryType.CHART_OF_ACCOUNTS_REF,
        content: {
          assetRange: '1000-1999',
          liabilityRange: '2000-2999',
          equityRange: '3000-3999',
          revenueRange: '4000-4999',
          expenseRange: '5000-5999',
        },
        tags: ['chart_of_accounts', 'structure'],
        importance: 9,
      },
      {
        type: MemoryType.STANDARD_OPERATING_PROCEDURE,
        content: {
          sopId: 'SOP-01',
          name: 'End-of-Month Ledger Reconciliation & Depreciation Posting',
          steps: ['Verify trial balance', 'Compute monthly straight-line depreciation', 'Post adjusting journal', 'Run critic QA check'],
        },
        tags: ['sop', 'reconciliation'],
        importance: 8,
      },
      {
        type: MemoryType.EXECUTION_STRATEGY,
        content: {
          strategy: 'Deterministic Rule Match first; Fallback to LLM Research with Human Approval for novel cases',
        },
        tags: ['architecture', 'dual_path'],
        importance: 9,
      },
    ];

    for (const item of defaultEntries) {
      this.write('system', item.type, item.content, { tags: item.tags, importance: item.importance });
    }
  }

  public write(
    scope: string,
    memoryType: MemoryType,
    content: any,
    options: { tags?: string[]; importance?: number } = {}
  ): MemoryEntry {
    const id = `mem_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    const isPermanent = isPermanentMemoryType(memoryType);
    const entry: MemoryEntry = {
      id,
      scope,
      memoryType,
      family: getFamilyForType(memoryType),
      content,
      importance: options.importance ?? 5,
      tags: options.tags ?? [],
      createdAt: new Date().toISOString(),
      accessCount: 1,
      lastAccessedAt: new Date().toISOString(),
      isPermanent,
    };
    this.entries.set(id, entry);
    return entry;
  }

  public get(id: string): MemoryEntry | undefined {
    const entry = this.entries.get(id);
    if (entry) {
      entry.accessCount++;
      entry.lastAccessedAt = new Date().toISOString();
    }
    return entry;
  }

  public query(filter?: {
    scope?: string;
    memoryType?: MemoryType;
    family?: MemoryFamily;
    tag?: string;
    minImportance?: number;
  }): MemoryEntry[] {
    let result = Array.from(this.entries.values());

    if (filter?.scope) {
      result = result.filter((e) => e.scope === filter.scope || e.scope === 'system');
    }
    if (filter?.memoryType) {
      result = result.filter((e) => e.memoryType === filter.memoryType);
    }
    if (filter?.family) {
      result = result.filter((e) => e.family === filter.family);
    }
    if (filter?.tag) {
      result = result.filter((e) => e.tags.includes(filter.tag!));
    }
    if (filter?.minImportance !== undefined) {
      result = result.filter((e) => e.importance >= filter.minImportance!);
    }

    return result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public inputAnalyser(text: string): { memoryType: MemoryType; importance: number; tags: string[] } {
    const lower = text.toLowerCase();
    if (lower.includes('خطا') || lower.includes('error') || lower.includes('fail') || lower.includes('شکست')) {
      return { memoryType: MemoryType.FAILURE, importance: 9, tags: ['error', 'incident'] };
    }
    if (lower.includes('تراکنش') || lower.includes('transaction') || lower.includes('سند') || lower.includes('فروش') || lower.includes('خرید')) {
      return { memoryType: MemoryType.FINANCIAL_TRANSACTION, importance: 10, tags: ['financial', 'ledger'] };
    }
    if (lower.includes('قانون') || lower.includes('rule') || lower.includes('مالیات') || lower.includes('vat')) {
      return { memoryType: MemoryType.ACCOUNTING_RULE_BASE, importance: 8, tags: ['rule', 'tax'] };
    }
    if (lower.includes('چک‌پوینت') || lower.includes('checkpoint') || lower.includes('وضعیت')) {
      return { memoryType: MemoryType.CHECKPOINT_RECORD, importance: 6, tags: ['checkpoint', 'state'] };
    }
    if (lower.includes('تجربه') || lower.includes('lesson') || lower.includes('بررسی') || lower.includes('reflection')) {
      return { memoryType: MemoryType.POST_MORTEM_REFLECTION, importance: 7, tags: ['reflection', 'learning'] };
    }
    return { memoryType: MemoryType.SHORT_TERM_SCRATCHPAD, importance: 3, tags: ['scratchpad', 'general'] };
  }

  /**
   * Maintenance Sweep / Sleep Mode (n13::n3::n1 maintenance path)
   * Prunes stale, low-importance non-permanent memories while preserving immutable audit/financial/failure logs
   */
  public runSleepModeMaintenance(): {
    scanned: number;
    pruned: number;
    retained: number;
    familyBreakdown: Record<string, number>;
  } {
    const scanned = this.entries.size;
    let pruned = 0;

    for (const [id, entry] of this.entries.entries()) {
      if (entry.isPermanent) {
        continue; // Never prune permanent financial, audit, or failure logs
      }

      // Evict transient working scratchpads older than threshold with low access
      if (
        (entry.family === 'working' || entry.memoryType === MemoryType.SHORT_TERM_SCRATCHPAD) &&
        entry.importance <= 4 &&
        entry.accessCount <= 3
      ) {
        this.entries.delete(id);
        pruned++;
      }
    }

    const familyBreakdown: Record<string, number> = {};
    for (const entry of this.entries.values()) {
      familyBreakdown[entry.family] = (familyBreakdown[entry.family] || 0) + 1;
    }

    return {
      scanned,
      pruned,
      retained: this.entries.size,
      familyBreakdown,
    };
  }

  public getStats() {
    const all = Array.from(this.entries.values());
    const byType: Record<string, number> = {};
    const byFamily: Record<string, number> = {};

    for (const e of all) {
      byType[e.memoryType] = (byType[e.memoryType] || 0) + 1;
      byFamily[e.family] = (byFamily[e.family] || 0) + 1;
    }

    return {
      total: all.length,
      permanentCount: all.filter((e) => e.isPermanent).length,
      byType,
      byFamily,
    };
  }
}

export const globalMemoryStore = new MemoryStore();
