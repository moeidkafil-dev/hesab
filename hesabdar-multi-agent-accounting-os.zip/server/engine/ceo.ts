import { globalMemoryStore } from './memory.js';
import { globalMessagingChannel, globalIdentityRegistry } from './messaging.js';
import { globalDBManager } from './dbManager.js';
import { globalToolManager } from './tools.js';
import { globalDomainEngine } from './domainEngine.js';
import { globalCritic } from './critic.js';
import { MemoryType } from '../types.js';
import { generateAIText } from '../gemini.js';

export class CEOAgentArchitecture {
  private retryCounter = 0;
  private maxRetries = 3;

  constructor() {}

  /**
   * Log Input Manager (n5::n0):
   * log reader -> log analyser -> situation analyser -> References analyser -> Legible log
   */
  public logInputManager(rawLogs: string[]): string {
    return `[CEO Log Analyser]: Synthesized ${rawLogs.length} operational log frames. System telemetry nominal.`;
  }

  /**
   * Prompt Manager (n5::n1):
   * input receiver -> input compiler -> input analyser -> policy checker -> prompt reader -> prompt analyser -> decision system
   */
  public analyzePrompt(prompt: string): {
    intent: 'transaction_entry' | 'report_request' | 'rule_inquiry' | 'standard_research' | 'system_status' | 'general';
    policyPassed: boolean;
    recommendedAgents: string[];
    confidence: number;
    extractedParams: { amount?: number; account?: string; date?: string; text: string };
  } {
    const text = prompt.trim();
    const lower = text.toLowerCase();

    // Extract potential amount numbers
    const numMatch = text.match(/[\d,]+/g);
    let amount: number | undefined;
    if (numMatch) {
      const cleanNum = numMatch[0].replace(/,/g, '');
      const parsed = parseFloat(cleanNum);
      if (!isNaN(parsed) && parsed > 0) {
        amount = parsed;
      }
    }

    // Policy check (prevent hostile operations or unauthenticated direct DB access)
    let policyPassed = true;
    if (lower.includes('drop table') || lower.includes('delete *') || lower.includes('rm -rf /')) {
      policyPassed = false;
    }

    let intent: 'transaction_entry' | 'report_request' | 'rule_inquiry' | 'standard_research' | 'system_status' | 'general' = 'general';
    let recommendedAgents: string[] = ['ceo'];

    if (lower.includes('ترازنامه') || lower.includes('سود و زیان') || lower.includes('گزارش') || lower.includes('report') || lower.includes('balance sheet') || lower.includes('p&l')) {
      intent = 'report_request';
      recommendedAgents = ['report_maker', 'db_manager_agent'];
    } else if (lower.includes('ثبت') || lower.includes('فروش') || lower.includes('خرید') || lower.includes('واریز') || lower.includes('حقوق') || lower.includes('هزینه') || lower.includes('transaction') || lower.includes('سند')) {
      intent = 'transaction_entry';
      recommendedAgents = ['accounting_domain_engine', 'final_checker_agent', 'db_manager_agent'];
    } else if (lower.includes('قانون') || lower.includes('مالیات') || lower.includes('ارزش افزوده') || lower.includes('ماده ۱۳۱') || lower.includes('rule')) {
      intent = 'rule_inquiry';
      recommendedAgents = ['accounting_domain_engine', 'study_knowledge_agent'];
    } else if (lower.includes('استاندارد') || lower.includes('ifrs') || lower.includes('حسابرسی') || lower.includes('تحقیق')) {
      intent = 'standard_research';
      recommendedAgents = ['study_knowledge_agent'];
    } else if (lower.includes('وضعیت') || lower.includes('حافظه') || lower.includes('status') || lower.includes('عوامل') || lower.includes('agents')) {
      intent = 'system_status';
      recommendedAgents = ['ceo', 'self_healing_system'];
    }

    return {
      intent,
      policyPassed,
      recommendedAgents,
      confidence: 0.96,
      extractedParams: {
        amount,
        text,
      },
    };
  }

  /**
   * End-to-End Orchestration Loop (§4.3 Bounded-Retry Checkpoint Loop):
   * input_receiver -> input_compiler -> input_analyser -> output_forecaster -> output_checker -> decision -> counter
   */
  public async handleUserPrompt(prompt: string): Promise<{
    ok: boolean;
    prompt: string;
    intent: string;
    stages: Array<{ stageName: string; agent: string; status: 'ok' | 'error'; details: any; timestamp: string }>;
    result: any;
    error?: string;
  }> {
    const stages: Array<{ stageName: string; agent: string; status: 'ok' | 'error'; details: any; timestamp: string }> = [];
    const pushStage = (stageName: string, agent: string, status: 'ok' | 'error', details: any) => {
      stages.push({ stageName, agent, status, details, timestamp: new Date().toISOString() });
    };

    // Stage 1: Prompt Manager & Policy Checker (n5::n1)
    const analysis = this.analyzePrompt(prompt);
    pushStage('Prompt Analysis & Policy Validation', 'ceo_prompt_manager', analysis.policyPassed ? 'ok' : 'error', {
      intent: analysis.intent,
      policyPassed: analysis.policyPassed,
      recommendedAgents: analysis.recommendedAgents,
      extractedParams: analysis.extractedParams,
    });

    if (!analysis.policyPassed) {
      return {
        ok: false,
        prompt,
        intent: analysis.intent,
        stages,
        result: null,
        error: 'Prompt rejected by CEO Policy Checker (n5::n1): Security or authorization violation',
      };
    }

    // Branch by Intent
    if (analysis.intent === 'transaction_entry') {
      // Stage 2: Accounting Domain Engine - Dual Path (n16, n17)
      const domainResult = await globalDomainEngine.classifyAndGenerateVoucher({
        description: prompt,
        amount: analysis.extractedParams.amount || 15000000,
      });

      pushStage('Accounting Domain Engine (Dual-Path)', 'accounting_domain_engine', 'ok', {
        path: domainResult.path,
        ruleMatched: domainResult.ruleMatched?.code || 'None (LLM Fallback)',
        confidence: domainResult.confidence,
        explanation: domainResult.explanation,
        linesCount: domainResult.lines.length,
      });

      // Stage 3: Quality Assurance & Critic Pattern (n8 / Final Checker Agent)
      const criticResult = globalCritic.verifyVoucherCandidate({
        description: prompt,
        lines: domainResult.lines,
      });

      pushStage('QA Critic Pattern (4-Tier Verification)', 'final_checker_agent', criticResult.passed ? 'ok' : 'error', {
        score: criticResult.score,
        disposition: criticResult.disposition,
        layers: criticResult.layers,
      });

      if (!criticResult.passed) {
        return {
          ok: false,
          prompt,
          intent: analysis.intent,
          stages,
          result: { domainResult, criticResult },
          error: `Transaction rejected by Final Checker Critic (n8): ${criticResult.layers.layer4_confidenceAggregation.rationale}`,
        };
      }

      // Stage 4: Signed Channel to DB Manager Agent (n10 -> n6)
      const msgSend = globalMessagingChannel.send('ceo', 'db_manager_agent', {
        op: 'post_journal_voucher',
        voucherCandidate: {
          description: prompt,
          lines: domainResult.lines,
          ruleMatched: domainResult.ruleMatched?.code,
        },
      });

      pushStage('Cryptographic Ed25519 Message & Audit Chaining', 'messaging_channel', msgSend.ok ? 'ok' : 'error', {
        messageId: msgSend.message?.messageId,
        chainIndex: msgSend.message?.chainIndex,
        hash: msgSend.message?.hash,
        previousHash: msgSend.message?.previousHash,
      });

      // Stage 5: DB Manager Mutation & DB Situation Analyser (n6)
      const postResult = globalDBManager.postJournalVoucher({
        date: new Date().toISOString().split('T')[0],
        description: prompt,
        lines: domainResult.lines,
        createdByAgent: 'accounting_domain_engine',
        ruleMatched: domainResult.ruleMatched?.code,
      });

      pushStage('DB Manager Agent (Authoritative Ledger Post)', 'db_manager_agent', postResult.ok ? 'ok' : 'error', {
        voucherNumber: postResult.voucher?.voucherNumber,
        totalDebit: postResult.voucher?.totalDebit,
        situationReport: postResult.situationReport,
      });

      return {
        ok: true,
        prompt,
        intent: analysis.intent,
        stages,
        result: {
          voucher: postResult.voucher,
          domainResult,
          criticResult,
          messageAudit: msgSend.message,
        },
      };
    } else {
      // General or Reporting or Knowledge Inquiries
      const aiResponse = await generateAIText(
        `User Prompt: "${prompt}"\nIntent: ${analysis.intent}\nContext: Hesabdar Multi-Agent Accounting Operating System. Provide a professional, concise executive response with accounting accuracy and system status.`,
        'You are the CEO Supervisory Kernel of Hesabdar. Provide direct, helpful accounting and system insights.'
      );

      pushStage('Executive Synthesis & Reasoning', 'ceo_core', 'ok', {
        model: 'gemini-3.7-flash',
        synthesisPreview: aiResponse.slice(0, 120),
      });

      return {
        ok: true,
        prompt,
        intent: analysis.intent,
        stages,
        result: {
          response: aiResponse,
          intent: analysis.intent,
        },
      };
    }
  }

  /**
   * Provision New Agent (n5::n2 & n5::n9)
   */
  public provisionAgent(agentId: string, role: string, capabilities: string[] = []) {
    const identity = globalIdentityRegistry.registerAgent(agentId, role, capabilities);
    globalMemoryStore.write(
      'ceo',
      MemoryType.AGENT_PERMISSION_MANIFEST,
      { agentId, role, capabilities },
      { tags: ['agent_provisioned'], importance: 7 }
    );
    return identity;
  }

  /**
   * Retire Agent (n5::n3 Agent Killer -> Summary Maker)
   */
  public async retireAgent(agentId: string, notes: string = '') {
    globalIdentityRegistry.retireAgent(agentId);
    const summary = `Agent '${agentId}' retired with notes: ${notes}. State archived in reflection memory.`;

    globalMemoryStore.write(
      'ceo',
      MemoryType.POST_MORTEM_REFLECTION,
      { agentId, summary, retiredAt: new Date().toISOString() },
      { tags: ['agent_retired', 'reflection'], importance: 8 }
    );

    return summary;
  }
}

export const globalCEO = new CEOAgentArchitecture();
