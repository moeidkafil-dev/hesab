import { Account, JournalVoucher, JournalLine } from '../types.js';
import { globalMemoryStore } from './memory.js';
import { MemoryType } from '../types.js';

export class DBManagerAgent {
  private accounts: Map<string, Account> = new Map();
  private vouchers: Map<string, JournalVoucher> = new Map();
  private voucherCounter = 1000;

  constructor() {
    this.initializeStandardChartOfAccounts();
    this.seedInitialTransactions();
  }

  private initializeStandardChartOfAccounts() {
    const standardAccounts: Account[] = [
      // Assets (1000s)
      { id: 'acc_cash', code: '1010', name: 'Cash and Bank Equivalents', nameFa: 'موجودی نقد و بانک', type: 'asset', category: 'current_asset', balance: 50000000, normalBalance: 'debit' },
      { id: 'acc_ar', code: '1020', name: 'Accounts Receivable', nameFa: 'حساب‌ها و اسناد دریافتنی تجاری', type: 'asset', category: 'current_asset', balance: 24000000, normalBalance: 'debit' },
      { id: 'acc_inventory', code: '1030', name: 'Merchandise Inventory', nameFa: 'موجودی کالا', type: 'asset', category: 'current_asset', balance: 35000000, normalBalance: 'debit' },
      { id: 'acc_vat_input', code: '1040', name: 'VAT Input Tax Receivable', nameFa: 'اعتبار مالیات بر ارزش افزوده خرید', type: 'asset', category: 'current_asset', balance: 3500000, normalBalance: 'debit' },
      { id: 'acc_equipment', code: '1510', name: 'Office & IT Equipment', nameFa: 'تجهیزات و ماشین‌آلات اداری', type: 'asset', category: 'non_current_asset', balance: 60000000, normalBalance: 'debit' },
      { id: 'acc_accum_dep', code: '1520', name: 'Accumulated Depreciation', nameFa: 'استهلاک انباشته تجهیزات', type: 'asset', category: 'non_current_asset', balance: -10000000, normalBalance: 'credit' },

      // Liabilities (2000s)
      { id: 'acc_ap', code: '2010', name: 'Accounts Payable', nameFa: 'حساب‌ها و اسناد پرداختنی تجاری', type: 'liability', category: 'current_liability', balance: 18000000, normalBalance: 'credit' },
      { id: 'acc_salaries_payable', code: '2020', name: 'Salaries & Wages Payable', nameFa: 'حقوق و دستمزد پرداختنی', type: 'liability', category: 'current_liability', balance: 12000000, normalBalance: 'credit' },
      { id: 'acc_vat_output', code: '2030', name: 'VAT Output Tax Payable', nameFa: 'مالیات بر ارزش افزوده فروش پرداختنی', type: 'liability', category: 'current_liability', balance: 6500000, normalBalance: 'credit' },
      { id: 'acc_tax_withholding', code: '2040', name: 'Income Tax Withholding Payable', nameFa: 'مالیات تکلیفی پرداختنی (ماده ۱۳۱)', type: 'liability', category: 'current_liability', balance: 4000000, normalBalance: 'credit' },
      { id: 'acc_long_term_loan', code: '2510', name: 'Bank Facility / Long-Term Loan', nameFa: 'تسهیلات مالی بلندمدت بانکی', type: 'liability', category: 'long_term_liability', balance: 30000000, normalBalance: 'credit' },

      // Equity (3000s)
      { id: 'acc_capital', code: '3010', name: 'Share Capital', nameFa: 'سرمایه ثبتی', type: 'equity', category: 'equity', balance: 75000000, normalBalance: 'credit' },
      { id: 'acc_retained_earnings', code: '3020', name: 'Retained Earnings', nameFa: 'سود و زیان انباشته', type: 'equity', category: 'equity', balance: 17000000, normalBalance: 'credit' },

      // Revenues (4000s)
      { id: 'acc_sales_rev', code: '4010', name: 'Sales Revenue', nameFa: 'درآمد حاصل از فروش کالا و خدمات', type: 'revenue', category: 'operating_revenue', balance: 85000000, normalBalance: 'credit' },
      { id: 'acc_discount', code: '4020', name: 'Sales Discounts', nameFa: 'تخفیفات نقدی فروش', type: 'revenue', category: 'operating_revenue', balance: -2000000, normalBalance: 'debit' },

      // Expenses (5000s)
      { id: 'acc_cogs', code: '5010', name: 'Cost of Goods Sold (COGS)', nameFa: 'بهای تمام شده کالای فروش رفته', type: 'expense', category: 'operating_expense', balance: 42000000, normalBalance: 'debit' },
      { id: 'acc_salary_exp', code: '5020', name: 'Salaries & Staff Expenses', nameFa: 'هزینه حقوق و دستمزد پرسنل', type: 'expense', category: 'operating_expense', balance: 22000000, normalBalance: 'debit' },
      { id: 'acc_rent_exp', code: '5030', name: 'Office Rent & Utilities Expense', nameFa: 'هزینه اجاره و سربار اداری', type: 'expense', category: 'operating_expense', balance: 10000000, normalBalance: 'debit' },
      { id: 'acc_deprec_exp', code: '5040', name: 'Depreciation Expense', nameFa: 'هزینه استهلاک دارایی‌های ثابت', type: 'expense', category: 'operating_expense', balance: 3000000, normalBalance: 'debit' },
      { id: 'acc_tax_exp', code: '5050', name: 'Corporate Income Tax Expense', nameFa: 'هزینه مالیات بر درآمد عملکرد', type: 'expense', category: 'tax_expense', balance: 5000000, normalBalance: 'debit' },
    ];

    for (const acc of standardAccounts) {
      this.accounts.set(acc.id, acc);
    }
  }

  private seedInitialTransactions() {
    const seedVouchers: Array<Omit<JournalVoucher, 'id' | 'voucherNumber' | 'hash'>> = [
      {
        date: new Date(Date.now() - 86400000 * 5).toISOString().split('T')[0],
        description: 'ثبت سند فروش نقدی کالا به همراه ۱۰٪ مالیات بر ارزش افزوده',
        lines: [
          { id: 'l1', accountId: 'acc_cash', accountName: 'موجودی نقد و بانک', accountCode: '1010', debit: 22000000, credit: 0 },
          { id: 'l2', accountId: 'acc_sales_rev', accountName: 'درآمد حاصل از فروش کالا و خدمات', accountCode: '4010', debit: 0, credit: 20000000 },
          { id: 'l3', accountId: 'acc_vat_output', accountName: 'مالیات بر ارزش افزوده فروش پرداختنی', accountCode: '2030', debit: 0, credit: 2000000 },
        ],
        totalDebit: 22000000,
        totalCredit: 22000000,
        status: 'posted',
        createdByAgent: 'accounting_domain_engine',
        ruleMatched: 'RULE-VAT-01',
      },
      {
        date: new Date(Date.now() - 86400000 * 3).toISOString().split('T')[0],
        description: 'ثبت بهای تمام شده کالای فروش رفته (COGS) و خروج موجودی کالا',
        lines: [
          { id: 'l4', accountId: 'acc_cogs', accountName: 'بهای تمام شده کالای فروش رفته', accountCode: '5010', debit: 11000000, credit: 0 },
          { id: 'l5', accountId: 'acc_inventory', accountName: 'موجودی کالا', accountCode: '1030', debit: 0, credit: 11000000 },
        ],
        totalDebit: 11000000,
        totalCredit: 11000000,
        status: 'posted',
        createdByAgent: 'accounting_domain_engine',
        ruleMatched: 'RULE-COGS-FIFO',
      },
      {
        date: new Date(Date.now() - 86400000 * 1).toISOString().split('T')[0],
        description: 'ثبت سند حقوق و دستمزد ماهانه به کسر مالیات تکلیفی ماده ۱۳۱',
        lines: [
          { id: 'l6', accountId: 'acc_salary_exp', accountName: 'هزینه حقوق و دستمزد پرسنل', accountCode: '5020', debit: 8000000, credit: 0 },
          { id: 'l7', accountId: 'acc_tax_withholding', accountName: 'مالیات تکلیفی پرداختنی (ماده ۱۳۱)', accountCode: '2040', debit: 0, credit: 800000 },
          { id: 'l8', accountId: 'acc_salaries_payable', accountName: 'حقوق و دستمزد پرداختنی', accountCode: '2020', debit: 0, credit: 7200000 },
        ],
        totalDebit: 8000000,
        totalCredit: 8000000,
        status: 'posted',
        createdByAgent: 'accounting_domain_engine',
        ruleMatched: 'RULE-PAYROLL-01',
      },
    ];

    for (const v of seedVouchers) {
      const vNum = `VOU-${++this.voucherCounter}`;
      const id = `vou_${Date.now()}_${this.voucherCounter}`;
      this.vouchers.set(id, {
        ...v,
        id,
        voucherNumber: vNum,
        hash: `h_${Math.random().toString(36).substring(2, 10)}`,
      });
    }
  }

  // Double-Entry Ledger Operations
  public listAccounts(): Account[] {
    return Array.from(this.accounts.values()).sort((a, b) => a.code.localeCompare(b.code));
  }

  public getAccount(id: string): Account | undefined {
    return this.accounts.get(id);
  }

  public createAccount(account: Omit<Account, 'id'>): Account {
    const id = `acc_${account.code}_${Date.now()}`;
    const newAccount: Account = { ...account, id };
    this.accounts.set(id, newAccount);
    return newAccount;
  }

  /**
   * DB Analyser vs DB Situation Analyser Generator/Critic Pair (§9.2)
   * 1. DB Analyser prepares write & checks balance equality
   * 2. Executor mutates balances
   * 3. DB Situation Analyser verifies state integrity post-mutation
   */
  public postJournalVoucher(params: {
    date: string;
    description: string;
    lines: Array<{ accountId: string; debit: number; credit: number; description?: string }>;
    createdByAgent?: string;
    ruleMatched?: string;
  }): { ok: boolean; voucher?: JournalVoucher; error?: string; situationReport?: string } {
    const totalDebit = params.lines.reduce((s, l) => s + (Number(l.debit) || 0), 0);
    const totalCredit = params.lines.reduce((s, l) => s + (Number(l.credit) || 0), 0);

    // Generator check: Debit == Credit
    if (Math.abs(totalDebit - totalCredit) > 0.0001) {
      return {
        ok: false,
        error: `Double-entry imbalance: Total Debit (${totalDebit}) != Total Credit (${totalCredit})`,
      };
    }

    if (params.lines.length < 2) {
      return { ok: false, error: 'A journal voucher must have at least 2 lines (debit & credit)' };
    }

    // Verify all accounts exist
    const hydratedLines: JournalLine[] = [];
    for (let i = 0; i < params.lines.length; i++) {
      const line = params.lines[i];
      const acc = this.accounts.get(line.accountId);
      if (!acc) {
        return { ok: false, error: `Account with ID ${line.accountId} not found in Chart of Accounts` };
      }
      hydratedLines.push({
        id: `line_${i}_${Date.now()}`,
        accountId: acc.id,
        accountName: acc.nameFa || acc.name,
        accountCode: acc.code,
        debit: Number(line.debit) || 0,
        credit: Number(line.credit) || 0,
        description: line.description,
      });
    }

    // Step 2: Executor mutates ledger balances
    for (const line of hydratedLines) {
      const acc = this.accounts.get(line.accountId)!;
      if (acc.normalBalance === 'debit') {
        acc.balance += line.debit - line.credit;
      } else {
        acc.balance += line.credit - line.debit;
      }
    }

    // Step 3: DB Situation Analyser (Critic on DB state)
    let isLedgerSound = true;
    for (const line of hydratedLines) {
      const acc = this.accounts.get(line.accountId)!;
      if (isNaN(acc.balance)) {
        isLedgerSound = false;
      }
    }

    if (!isLedgerSound) {
      return { ok: false, error: 'DB Situation Analyser detected NaN balance corruption after execution' };
    }

    const vNum = `VOU-${++this.voucherCounter}`;
    const id = `vou_${Date.now()}_${this.voucherCounter}`;
    const voucher: JournalVoucher = {
      id,
      voucherNumber: vNum,
      date: params.date || new Date().toISOString().split('T')[0],
      description: params.description,
      lines: hydratedLines,
      totalDebit,
      totalCredit,
      status: 'posted',
      createdByAgent: params.createdByAgent || 'accounting_domain_engine',
      ruleMatched: params.ruleMatched,
      hash: `h_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`,
    };

    this.vouchers.set(id, voucher);

    // Record immutable financial transaction in memory store (§3.5)
    globalMemoryStore.write(
      'db_manager',
      MemoryType.FINANCIAL_TRANSACTION,
      {
        voucherId: voucher.id,
        voucherNumber: voucher.voucherNumber,
        totalAmount: totalDebit,
        description: voucher.description,
      },
      { tags: ['voucher_posted', 'immutable_financial'], importance: 10 }
    );

    return {
      ok: true,
      voucher,
      situationReport: `DB Situation Analyser: Voucher ${vNum} verified and posted cleanly. Ledger balances updated.`,
    };
  }

  public listVouchers(): JournalVoucher[] {
    return Array.from(this.vouchers.values()).sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
    );
  }

  public queryBalance(accountId: string): number {
    const acc = this.accounts.get(accountId);
    return acc ? acc.balance : 0;
  }

  public getTrialBalance(): {
    accounts: Array<{ code: string; name: string; type: string; debit: number; credit: number }>;
    totalDebit: number;
    totalCredit: number;
    isBalanced: boolean;
  } {
    const list = this.listAccounts();
    const rows = list.map((a) => {
      let debit = 0;
      let credit = 0;
      if (a.normalBalance === 'debit') {
        if (a.balance >= 0) debit = a.balance;
        else credit = Math.abs(a.balance);
      } else {
        if (a.balance >= 0) credit = a.balance;
        else debit = Math.abs(a.balance);
      }
      return {
        code: a.code,
        name: a.nameFa || a.name,
        type: a.type,
        debit,
        credit,
      };
    });

    const totalDebit = rows.reduce((s, r) => s + r.debit, 0);
    const totalCredit = rows.reduce((s, r) => s + r.credit, 0);
    const isBalanced = Math.abs(totalDebit - totalCredit) < 1;

    return {
      accounts: rows,
      totalDebit,
      totalCredit,
      isBalanced,
    };
  }
}

export const globalDBManager = new DBManagerAgent();
