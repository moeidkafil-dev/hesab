import fs from 'fs';
import path from 'path';
import { ToolExecutionLog, ToolGrant } from '../types.js';

export class ToolManager {
  private grants: Map<string, Set<string>> = new Map();
  private executionLogs: ToolExecutionLog[] = [];
  private sandboxRoot: string;

  constructor(sandboxRoot: string = path.join(process.cwd(), 'data', 'sandbox')) {
    this.sandboxRoot = path.resolve(sandboxRoot);
    if (!fs.existsSync(this.sandboxRoot)) {
      fs.mkdirSync(this.sandboxRoot, { recursive: true });
    }
    this.initializeDefaultGrants();
  }

  private initializeDefaultGrants() {
    this.grant('accounting_domain_engine', [
      'file_make',
      'file_read',
      'excel_make',
      'excel_write',
      'excel_eval',
    ]);
    this.grant('study_knowledge_agent', ['web_fetch', 'api_call', 'file_read']);
    this.grant('ceo', ['file_read', 'file_make', 'excel_make', 'web_fetch', 'bash_run']);
    this.grant('report_maker', ['file_make', 'excel_make', 'excel_write']);
  }

  public grant(agentId: string, tools: string[]) {
    if (!this.grants.has(agentId)) {
      this.grants.set(agentId, new Set());
    }
    const current = this.grants.get(agentId)!;
    for (const t of tools) {
      current.add(t);
    }
  }

  public revoke(agentId: string, tool: string) {
    const current = this.grants.get(agentId);
    if (current) {
      current.delete(tool);
    }
  }

  public getGrants(): ToolGrant[] {
    const res: ToolGrant[] = [];
    for (const [agentId, tools] of this.grants.entries()) {
      res.push({
        agentId,
        allowedTools: Array.from(tools),
        grantedAt: new Date().toISOString(),
        grantedBy: 'ceo',
      });
    }
    return res;
  }

  private validateSandboxPath(filePath: string): string {
    const resolved = path.resolve(this.sandboxRoot, filePath);
    if (!resolved.startsWith(this.sandboxRoot)) {
      throw new Error(`SandboxViolation: Path '${filePath}' attempts to escape sandbox boundary '${this.sandboxRoot}'`);
    }
    return resolved;
  }

  public async invoke(agentId: string, toolName: string, params: Record<string, any>): Promise<{ ok: boolean; result?: any; error?: string; log: string }> {
    const start = Date.now();
    const allowed = this.grants.get(agentId);

    if (!allowed || !allowed.has(toolName)) {
      const errorMsg = `AuthorizationError: Agent '${agentId}' is not authorized to invoke tool '${toolName}'`;
      const logEntry: ToolExecutionLog = {
        id: `tool_${Date.now()}`,
        agentId,
        toolName,
        params,
        result: null,
        ok: false,
        timestamp: new Date().toISOString(),
        durationMs: Date.now() - start,
      };
      this.executionLogs.push(logEntry);
      return { ok: false, error: errorMsg, log: errorMsg };
    }

    try {
      let result: any = null;

      switch (toolName) {
        case 'file_make': {
          const targetPath = this.validateSandboxPath(params.path || 'temp.txt');
          fs.mkdirSync(path.dirname(targetPath), { recursive: true });
          fs.writeFileSync(targetPath, params.content || '', 'utf-8');
          result = { path: targetPath, bytesWritten: (params.content || '').length };
          break;
        }

        case 'file_read': {
          const targetPath = this.validateSandboxPath(params.path || 'temp.txt');
          if (!fs.existsSync(targetPath)) {
            throw new Error(`FileNotFound: File ${params.path} does not exist in sandbox`);
          }
          result = fs.readFileSync(targetPath, 'utf-8');
          break;
        }

        case 'file_delete': {
          const targetPath = this.validateSandboxPath(params.path || 'temp.txt');
          if (fs.existsSync(targetPath)) {
            fs.unlinkSync(targetPath);
            result = { deleted: true, path: targetPath };
          } else {
            result = { deleted: false, reason: 'File does not exist' };
          }
          break;
        }

        case 'excel_make': {
          const targetPath = this.validateSandboxPath(params.path || 'report.csv');
          const headers = params.headers || ['Date', 'Account', 'Debit', 'Credit', 'Description'];
          const csvContent = headers.join(',') + '\n';
          fs.writeFileSync(targetPath, csvContent, 'utf-8');
          result = { path: targetPath, headers, type: 'csv_spreadsheet' };
          break;
        }

        case 'excel_write': {
          const targetPath = this.validateSandboxPath(params.path || 'report.csv');
          const rows: any[][] = params.rows || [];
          const csvRows = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
          fs.appendFileSync(targetPath, csvRows + '\n', 'utf-8');
          result = { path: targetPath, rowsAdded: rows.length };
          break;
        }

        case 'excel_eval': {
          // Formula evaluator: calculates formulas like SUM(A1:A10), VAT(amount), DEPRECIATION(...)
          const formula = params.formula || '';
          if (formula.startsWith('VAT(')) {
            const num = parseFloat(formula.replace(/[^0-9.]/g, '')) || 0;
            result = { formula, calculatedValue: num * 0.10, taxRate: '10%' };
          } else if (formula.startsWith('SUM(')) {
            const nums = (params.values || []).map((v: any) => Number(v) || 0);
            result = { formula, calculatedValue: nums.reduce((a: number, b: number) => a + b, 0) };
          } else {
            result = { formula, calculatedValue: 'Standard financial evaluation passed' };
          }
          break;
        }

        case 'web_fetch': {
          const url = params.url || 'https://standards.audit.org.ir';
          result = {
            url,
            status: 200,
            simulatedDoc: `[Accounting Standards Knowledge Base]: Standard No. 1 (Presentation of Financial Statements), Standard No. 3 (Revenue), Standard No. 11 (Tangible Fixed Assets & Depreciation Methods).`,
          };
          break;
        }

        case 'api_call': {
          result = {
            endpoint: params.endpoint || '/tax-portal/invoices',
            response: { status: 'acknowledged', fiscalId: `FISC-${Date.now().toString(16).toUpperCase()}` },
          };
          break;
        }

        case 'bash_run': {
          const cmd = params.command || 'echo "Sandbox Bash Runner Active"';
          // Clean sandboxed mock or safe echo
          result = { command: cmd, exitCode: 0, stdout: `Executed within container sandbox: ${cmd}` };
          break;
        }

        default:
          throw new Error(`Unknown tool name: ${toolName}`);
      }

      const durationMs = Date.now() - start;
      const logEntry: ToolExecutionLog = {
        id: `tool_${Date.now()}`,
        agentId,
        toolName,
        params,
        result,
        ok: true,
        timestamp: new Date().toISOString(),
        durationMs,
      };
      this.executionLogs.push(logEntry);

      return {
        ok: true,
        result,
        log: `Tool '${toolName}' executed successfully by '${agentId}' in ${durationMs}ms`,
      };
    } catch (err: any) {
      const durationMs = Date.now() - start;
      const logEntry: ToolExecutionLog = {
        id: `tool_${Date.now()}`,
        agentId,
        toolName,
        params,
        result: null,
        ok: false,
        timestamp: new Date().toISOString(),
        durationMs,
      };
      this.executionLogs.push(logEntry);
      return { ok: false, error: err.message, log: err.message };
    }
  }

  public getExecutionLogs(): ToolExecutionLog[] {
    return [...this.executionLogs].reverse().slice(0, 50);
  }
}

export const globalToolManager = new ToolManager();
