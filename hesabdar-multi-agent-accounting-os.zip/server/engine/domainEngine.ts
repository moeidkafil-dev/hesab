import { AccountingRule, JournalLine } from '../types.js';
import { globalDBManager } from './dbManager.js';
import { generateAIText } from '../gemini.js';
import { globalMemoryStore } from './memory.js';
import { MemoryType } from '../types.js';

export class AccountingDomainEngine {
  private rules: Map<string, AccountingRule> = new Map();

  constructor() {
    this.seedStandardRules();
  }

  private seedStandardRules() {
    const standardRules: AccountingRule[] = [
      {
        id: 'rule_vat_sales',
        code: 'RULE-VAT-01',
        title: 'Value Added Tax (VAT) 10% on Sales',
        titleFa: 'محاسبه و تفکیک ۱۰٪ مالیات بر ارزش افزوده فروش',
        description: 'Splits sales transaction into net Sales Revenue (4010) and Output VAT Payable (2030) at 10% rate',
        condition: 'description.includes("فروش") || description.includes("sales") || description.includes("sale")',
        ruleType: 'vat',
        parameters: { vatRate: 0.10, revenueAccountCode: '4010', vatAccountCode: '2030', cashAccountCode: '1010' },
        isApproved: true,
        approvalStatus: 'approved',
        confidenceScore: 1.0,
        version: 1,
      },
      {
        id: 'rule_cogs_fifo',
        code: 'RULE-COGS-FIFO',
        title: 'Cost of Goods Sold (FIFO Matching)',
        titleFa: 'شناسایی بهای تمام شده کالای فروش رفته بر اساس فایفو',
        description: 'Debits Cost of Goods Sold (5010) and credits Inventory (1030) upon sale of goods',
        condition: 'description.includes("کالا") || description.includes("inventory") || description.includes("cogs")',
        ruleType: 'inventory_cogs',
        parameters: { cogsAccountCode: '5010', inventoryAccountCode: '1030', estimatedMargin: 0.50 },
        isApproved: true,
        approvalStatus: 'approved',
        confidenceScore: 0.98,
        version: 1,
      },
      {
        id: 'rule_payroll_tax',
        code: 'RULE-PAYROLL-01',
        title: 'Payroll Expense & Article 131 Withholding Tax',
        titleFa: 'ثبت حقوق و دستمزد به کسر ۱۰٪ مالیات تکلیفی ماده ۱۳۱',
        description: 'Debits Salary Expense (5020), credits Tax Withholding (2040) at 10%, credits Salaries Payable (2020) for net pay',
        condition: 'description.includes("حقوق") || description.includes("دستمزد") || description.includes("payroll") || description.includes("salary")',
        ruleType: 'payroll_withholding',
        parameters: { withholdingRate: 0.10, salaryExpenseCode: '5020', withholdingTaxCode: '2040', netPayableCode: '2020' },
        isApproved: true,
        approvalStatus: 'approved',
        confidenceScore: 1.0,
        version: 1,
      },
      {
        id: 'rule_depreciation_sl',
        code: 'RULE-DEP-SL',
        title: 'Monthly Straight-Line Fixed Asset Depreciation',
        titleFa: 'ثبت استهلاک مستقیم ماهانه تجهیزات و اثاثیه',
        description: 'Debits Depreciation Expense (5040) and credits Accumulated Depreciation (1520)',
        condition: 'description.includes("استهلاک") || description.includes("depreciation")',
        ruleType: 'depreciation',
        parameters: { usefulLifeMonths: 60, expenseCode: '5040', accumDepCode: '1520' },
        isApproved: true,
        approvalStatus: 'approved',
        confidenceScore: 0.99,
        version: 1,
      },
      {
        id: 'rule_rent_expense',
        code: 'RULE-RENT-01',
        title: 'Office Rent and Operating Overhead Payment',
        titleFa: 'ثبت هزینه اجاره و سربار اداری از محل بانک',
        description: 'Debits Office Rent Expense (5030) and credits Cash & Bank (1010)',
        condition: 'description.includes("اجاره") || description.includes("rent") || description.includes("سربار")',
        ruleType: 'custom',
        parameters: { rentExpenseCode: '5030', cashAccountCode: '1010' },
        isApproved: true,
        approvalStatus: 'approved',
        confidenceScore: 1.0,
        version: 1,
      },
    ];

    for (const r of standardRules) {
      this.rules.set(r.id, r);
    }
  }

  public listRules(): AccountingRule[] {
    return Array.from(this.rules.values());
  }

  public getRule(id: string): AccountingRule | undefined {
    return this.rules.get(id);
  }

  public createProposedRule(ruleData: Omit<AccountingRule, 'id' | 'isApproved' | 'approvalStatus' | 'version'>): AccountingRule {
    const id = `rule_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const newRule: AccountingRule = {
      ...ruleData,
      id,
      isApproved: false,
      approvalStatus: 'pending_approval',
      version: 1,
    };
    this.rules.set(id, newRule);

    globalMemoryStore.write(
      'accounting_domain_engine',
      MemoryType.ACCOUNTING_RULE_BASE,
      {
        action: 'proposed_rule_created',
        ruleId: newRule.id,
        code: newRule.code,
        title: newRule.title,
      },
      { tags: ['rule_proposal', 'pending_approval'], importance: 8 }
    );

    return newRule;
  }

  /**
   * Human Approval Gate (§5.4)
   * Only human review via CEO can promote a rule to approved status
   */
  public reviewProposedRule(ruleId: string, approve: boolean, reviewer: string = 'CEO_Human_Supervisor'): { ok: boolean; rule?: AccountingRule; error?: string } {
    const rule = this.rules.get(ruleId);
    if (!rule) {
      return { ok: false, error: `Rule ${ruleId} not found` };
    }

    if (approve) {
      rule.isApproved = true;
      rule.approvalStatus = 'approved';
    } else {
      rule.isApproved = false;
      rule.approvalStatus = 'rejected';
    }

    globalMemoryStore.write(
      'ceo',
      MemoryType.ACCOUNTING_RULE_BASE,
      {
        action: approve ? 'rule_approved_for_production' : 'rule_rejected',
        ruleId: rule.id,
        reviewer,
      },
      { tags: ['rule_governance', 'human_gate'], importance: 9 }
    );

    return { ok: true, rule };
  }

  /**
   * Dual-Path Execution Engine (§2.3 & §5)
   * Deterministic Fast Path -> Fallback to LLM Research with Rule Proposal
   */
  public async classifyAndGenerateVoucher(input: {
    description: string;
    amount?: number;
    date?: string;
  }): Promise<{
    path: 'deterministic' | 'probabilistic_llm';
    ruleMatched?: AccountingRule;
    lines: Array<{ accountId: string; accountName: string; accountCode: string; debit: number; credit: number }>;
    totalDebit: number;
    totalCredit: number;
    confidence: number;
    explanation: string;
    proposedRule?: AccountingRule;
  }> {
    const desc = input.description;
    const amount = Number(input.amount) || 10000000;
    const accounts = globalDBManager.listAccounts();

    const getAcc = (code: string) => accounts.find((a) => a.code === code) || accounts[0];

    // Fast Deterministic Path
    for (const rule of this.rules.values()) {
      if (!rule.isApproved) continue;

      let matches = false;
      try {
        const description = desc.toLowerCase();
        // Safe evaluation of condition keyword
        if (rule.ruleType === 'vat' && (description.includes('فروش') || description.includes('sale'))) {
          matches = true;
        } else if (rule.ruleType === 'payroll_withholding' && (description.includes('حقوق') || description.includes('دستمزد') || description.includes('salary'))) {
          matches = true;
        } else if (rule.ruleType === 'depreciation' && (description.includes('استهلاک') || description.includes('depreciation'))) {
          matches = true;
        } else if (rule.ruleType === 'inventory_cogs' && (description.includes('خرید کالا') || description.includes('موجودی') || description.includes('بهای تمام شده'))) {
          matches = true;
        } else if (rule.code === 'RULE-RENT-01' && (description.includes('اجاره') || description.includes('rent'))) {
          matches = true;
        }
      } catch {
        matches = false;
      }

      if (matches) {
        let lines: JournalLine[] = [];

        if (rule.ruleType === 'vat') {
          const cashAcc = getAcc('1010');
          const salesAcc = getAcc('4010');
          const vatAcc = getAcc('2030');
          const netSales = Math.round(amount / 1.10);
          const vat = amount - netSales;

          lines = [
            { id: '1', accountId: cashAcc.id, accountName: cashAcc.nameFa, accountCode: cashAcc.code, debit: amount, credit: 0 },
            { id: '2', accountId: salesAcc.id, accountName: salesAcc.nameFa, accountCode: salesAcc.code, debit: 0, credit: netSales },
            { id: '3', accountId: vatAcc.id, accountName: vatAcc.nameFa, accountCode: vatAcc.code, debit: 0, credit: vat },
          ];
        } else if (rule.ruleType === 'payroll_withholding') {
          const salExp = getAcc('5020');
          const taxWithhold = getAcc('2040');
          const salPayable = getAcc('2020');
          const tax = Math.round(amount * 0.10);
          const netPay = amount - tax;

          lines = [
            { id: '1', accountId: salExp.id, accountName: salExp.nameFa, accountCode: salExp.code, debit: amount, credit: 0 },
            { id: '2', accountId: taxWithhold.id, accountName: taxWithhold.nameFa, accountCode: taxWithhold.code, debit: 0, credit: tax },
            { id: '3', accountId: salPayable.id, accountName: salPayable.nameFa, accountCode: salPayable.code, debit: 0, credit: netPay },
          ];
        } else if (rule.ruleType === 'depreciation') {
          const depExp = getAcc('5040');
          const accumDep = getAcc('1520');
          lines = [
            { id: '1', accountId: depExp.id, accountName: depExp.nameFa, accountCode: depExp.code, debit: amount, credit: 0 },
            { id: '2', accountId: accumDep.id, accountName: accumDep.nameFa, accountCode: accumDep.code, debit: 0, credit: amount },
          ];
        } else if (rule.code === 'RULE-RENT-01') {
          const rentExp = getAcc('5030');
          const cashAcc = getAcc('1010');
          lines = [
            { id: '1', accountId: rentExp.id, accountName: rentExp.nameFa, accountCode: rentExp.code, debit: amount, credit: 0 },
            { id: '2', accountId: cashAcc.id, accountName: cashAcc.nameFa, accountCode: cashAcc.code, debit: 0, credit: amount },
          ];
        } else {
          const cashAcc = getAcc('1010');
          const salesAcc = getAcc('4010');
          lines = [
            { id: '1', accountId: cashAcc.id, accountName: cashAcc.nameFa, accountCode: cashAcc.code, debit: amount, credit: 0 },
            { id: '2', accountId: salesAcc.id, accountName: salesAcc.nameFa, accountCode: salesAcc.code, debit: 0, credit: amount },
          ];
        }

        const totalDebit = lines.reduce((s, l) => s + l.debit, 0);
        const totalCredit = lines.reduce((s, l) => s + l.credit, 0);

        return {
          path: 'deterministic',
          ruleMatched: rule,
          lines: lines as any,
          totalDebit,
          totalCredit,
          confidence: rule.confidenceScore,
          explanation: `Matched deterministic rule: [${rule.code}] ${rule.titleFa}`,
        };
      }
    }

    // Probabilistic Fallback (LLM-Assisted Research & Novel Rule Proposer §5.3)
    const prompt = `Analyze this accounting transaction description: "${desc}" with amount ${amount}.
Available Chart of Accounts:
${accounts.map((a) => `${a.code} - ${a.nameFa} (${a.type})`).join('\n')}

Output JSON format:
{
  "debitAccountCode": "string",
  "creditAccountCode": "string",
  "explanation": "string",
  "proposedRuleTitle": "string",
  "confidence": 0.85
}`;

    const aiRes = await generateAIText(prompt, 'You are an accounting domain rule generator. Output strictly JSON.');
    let debitCode = '5030';
    let creditCode = '1010';
    let explanation = 'Transaction resolved via LLM probabilistic fallback reasoning.';
    let proposedRuleTitle = `Rule for ${desc.slice(0, 30)}`;

    try {
      const jsonMatch = aiRes.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        debitCode = parsed.debitAccountCode || debitCode;
        creditCode = parsed.creditAccountCode || creditCode;
        explanation = parsed.explanation || explanation;
        proposedRuleTitle = parsed.proposedRuleTitle || proposedRuleTitle;
      }
    } catch {
      // Fallback defaults
    }

    const debAcc = getAcc(debitCode);
    const credAcc = getAcc(creditCode);

    const lines = [
      { id: '1', accountId: debAcc.id, accountName: debAcc.nameFa, accountCode: debAcc.code, debit: amount, credit: 0 },
      { id: '2', accountId: credAcc.id, accountName: credAcc.nameFa, accountCode: credAcc.code, debit: 0, credit: amount },
    ];

    // Propose new rule to human queue (§5.4)
    const proposedRule = this.createProposedRule({
      code: `RULE-PROP-${Math.floor(Math.random() * 9000 + 1000)}`,
      title: `Proposed: ${proposedRuleTitle}`,
      titleFa: `قانون پیشنهادی: ${desc.slice(0, 40)}`,
      description: `Automated proposal created for novel transaction '${desc}'`,
      condition: `description.includes("${desc.split(' ')[0]}")`,
      ruleType: 'custom',
      parameters: { debitCode, creditCode },
      proposedByAgent: 'accounting_domain_engine_researcher',
      confidenceScore: 0.85,
    });

    return {
      path: 'probabilistic_llm',
      lines: lines as any,
      totalDebit: amount,
      totalCredit: amount,
      confidence: 0.85,
      explanation: `${explanation} (A new rule proposal has been submitted to CEO human approval queue)`,
      proposedRule,
    };
  }
}

export const globalDomainEngine = new AccountingDomainEngine();
