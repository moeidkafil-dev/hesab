export enum MemoryType {
  // 1. Working Memory Family (n13::n3::n0_w)
  IMMEDIATE_CONTEXT = 'immediate_context',
  SHORT_TERM_SCRATCHPAD = 'short_term_scratchpad',
  OPERATIONAL_STATE = 'operational_state',

  // 2. Episodic Memory Family (n13::n3::n0_e)
  DAILY_ACTIVITY_LOG = 'daily_activity_log',
  AGENT_INTERACTION_HISTORY = 'agent_interaction_history',
  INCIDENT_ANOMALY_LOG = 'incident_anomaly_log',
  CHECKPOINT_RECORD = 'checkpoint_record',

  // 3. Semantic Memory Family (n13::n3::n0_s)
  ACCOUNTING_RULE_BASE = 'accounting_rule_base',
  CHART_OF_ACCOUNTS_REF = 'chart_of_accounts_ref',
  STANDARD_OPERATING_PROCEDURE = 'standard_operating_procedure',
  DOMAIN_KNOWLEDGE = 'domain_knowledge',

  // 4. Procedural Memory Family (n13::n3::n0_p)
  WORKFLOW_TEMPLATE = 'workflow_template',
  EXECUTION_STRATEGY = 'execution_strategy',
  TOOL_PATTERN = 'tool_pattern',

  // 5. Experiential & Reflection Memory Family (n13::n3::n0_r)
  POST_MORTEM_REFLECTION = 'post_mortem_reflection',
  AGENT_PERFORMANCE_METRIC = 'agent_performance_metric',
  SYSTEM_EVOLUTION_INSIGHT = 'system_evolution_insight',
  STRATEGY_REFINEMENT_LOG = 'strategy_refinement_log',

  // 6. Financial & Audit Memory Family (n13::n3::n0_f) - IMMUTABLE PER §3.5
  FINANCIAL_TRANSACTION = 'financial_transaction',
  AUDIT_TRAIL_CHAIN = 'audit_trail_chain',
  GENERAL_LEDGER_CACHE = 'general_ledger_cache',
  REGULATORY_COMPLIANCE = 'regulatory_compliance',

  // 7. System & Config Memory Family (n13::n3::n0_c)
  SYSTEM_CONFIGURATION = 'system_configuration',
  AGENT_PERMISSION_MANIFEST = 'agent_permission_manifest',
  CRYPTOGRAPHIC_KEYRING = 'cryptographic_keyring',
  RESOURCE_ALLOCATION_PROFILE = 'resource_allocation_profile',
  FAILURE = 'failure', // IMMUTABLE PER §3.5
}

export type MemoryFamily =
  | 'working'
  | 'episodic'
  | 'semantic'
  | 'procedural'
  | 'reflection'
  | 'financial_audit'
  | 'system_config';

export interface MemoryEntry {
  id: string;
  scope: string;
  memoryType: MemoryType;
  family: MemoryFamily;
  content: any;
  importance: number; // 1-10
  tags: string[];
  createdAt: string;
  accessCount: number;
  lastAccessedAt: string;
  isPermanent: boolean;
}

export interface AgentIdentityInfo {
  agentId: string;
  role: string;
  publicKey: string;
  createdAt: string;
  status: 'active' | 'retired' | 'suspended';
  rules: string[];
  capabilities: string[];
}

export interface SignedMessage {
  messageId: string;
  senderId: string;
  recipientId: string;
  timestamp: string;
  payload: any;
  signature: string;
  digest: string;
  previousHash: string;
  hash: string;
  chainIndex: number;
}

export interface Account {
  id: string;
  code: string;
  name: string;
  nameFa: string;
  type: 'asset' | 'liability' | 'equity' | 'revenue' | 'expense';
  category: 'current_asset' | 'non_current_asset' | 'current_liability' | 'long_term_liability' | 'equity' | 'operating_revenue' | 'operating_expense' | 'tax_expense';
  balance: number;
  normalBalance: 'debit' | 'credit';
  description?: string;
}

export interface JournalLine {
  id: string;
  accountId: string;
  accountName?: string;
  accountCode?: string;
  debit: number;
  credit: number;
  description?: string;
}

export interface JournalVoucher {
  id: string;
  voucherNumber: string;
  date: string;
  description: string;
  lines: JournalLine[];
  totalDebit: number;
  totalCredit: number;
  status: 'draft' | 'verified' | 'posted' | 'rejected';
  createdByAgent: string;
  criticVerification?: CriticVerificationResult;
  ruleMatched?: string;
  hash?: string;
}

export interface AccountingRule {
  id: string;
  code: string;
  title: string;
  titleFa: string;
  description: string;
  condition: string; // JavaScript expression / pattern
  ruleType: 'vat' | 'depreciation' | 'payroll_withholding' | 'revenue_recognition' | 'inventory_cogs' | 'custom';
  parameters: Record<string, any>;
  isApproved: boolean;
  proposedByAgent?: string;
  approvalStatus: 'approved' | 'pending_approval' | 'rejected';
  confidenceScore: number;
  version: number;
}

export interface CriticVerificationResult {
  passed: boolean;
  score: number; // 0-100
  disposition: 'auto_release' | 'escalate_to_human' | 'reject';
  layers: {
    layer1_structural: {
      passed: boolean;
      details: string;
      debitCreditBalance: boolean;
    };
    layer2_crossReferential: {
      passed: boolean;
      details: string;
      accountsExist: boolean;
    };
    layer3_historicalStatistical: {
      passed: boolean;
      details: string;
      zScore: number;
      isAnomaly: boolean;
    };
    layer4_confidenceAggregation: {
      score: number;
      routing: 'auto_release' | 'escalate_to_human' | 'reject';
      rationale: string;
    };
  };
}

export interface FinancialReports {
  balanceSheet: {
    assets: { items: { name: string; amount: number; code: string }[]; total: number };
    liabilities: { items: { name: string; amount: number; code: string }[]; total: number };
    equity: { items: { name: string; amount: number; code: string }[]; total: number };
    isBalanced: boolean;
    date: string;
  };
  incomeStatement: {
    revenue: { items: { name: string; amount: number }[]; total: number };
    costOfGoodsSold: { items: { name: string; amount: number }[]; total: number };
    grossProfit: number;
    operatingExpenses: { items: { name: string; amount: number }[]; total: number };
    operatingIncome: number;
    taxExpense: number;
    netIncome: number;
    period: string;
  };
  cashFlow: {
    operatingActivities: { description: string; amount: number }[];
    investingActivities: { description: string; amount: number }[];
    financingActivities: { description: string; amount: number }[];
    netCashChange: number;
    beginningCash: number;
    endingCash: number;
  };
  trialBalance: {
    accounts: { code: string; name: string; type: string; debit: number; credit: number }[];
    totalDebit: number;
    totalCredit: number;
    isBalanced: boolean;
  };
  forecast: {
    months: string[];
    revenue: number[];
    expenses: number[];
    netIncome: number[];
    cashRunwayMonths: number;
  };
  aiAnalysis?: {
    summary: string;
    keyIssues: string[];
    recommendations: string[];
    confidence: number;
  };
}

export interface ToolGrant {
  agentId: string;
  allowedTools: string[];
  grantedAt: string;
  grantedBy: string;
}

export interface ToolExecutionLog {
  id: string;
  agentId: string;
  toolName: string;
  params: any;
  result: any;
  ok: boolean;
  timestamp: string;
  durationMs: number;
}
