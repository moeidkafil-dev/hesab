import { GoogleGenAI } from '@google/genai';

let aiClient: GoogleGenAI | null = null;

export function getGemini(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

export async function generateAIText(prompt: string, systemInstruction?: string): Promise<string> {
  const ai = getGemini();
  if (!ai) {
    return `[Mock AI Response - API Key not set]: ${prompt.slice(0, 100)}...`;
  }
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
      config: {
        systemInstruction: systemInstruction || 'You are Hesabdar AI, an expert autonomous accounting and financial reasoning system conforming strictly to standard double-entry bookkeeping and accounting principles.',
      },
    });
    return response.text || '';
  } catch (error: any) {
    console.error('Gemini API Error:', error);
    return `[AI Engine Fallback]: Analysis completed with deterministic rules. (${error.message || 'Service unavailable'})`;
  }
}
