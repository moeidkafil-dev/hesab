export interface SystemStatus {
  status: string;
  appName: string;
  version: string;
  environment: string;
  invariants: {
    deterministicPath: string;
    supervisoryKernel: string;
    dbManagerAuthoritative: string;
    tamperEvidentChain: string;
    doubleEntryBalanced: boolean;
  };
  counts: {
    activeAgents: number;
    totalAgents: number;
    accountsCount: number;
    vouchersCount: number;
    memoryEntries: number;
    permanentMemories: number;
    auditChainHeight: number;
  };
}

export interface AgentIdentity {
  agentId: string;
  role: string;
  publicKey: string;
  createdAt: string;
  status: 'active' | 'retired' | 'suspended';
  rules: string[];
  capabilities: string[];
}

export interface MemoryItem {
  id: string;
  scope: string;
  memoryType: string;
  family: string;
  content: any;
  importance: number;
  tags: string[];
  createdAt: string;
  accessCount: number;
  lastAccessedAt: string;
  isPermanent: boolean;
}

export interface SignedMessageItem {
  messageId: string;
  senderId: string;
  recipientId: string;
  timestamp: string;
  payload: any;
  signature: string;
  digest: string;
  previousHash: string;
  hash: string;
  chainIndex: number;
}

export interface AccountItem {
  id: string;
  code: string;
  name: string;
  nameFa: string;
  type: 'asset' | 'liability' | 'equity' | 'revenue' | 'expense';
  category: string;
  balance: number;
  normalBalance: 'debit' | 'credit';
  description?: string;
}

export interface JournalLineItem {
  id: string;
  accountId: string;
  accountName?: string;
  accountCode?: string;
  debit: number;
  credit: number;
  description?: string;
}

export interface JournalVoucherItem {
  id: string;
  voucherNumber: string;
  date: string;
  description: string;
  lines: JournalLineItem[];
  totalDebit: number;
  totalCredit: number;
  status: 'draft' | 'verified' | 'posted' | 'rejected';
  createdByAgent: string;
  ruleMatched?: string;
  hash?: string;
}

export interface RuleItem {
  id: string;
  code: string;
  title: string;
  titleFa: string;
  description: string;
  condition: string;
  ruleType: 'vat' | 'depreciation' | 'payroll_withholding' | 'revenue_recognition' | 'inventory_cogs' | 'custom';
  parameters: Record<string, any>;
  isApproved: boolean;
  proposedByAgent?: string;
  approvalStatus: 'approved' | 'pending_approval' | 'rejected';
  confidenceScore: number;
  version: number;
}

export interface CriticResult {
  passed: boolean;
  score: number;
  disposition: 'auto_release' | 'escalate_to_human' | 'reject';
  layers: {
    layer1_structural: {
      passed: boolean;
      details: string;
      debitCreditBalance: boolean;
    };
    layer2_crossReferential: {
      passed: boolean;
      details: string;
      accountsExist: boolean;
    };
    layer3_historicalStatistical: {
      passed: boolean;
      details: string;
      zScore: number;
      isAnomaly: boolean;
    };
    layer4_confidenceAggregation: {
      score: number;
      routing: 'auto_release' | 'escalate_to_human' | 'reject';
      rationale: string;
    };
  };
}

export interface FinancialReportsData {
  balanceSheet: {
    assets: { items: { name: string; amount: number; code: string }[]; total: number };
    liabilities: { items: { name: string; amount: number; code: string }[]; total: number };
    equity: { items: { name: string; amount: number; code: string }[]; total: number };
    isBalanced: boolean;
    date: string;
  };
  incomeStatement: {
    revenue: { items: { name: string; amount: number }[]; total: number };
    costOfGoodsSold: { items: { name: string; amount: number }[]; total: number };
    grossProfit: number;
    operatingExpenses: { items: { name: string; amount: number }[]; total: number };
    operatingIncome: number;
    taxExpense: number;
    netIncome: number;
    period: string;
  };
  cashFlow: {
    operatingActivities: { description: string; amount: number }[];
    investingActivities: { description: string; amount: number }[];
    financingActivities: { description: string; amount: number }[];
    netCashChange: number;
    beginningCash: number;
    endingCash: number;
  };
  trialBalance: {
    accounts: { code: string; name: string; type: string; debit: number; credit: number }[];
    totalDebit: number;
    totalCredit: number;
    isBalanced: boolean;
  };
  forecast: {
    months: string[];
    revenue: number[];
    expenses: number[];
    netIncome: number[];
    cashRunwayMonths: number;
  };
  aiAnalysis?: {
    summary: string;
    keyIssues: string[];
    recommendations: string[];
    confidence: number;
  };
}

export interface ArchitectureNodeItem {
  id: string;
  label: string;
  labelFa: string;
  group: string;
  role: string;
  docChapter: string;
  sourceCodeRef: string;
  description: string;
  isDeterministic: boolean;
}

export interface ArchitectureChapterItem {
  id: string;
  file: string;
  title: string;
  titleFa: string;
}

export interface DiagnosticsReport {
  isHealthy: boolean;
  score: number;
  checks: Array<{
    name: string;
    status: 'passed' | 'warning' | 'failed';
    details: string;
  }>;
}

export interface SnapshotItem {
  id: string;
  timestamp: string;
  accountsCount: number;
  vouchersCount: number;
  memoriesCount: number;
  chainLength: number;
  rulesCount: number;
  totalLedgerBalance: number;
  hash: string;
}

export interface GraphMLNode {
  id: string;
  label: string;
  cluster: string;
  description: string;
  invariant?: string;
  mappedCode?: string;
}

export interface KnowledgeArticle {
  id: string;
  category: 'standard' | 'tax_law' | 'vat_law' | 'ifrs';
  code: string;
  titleFa: string;
  titleEn: string;
  summaryFa: string;
  keyPoints: string[];
}
