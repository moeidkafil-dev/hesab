import React, { useState } from 'react';
import {
  Lock,
  ShieldCheck,
  Link,
  Key,
  CheckCircle2,
  AlertTriangle,
  Send,
  Hash,
  Fingerprint,
} from 'lucide-react';
import { SignedMessageItem } from '../types.js';
import { sendSignedMessage } from '../api.js';

interface CryptoAuditViewProps {
  auditChain: SignedMessageItem[];
  integrity: any;
  lang: 'fa' | 'en';
  onRefresh: () => void;
}

export const CryptoAuditView: React.FC<CryptoAuditViewProps> = ({
  auditChain,
  integrity,
  lang,
  onRefresh,
}) => {
  const isFa = lang === 'fa';
  const [sender, setSender] = useState('accounting_domain_engine');
  const [recipient, setRecipient] = useState('db_manager_agent');
  const [payloadText, setPayloadText] = useState('{"action":"verify_balance","currency":"IRR"}');
  const [sending, setSending] = useState(false);
  const [tamperedIndex, setTamperedIndex] = useState<number | null>(null);

  const handleSendCustomMessage = async () => {
    if (!payloadText) return;
    setSending(true);
    try {
      let parsed = payloadText;
      try {
        parsed = JSON.parse(payloadText);
      } catch {}
      await sendSignedMessage(sender, recipient, parsed);
      onRefresh();
    } catch (err) {
      console.error(err);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-3 bg-indigo-500/10 text-indigo-400 rounded-xl">
            <Lock className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">
              {isFa ? 'زنجیره هش هابر-استورنتا و پیام‌های امن Ed25519 (Haber-Stornetta Audit Chain - n10)' : 'Cryptographic Haber-Stornetta Audit Chain (n10)'}
            </h2>
            <p className="text-xs text-slate-400">
              {isFa
                ? 'ارتباطات بین عاملی رمزنگاری شده با پایپ‌لاین ۴ مرحله‌ای (Receiver -> Compiler -> Sign-Reader -> Read) و زنجیره هش غیرقابل دستکاری'
                : 'Tamper-evident audit chain with 4-stage pipeline and Ed25519 digital message signing (§7.2)'}
            </p>
          </div>
        </div>
      </div>

      {/* Integrity Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-between shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-emerald-500/20 text-emerald-400 rounded-xl">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs text-slate-400 font-medium">
              {isFa ? 'وضعیت صحت ساختار زنجیره هش' : 'Audit Chain Cryptographic Integrity'}
            </div>
            <div className="text-sm font-bold text-emerald-400">
              {integrity?.isValid
                ? isFa
                  ? 'کلیه بلوک‌ها و پیوندهای هش معتبر و بدون دستکاری هستند'
                  : 'All Hash Links & Ed25519 Signatures Verified Intact'
                : isFa
                ? 'هشدار: پیوند زنجیره هش دچار شکستگی است!'
                : 'Warning: Hash chain broken!'}
            </div>
          </div>
        </div>
        <div className="text-xs font-mono text-slate-400">
          Height: {auditChain.length} Blocks
        </div>
      </div>

      {/* Send Signed Message Box */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Key className="w-4 h-4 text-indigo-400" />
          <span>{isFa ? 'ارسال پیام امضا شده در کانال رمزنگاری (Signed Message Dispatcher)' : 'Dispatch Ed25519 Signed Message'}</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">{isFa ? 'عامل فرستنده (Sender):' : 'Sender Agent:'}</label>
            <select
              value={sender}
              onChange={(e) => setSender(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-100 font-mono"
            >
              <option value="ceo">ceo (supervisory_kernel)</option>
              <option value="accounting_domain_engine">accounting_domain_engine (rule_execution)</option>
              <option value="final_checker_agent">final_checker_agent (critic_qa)</option>
              <option value="db_manager_agent">db_manager_agent (authoritative_db_writer)</option>
              <option value="report_maker">report_maker (reporting_analytics)</option>
              <option value="study_knowledge_agent">study_knowledge_agent (knowledge_research)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">{isFa ? 'عامل گیرنده (Recipient):' : 'Recipient Agent:'}</label>
            <select
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-100 font-mono"
            >
              <option value="db_manager_agent">db_manager_agent (authoritative_db_writer)</option>
              <option value="ceo">ceo (supervisory_kernel)</option>
              <option value="accounting_domain_engine">accounting_domain_engine (rule_execution)</option>
              <option value="final_checker_agent">final_checker_agent (critic_qa)</option>
            </select>
          </div>

          <div className="sm:col-span-2">
            <label className="block text-xs font-medium text-slate-300 mb-1">{isFa ? 'داده‌های پیام (Payload JSON):' : 'Payload:'}</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={payloadText}
                onChange={(e) => setPayloadText(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-100 font-mono"
              />
              <button
                id="send-crypto-msg-btn"
                onClick={handleSendCustomMessage}
                disabled={sending}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shrink-0 shadow-lg shadow-indigo-600/20 transition flex items-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{sending ? '...' : isFa ? 'امضا و ارسال' : 'Sign & Send'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Visual Hash-Chain Blocks */}
      <div className="space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Link className="w-4 h-4 text-emerald-400" />
          <span>{isFa ? 'بلوک‌های متصل زنجیره هش ممیزی' : 'Haber-Stornetta Linked Audit Blocks'}</span>
        </h3>

        <div className="space-y-4">
          {auditChain.map((msg, idx) => (
            <div
              key={msg.messageId}
              id={`block-${msg.chainIndex}`}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl relative"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 mb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 px-2.5 py-1 rounded-lg">
                    Block #{msg.chainIndex}
                  </span>
                  <span className="text-xs font-mono text-slate-400">{msg.messageId}</span>
                  <span className="text-xs text-slate-500">{msg.timestamp}</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-mono">
                  <span className="text-teal-400 font-bold">{msg.senderId}</span>
                  <span className="text-slate-500">➜</span>
                  <span className="text-indigo-400 font-bold">{msg.recipientId}</span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 space-y-1.5 overflow-x-auto">
                  <div className="text-[11px] text-slate-400 font-bold flex items-center gap-1">
                    <Hash className="w-3 h-3 text-slate-500" />
                    <span>Previous Block Hash:</span>
                  </div>
                  <div className="text-[11px] text-slate-500 truncate">{msg.previousHash}</div>

                  <div className="text-[11px] text-emerald-400 font-bold flex items-center gap-1 pt-1 border-t border-slate-900">
                    <Fingerprint className="w-3 h-3 text-emerald-400" />
                    <span>Current Linked Hash:</span>
                  </div>
                  <div className="text-[11px] text-emerald-400 font-bold truncate">{msg.hash}</div>
                </div>

                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 space-y-1.5 overflow-x-auto">
                  <div className="text-[11px] text-slate-400 font-bold">Payload:</div>
                  <div className="text-[11px] text-slate-300 truncate">
                    {typeof msg.payload === 'string' ? msg.payload : JSON.stringify(msg.payload)}
                  </div>

                  <div className="text-[11px] text-indigo-400 font-bold pt-1 border-t border-slate-900">
                    Ed25519 Digital Signature:
                  </div>
                  <div className="text-[10px] text-indigo-300 truncate">{msg.signature}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
