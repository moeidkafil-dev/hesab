import React, { useState } from 'react';
import {
  Send,
  Sparkles,
  Bot,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  Database,
  Lock,
  Layers,
  Activity,
  Terminal,
  Clock,
  Play,
  RotateCcw,
} from 'lucide-react';
import { executeCEOPrompt } from '../api.js';
import { AgentIdentity, SystemStatus } from '../types.js';

interface CommandCenterProps {
  status: SystemStatus | null;
  agents: AgentIdentity[];
  lang: 'fa' | 'en';
  onVoucherCreated: () => void;
}

export const CommandCenter: React.FC<CommandCenterProps> = ({
  status,
  agents,
  lang,
  onVoucherCreated,
}) => {
  const isFa = lang === 'fa';
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [executionResult, setExecutionResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const samplePrompts = [
    {
      labelFa: 'ثبت فروش نقدی ۲۵,۰۰۰,۰۰۰ ریال به همراه ۱۰٪ ارزش افزوده',
      labelEn: 'Record cash sales of 25,000,000 with 10% VAT',
      text: 'ثبت فروش نقدی کالا به مبلغ ۲۵,۰۰۰,۰۰۰ ریال به همراه ۱۰٪ ارزش افزوده',
    },
    {
      labelFa: 'ثبت سند حقوق و دستمزد پرسنل به مبلغ ۱۸,۰۰۰,۰۰۰ ریال',
      labelEn: 'Post staff payroll expense 18,000,000 with withholding tax',
      text: 'ثبت هزینه حقوق و دستمزد پرسنل به مبلغ ۱۸,۰۰۰,۰۰۰ ریال به کسر مالیات تکلیفی ماده ۱۳۱',
    },
    {
      labelFa: 'ثبت استهلاک مستقیم ماهانه تجهیزات ۳,۰۰۰,۰۰۰ ریال',
      labelEn: 'Record monthly equipment depreciation 3,000,000',
      text: 'ثبت استهلاک مستقیم ماهانه تجهیزات به مبلغ ۳,۰۰۰,۰۰۰ ریال',
    },
    {
      labelFa: 'پرداخت اجاره دفتر مرکزی به مبلغ ۱۲,۰۰۰,۰۰۰ ریال از بانک',
      labelEn: 'Pay office rent 12,000,000 from bank',
      text: 'پرداخت هزینه اجاره دفتر مرکزی به مبلغ ۱۲,۰۰۰,۰۰۰ ریال از محل موجودی نقد و بانک',
    },
    {
      labelFa: 'تحلیل وضعیت مالی و ترازنامه شرکت',
      labelEn: 'Analyze company financial health and balance sheet',
      text: 'تحلیل صورت‌های مالی، حاشیه سود و ارائه راهکارهای بهبود جریان نقدینگی',
    },
  ];

  const handleRun = async (textToRun?: string) => {
    const query = textToRun || prompt;
    if (!query.trim()) return;

    setLoading(true);
    setError(null);
    try {
      const res = await executeCEOPrompt(query);
      setExecutionResult(res);
      if (res.result?.voucher) {
        onVoucherCreated();
      }
    } catch (err: any) {
      setError(err.message || 'Error processing request');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner / Invariant Guarantee Box */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex items-center gap-3">
          <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-lg">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs text-slate-400 font-medium">
              {isFa ? 'هسته نظارتی CEO' : 'Supervisory Kernel'}
            </div>
            <div className="text-sm font-bold text-slate-100">
              {isFa ? 'کنترل چرخه حیات (n5)' : 'Full Lifecycle Control'}
            </div>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex items-center gap-3">
          <div className="p-3 bg-teal-500/10 text-teal-400 rounded-lg">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs text-slate-400 font-medium">
              {isFa ? 'انحصار نوشتن در دیتابیس' : 'DB Write Authority'}
            </div>
            <div className="text-sm font-bold text-slate-100">
              {isFa ? 'عامل DB Manager (n6)' : 'Exclusive DB Writer'}
            </div>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex items-center gap-3">
          <div className="p-3 bg-indigo-500/10 text-indigo-400 rounded-lg">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs text-slate-400 font-medium">
              {isFa ? 'امنیت پیام‌ها' : 'Signed Messaging'}
            </div>
            <div className="text-sm font-bold text-slate-100">
              {isFa ? 'امضای Ed25519 و هش هابر (n10)' : 'Ed25519 & Haber Chain'}
            </div>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex items-center gap-3">
          <div className="p-3 bg-amber-500/10 text-amber-400 rounded-lg">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs text-slate-400 font-medium">
              {isFa ? 'مسیر دوگانه حسابداری' : 'Dual-Path Engine'}
            </div>
            <div className="text-sm font-bold text-slate-100">
              {isFa ? 'قطعی + پژوهش LLM' : 'Deterministic + Fallback'}
            </div>
          </div>
        </div>
      </div>

      {/* Main Interactive Prompt Console */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute -top-24 -right-24 w-72 h-72 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Terminal className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                {isFa ? 'ورودی دستورات به هسته نظارتی مدیر ارشد (CEO Kernel)' : 'CEO Supervisory Prompt Terminal'}
              </h2>
              <p className="text-xs text-slate-400">
                {isFa
                  ? 'پرامپت مالی یا دستور سیستم خود را وارد کنید تا از طریق حلقه چک‌پوینت و عامل‌های تخصصی پردازش شود'
                  : 'Submit financial transactions, reporting requests, or rule queries through the bounded-retry checkpoint loop'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-emerald-400 bg-emerald-950/40 border border-emerald-500/20 px-3 py-1 rounded-full">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isFa ? 'آماده دریافت' : 'Swarm Ready'}</span>
          </div>
        </div>

        {/* Textarea Input */}
        <div className="relative mb-4">
          <textarea
            id="ceo-prompt-input"
            rows={3}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={
              isFa
                ? 'دستور حسابداری یا درخواست مالی خود را وارد کنید... (مثلاً: ثبت فروش نقدی کالا به مبلغ ۱۵,۰۰۰,۰۰۰ ریال)'
                : 'Enter accounting transaction or query (e.g. Record 15,000,000 cash sale with 10% VAT)...'
            }
            className="w-full bg-slate-950/80 border border-slate-700/80 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-xl p-4 text-sm text-slate-100 placeholder-slate-500 transition resize-none"
          />
          <div className="absolute bottom-3 left-3 flex items-center gap-2">
            <button
              id="execute-prompt-btn"
              onClick={() => handleRun()}
              disabled={loading || !prompt.trim()}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-medium text-xs shadow-lg shadow-emerald-500/20 disabled:opacity-50 disabled:cursor-not-allowed transition"
            >
              {loading ? (
                <>
                  <RotateCcw className="w-3.5 h-3.5 animate-spin" />
                  <span>{isFa ? 'در حال ارکستراسیون...' : 'Orchestrating...'}</span>
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  <span>{isFa ? 'اجرا در سوارم' : 'Execute in Swarm'}</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Quick Sample Prompts */}
        <div>
          <div className="text-xs text-slate-400 mb-2 font-medium">
            {isFa ? 'دستورات نمونه حسابداری:' : 'Sample Pre-Configured Workflows:'}
          </div>
          <div className="flex flex-wrap gap-2">
            {samplePrompts.map((s, idx) => (
              <button
                key={idx}
                id={`sample-prompt-${idx}`}
                onClick={() => {
                  setPrompt(s.text);
                  handleRun(s.text);
                }}
                className="text-xs px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-slate-700/60 hover:border-slate-600 flex items-center gap-1.5 transition text-left"
              >
                <Play className="w-3 h-3 text-emerald-400" />
                <span>{isFa ? s.labelFa : s.labelEn}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Error Display */}
      {error && (
        <div className="bg-rose-950/40 border border-rose-500/50 rounded-xl p-4 text-rose-300 text-xs flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 shrink-0 text-rose-400" />
          <div>
            <div className="font-bold">{isFa ? 'خطا در اجرای فرآیند' : 'Execution Pipeline Error'}</div>
            <div>{error}</div>
          </div>
        </div>
      )}

      {/* Pipeline Checkpoint Trace Visualizer */}
      {executionResult?.stages && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Layers className="w-5 h-5 text-teal-400" />
              <h3 className="text-sm font-bold text-white">
                {isFa ? 'ردیابی مراحل حلقه چک‌پوینت CEO (Checkpoint Loop Stages)' : 'CEO Checkpoint Loop Execution Trace'}
              </h3>
            </div>
            <span className="text-xs px-2.5 py-1 rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono">
              Intent: {executionResult.intent}
            </span>
          </div>

          {/* Stepper Timeline */}
          <div className="space-y-3">
            {executionResult.stages.map((stage: any, idx: number) => (
              <div
                key={idx}
                className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3.5 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                    {idx + 1}
                  </div>
                  <div>
                    <div className="font-semibold text-slate-200">{stage.stageName}</div>
                    <div className="text-slate-400 flex items-center gap-2 mt-0.5">
                      <Bot className="w-3 h-3 text-teal-400" />
                      <span>{stage.agent}</span>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800 text-slate-300 font-mono text-[11px] max-w-xl overflow-x-auto">
                  {typeof stage.details === 'string' ? stage.details : JSON.stringify(stage.details)}
                </div>

                <div className="flex items-center gap-1.5 text-emerald-400 shrink-0">
                  <CheckCircle2 className="w-4 h-4" />
                  <span className="text-[11px]">{isFa ? 'موفق' : 'Passed'}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Outcome Summary */}
          {executionResult.result?.voucher && (
            <div className="mt-4 p-4 bg-emerald-950/30 border border-emerald-500/30 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <div className="font-bold text-emerald-300 text-sm flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isFa ? 'سند حسابداری با موفقیت صادر و در دفتر کل ثبت شد' : 'Journal Voucher Posted Successfully'}</span>
                </div>
                <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                  {executionResult.result.voucher.voucherNumber}
                </span>
              </div>
              <p className="text-xs text-slate-300 mb-3">{executionResult.result.voucher.description}</p>
              
              {/* Lines table */}
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-slate-200">
                  <thead>
                    <tr className="border-b border-emerald-500/20 text-slate-400 text-right">
                      <th className="pb-1">{isFa ? 'کد حساب' : 'Code'}</th>
                      <th className="pb-1">{isFa ? 'عنوان حساب' : 'Account'}</th>
                      <th className="pb-1 text-left">{isFa ? 'بدهکار (ریال)' : 'Debit'}</th>
                      <th className="pb-1 text-left">{isFa ? 'بستانکار (ریال)' : 'Credit'}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {executionResult.result.voucher.lines?.map((line: any, lidx: number) => (
                      <tr key={lidx} className="border-b border-slate-800/60">
                        <td className="py-1.5 font-mono text-teal-400">{line.accountCode}</td>
                        <td className="py-1.5">{line.accountName}</td>
                        <td className="py-1.5 text-left font-mono text-emerald-400">
                          {line.debit > 0 ? line.debit.toLocaleString() : '-'}
                        </td>
                        <td className="py-1.5 text-left font-mono text-indigo-400">
                          {line.credit > 0 ? line.credit.toLocaleString() : '-'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* AI Response Output if available */}
          {executionResult.result?.response && (
            <div className="mt-4 p-4 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 leading-relaxed whitespace-pre-line">
              <div className="font-bold text-teal-400 mb-1 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>{isFa ? 'پاسخ هوشمند هسته نظارتی مدیر ارشد:' : 'CEO Executive Response:'}</span>
              </div>
              {executionResult.result.response}
            </div>
          )}
        </div>
      )}

      {/* Active Agent Swarm Grid */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Bot className="w-5 h-5 text-emerald-400" />
            <h3 className="text-sm font-bold text-white">
              {isFa ? 'عامل‌های خودمختار سوارم سیستم حسابدار' : 'Autonomous Hesabdar Agent Swarm'}
            </h3>
          </div>
          <span className="text-xs text-slate-400">
            {isFa ? `${agents.length} عامل ثبت‌شده در رجیستری هویت` : `${agents.length} Registered Identities`}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {agents.map((ag) => (
            <div
              key={ag.agentId}
              id={`agent-card-${ag.agentId}`}
              className="bg-slate-950/70 border border-slate-800 hover:border-slate-700 rounded-xl p-4 transition flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold text-xs text-slate-100 font-mono">{ag.agentId}</span>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                      ag.status === 'active'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {ag.status}
                  </span>
                </div>
                <div className="text-xs text-slate-400 mb-2 font-medium">Role: {ag.role}</div>
                <div className="flex flex-wrap gap-1 mb-2">
                  {ag.capabilities?.slice(0, 3).map((cap, cidx) => (
                    <span key={cidx} className="text-[10px] bg-slate-900 border border-slate-800 px-1.5 py-0.5 rounded text-slate-300">
                      {cap}
                    </span>
                  ))}
                </div>
              </div>
              <div className="text-[10px] text-slate-500 font-mono truncate mt-2 pt-2 border-t border-slate-800">
                Key: {ag.publicKey ? ag.publicKey.slice(27, 47) + '...' : 'Ed25519 Active'}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
