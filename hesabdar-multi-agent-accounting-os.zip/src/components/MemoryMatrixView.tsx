import React, { useState } from 'react';
import {
  Brain,
  Search,
  Filter,
  Plus,
  Moon,
  Sparkles,
  ShieldCheck,
  Tag,
  Clock,
  Zap,
} from 'lucide-react';
import { MemoryItem } from '../types.js';
import { runMemoryMaintenance, writeMemory } from '../api.js';

interface MemoryMatrixViewProps {
  memories: MemoryItem[];
  stats: any;
  lang: 'fa' | 'en';
  onRefresh: () => void;
}

export const MemoryMatrixView: React.FC<MemoryMatrixViewProps> = ({
  memories,
  stats,
  lang,
  onRefresh,
}) => {
  const isFa = lang === 'fa';
  const [search, setSearch] = useState('');
  const [selectedFamily, setSelectedFamily] = useState<string>('all');
  const [showWriteModal, setShowWriteModal] = useState(false);
  const [maintenanceReport, setMaintenanceReport] = useState<any>(null);
  const [cleaning, setCleaning] = useState(false);

  // New Memory Form
  const [scope, setScope] = useState('user');
  const [memType, setMemType] = useState('short_term_scratchpad');
  const [content, setContent] = useState('');
  const [tagsStr, setTagsStr] = useState('accounting, notes');
  const [importance, setImportance] = useState(5);

  const families = [
    { id: 'all', labelFa: 'همه خانواده‌ها', labelEn: 'All Families' },
    { id: 'working', labelFa: 'حافظه کاری (Working)', labelEn: 'Working' },
    { id: 'episodic', labelFa: 'رویدادی (Episodic)', labelEn: 'Episodic' },
    { id: 'semantic', labelFa: 'معنایی (Semantic)', labelEn: 'Semantic' },
    { id: 'procedural', labelFa: 'روشی (Procedural)', labelEn: 'Procedural' },
    { id: 'reflection', labelFa: 'بازتاب و تجربه (Reflection)', labelEn: 'Reflection' },
    { id: 'financial_audit', labelFa: 'مالی و ممیزی (غیرقابل حذف)', labelEn: 'Financial/Audit (Immutable)' },
    { id: 'system_config', labelFa: 'سیستم و کانفیگ (System)', labelEn: 'System/Config' },
  ];

  const filteredMemories = memories.filter((m) => {
    const matchesFamily = selectedFamily === 'all' || m.family === selectedFamily;
    const matchesSearch =
      search === '' ||
      m.memoryType.toLowerCase().includes(search.toLowerCase()) ||
      JSON.stringify(m.content).toLowerCase().includes(search.toLowerCase()) ||
      m.tags.some((t) => t.toLowerCase().includes(search.toLowerCase()));
    return matchesFamily && matchesSearch;
  });

  const handleMaintenance = async () => {
    setCleaning(true);
    try {
      const res = await runMemoryMaintenance();
      setMaintenanceReport(res);
      onRefresh();
    } catch (err) {
      console.error(err);
    } finally {
      setCleaning(false);
    }
  };

  const handleWriteMemory = async () => {
    if (!content) return;
    try {
      const tags = tagsStr.split(',').map((t) => t.trim()).filter(Boolean);
      await writeMemory(scope, memType, content, tags, importance);
      setShowWriteModal(false);
      setContent('');
      onRefresh();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-purple-500/10 text-purple-400 rounded-xl">
              <Brain className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                {isFa ? 'ماتریس ۲۷ نوع حافظه تخصصی (27 Memory Taxonomy Matrix - n13)' : '27-Type Memory Taxonomy Matrix (n13)'}
              </h2>
              <p className="text-xs text-slate-400">
                {isFa
                  ? 'تفکیک ۷ خانواده حافظه با تضمین تغییرناپذیری تراکنش‌های مالی، سوابق ممیزی و رویدادهای شکست طبق بند ۳.۵'
                  : '7 Memory Families with invariant protection for financial transactions, audit chains, and failures (§3.5)'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="sleep-mode-maintenance-btn"
              onClick={handleMaintenance}
              disabled={cleaning}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold shadow-lg shadow-purple-600/20 disabled:opacity-50 transition"
            >
              <Moon className="w-3.5 h-3.5" />
              <span>{cleaning ? (isFa ? 'در حال پاکسازی...' : 'Running...') : isFa ? 'رفت و روب حالت خواب (Sleep Mode)' : 'Sleep-Mode Sweep'}</span>
            </button>

            <button
              id="write-memory-btn"
              onClick={() => setShowWriteModal(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isFa ? 'ثبت حافظه جدید' : 'Write Memory'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Maintenance Sweep Result Alert */}
      {maintenanceReport && (
        <div className="bg-purple-950/40 border border-purple-500/30 rounded-xl p-4 text-xs text-purple-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span>
              {isFa
                ? `عملیات نگهداری حالت خواب انجام شد: ${maintenanceReport.scanned} آیتم اسکن، ${maintenanceReport.pruned} رکورد موقت حذف، ${maintenanceReport.retained} آیتم دائمی حفظ گردید.`
                : `Sleep Mode Sweep: Scanned ${maintenanceReport.scanned}, pruned ${maintenanceReport.pruned} transient scratchpads, retained ${maintenanceReport.retained} permanent items.`}
            </span>
          </div>
          <button onClick={() => setMaintenanceReport(null)} className="text-purple-400 hover:text-purple-200">
            ✕
          </button>
        </div>
      )}

      {/* Search & Family Filter */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={isFa ? 'جستجو در انواع حافظه، تگ‌ها و محتوا...' : 'Search memory types, tags, content...'}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-9 pl-3 py-2 text-xs text-slate-200 placeholder-slate-500"
          />
        </div>

        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-1">
          {families.map((fam) => (
            <button
              key={fam.id}
              onClick={() => setSelectedFamily(fam.id)}
              className={`px-3 py-1.5 rounded-lg text-xs whitespace-nowrap transition ${
                selectedFamily === fam.id
                  ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {isFa ? fam.labelFa : fam.labelEn}
            </button>
          ))}
        </div>
      </div>

      {/* Memory Items List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredMemories.map((m) => (
          <div
            key={m.id}
            id={`mem-card-${m.id}`}
            className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between hover:border-purple-500/40 transition space-y-3"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono font-bold text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded">
                  {m.memoryType}
                </span>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                    m.isPermanent
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {m.isPermanent ? (isFa ? 'تغییرناپذیر §3.5' : 'Immutable §3.5') : m.family}
                </span>
              </div>

              <div className="text-xs text-slate-200 font-mono bg-slate-950 p-2.5 rounded-lg border border-slate-800/80 max-h-28 overflow-y-auto whitespace-pre-wrap">
                {typeof m.content === 'string' ? m.content : JSON.stringify(m.content, null, 2)}
              </div>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-800">
              <div className="flex flex-wrap gap-1">
                {m.tags.map((tag, tidx) => (
                  <span key={tidx} className="text-[10px] text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded flex items-center gap-1">
                    <Tag className="w-2.5 h-2.5" />
                    {tag}
                  </span>
                ))}
              </div>
              <div className="flex items-center justify-between text-[10px] text-slate-500">
                <span>Scope: {m.scope}</span>
                <span>Importance: {m.importance}/10</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal: Write Memory */}
      {showWriteModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Brain className="w-5 h-5 text-purple-400" />
                <span>{isFa ? 'ثبت رکورد در ماتریس حافظه' : 'Write Memory Item'}</span>
              </h3>
              <button onClick={() => setShowWriteModal(false)} className="text-slate-400 hover:text-slate-200">
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">{isFa ? 'حوزه دسترسی (Scope):' : 'Scope:'}</label>
                <input
                  type="text"
                  value={scope}
                  onChange={(e) => setScope(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100 font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-300 mb-1">{isFa ? 'نوع حافظه (Memory Type):' : 'Memory Type:'}</label>
                <select
                  value={memType}
                  onChange={(e) => setMemType(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100 font-mono"
                >
                  <option value="short_term_scratchpad">short_term_scratchpad (working)</option>
                  <option value="daily_activity_log">daily_activity_log (episodic)</option>
                  <option value="accounting_rule_base">accounting_rule_base (semantic)</option>
                  <option value="execution_strategy">execution_strategy (procedural)</option>
                  <option value="post_mortem_reflection">post_mortem_reflection (reflection)</option>
                  <option value="financial_transaction">financial_transaction (financial - immutable)</option>
                  <option value="failure">failure (system - immutable)</option>
                </select>
              </div>
              <div>
                <label className="block text-slate-300 mb-1">{isFa ? 'محتوای حافظه:' : 'Content:'}</label>
                <textarea
                  rows={3}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder={isFa ? 'محتوا یا داده‌های JSON...' : 'Memory content or JSON...'}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100"
                />
              </div>
              <div>
                <label className="block text-slate-300 mb-1">{isFa ? 'برچسب‌ها (با کاما):' : 'Tags (comma separated):'}</label>
                <input
                  type="text"
                  value={tagsStr}
                  onChange={(e) => setTagsStr(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100"
                />
              </div>
              <div>
                <label className="block text-slate-300 mb-1">{isFa ? 'میزان اهمیت (۱ تا ۱۰):' : 'Importance (1-10):'}</label>
                <input
                  type="number"
                  min={1}
                  max={10}
                  value={importance}
                  onChange={(e) => setImportance(Number(e.target.value) || 5)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100 font-mono"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
              <button onClick={() => setShowWriteModal(false)} className="px-3 py-1.5 rounded-lg text-xs text-slate-400">
                {isFa ? 'انصراف' : 'Cancel'}
              </button>
              <button
                onClick={handleWriteMemory}
                className="px-4 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold transition"
              >
                {isFa ? 'ذخیره حافظه' : 'Save'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
