import React from 'react';
import {
  Activity,
  ShieldCheck,
  Cpu,
  Database,
  FileSpreadsheet,
  Brain,
  Scale,
  Lock,
  Wrench,
  Network,
  BookOpen,
  RefreshCw,
  Camera,
  Layers,
} from 'lucide-react';
import { SystemStatus } from '../types.js';

interface NavbarProps {
  status: SystemStatus | null;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  lang: 'fa' | 'en';
  setLang: (lang: 'fa' | 'en') => void;
  onSnapshot: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  status,
  activeTab,
  setActiveTab,
  lang,
  setLang,
  onSnapshot,
}) => {
  const isFa = lang === 'fa';

  const navTabs = [
    { id: 'command', labelEn: 'CEO Swarm', labelFa: 'مرکز فرماندهی CEO', icon: Cpu },
    { id: 'ledger', labelEn: 'Double-Entry Ledger', labelFa: 'دفتر کل و اسناد', icon: FileSpreadsheet },
    { id: 'reports', labelEn: 'Financial Reports', labelFa: 'صورت‌های مالی و AI', icon: Activity },
    { id: 'domain', labelEn: 'Domain Engine & Rules', labelFa: 'موتور قوانین و مالیات', icon: Scale },
    { id: 'critic', labelEn: 'QA Critic Hub', labelFa: 'کنترل کیفیت و منتقد', icon: ShieldCheck },
    { id: 'memory', labelEn: '27 Memory Matrix', labelFa: 'ماتریس ۲۷ حافظه', icon: Brain },
    { id: 'crypto', labelEn: 'Cryptographic Audit', labelFa: 'زنجیره هش Ed25519', icon: Lock },
    { id: 'tools', labelEn: 'Sandbox & Tools', labelFa: 'محیط ایزوله و ابزارها', icon: Wrench },
    { id: 'graphml', labelEn: '350-Node Map', labelFa: 'نقشه ۳۵۰ نود سیستم', icon: Network },
    { id: 'knowledge', labelEn: 'Standards & Tax', labelFa: 'استانداردها و قوانین', icon: BookOpen },
    { id: 'resilience', labelEn: 'Self-Healing & Backup', labelFa: 'خودترمیمی و پایداری', icon: RefreshCw },
  ];

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 sticky top-0 z-50">
      {/* Top Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-500/20 text-slate-950 font-black text-xl">
              H
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg text-white tracking-tight">
                  {isFa ? 'سیستم عامل حسابدار چندعاملی' : 'Hesabdar Multi-Agent Accounting OS'}
                </span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono">
                  v2.0 PRO
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {isFa
                  ? 'معماری نظارتی CEO، موتور ۲۷ حافظه، زنجیره هش هابر-استورنتا و تراز دوبل'
                  : 'CEO Supervisory Kernel, 27 Memory Matrix & Double-Entry Ledger'}
              </p>
            </div>
          </div>

          {/* System Invariant Status Badges */}
          <div className="hidden lg:flex items-center gap-3 text-xs">
            <div
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border ${
                status?.invariants?.doubleEntryBalanced
                  ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300'
                  : 'bg-rose-950/60 border-rose-500/40 text-rose-300'
              }`}
            >
              <div
                className={`w-2 h-2 rounded-full ${
                  status?.invariants?.doubleEntryBalanced ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'
                }`}
              />
              <span>{isFa ? 'تراز دوبل: متوازن' : 'Double-Entry: Balanced'}</span>
            </div>

            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-950/60 border border-indigo-500/40 text-indigo-300">
              <Lock className="w-3.5 h-3.5" />
              <span>
                {isFa ? `زنجیره هش: ${status?.counts?.auditChainHeight || 0} بلوک` : `Audit Chain: ${status?.counts?.auditChainHeight || 0}`}
              </span>
            </div>

            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-teal-950/60 border border-teal-500/40 text-teal-300">
              <Database className="w-3.5 h-3.5" />
              <span>
                {isFa ? `عامل‌های فعال: ${status?.counts?.activeAgents || 8}` : `Agents: ${status?.counts?.activeAgents || 8}`}
              </span>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-2">
            <button
              id="snapshot-btn"
              onClick={onSnapshot}
              title={isFa ? 'ایجاد اسنپ‌شات وضعیت' : 'Create Snapshot'}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition"
            >
              <Camera className="w-3.5 h-3.5 text-teal-400" />
              <span className="hidden sm:inline">{isFa ? 'اسنپ‌شات' : 'Snapshot'}</span>
            </button>

            <button
              id="lang-toggle-btn"
              onClick={() => setLang(lang === 'fa' ? 'en' : 'fa')}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs font-semibold uppercase transition"
            >
              {lang === 'fa' ? 'English' : 'فارسی'}
            </button>
          </div>
        </div>

        {/* Navigation Tabs Bar */}
        <nav className="flex items-center gap-1 overflow-x-auto py-2 border-t border-slate-800/80 no-scrollbar">
          {navTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`tab-${tab.id}`}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-400' : 'text-slate-400'}`} />
                <span>{isFa ? tab.labelFa : tab.labelEn}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
