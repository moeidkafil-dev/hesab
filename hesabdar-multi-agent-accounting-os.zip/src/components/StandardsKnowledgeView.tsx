import React, { useState } from 'react';
import {
  BookOpen,
  Search,
  Sparkles,
  ExternalLink,
  Tag,
  CheckCircle2,
  FileText,
} from 'lucide-react';
import { KnowledgeArticle } from '../types.js';
import { searchKnowledge } from '../api.js';

interface StandardsKnowledgeViewProps {
  articles: KnowledgeArticle[];
  lang: 'fa' | 'en';
}

export const StandardsKnowledgeView: React.FC<StandardsKnowledgeViewProps> = ({
  articles,
  lang,
}) => {
  const isFa = lang === 'fa';
  const [query, setQuery] = useState('');
  const [searching, setSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<KnowledgeArticle[]>(articles);
  const [activeArticle, setActiveArticle] = useState<KnowledgeArticle | null>(articles[0] || null);

  const handleSearch = async () => {
    if (!query.trim()) {
      setSearchResults(articles);
      return;
    }
    setSearching(true);
    try {
      const res = await searchKnowledge(query);
      if (res.results) {
        setSearchResults(res.results);
        if (res.results.length > 0) {
          setActiveArticle(res.results[0]);
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSearching(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-3 bg-teal-500/10 text-teal-400 rounded-xl">
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">
              {isFa ? 'پایگاه دانش استانداردهای حسابداری و قوانین مالیاتی (Standards & Tax Knowledge - n3::n5)' : 'Accounting Standards & Tax Law Knowledge Base (n3::n5)'}
            </h2>
            <p className="text-xs text-slate-400">
              {isFa
                ? 'پژوهش استانداردها و قوانین مالیاتی ایران (استانداردهای ۱ تا ۱۶، قوانین مالیات‌های مستقیم و ارزش افزوده)'
                : 'National Accounting Standards & Direct Tax Code research and compliance repository'}
            </p>
          </div>
        </div>
      </div>

      {/* Search Box */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl flex gap-2">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            placeholder={isFa ? 'جستجو در استانداردها (مثلاً: استهلاک دارایی، مالیات عملکرد، ارزش افزوده)...' : 'Search accounting standards (e.g. depreciation, VAT rate)...'}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-9 pl-3 py-2 text-xs text-slate-200"
          />
        </div>
        <button
          onClick={handleSearch}
          disabled={searching}
          className="px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-semibold shrink-0 transition flex items-center gap-1.5"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>{searching ? '...' : isFa ? 'جستجوی هوشمند' : 'AI Search'}</span>
        </button>
      </div>

      {/* Content Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Article List */}
        <div className="lg:col-span-5 space-y-3 max-h-[600px] overflow-y-auto">
          {searchResults.map((art) => (
            <button
              key={art.id}
              onClick={() => setActiveArticle(art)}
              className={`w-full text-right p-4 rounded-xl transition border text-xs flex flex-col justify-between ${
                activeArticle?.id === art.id
                  ? 'bg-teal-950/60 border-teal-500/50 text-white'
                  : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-mono font-bold text-teal-400 bg-teal-500/10 px-2 py-0.5 rounded text-[11px]">
                    {art.standardCode}
                  </span>
                  <span className="text-[10px] text-slate-400 capitalize">{art.category}</span>
                </div>
                <div className="font-bold text-slate-100 mb-1">{art.title}</div>
                <p className="text-slate-400 line-clamp-2 text-[11px]">{art.content}</p>
              </div>

              <div className="flex flex-wrap gap-1 mt-3">
                {art.tags?.map((t, idx) => (
                  <span key={idx} className="text-[10px] bg-slate-950 px-1.5 py-0.5 rounded text-slate-400">
                    #{t}
                  </span>
                ))}
              </div>
            </button>
          ))}
        </div>

        {/* Article Full Detail */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          {activeArticle ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <span className="text-xs font-mono font-bold text-teal-400 bg-teal-500/10 border border-teal-500/20 px-2 py-0.5 rounded">
                    {activeArticle.standardCode}
                  </span>
                  <h3 className="text-base font-bold text-white mt-1.5">{activeArticle.title}</h3>
                </div>
                <span className="text-xs bg-slate-800 text-slate-300 px-3 py-1 rounded-full capitalize">
                  {activeArticle.category}
                </span>
              </div>

              <div className="text-xs text-slate-200 leading-relaxed bg-slate-950 p-4 rounded-xl border border-slate-800 whitespace-pre-line">
                {activeArticle.content}
              </div>

              {activeArticle.keyRules && (
                <div className="p-4 bg-emerald-950/30 border border-emerald-500/30 rounded-xl space-y-2">
                  <div className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{isFa ? 'نکات کلیدی اجرایی در حسابداری:' : 'Key Operational Accounting Rules:'}</span>
                  </div>
                  <ul className="list-disc list-inside text-xs text-slate-300 space-y-1">
                    {activeArticle.keyRules.map((kr, idx) => (
                      <li key={idx}>{kr}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-20 text-slate-500 text-xs">
              {isFa ? 'ماده یا استانداردی را انتخاب کنید' : 'Select a standard to view details'}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
