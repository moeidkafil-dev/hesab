import React, { useState } from 'react';
import {
  RefreshCw,
  ShieldCheck,
  Camera,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Database,
  History,
  Activity,
  Layers,
} from 'lucide-react';
import { DiagnosticsReport, SnapshotItem } from '../types.js';
import { runDiagnostics, runAutoRepair, createSnapshot, restoreSnapshot } from '../api.js';

interface ResilienceViewProps {
  diagnostics: DiagnosticsReport | null;
  snapshots: SnapshotItem[];
  lang: 'fa' | 'en';
  onRefresh: () => void;
}

export const ResilienceView: React.FC<ResilienceViewProps> = ({
  diagnostics,
  snapshots,
  lang,
  onRefresh,
}) => {
  const isFa = lang === 'fa';
  const [runningDiag, setRunningDiag] = useState(false);
  const [runningRepair, setRunningRepair] = useState(false);
  const [creatingSnap, setCreatingSnap] = useState(false);
  const [repairResult, setRepairResult] = useState<any>(null);

  const handleRunDiagnostics = async () => {
    setRunningDiag(true);
    try {
      await runDiagnostics();
      onRefresh();
    } catch (err) {
      console.error(err);
    } finally {
      setRunningDiag(false);
    }
  };

  const handleRunRepair = async () => {
    setRunningRepair(true);
    try {
      const res = await runAutoRepair();
      setRepairResult(res);
      onRefresh();
    } catch (err) {
      console.error(err);
    } finally {
      setRunningRepair(false);
    }
  };

  const handleCreateSnapshot = async () => {
    setCreatingSnap(true);
    try {
      await createSnapshot(isFa ? 'اسنپ‌شات دستی سیستم' : 'Manual System Snapshot');
      onRefresh();
    } catch (err) {
      console.error(err);
    } finally {
      setCreatingSnap(false);
    }
  };

  const handleRestore = async (snapId: string) => {
    if (!window.confirm(isFa ? 'آیا از بازیابی این اسنپ‌شات اطمینان دارید؟' : 'Restore this snapshot?')) return;
    try {
      await restoreSnapshot(snapId);
      onRefresh();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl">
              <RefreshCw className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                {isFa ? 'سیستم خودترمیمی، عیب‌یابی و پایداری (Self-Healing & Resilience - n1, n12, n24)' : 'Self-Healing, Diagnostics & Snapshot Engine'}
              </h2>
              <p className="text-xs text-slate-400">
                {isFa
                  ? 'پایش پیوسته سلامت عامل‌ها، راستی‌آزمایی تراز دوبل، ترمیم خودکار و بازیابی اسنپ‌شات‌ها'
                  : 'Continuous telemetry, auto-rebalancing repair procedures, and state snapshots'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="run-diag-btn"
              onClick={handleRunDiagnostics}
              disabled={runningDiag}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition"
            >
              <Activity className="w-3.5 h-3.5 text-teal-400" />
              <span>{runningDiag ? (isFa ? 'در حال پایش...' : 'Checking...') : isFa ? 'پایش جامع سلامت' : 'Run Diagnostics'}</span>
            </button>

            <button
              id="auto-repair-btn"
              onClick={handleRunRepair}
              disabled={runningRepair}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-lg shadow-emerald-600/20 transition"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>{runningRepair ? (isFa ? 'در حال ترمیم...' : 'Repairing...') : isFa ? 'اجرای خودترمیمی' : 'Auto-Repair Swarm'}</span>
            </button>

            <button
              id="create-snap-btn"
              onClick={handleCreateSnapshot}
              disabled={creatingSnap}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-lg shadow-indigo-600/20 transition"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>{isFa ? 'ثبت اسنپ‌شات' : 'Take Snapshot'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Auto Repair Result Alert */}
      {repairResult && (
        <div className="bg-emerald-950/40 border border-emerald-500/30 rounded-xl p-4 text-xs text-emerald-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>
              {isFa
                ? `عملیات خودترمیمی با موفقیت پایان یافت: ${repairResult.actionsExecuted?.length || 0} اقدام ترمیمی انجام شد.`
                : `Self-Healing executed successfully: ${repairResult.actionsExecuted?.length || 0} procedures completed.`}
            </span>
          </div>
          <button onClick={() => setRepairResult(null)} className="text-emerald-400 hover:text-emerald-200">
            ✕
          </button>
        </div>
      )}

      {/* Diagnostics Score & Checks */}
      {diagnostics && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col justify-between">
            <div>
              <div className="text-xs text-slate-400 font-bold uppercase mb-2">
                {isFa ? 'شاخص سلامت و پایداری سیستم' : 'System Resilience Score'}
              </div>
              <div className="text-4xl font-black text-emerald-400 font-mono mb-2">
                {diagnostics.overallScore}%
              </div>
              <div className="text-xs text-slate-300 font-medium capitalize">
                Status: <strong className="text-emerald-400">{diagnostics.status}</strong>
              </div>
            </div>
            <div className="text-[11px] text-slate-500 font-mono pt-4 border-t border-slate-800 mt-4">
              Last Diagnostic: {diagnostics.timestamp}
            </div>
          </div>

          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-3">
            <h3 className="text-sm font-bold text-white mb-2">
              {isFa ? 'راستی‌آزمایی اینواریانت‌های معماری:' : 'Architectural Invariant Audits:'}
            </h3>

            <div className="space-y-2.5">
              {diagnostics.checks?.map((chk: any, idx: number) => (
                <div
                  key={idx}
                  className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-xl flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-3">
                    {chk.passed ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                    )}
                    <div>
                      <div className="font-bold text-slate-200">{chk.component}</div>
                      <div className="text-[11px] text-slate-400">{chk.details}</div>
                    </div>
                  </div>

                  <span
                    className={`px-2 py-0.5 rounded font-mono font-bold text-[10px] ${
                      chk.passed
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                    }`}
                  >
                    {chk.passed ? 'PASSED' : 'CHECK'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Snapshots & State Rollback History */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <History className="w-4 h-4 text-indigo-400" />
            <span>{isFa ? 'سوابق اسنپ‌شات‌ها و نقاط بازیابی (Snapshots & State Recovery)' : 'System State Snapshots & Rollback'}</span>
          </h3>
          <span className="text-xs text-slate-400">{snapshots.length} Snapshots Available</span>
        </div>

        <div className="space-y-3">
          {snapshots.map((snap) => (
            <div
              key={snap.id}
              id={`snapshot-${snap.id}`}
              className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
            >
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-mono font-bold text-indigo-400">{snap.id}</span>
                  <span className="text-white font-medium">{snap.label}</span>
                </div>
                <div className="text-slate-400 font-mono text-[11px]">
                  Timestamp: {snap.timestamp} | Vouchers: {snap.vouchersCount} | Accounts: {snap.accountsCount}
                </div>
              </div>

              <button
                onClick={() => handleRestore(snap.id)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-indigo-900 text-slate-200 hover:text-indigo-200 text-xs font-semibold transition border border-slate-700"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{isFa ? 'بازیابی به این وضعیت' : 'Restore State'}</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
