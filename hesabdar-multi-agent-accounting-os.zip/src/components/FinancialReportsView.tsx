import React from 'react';
import {
  Activity,
  TrendingUp,
  Scale,
  DollarSign,
  Sparkles,
  PieChart as PieIcon,
  Calendar,
  AlertCircle,
  CheckCircle2,
  FileText,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
} from 'recharts';
import { FinancialReportsData } from '../types.js';

interface FinancialReportsViewProps {
  reports: FinancialReportsData | null;
  lang: 'fa' | 'en';
  loading: boolean;
  onRefresh: () => void;
}

export const FinancialReportsView: React.FC<FinancialReportsViewProps> = ({
  reports,
  lang,
  loading,
  onRefresh,
}) => {
  const isFa = lang === 'fa';

  if (loading || !reports) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center text-slate-400">
        <Activity className="w-8 h-8 text-emerald-400 animate-spin mx-auto mb-3" />
        <p className="text-sm">{isFa ? 'در حال تهیه و پردازش صورت‌های مالی...' : 'Compiling financial reports...'}</p>
      </div>
    );
  }

  const { balanceSheet, incomeStatement, cashFlow, forecast, aiAnalysis } = reports;

  const forecastData = forecast.months.map((month, idx) => ({
    name: month,
    revenue: forecast.revenue[idx],
    expenses: forecast.expenses[idx],
    netIncome: forecast.netIncome[idx],
  }));

  return (
    <div className="space-y-6">
      {/* AI CFO Commentary Banner */}
      {aiAnalysis && (
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-indigo-500/30 rounded-2xl p-6 shadow-xl relative overflow-hidden">
          <div className="flex items-start gap-3">
            <div className="p-3 bg-indigo-500/20 text-indigo-300 rounded-xl shrink-0 mt-1">
              <Sparkles className="w-5 h-5" />
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white">
                  {isFa ? 'تحلیل هوشمند مدیر مالی ارشد (AI CFO Executive Commentary)' : 'AI CFO Executive Commentary'}
                </h3>
                <span className="text-[11px] px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 font-mono">
                  Confidence: {((aiAnalysis.confidence || 0.98) * 100).toFixed(0)}%
                </span>
              </div>
              <p className="text-xs text-slate-200 leading-relaxed whitespace-pre-line">
                {aiAnalysis.summary}
              </p>
              {aiAnalysis.recommendations && aiAnalysis.recommendations.length > 0 && (
                <div className="pt-2 border-t border-indigo-500/20">
                  <div className="text-xs font-bold text-indigo-300 mb-1">
                    {isFa ? 'راهکارهای پیشنهادی جهت بهینه‌سازی:' : 'Strategic Recommendations:'}
                  </div>
                  <ul className="list-disc list-inside text-xs text-slate-300 space-y-1">
                    {aiAnalysis.recommendations.map((rec, rIdx) => (
                      <li key={rIdx}>{rec}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="text-xs text-slate-400 font-medium mb-1">
            {isFa ? 'درآمد کل فروش (Revenue)' : 'Total Revenue'}
          </div>
          <div className="text-xl font-black text-emerald-400 font-mono">
            {incomeStatement.revenue.total.toLocaleString()} <span className="text-xs text-slate-400 font-normal">ریال</span>
          </div>
          <div className="text-[11px] text-emerald-400/80 flex items-center gap-1 mt-2">
            <TrendingUp className="w-3 h-3" />
            <span>{isFa ? 'درآمد عملیاتی محقق شده' : 'Realized Operating Revenue'}</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="text-xs text-slate-400 font-medium mb-1">
            {isFa ? 'سود ناخالص (Gross Profit)' : 'Gross Profit'}
          </div>
          <div className="text-xl font-black text-teal-400 font-mono">
            {incomeStatement.grossProfit.toLocaleString()} <span className="text-xs text-slate-400 font-normal">ریال</span>
          </div>
          <div className="text-[11px] text-teal-400/80 mt-2 font-mono">
            {isFa ? `حاشیه سود: ${((incomeStatement.grossProfit / (incomeStatement.revenue.total || 1)) * 100).toFixed(1)}%` : `Margin: ${((incomeStatement.grossProfit / (incomeStatement.revenue.total || 1)) * 100).toFixed(1)}%`}
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="text-xs text-slate-400 font-medium mb-1">
            {isFa ? 'سود خالص دوره (Net Income)' : 'Net Income'}
          </div>
          <div className="text-xl font-black text-indigo-400 font-mono">
            {incomeStatement.netIncome.toLocaleString()} <span className="text-xs text-slate-400 font-normal">ریال</span>
          </div>
          <div className="text-[11px] text-indigo-400/80 mt-2">
            {isFa ? 'پس از کسر کلیه هزینه‌ها و مالیات' : 'After COGS, OpEx & Tax'}
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="text-xs text-slate-400 font-medium mb-1">
            {isFa ? 'طول عمر نقدینگی (Cash Runway)' : 'Cash Runway'}
          </div>
          <div className="text-xl font-black text-amber-400 font-mono">
            {forecast.cashRunwayMonths} <span className="text-xs text-slate-400 font-normal">{isFa ? 'ماه' : 'Months'}</span>
          </div>
          <div className="text-[11px] text-amber-400/80 mt-2">
            {isFa ? `موجودی نقد: ${cashFlow.endingCash.toLocaleString()} ریال` : `Cash: ${cashFlow.endingCash.toLocaleString()}`}
          </div>
        </div>
      </div>

      {/* 6-Month Forward Forecasting Chart */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-400" />
            <h3 className="text-sm font-bold text-white">
              {isFa ? 'پیش‌بینی ۶ ماهه درآمد، هزینه‌ها و سود خالص (Forecasting Model)' : '6-Month Revenue & Expense Forecast'}
            </h3>
          </div>
          <span className="text-xs text-slate-400">
            {isFa ? 'مبتنی بر مدل خط لوله n2::n5' : 'Forecasting Engine n2::n5'}
          </span>
        </div>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={forecastData} margin={{ top: 20, right: 20, left: 20, bottom: 20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
              <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} />
              <YAxis stroke="#94a3b8" fontSize={11} tickFormatter={(v) => `${(v / 1000000).toFixed(0)}M`} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.75rem', fontSize: '12px' }}
                formatter={(value: any) => [`${Number(value).toLocaleString()} ریال`, '']}
              />
              <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
              <Bar dataKey="revenue" name={isFa ? 'درآمد پیش‌بینی‌شده' : 'Forecast Revenue'} fill="#10b981" radius={[4, 4, 0, 0]} />
              <Bar dataKey="expenses" name={isFa ? 'هزینه‌های پیش‌بینی‌شده' : 'Forecast Expenses'} fill="#f43f5e" radius={[4, 4, 0, 0]} />
              <Bar dataKey="netIncome" name={isFa ? 'سود خالص پیش‌بینی‌شده' : 'Forecast Net Income'} fill="#6366f1" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Grid: Balance Sheet & Income Statement */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Balance Sheet (ترازنامه) */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Scale className="w-4 h-4 text-teal-400" />
              <span>{isFa ? 'ترازنامه (Balance Sheet)' : 'Balance Sheet'}</span>
            </h3>
            <span
              className={`text-xs px-2.5 py-0.5 rounded-full font-bold ${
                balanceSheet.isBalanced
                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                  : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
              }`}
            >
              {balanceSheet.isBalanced ? (isFa ? 'ترازنامه متوازن ✓' : 'Balanced ✓') : 'Imbalance'}
            </span>
          </div>

          {/* Assets */}
          <div>
            <div className="text-xs font-bold text-teal-400 mb-2">{isFa ? 'دارایی‌ها (Assets):' : 'Assets:'}</div>
            <div className="space-y-1 text-xs">
              {balanceSheet.assets.items.map((item, idx) => (
                <div key={idx} className="flex justify-between py-1 border-b border-slate-800/60 text-slate-300">
                  <span>{item.name}</span>
                  <span className="font-mono font-semibold text-slate-100">{item.amount.toLocaleString()}</span>
                </div>
              ))}
              <div className="flex justify-between py-1.5 font-bold text-teal-400 bg-slate-950/60 px-2 rounded-lg">
                <span>{isFa ? 'جمع دارایی‌ها:' : 'Total Assets:'}</span>
                <span className="font-mono">{balanceSheet.assets.total.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Liabilities & Equity */}
          <div className="pt-2">
            <div className="text-xs font-bold text-indigo-400 mb-2">{isFa ? 'بدهی‌ها و حقوق صاحبان سهام:' : 'Liabilities & Equity:'}</div>
            <div className="space-y-1 text-xs">
              {balanceSheet.liabilities.items.map((item, idx) => (
                <div key={idx} className="flex justify-between py-1 border-b border-slate-800/60 text-slate-300">
                  <span>{item.name}</span>
                  <span className="font-mono font-semibold text-slate-100">{item.amount.toLocaleString()}</span>
                </div>
              ))}
              <div className="flex justify-between py-1 font-semibold text-slate-400">
                <span>{isFa ? 'جمع بدهی‌ها:' : 'Total Liabilities:'}</span>
                <span className="font-mono">{balanceSheet.liabilities.total.toLocaleString()}</span>
              </div>

              {balanceSheet.equity.items.map((item, idx) => (
                <div key={idx} className="flex justify-between py-1 border-b border-slate-800/60 text-slate-300">
                  <span>{item.name}</span>
                  <span className="font-mono font-semibold text-slate-100">{item.amount.toLocaleString()}</span>
                </div>
              ))}
              <div className="flex justify-between py-1.5 font-bold text-indigo-400 bg-slate-950/60 px-2 rounded-lg">
                <span>{isFa ? 'جمع حقوق صاحبان سهام:' : 'Total Equity:'}</span>
                <span className="font-mono">{balanceSheet.equity.total.toLocaleString()}</span>
              </div>
            </div>
          </div>

          <div className="flex justify-between py-2 font-black text-sm text-emerald-400 bg-slate-950 rounded-xl px-3 border border-slate-800">
            <span>{isFa ? 'جمع کل بدهی‌ها و حقوق صاحبان سهام:' : 'Total Liabilities & Equity:'}</span>
            <span className="font-mono">{(balanceSheet.liabilities.total + balanceSheet.equity.total).toLocaleString()}</span>
          </div>
        </div>

        {/* Income Statement (صورت سود و زیان) */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <FileText className="w-4 h-4 text-emerald-400" />
              <span>{isFa ? 'صورت سود و زیان (Income Statement)' : 'Income Statement'}</span>
            </h3>
            <span className="text-xs text-slate-400">{incomeStatement.period}</span>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex justify-between py-1.5 border-b border-slate-800 text-slate-200">
              <span className="font-semibold">{isFa ? 'درآمد حاصل از فروش کالا و خدمات' : 'Revenue'}</span>
              <span className="font-mono font-bold text-emerald-400">{incomeStatement.revenue.total.toLocaleString()}</span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-slate-800 text-slate-300">
              <span>{isFa ? 'بهای تمام شده کالای فروش رفته (COGS)' : 'Cost of Goods Sold (COGS)'}</span>
              <span className="font-mono text-rose-400">({incomeStatement.costOfGoodsSold.total.toLocaleString()})</span>
            </div>

            <div className="flex justify-between py-1.5 font-bold text-teal-300 bg-slate-950/60 px-2 rounded-lg">
              <span>{isFa ? 'سود ناخالص (Gross Profit)' : 'Gross Profit'}</span>
              <span className="font-mono">{incomeStatement.grossProfit.toLocaleString()}</span>
            </div>

            <div className="pt-2 text-slate-400 font-bold">{isFa ? 'هزینه‌های عمومی و اداری:' : 'Operating Expenses:'}</div>
            {incomeStatement.operatingExpenses.items.map((item, idx) => (
              <div key={idx} className="flex justify-between py-1 border-b border-slate-800/60 text-slate-300">
                <span>{item.name}</span>
                <span className="font-mono text-rose-400">({item.amount.toLocaleString()})</span>
              </div>
            ))}

            <div className="flex justify-between py-1.5 font-bold text-slate-200">
              <span>{isFa ? 'سود عملیاتی قبل از مالیات (EBIT)' : 'Operating Income (EBIT)'}</span>
              <span className="font-mono text-indigo-300">{incomeStatement.operatingIncome.toLocaleString()}</span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-slate-800 text-slate-300">
              <span>{isFa ? 'هزینه مالیات بر درآمد عملکرد' : 'Income Tax Expense'}</span>
              <span className="font-mono text-rose-400">({incomeStatement.taxExpense.toLocaleString()})</span>
            </div>

            <div className="flex justify-between py-2.5 font-black text-sm text-emerald-400 bg-slate-950 rounded-xl px-3 border border-emerald-500/30">
              <span>{isFa ? 'سود خالص دوره (Net Income)' : 'Net Income (Profit)'}</span>
              <span className="font-mono">{incomeStatement.netIncome.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
