import React, { useState } from 'react';
import {
  Network,
  Search,
  Layers,
  ShieldCheck,
  Code,
  Tag,
  CheckCircle2,
} from 'lucide-react';
import { GraphMLNode } from '../types.js';

interface GraphMLMapViewProps {
  nodes: GraphMLNode[];
  lang: 'fa' | 'en';
}

export const GraphMLMapView: React.FC<GraphMLMapViewProps> = ({ nodes, lang }) => {
  const isFa = lang === 'fa';
  const [search, setSearch] = useState('');
  const [selectedCluster, setSelectedCluster] = useState('all');
  const [activeNode, setActiveNode] = useState<GraphMLNode | null>(nodes[0] || null);

  const clusters = [
    { id: 'all', label: 'All Nodes (350)', labelFa: 'همه ۳۵۰ نود معماری' },
    { id: 'Supervisory Kernel', label: 'Supervisory Kernel (n5)', labelFa: 'هسته نظارتی CEO' },
    { id: 'Authoritative DB Writer', label: 'DB Manager (n6)', labelFa: 'عامل انحصاری دیتابیس' },
    { id: 'Messaging Channel', label: 'Messaging & Audit (n10)', labelFa: 'پیام‌رسانی و زنجیره هش' },
    { id: 'Memory Matrix', label: '27 Memory Matrix (n13)', labelFa: 'ماتریس ۲۷ حافظه' },
    { id: 'QA Critic Hub', label: 'Critic Hub (n8)', labelFa: 'کنترل کیفیت و منتقد' },
    { id: 'Domain Engine', label: 'Domain Engine (n20)', labelFa: 'موتور قوانین حسابداری' },
    { id: 'Tool Sandbox', label: 'Tool Sandbox (n20::n14)', labelFa: 'سندباکس ابزارها' },
    { id: 'Reporting & Forecasting', label: 'Reporting (n2)', labelFa: 'گزارش‌گیری و پیش‌بینی' },
    { id: 'Knowledge & Standards', label: 'Standards (n3)', labelFa: 'استانداردها و قوانین' },
    { id: 'Self-Healing & Resilience', label: 'Resilience (n1)', labelFa: 'خودترمیمی و پایداری' },
  ];

  const filteredNodes = nodes.filter((n) => {
    const matchesCluster = selectedCluster === 'all' || n.cluster === selectedCluster;
    const matchesSearch =
      search === '' ||
      n.id.toLowerCase().includes(search.toLowerCase()) ||
      n.label.toLowerCase().includes(search.toLowerCase()) ||
      n.description.toLowerCase().includes(search.toLowerCase()) ||
      (n.invariant && n.invariant.toLowerCase().includes(search.toLowerCase()));
    return matchesCluster && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-3 bg-teal-500/10 text-teal-400 rounded-xl">
            <Network className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">
              {isFa ? 'نقشه ۳۵۰ نود معماری و تضمین‌های سیستم (350-Node GraphML Map)' : 'Hesabdar 350-Node Architectural Map (حسابدار.graphml)'}
            </h2>
            <p className="text-xs text-slate-400">
              {isFa
                ? 'تطابق ۱۰۰٪ کدهای سیستم با دیاگرام رسمی معماری و اینواریانت‌های قطعی هسته نظارتی، دیتابیس، حافظه و پیام‌ها'
                : '100% strict adherence mapping between graphml architecture nodes, invariant specifications, and runtime code'}
            </p>
          </div>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={isFa ? 'جستجو در نودها بر اساس کد، عنوان، اینواریانت...' : 'Search nodes by ID, label, invariant...'}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-9 pl-3 py-2 text-xs text-slate-200"
          />
        </div>

        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-1">
          {clusters.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCluster(c.id)}
              className={`px-3 py-1.5 rounded-lg text-xs whitespace-nowrap transition ${
                selectedCluster === c.id
                  ? 'bg-teal-500/20 text-teal-300 border border-teal-500/40 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {isFa ? c.labelFa : c.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Left Node List, Right Node Detail */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Node List */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl max-h-[600px] overflow-y-auto space-y-2">
          <div className="text-xs text-slate-400 font-bold mb-2">
            {isFa ? `نودهای منطبق (${filteredNodes.length}):` : `Matching Architectural Nodes (${filteredNodes.length}):`}
          </div>
          {filteredNodes.map((node) => (
            <button
              key={node.id}
              onClick={() => setActiveNode(node)}
              className={`w-full text-right p-3 rounded-xl transition border text-xs flex flex-col justify-between ${
                activeNode?.id === node.id
                  ? 'bg-teal-950/60 border-teal-500/50 text-white'
                  : 'bg-slate-950/60 border-slate-800/80 text-slate-300 hover:bg-slate-800/80'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-mono font-bold text-teal-400 bg-teal-500/10 px-1.5 py-0.5 rounded text-[11px]">
                  {node.id}
                </span>
                <span className="text-[10px] text-slate-400">{node.cluster}</span>
              </div>
              <div className="font-semibold text-slate-200 truncate">{node.label}</div>
            </button>
          ))}
        </div>

        {/* Node Detail Inspector */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          {activeNode ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <span className="text-xs font-mono font-bold text-teal-400 bg-teal-500/10 border border-teal-500/20 px-2 py-0.5 rounded">
                    Node: {activeNode.id}
                  </span>
                  <h3 className="text-base font-bold text-white mt-1.5">{activeNode.label}</h3>
                </div>
                <span className="text-xs bg-slate-800 text-slate-300 px-3 py-1 rounded-full font-medium">
                  {activeNode.cluster}
                </span>
              </div>

              <div>
                <div className="text-xs font-bold text-slate-400 mb-1">{isFa ? 'شرح و مسئولیت نود:' : 'Description & Functionality:'}</div>
                <p className="text-xs text-slate-200 leading-relaxed bg-slate-950 p-3 rounded-xl border border-slate-800">
                  {activeNode.description}
                </p>
              </div>

              {activeNode.invariant && (
                <div className="p-3 bg-emerald-950/40 border border-emerald-500/30 rounded-xl space-y-1">
                  <div className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4" />
                    <span>{isFa ? 'اینواریانت قطعی تضمین‌شده:' : 'Architectural Invariant Guarantee:'}</span>
                  </div>
                  <div className="text-xs text-emerald-200 font-mono">{activeNode.invariant}</div>
                </div>
              )}

              {activeNode.mappedCode && (
                <div>
                  <div className="text-xs font-bold text-slate-400 mb-1 flex items-center gap-1.5">
                    <Code className="w-3.5 h-3.5 text-teal-400" />
                    <span>{isFa ? 'مسیر نگاشت کد در سیستم:' : 'Codebase Implementation Target:'}</span>
                  </div>
                  <div className="text-xs font-mono text-teal-300 bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                    {activeNode.mappedCode}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-20 text-slate-500 text-xs">
              {isFa ? 'یک نود را از لیست سمت راست انتخاب کنید' : 'Select a node from the list'}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
