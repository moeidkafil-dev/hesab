import React, { useState } from 'react';
import {
  Wrench,
  Shield,
  Play,
  CheckCircle2,
  Clock,
  Cpu,
  Layers,
  Terminal,
  Activity,
} from 'lucide-react';
import { executeTool } from '../api.js';

interface ToolsSandboxViewProps {
  lang: 'fa' | 'en';
}

export const ToolsSandboxView: React.FC<ToolsSandboxViewProps> = ({ lang }) => {
  const isFa = lang === 'fa';
  const [selectedTool, setSelectedTool] = useState('calculate_tax_and_cogs');
  const [argsJson, setArgsJson] = useState('{\n  "baseAmount": 50000000,\n  "taxRate": 0.10,\n  "costBasis": 35000000\n}');
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<any>(null);

  const toolsList = [
    {
      id: 'calculate_tax_and_cogs',
      name: 'محاسبه مالیات و بهای تمام شده',
      nameEn: 'Calculate Tax & COGS',
      defaultArgs: '{\n  "baseAmount": 50000000,\n  "taxRate": 0.10,\n  "costBasis": 35000000\n}',
    },
    {
      id: 'reconcile_bank_statement',
      name: 'مغایرت‌گیری خودکار بانکی',
      nameEn: 'Reconcile Bank Statement',
      defaultArgs: '{\n  "bankBalance": 45000000,\n  "bookBalance": 45000000,\n  "outstandingChecks": []\n}',
    },
    {
      id: 'generate_financial_ratio_matrix',
      name: 'ماتریس نسبت‌های مالی (جاری، آنی، حاشیه)',
      nameEn: 'Generate Financial Ratio Matrix',
      defaultArgs: '{\n  "currentAssets": 80000000,\n  "currentLiabilities": 40000000,\n  "inventory": 20000000,\n  "netIncome": 18000000,\n  "revenue": 90000000\n}',
    },
    {
      id: 'evaluate_depreciation_schedule',
      name: 'جدول استهلاک خط مستقیم دارایی',
      nameEn: 'Evaluate Depreciation Schedule',
      defaultArgs: '{\n  "cost": 120000000,\n  "salvageValue": 12000000,\n  "usefulLifeYears": 5\n}',
    },
  ];

  const handleToolSelect = (id: string) => {
    setSelectedTool(id);
    const found = toolsList.find((t) => t.id === id);
    if (found) {
      setArgsJson(found.defaultArgs);
    }
  };

  const handleRun = async () => {
    setRunning(true);
    try {
      const parsed = JSON.parse(argsJson);
      const res = await executeTool(selectedTool, parsed, 'CEO_Supervisor');
      setResult(res);
    } catch (err: any) {
      setResult({ error: err.message });
    } finally {
      setRunning(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-3 bg-amber-500/10 text-amber-400 rounded-xl">
            <Wrench className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">
              {isFa ? 'محیط ایزوله اجرای ابزارها و محاسبات مالی (Tool Sandbox - n20::n14)' : 'Isolated Tool Execution Sandbox (n20::n14)'}
            </h2>
            <p className="text-xs text-slate-400">
              {isFa
                ? 'ایزولاسیون کامل توابع ریاضی و پردازشی، مهار تایم‌اوت، مدیریت حافظه و محافظت در برابر فراخوانی‌های مخرب سیستم'
                : 'Sandboxed execution environment with strict timeout limits, memory cap, and AST safety barriers'}
            </p>
          </div>
        </div>
      </div>

      {/* Tool Selector & Runner Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Tools Selection List */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            {isFa ? 'ابزارهای مالی مجاز:' : 'Authorized Tools:'}
          </h3>
          <div className="space-y-2">
            {toolsList.map((t) => (
              <button
                key={t.id}
                onClick={() => handleToolSelect(t.id)}
                className={`w-full p-3 rounded-xl text-xs text-right transition flex items-center justify-between ${
                  selectedTool === t.id
                    ? 'bg-amber-500/15 border border-amber-500/30 text-amber-300 font-bold'
                    : 'bg-slate-950/60 border border-slate-800/80 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <div>
                  <div>{isFa ? t.name : t.nameEn}</div>
                  <div className="text-[10px] text-slate-500 font-mono mt-0.5">{t.id}</div>
                </div>
                {selectedTool === t.id && <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />}
              </button>
            ))}
          </div>
        </div>

        {/* JSON Arguments & Execution */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-amber-400" />
              <h3 className="text-sm font-bold text-white">
                {isFa ? 'پارامترهای ورودی ابزار (JSON Arguments):' : 'Tool Input Parameters:'}
              </h3>
            </div>
            <button
              id="execute-tool-btn"
              onClick={handleRun}
              disabled={running}
              className="flex items-center gap-1.5 px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-amber-600/20 disabled:opacity-50 transition"
            >
              <Play className="w-3.5 h-3.5" />
              <span>{running ? (isFa ? 'در حال محاسبه در سندباکس...' : 'Executing...') : isFa ? 'اجرا در سندباکس ایزوله' : 'Run in Sandbox'}</span>
            </button>
          </div>

          <textarea
            rows={7}
            value={argsJson}
            onChange={(e) => setArgsJson(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs font-mono text-emerald-400 leading-relaxed"
          />

          {/* Results Output */}
          {result && (
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
              <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-800">
                <span className="font-bold text-slate-300">{isFa ? 'خروجی سندباکس:' : 'Sandbox Output:'}</span>
                <span className="font-mono text-emerald-400">
                  Execution Time: {result.executionTimeMs || 2}ms
                </span>
              </div>
              <pre className="text-xs font-mono text-slate-200 overflow-x-auto p-2 bg-slate-900 rounded-lg">
                {JSON.stringify(result, null, 2)}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
