import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Plus,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Hash,
  Scale,
  DollarSign,
  Layers,
  ArrowDownLeft,
  ArrowUpRight,
  Filter,
} from 'lucide-react';
import { AccountItem, JournalVoucherItem } from '../types.js';
import { postVoucher, createAccount } from '../api.js';

interface LedgerViewProps {
  accounts: AccountItem[];
  vouchers: JournalVoucherItem[];
  trialBalance: any;
  lang: 'fa' | 'en';
  onRefresh: () => void;
}

export const LedgerView: React.FC<LedgerViewProps> = ({
  accounts,
  vouchers,
  trialBalance,
  lang,
  onRefresh,
}) => {
  const isFa = lang === 'fa';
  const [activeSubTab, setActiveSubTab] = useState<'vouchers' | 'accounts' | 'trial_balance'>('vouchers');
  const [showNewVoucherModal, setShowNewVoucherModal] = useState(false);
  const [showNewAccountModal, setShowNewAccountModal] = useState(false);

  // New Voucher State
  const [voucherDesc, setVoucherDesc] = useState('');
  const [voucherDate, setVoucherDate] = useState(new Date().toISOString().split('T')[0]);
  const [lines, setLines] = useState<Array<{ accountId: string; debit: number; credit: number; description: string }>>([
    { accountId: accounts[0]?.id || 'acc_cash', debit: 10000000, credit: 0, description: '' },
    { accountId: accounts[accounts.length > 1 ? 1 : 0]?.id || 'acc_sales_rev', debit: 0, credit: 10000000, description: '' },
  ]);
  const [voucherError, setVoucherError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // New Account State
  const [accCode, setAccCode] = useState('');
  const [accName, setAccName] = useState('');
  const [accNameFa, setAccNameFa] = useState('');
  const [accType, setAccType] = useState<'asset' | 'liability' | 'equity' | 'revenue' | 'expense'>('asset');
  const [accCategory, setAccCategory] = useState('current_asset');
  const [accBalance, setAccBalance] = useState(0);

  const totalDebit = lines.reduce((s, l) => s + (Number(l.debit) || 0), 0);
  const totalCredit = lines.reduce((s, l) => s + (Number(l.credit) || 0), 0);
  const isBalanced = Math.abs(totalDebit - totalCredit) < 0.001 && totalDebit > 0;

  const handleAddLine = () => {
    setLines([
      ...lines,
      { accountId: accounts[0]?.id || '', debit: 0, credit: 0, description: '' },
    ]);
  };

  const handleRemoveLine = (idx: number) => {
    if (lines.length <= 2) return;
    setLines(lines.filter((_, i) => i !== idx));
  };

  const handleLineChange = (idx: number, field: string, value: any) => {
    const next = [...lines];
    next[idx] = { ...next[idx], [field]: value };
    setLines(next);
  };

  const handlePostVoucher = async () => {
    if (!voucherDesc.trim()) {
      setVoucherError(isFa ? 'شرح سند الزامی است' : 'Voucher description is required');
      return;
    }
    if (!isBalanced) {
      setVoucherError(isFa ? 'سند تراز نیست (مجموع بدهکار باید برابر مجموع بستانکار باشد)' : 'Voucher is not balanced (Debit must equal Credit)');
      return;
    }

    setSubmitting(true);
    setVoucherError(null);
    try {
      const res = await postVoucher({
        date: voucherDate,
        description: voucherDesc,
        lines,
        createdByAgent: 'human_controller',
      });
      if (res.ok) {
        setShowNewVoucherModal(false);
        setVoucherDesc('');
        onRefresh();
      } else {
        setVoucherError(res.error || 'Posting failed');
      }
    } catch (err: any) {
      setVoucherError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleCreateAccount = async () => {
    if (!accCode || !accName) return;
    try {
      await createAccount({
        code: accCode,
        name: accName,
        nameFa: accNameFa || accName,
        type: accType,
        category: accCategory,
        balance: Number(accBalance) || 0,
      });
      setShowNewAccountModal(false);
      setAccCode('');
      setAccName('');
      setAccNameFa('');
      onRefresh();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Sub-tab Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl">
        <div className="flex items-center gap-2">
          <button
            id="subtab-vouchers"
            onClick={() => setActiveSubTab('vouchers')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition ${
              activeSubTab === 'vouchers'
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {isFa ? `اسناد حسابداری (${vouchers.length})` : `Journal Vouchers (${vouchers.length})`}
          </button>
          <button
            id="subtab-accounts"
            onClick={() => setActiveSubTab('accounts')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition ${
              activeSubTab === 'accounts'
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {isFa ? `کدینگ حساب‌ها (${accounts.length})` : `Chart of Accounts (${accounts.length})`}
          </button>
          <button
            id="subtab-trial"
            onClick={() => setActiveSubTab('trial_balance')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition ${
              activeSubTab === 'trial_balance'
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {isFa ? 'تراز آزمایشی (Trial Balance)' : 'Trial Balance'}
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="open-new-voucher-btn"
            onClick={() => setShowNewVoucherModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium shadow-lg shadow-emerald-600/20 transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{isFa ? 'ثبت سند دوبل جدید' : 'New Journal Voucher'}</span>
          </button>
          <button
            id="open-new-account-btn"
            onClick={() => setShowNewAccountModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{isFa ? 'تعریف حساب جدید' : 'Add Account'}</span>
          </button>
        </div>
      </div>

      {/* 1. Vouchers List */}
      {activeSubTab === 'vouchers' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              <span>{isFa ? 'دفتر ثبت اسناد دوبل حسابداری (Journal Entries)' : 'General Ledger Journal Entries'}</span>
            </h3>
            <span className="text-xs text-slate-400">
              {isFa ? 'تمامی اسناد با اعتبارسنجی DB Analyser ثبت شده‌اند' : 'All vouchers verified via DB Analyser'}
            </span>
          </div>

          <div className="space-y-4">
            {vouchers.map((v) => (
              <div
                key={v.id}
                id={`voucher-${v.id}`}
                className="bg-slate-950/70 border border-slate-800/90 hover:border-slate-700 rounded-xl p-4 transition"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 mb-3 border-b border-slate-800/80">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2.5 py-1 rounded-lg">
                      {v.voucherNumber}
                    </span>
                    <span className="text-xs text-slate-400">{v.date}</span>
                    {v.ruleMatched && (
                      <span className="text-[11px] font-mono bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 px-2 py-0.5 rounded">
                        {v.ruleMatched}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-slate-400 font-mono text-[11px]">
                      Agent: <strong className="text-slate-300">{v.createdByAgent}</strong>
                    </span>
                    <span className="text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-full text-[10px] font-bold">
                      {v.status.toUpperCase()}
                    </span>
                  </div>
                </div>

                <div className="text-xs font-medium text-slate-200 mb-3">{v.description}</div>

                {/* Lines Table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-slate-300">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-400 text-right">
                        <th className="pb-1.5 w-20">{isFa ? 'کد' : 'Code'}</th>
                        <th className="pb-1.5">{isFa ? 'شرح حساب' : 'Account Name'}</th>
                        <th className="pb-1.5 text-left w-32">{isFa ? 'بدهکار (ریال)' : 'Debit'}</th>
                        <th className="pb-1.5 text-left w-32">{isFa ? 'بستانکار (ریال)' : 'Credit'}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {v.lines.map((l, lidx) => (
                        <tr key={lidx} className="border-b border-slate-900/60 hover:bg-slate-900/40">
                          <td className="py-2 font-mono text-teal-400">{l.accountCode}</td>
                          <td className="py-2 font-medium">{l.accountName}</td>
                          <td className="py-2 text-left font-mono text-emerald-400 font-semibold">
                            {l.debit > 0 ? l.debit.toLocaleString() : '-'}
                          </td>
                          <td className="py-2 text-left font-mono text-indigo-400 font-semibold">
                            {l.credit > 0 ? l.credit.toLocaleString() : '-'}
                          </td>
                        </tr>
                      ))}
                      <tr className="font-bold text-slate-100 bg-slate-900/60">
                        <td colSpan={2} className="py-2 text-right">
                          {isFa ? 'جمع کل سند:' : 'Total:'}
                        </td>
                        <td className="py-2 text-left font-mono text-emerald-400">
                          {v.totalDebit.toLocaleString()}
                        </td>
                        <td className="py-2 text-left font-mono text-indigo-400">
                          {v.totalCredit.toLocaleString()}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <div className="mt-2 text-[10px] text-slate-500 font-mono truncate">
                  Audit Hash: {v.hash || 'Verified'}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 2. Chart of Accounts */}
      {activeSubTab === 'accounts' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-teal-400" />
              <span>{isFa ? 'جدول و ساختار کدینگ حساب‌های دفتر کل' : 'Authoritative Chart of Accounts'}</span>
            </h3>
            <span className="text-xs text-slate-400">
              {isFa ? 'طبقه‌بندی استاندارد ۵ گانه حسابداری' : 'Standard 5-Category Taxonomy'}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-slate-300">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 text-right">
                  <th className="pb-2">{isFa ? 'کد' : 'Code'}</th>
                  <th className="pb-2">{isFa ? 'عنوان حساب (فارسی)' : 'Account Title'}</th>
                  <th className="pb-2">{isFa ? 'نام لاتین' : 'English Name'}</th>
                  <th className="pb-2">{isFa ? 'ماهیت' : 'Type'}</th>
                  <th className="pb-2 text-left">{isFa ? 'مانده دفتر کل (ریال)' : 'Balance (IRR)'}</th>
                </tr>
              </thead>
              <tbody>
                {accounts.map((acc) => (
                  <tr key={acc.id} id={`acc-row-${acc.id}`} className="border-b border-slate-800/60 hover:bg-slate-950/40">
                    <td className="py-2.5 font-mono font-bold text-teal-400">{acc.code}</td>
                    <td className="py-2.5 font-semibold text-slate-100">{acc.nameFa}</td>
                    <td className="py-2.5 text-slate-400 text-[11px]">{acc.name}</td>
                    <td className="py-2.5">
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                          acc.type === 'asset'
                            ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                            : acc.type === 'liability'
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                            : acc.type === 'equity'
                            ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                            : acc.type === 'revenue'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        }`}
                      >
                        {acc.type.toUpperCase()}
                      </span>
                    </td>
                    <td className="py-2.5 text-left font-mono font-bold text-slate-100">
                      {acc.balance.toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. Trial Balance */}
      {activeSubTab === 'trial_balance' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Scale className="w-4 h-4 text-emerald-400" />
              <span>{isFa ? 'تراز آزمایشی کل (Trial Balance Verification)' : 'Trial Balance Summary'}</span>
            </h3>
            <div
              className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${
                trialBalance?.isBalanced
                  ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-500/40'
                  : 'bg-rose-950/80 text-rose-400 border border-rose-500/40'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{isFa ? 'ترازنامه در تعادل کامل است' : 'Equilibrium Verified'}</span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-slate-300">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 text-right">
                  <th className="pb-2">{isFa ? 'کد' : 'Code'}</th>
                  <th className="pb-2">{isFa ? 'عنوان حساب' : 'Account Name'}</th>
                  <th className="pb-2">{isFa ? 'نوع' : 'Type'}</th>
                  <th className="pb-2 text-left">{isFa ? 'گردش بدهکار (ریال)' : 'Debit Balance'}</th>
                  <th className="pb-2 text-left">{isFa ? 'گردش بستانکار (ریال)' : 'Credit Balance'}</th>
                </tr>
              </thead>
              <tbody>
                {trialBalance?.accounts?.map((row: any, idx: number) => (
                  <tr key={idx} className="border-b border-slate-800/60 hover:bg-slate-950/40">
                    <td className="py-2 font-mono text-teal-400">{row.code}</td>
                    <td className="py-2 font-medium text-slate-200">{row.name}</td>
                    <td className="py-2 text-slate-400 text-[11px]">{row.type}</td>
                    <td className="py-2 text-left font-mono text-emerald-400">
                      {row.debit > 0 ? row.debit.toLocaleString() : '-'}
                    </td>
                    <td className="py-2 text-left font-mono text-indigo-400">
                      {row.credit > 0 ? row.credit.toLocaleString() : '-'}
                    </td>
                  </tr>
                ))}
                <tr className="font-bold text-slate-100 bg-slate-950/80 text-sm border-t-2 border-emerald-500/40">
                  <td colSpan={3} className="py-3 text-right">
                    {isFa ? 'مجموع کل تراز آزمایشی:' : 'Total Trial Balance Sum:'}
                  </td>
                  <td className="py-3 text-left font-mono text-emerald-400">
                    {trialBalance?.totalDebit?.toLocaleString()}
                  </td>
                  <td className="py-3 text-left font-mono text-indigo-400">
                    {trialBalance?.totalCredit?.toLocaleString()}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal: New Journal Voucher */}
      {showNewVoucherModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-2xl w-full shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
                <span>{isFa ? 'صدور و ثبت سند دوبل حسابداری جدید' : 'Post New Double-Entry Journal Voucher'}</span>
              </h3>
              <button
                onClick={() => setShowNewVoucherModal(false)}
                className="text-slate-400 hover:text-slate-200 text-sm"
              >
                ✕
              </button>
            </div>

            {voucherError && (
              <div className="p-3 bg-rose-950/60 border border-rose-500/40 text-rose-300 rounded-xl text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{voucherError}</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">{isFa ? 'تاریخ سند:' : 'Date:'}</label>
                <input
                  type="date"
                  value={voucherDate}
                  onChange={(e) => setVoucherDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">{isFa ? 'شرح سند:' : 'Description:'}</label>
                <input
                  type="text"
                  value={voucherDesc}
                  onChange={(e) => setVoucherDesc(e.target.value)}
                  placeholder={isFa ? 'مثلاً: پرداخت هزینه اینترنت و ملزومات' : 'e.g. Office supplies purchase'}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200"
                />
              </div>
            </div>

            {/* Voucher Lines */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300">{isFa ? 'سطرهای سند دوبل:' : 'Voucher Lines:'}</span>
                <button
                  type="button"
                  onClick={handleAddLine}
                  className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{isFa ? 'افزودن ردیف' : 'Add Row'}</span>
                </button>
              </div>

              {lines.map((l, idx) => (
                <div key={idx} className="grid grid-cols-12 gap-2 items-center bg-slate-950/60 p-2.5 rounded-xl border border-slate-800">
                  <div className="col-span-5">
                    <select
                      value={l.accountId}
                      onChange={(e) => handleLineChange(idx, 'accountId', e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-slate-200"
                    >
                      {accounts.map((acc) => (
                        <option key={acc.id} value={acc.id}>
                          {acc.code} - {acc.nameFa}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="col-span-3">
                    <input
                      type="number"
                      placeholder={isFa ? 'بدهکار' : 'Debit'}
                      value={l.debit || ''}
                      onChange={(e) => handleLineChange(idx, 'debit', Number(e.target.value) || 0)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-emerald-400 font-mono text-left"
                    />
                  </div>
                  <div className="col-span-3">
                    <input
                      type="number"
                      placeholder={isFa ? 'بستانکار' : 'Credit'}
                      value={l.credit || ''}
                      onChange={(e) => handleLineChange(idx, 'credit', Number(e.target.value) || 0)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-indigo-400 font-mono text-left"
                    />
                  </div>
                  <div className="col-span-1 text-center">
                    <button
                      type="button"
                      onClick={() => handleRemoveLine(idx)}
                      disabled={lines.length <= 2}
                      className="text-slate-500 hover:text-rose-400 disabled:opacity-30"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}

              {/* Total & Balance Badge */}
              <div className="flex items-center justify-between p-3 bg-slate-950 rounded-xl text-xs">
                <div className="flex items-center gap-4">
                  <span>
                    {isFa ? 'جمع بدهکار:' : 'Total Debit:'}{' '}
                    <strong className="text-emerald-400 font-mono">{totalDebit.toLocaleString()}</strong>
                  </span>
                  <span>
                    {isFa ? 'جمع بستانکار:' : 'Total Credit:'}{' '}
                    <strong className="text-indigo-400 font-mono">{totalCredit.toLocaleString()}</strong>
                  </span>
                </div>
                <span
                  className={`px-2.5 py-1 rounded-full text-[11px] font-bold ${
                    isBalanced
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                  }`}
                >
                  {isBalanced ? (isFa ? 'تراز است ✓' : 'Balanced ✓') : (isFa ? 'عدم تراز ✗' : 'Imbalanced ✗')}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                onClick={() => setShowNewVoucherModal(false)}
                className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-slate-200"
              >
                {isFa ? 'انصراف' : 'Cancel'}
              </button>
              <button
                id="submit-voucher-btn"
                onClick={handlePostVoucher}
                disabled={submitting || !isBalanced}
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-lg shadow-emerald-600/20 disabled:opacity-50 disabled:cursor-not-allowed transition"
              >
                {submitting ? (isFa ? 'در حال ثبت...' : 'Posting...') : isFa ? 'ثبت قطعی در دفتر کل' : 'Post to Ledger'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: New Account */}
      {showNewAccountModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Plus className="w-5 h-5 text-teal-400" />
                <span>{isFa ? 'ایجاد حساب جدید در کدینگ' : 'Create New Account'}</span>
              </h3>
              <button onClick={() => setShowNewAccountModal(false)} className="text-slate-400 hover:text-slate-200">
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">{isFa ? 'کد حساب (مثلاً 1050):' : 'Account Code:'}</label>
                <input
                  type="text"
                  value={accCode}
                  onChange={(e) => setAccCode(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100 font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-300 mb-1">{isFa ? 'عنوان حساب (فارسی):' : 'Title (Persian):'}</label>
                <input
                  type="text"
                  value={accNameFa}
                  onChange={(e) => setAccNameFa(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100"
                />
              </div>
              <div>
                <label className="block text-slate-300 mb-1">{isFa ? 'نام انگلیسی:' : 'English Name:'}</label>
                <input
                  type="text"
                  value={accName}
                  onChange={(e) => setAccName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 mb-1">{isFa ? 'ماهیت:' : 'Type:'}</label>
                  <select
                    value={accType}
                    onChange={(e) => setAccType(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100"
                  >
                    <option value="asset">Asset (دارایی)</option>
                    <option value="liability">Liability (بدهی)</option>
                    <option value="equity">Equity (حقوق صاحبان سهام)</option>
                    <option value="revenue">Revenue (درآمد)</option>
                    <option value="expense">Expense (هزینه)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">{isFa ? 'مانده اولیه:' : 'Initial Balance:'}</label>
                  <input
                    type="number"
                    value={accBalance}
                    onChange={(e) => setAccBalance(Number(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100 font-mono"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
              <button onClick={() => setShowNewAccountModal(false)} className="px-3 py-1.5 rounded-lg text-xs text-slate-400">
                {isFa ? 'انصراف' : 'Cancel'}
              </button>
              <button
                onClick={handleCreateAccount}
                className="px-4 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold transition"
              >
                {isFa ? 'ایجاد حساب' : 'Create'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
