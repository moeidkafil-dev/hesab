import React, { useState } from 'react';
import {
  Scale,
  Plus,
  Check,
  X,
  Play,
  Sparkles,
  ShieldAlert,
  Sliders,
  CheckCircle2,
  Clock,
  Layers,
  HelpCircle,
} from 'lucide-react';
import { RuleItem } from '../types.js';
import { reviewRule, classifyTransaction, proposeRule } from '../api.js';

interface DomainRulesViewProps {
  rules: RuleItem[];
  lang: 'fa' | 'en';
  onRefresh: () => void;
}

export const DomainRulesView: React.FC<DomainRulesViewProps> = ({
  rules,
  lang,
  onRefresh,
}) => {
  const isFa = lang === 'fa';
  const [testText, setTestText] = useState('فروش نقدی خدمات نرم‌افزاری به مبلغ ۳۰,۰۰۰,۰۰۰ ریال');
  const [testAmount, setTestAmount] = useState(30000000);
  const [simResult, setSimResult] = useState<any>(null);
  const [simulating, setSimulating] = useState(false);
  const [showProposeModal, setShowProposeModal] = useState(false);

  // New Rule Proposal Form
  const [newTitle, setNewTitle] = useState('');
  const [newTitleFa, setNewTitleFa] = useState('');
  const [newType, setNewType] = useState<'vat' | 'depreciation' | 'payroll_withholding' | 'inventory_cogs' | 'custom'>('custom');
  const [newCondition, setNewCondition] = useState('');
  const [newDesc, setNewDesc] = useState('');

  const pendingRules = rules.filter((r) => r.approvalStatus === 'pending_approval');
  const approvedRules = rules.filter((r) => r.isApproved);

  const handleSimulate = async () => {
    if (!testText.trim()) return;
    setSimulating(true);
    try {
      const res = await classifyTransaction(testText, testAmount);
      setSimResult(res);
      if (res.proposedRule) {
        onRefresh();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSimulating(false);
    }
  };

  const handleReview = async (ruleId: string, approve: boolean) => {
    try {
      await reviewRule(ruleId, approve, 'CEO_Supervisor_Dashboard');
      onRefresh();
    } catch (err) {
      console.error(err);
    }
  };

  const handlePropose = async () => {
    if (!newTitle) return;
    try {
      await proposeRule({
        title: newTitle,
        titleFa: newTitleFa || newTitle,
        ruleType: newType,
        condition: newCondition || 'description.includes("...")',
        description: newDesc,
        confidenceScore: 0.9,
      });
      setShowProposeModal(false);
      setNewTitle('');
      setNewTitleFa('');
      setNewDesc('');
      onRefresh();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Scale className="w-5 h-5 text-emerald-400" />
            <span>{isFa ? 'موتور قوانین حسابداری و گیت نظارت انسانی (Domain Rules Engine)' : 'Accounting Domain Engine & Rules'}</span>
          </h2>
          <p className="text-xs text-slate-400">
            {isFa
              ? 'اجرای مسیر قطعی قوانین مالیاتی و تطابق با استانداردهای دوبل به انضمام گیت تصویب انسانی'
              : 'Deterministic rule executor with human-in-the-loop approval gate (§5.4 & Doc 12)'}
          </p>
        </div>

        <button
          id="propose-rule-btn"
          onClick={() => setShowProposeModal(true)}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium shadow-lg shadow-emerald-600/20 transition self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{isFa ? 'پیشنهاد قانون جدید' : 'Propose New Rule'}</span>
        </button>
      </div>

      {/* Dual-Path Simulator Box */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-teal-400" />
            <h3 className="text-sm font-bold text-white">
              {isFa ? 'شبیه‌ساز مسیر دوگانه (Deterministic Matcher vs. LLM Fallback)' : 'Dual-Path Transaction Classifier Simulator'}
            </h3>
          </div>
          <span className="text-xs px-2.5 py-1 rounded bg-teal-500/10 text-teal-400 border border-teal-500/20 font-mono">
            {isFa ? 'مسیر قطعی در اولویت است' : 'Deterministic First'}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="md:col-span-2">
            <label className="block text-xs font-medium text-slate-300 mb-1">{isFa ? 'شرح تراکنش جهت آزمون:' : 'Transaction Description:'}</label>
            <input
              type="text"
              value={testText}
              onChange={(e) => setTestText(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-100"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">{isFa ? 'مبلغ (ریال):' : 'Amount (IRR):'}</label>
            <div className="flex gap-2">
              <input
                type="number"
                value={testAmount}
                onChange={(e) => setTestAmount(Number(e.target.value) || 0)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-100 font-mono"
              />
              <button
                id="run-classify-btn"
                onClick={handleSimulate}
                disabled={simulating}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shrink-0 transition"
              >
                {simulating ? '...' : isFa ? 'تست قانون' : 'Test'}
              </button>
            </div>
          </div>
        </div>

        {/* Simulation Output */}
        {simResult && (
          <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span
                  className={`text-xs px-2.5 py-0.5 rounded-full font-bold uppercase ${
                    simResult.path === 'deterministic'
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30'
                  }`}
                >
                  Path: {simResult.path}
                </span>
                <span className="text-xs text-slate-300">{simResult.explanation}</span>
              </div>
              <span className="text-xs font-mono text-teal-400">
                Confidence: {((simResult.confidence || 0.9) * 100).toFixed(0)}%
              </span>
            </div>

            {/* Generated Lines */}
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-slate-300">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 text-right">
                    <th className="pb-1">{isFa ? 'کد حساب' : 'Code'}</th>
                    <th className="pb-1">{isFa ? 'عنوان حساب' : 'Account'}</th>
                    <th className="pb-1 text-left">{isFa ? 'بدهکار (ریال)' : 'Debit'}</th>
                    <th className="pb-1 text-left">{isFa ? 'بستانکار (ریال)' : 'Credit'}</th>
                  </tr>
                </thead>
                <tbody>
                  {simResult.lines?.map((line: any, idx: number) => (
                    <tr key={idx} className="border-b border-slate-800/40">
                      <td className="py-1.5 font-mono text-teal-400">{line.accountCode}</td>
                      <td className="py-1.5">{line.accountName}</td>
                      <td className="py-1.5 text-left font-mono text-emerald-400">
                        {line.debit > 0 ? line.debit.toLocaleString() : '-'}
                      </td>
                      <td className="py-1.5 text-left font-mono text-indigo-400">
                        {line.credit > 0 ? line.credit.toLocaleString() : '-'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Human Approval Queue (§5.4 Gate) */}
      {pendingRules.length > 0 && (
        <div className="bg-amber-950/30 border border-amber-500/30 rounded-2xl p-6 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-amber-300 flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-amber-400" />
              <span>{isFa ? 'صف تایید قوانین پیشنهادی هوش مصنوعی (Human Approval Queue)' : 'Human Approval Queue (§5.4 Gate)'}</span>
            </h3>
            <span className="text-xs text-amber-300 font-mono">{pendingRules.length} Pending Review</span>
          </div>
          <p className="text-xs text-slate-300">
            {isFa
              ? 'طبق سند معماری، هیچ قانون پیشنهادی توسط هوش مصنوعی بدون تایید صریح انسان در دفتر کل عملیاتی فعال نخواهد شد.'
              : 'Architectural Invariant: No AI-suggested rule can be enacted into production without explicit human supervisor sign-off.'}
          </p>

          <div className="space-y-3">
            {pendingRules.map((rule) => (
              <div
                key={rule.id}
                id={`pending-rule-${rule.id}`}
                className="bg-slate-900/90 border border-amber-500/20 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-amber-400">{rule.code}</span>
                    <span className="text-xs font-semibold text-white">{rule.titleFa || rule.title}</span>
                  </div>
                  <div className="text-xs text-slate-400 mt-1">{rule.description}</div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => handleReview(rule.id, true)}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>{isFa ? 'تایید و تصویب' : 'Approve'}</span>
                  </button>
                  <button
                    onClick={() => handleReview(rule.id, false)}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-rose-900 text-slate-300 hover:text-rose-200 text-xs font-semibold transition"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>{isFa ? 'رد' : 'Reject'}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Approved Active Rules Grid */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{isFa ? 'قوانین فعال و مصوب حسابداری' : 'Active Approved Rules Matrix'}</span>
          </h3>
          <span className="text-xs text-slate-400">{approvedRules.length} Production Rules</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {approvedRules.map((r) => (
            <div
              key={r.id}
              id={`rule-${r.id}`}
              className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-mono font-bold text-teal-400 bg-teal-500/10 px-2 py-0.5 rounded">
                    {r.code}
                  </span>
                  <span className="text-[10px] uppercase font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                    {r.ruleType}
                  </span>
                </div>
                <div className="text-xs font-bold text-slate-100 mb-1">{r.titleFa || r.title}</div>
                <p className="text-xs text-slate-400 mb-3">{r.description}</p>
              </div>

              <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-500 font-mono flex items-center justify-between">
                <span>Confidence: {((r.confidenceScore || 1) * 100).toFixed(0)}%</span>
                <span>v{r.version}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modal: Propose Rule */}
      {showProposeModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Plus className="w-5 h-5 text-emerald-400" />
                <span>{isFa ? 'پیشنهاد قانون حسابداری جدید' : 'Propose Accounting Rule'}</span>
              </h3>
              <button onClick={() => setShowProposeModal(false)} className="text-slate-400 hover:text-slate-200">
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">{isFa ? 'عنوان قانون (فارسی):' : 'Title (Persian):'}</label>
                <input
                  type="text"
                  value={newTitleFa}
                  onChange={(e) => setNewTitleFa(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100"
                />
              </div>
              <div>
                <label className="block text-slate-300 mb-1">{isFa ? 'عنوان انگلیسی:' : 'English Title:'}</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100"
                />
              </div>
              <div>
                <label className="block text-slate-300 mb-1">{isFa ? 'نوع قانون:' : 'Rule Type:'}</label>
                <select
                  value={newType}
                  onChange={(e) => setNewType(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100"
                >
                  <option value="vat">VAT (ارزش افزوده)</option>
                  <option value="depreciation">Depreciation (استهلاک)</option>
                  <option value="payroll_withholding">Payroll Tax (مالیات حقوق)</option>
                  <option value="inventory_cogs">COGS FIFO (بهای تمام شده)</option>
                  <option value="custom">Custom (سفارشی)</option>
                </select>
              </div>
              <div>
                <label className="block text-slate-300 mb-1">{isFa ? 'توضیحات و رفتار قانون:' : 'Description:'}</label>
                <textarea
                  rows={2}
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
              <button onClick={() => setShowProposeModal(false)} className="px-3 py-1.5 rounded-lg text-xs text-slate-400">
                {isFa ? 'انصراف' : 'Cancel'}
              </button>
              <button
                onClick={handlePropose}
                className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition"
              >
                {isFa ? 'ارسال به صف تایید' : 'Submit Proposal'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
