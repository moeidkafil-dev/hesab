import React, { useState } from 'react';
import {
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Activity,
  Layers,
  ArrowRight,
  TrendingUp,
  Cpu,
} from 'lucide-react';
import { verifyWithCritic } from '../api.js';
import { CriticResult } from '../types.js';

interface CriticQAViewProps {
  lang: 'fa' | 'en';
}

export const CriticQAView: React.FC<CriticQAViewProps> = ({ lang }) => {
  const isFa = lang === 'fa';
  const [desc, setDesc] = useState('خرید سرورهای ابری و سخت‌افزار با مبلغ بالا');
  const [debitAmount, setDebitAmount] = useState(150000000);
  const [creditAmount, setCreditAmount] = useState(150000000);
  const [testing, setTesting] = useState(false);
  const [result, setResult] = useState<CriticResult | null>(null);

  const handleTestCandidate = async () => {
    setTesting(true);
    try {
      const res = await verifyWithCritic(desc, [
        { accountId: 'acc_equipment', debit: debitAmount, credit: 0 },
        { accountId: 'acc_cash', debit: 0, credit: creditAmount },
      ]);
      setResult(res);
    } catch (err) {
      console.error(err);
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">
              {isFa ? 'عامل کنترل نهایی و بازرس کیفیت (Final Checker Critic Agent - n8)' : 'Final Checker QA Critic Agent (n8)'}
            </h2>
            <p className="text-xs text-slate-400">
              {isFa
                ? 'راستی‌آزمایی ۴ سطحی: تطابق ساختاری دوبل، اعتبارسنجی ارجاعات دیتابیس، تشخیص آماری ناهنجاری (Z-Score) و تصمیم‌گیری نهایی'
                : '4-Layer Verification: Structural math identity, DB referential check, statistical Z-score outlier detection, and disposition routing'}
            </p>
          </div>
        </div>
      </div>

      {/* 4 Layers Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs font-mono font-bold text-teal-400 mb-1">Layer 1</div>
          <div className="text-sm font-bold text-slate-100 mb-1">
            {isFa ? 'اعتبارسنجی ساختاری' : 'Structural Math Identity'}
          </div>
          <div className="text-xs text-slate-400">
            {isFa ? 'برابری جبری مجموع بدهکار با بستانکار (Debit == Credit)' : 'Closed-form equality: Sum(Debit) = Sum(Credit)'}
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs font-mono font-bold text-indigo-400 mb-1">Layer 2</div>
          <div className="text-sm font-bold text-slate-100 mb-1">
            {isFa ? 'بررسی ارجاعی متقابل' : 'Cross-Referential DB Check'}
          </div>
          <div className="text-xs text-slate-400">
            {isFa ? 'تطابق با کدینگ رسمی حساب‌ها در دیتابیس معتبر' : 'Verification against authoritative Chart of Accounts'}
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs font-mono font-bold text-amber-400 mb-1">Layer 3</div>
          <div className="text-sm font-bold text-slate-100 mb-1">
            {isFa ? 'تشخیص آماری ناهنجاری' : 'Statistical Z-Score Filter'}
          </div>
          <div className="text-xs text-slate-400">
            {isFa ? 'سنجش انحراف از میانگین تراکنش‌های تاریخی (Z > 3.0)' : 'Outlier detection vs. historical transaction distribution'}
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs font-mono font-bold text-emerald-400 mb-1">Layer 4</div>
          <div className="text-sm font-bold text-slate-100 mb-1">
            {isFa ? 'تلفیق اطمینان و مسیریابی' : 'Confidence & Routing'}
          </div>
          <div className="text-xs text-slate-400">
            {isFa ? 'انتشار خودکار / ارجاع به ناظر انسانی / رد قطعی' : 'Auto-release / Escalate to Human / Reject'}
          </div>
        </div>
      </div>

      {/* Interactive Candidate Verification Test Bench */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Activity className="w-4 h-4 text-emerald-400" />
          <span>{isFa ? 'میز آزمایش و بازرسی سند کاندید (Critic Test Bench)' : 'Candidate Voucher Verification Bench'}</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="md:col-span-3">
            <label className="block text-xs font-medium text-slate-300 mb-1">{isFa ? 'شرح سند:' : 'Voucher Description:'}</label>
            <input
              type="text"
              value={desc}
              onChange={(e) => setDesc(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-100"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">{isFa ? 'مبلغ بدهکار (ریال):' : 'Debit Amount:'}</label>
            <input
              type="number"
              value={debitAmount}
              onChange={(e) => setDebitAmount(Number(e.target.value) || 0)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-100 font-mono"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">{isFa ? 'مبلغ بستانکار (ریال):' : 'Credit Amount:'}</label>
            <input
              type="number"
              value={creditAmount}
              onChange={(e) => setCreditAmount(Number(e.target.value) || 0)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-100 font-mono"
            />
          </div>
          <div className="flex items-end">
            <button
              id="run-critic-check-btn"
              onClick={handleTestCandidate}
              disabled={testing}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-emerald-600/20 transition"
            >
              {testing ? (isFa ? 'در حال بازرسی...' : 'Inspecting...') : isFa ? 'اجرای بازرسی ۴ سطحی منتقد' : 'Run 4-Layer Inspection'}
            </button>
          </div>
        </div>

        {/* Inspection Report */}
        {result && (
          <div className="mt-4 p-5 bg-slate-950 border border-slate-800 rounded-xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <span
                  className={`text-xs px-3 py-1 rounded-full font-bold uppercase ${
                    result.disposition === 'auto_release'
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : result.disposition === 'escalate_to_human'
                      ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                      : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                  }`}
                >
                  Disposition: {result.disposition}
                </span>
                <span className="text-xs text-slate-300 font-medium">
                  {result.layers.layer4_confidenceAggregation.rationale}
                </span>
              </div>
              <div className="text-sm font-black font-mono text-emerald-400">
                Score: {result.score}/100
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-slate-300">Layer 1: Structural</span>
                  {result.layers.layer1_structural.passed ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <XCircle className="w-4 h-4 text-rose-400" />
                  )}
                </div>
                <p className="text-slate-400 text-[11px]">{result.layers.layer1_structural.details}</p>
              </div>

              <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-slate-300">Layer 2: Cross-Ref</span>
                  {result.layers.layer2_crossReferential.passed ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <XCircle className="w-4 h-4 text-rose-400" />
                  )}
                </div>
                <p className="text-slate-400 text-[11px]">{result.layers.layer2_crossReferential.details}</p>
              </div>

              <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-slate-300">Layer 3: Z-Score</span>
                  {result.layers.layer3_historicalStatistical.passed ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-amber-400" />
                  )}
                </div>
                <p className="text-slate-400 text-[11px]">
                  Z: {result.layers.layer3_historicalStatistical.zScore} — {result.layers.layer3_historicalStatistical.details}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
