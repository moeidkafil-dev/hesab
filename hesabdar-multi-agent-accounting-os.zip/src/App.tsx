/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Navbar } from './components/Navbar.js';
import { CommandCenter } from './components/CommandCenter.js';
import { LedgerView } from './components/LedgerView.js';
import { FinancialReportsView } from './components/FinancialReportsView.js';
import { DomainRulesView } from './components/DomainRulesView.js';
import { CriticQAView } from './components/CriticQAView.js';
import { MemoryMatrixView } from './components/MemoryMatrixView.js';
import { CryptoAuditView } from './components/CryptoAuditView.js';
import { ToolsSandboxView } from './components/ToolsSandboxView.js';
import { GraphMLMapView } from './components/GraphMLMapView.js';
import { StandardsKnowledgeView } from './components/StandardsKnowledgeView.js';
import { ResilienceView } from './components/ResilienceView.js';

import {
  fetchSystemStatus,
  fetchAccounts,
  fetchVouchers,
  fetchTrialBalance,
  fetchFinancialReports,
  fetchRules,
  fetchMemories,
  fetchMemoryStats,
  fetchAuditChain,
  verifyChainIntegrity,
  fetchDiagnostics,
  fetchSnapshots,
  createSnapshot,
  fetchGraphMLNodes,
  fetchKnowledgeArticles,
  fetchAgents,
} from './api.js';

import {
  SystemStatus,
  AccountItem,
  JournalVoucherItem,
  FinancialReportsData,
  RuleItem,
  MemoryItem,
  SignedMessageItem,
  DiagnosticsReport,
  SnapshotItem,
  GraphMLNode,
  KnowledgeArticle,
  AgentIdentity,
} from './types.js';

export default function App() {
  const [lang, setLang] = useState<'fa' | 'en'>('fa');
  const [activeTab, setActiveTab] = useState<string>('command');
  const [loading, setLoading] = useState(true);

  // System Core States
  const [status, setStatus] = useState<SystemStatus | null>(null);
  const [agents, setAgents] = useState<AgentIdentity[]>([]);
  const [accounts, setAccounts] = useState<AccountItem[]>([]);
  const [vouchers, setVouchers] = useState<JournalVoucherItem[]>([]);
  const [trialBalance, setTrialBalance] = useState<any>(null);
  const [reports, setReports] = useState<FinancialReportsData | null>(null);
  const [rules, setRules] = useState<RuleItem[]>([]);
  const [memories, setMemories] = useState<MemoryItem[]>([]);
  const [memoryStats, setMemoryStats] = useState<any>(null);
  const [auditChain, setAuditChain] = useState<SignedMessageItem[]>([]);
  const [chainIntegrity, setChainIntegrity] = useState<any>(null);
  const [diagnostics, setDiagnostics] = useState<DiagnosticsReport | null>(null);
  const [snapshots, setSnapshots] = useState<SnapshotItem[]>([]);
  const [graphmlNodes, setGraphmlNodes] = useState<GraphMLNode[]>([]);
  const [knowledgeArticles, setKnowledgeArticles] = useState<KnowledgeArticle[]>([]);

  const loadAllData = useCallback(async () => {
    try {
      const [
        sData,
        agData,
        accData,
        vData,
        tbData,
        repData,
        rData,
        mData,
        mStatData,
        chainData,
        integData,
        diagData,
        snapData,
        nodesData,
        knowData,
      ] = await Promise.all([
        fetchSystemStatus(),
        fetchAgents(),
        fetchAccounts(),
        fetchVouchers(),
        fetchTrialBalance(),
        fetchFinancialReports(),
        fetchRules(),
        fetchMemories(),
        fetchMemoryStats(),
        fetchAuditChain(),
        verifyChainIntegrity(),
        fetchDiagnostics(),
        fetchSnapshots(),
        fetchGraphMLNodes(),
        fetchKnowledgeArticles(),
      ]);

      setStatus(sData);
      setAgents(agData.agents || []);
      setAccounts(accData.accounts || []);
      setVouchers(vData.vouchers || []);
      setTrialBalance(tbData);
      setReports(repData);
      setRules(rData.rules || []);
      setMemories(mData.memories || []);
      setMemoryStats(mStatData);
      setAuditChain(chainData.chain || []);
      setChainIntegrity(integData);
      setDiagnostics(diagData);
      setSnapshots(snapData.snapshots || []);
      setGraphmlNodes(nodesData.nodes || []);
      setKnowledgeArticles(knowData.articles || []);
    } catch (err) {
      console.error('Failed to load system data:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAllData();
  }, [loadAllData]);

  const handleQuickSnapshot = async () => {
    try {
      await createSnapshot(lang === 'fa' ? 'اسنپ‌شات سریع نوار وضعیت' : 'Header Quick Snapshot');
      loadAllData();
    } catch (err) {
      console.error(err);
    }
  };

  const isRtl = lang === 'fa';

  return (
    <div
      dir={isRtl ? 'rtl' : 'ltr'}
      className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-emerald-500 selection:text-slate-950"
    >
      <Navbar
        status={status}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        lang={lang}
        setLang={setLang}
        onSnapshot={handleQuickSnapshot}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'command' && (
          <CommandCenter
            status={status}
            agents={agents}
            lang={lang}
            onVoucherCreated={loadAllData}
          />
        )}

        {activeTab === 'ledger' && (
          <LedgerView
            accounts={accounts}
            vouchers={vouchers}
            trialBalance={trialBalance}
            lang={lang}
            onRefresh={loadAllData}
          />
        )}

        {activeTab === 'reports' && (
          <FinancialReportsView
            reports={reports}
            lang={lang}
            loading={loading}
            onRefresh={loadAllData}
          />
        )}

        {activeTab === 'domain' && (
          <DomainRulesView
            rules={rules}
            lang={lang}
            onRefresh={loadAllData}
          />
        )}

        {activeTab === 'critic' && (
          <CriticQAView lang={lang} />
        )}

        {activeTab === 'memory' && (
          <MemoryMatrixView
            memories={memories}
            stats={memoryStats}
            lang={lang}
            onRefresh={loadAllData}
          />
        )}

        {activeTab === 'crypto' && (
          <CryptoAuditView
            auditChain={auditChain}
            integrity={chainIntegrity}
            lang={lang}
            onRefresh={loadAllData}
          />
        )}

        {activeTab === 'tools' && (
          <ToolsSandboxView lang={lang} />
        )}

        {activeTab === 'graphml' && (
          <GraphMLMapView
            nodes={graphmlNodes}
            lang={lang}
          />
        )}

        {activeTab === 'knowledge' && (
          <StandardsKnowledgeView
            articles={knowledgeArticles}
            lang={lang}
          />
        )}

        {activeTab === 'resilience' && (
          <ResilienceView
            diagnostics={diagnostics}
            snapshots={snapshots}
            lang={lang}
            onRefresh={loadAllData}
          />
        )}
      </main>

      {/* Modern Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 py-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>
            {lang === 'fa'
              ? 'سیستم عامل حسابدار چندعاملی (Hesabdar OS) • منطبق با معماری ۳۵۰ نود حسابدار.graphml'
              : 'Hesabdar Multi-Agent Accounting OS • Strict 350-Node GraphML Architectural Compliance'}
          </span>
          <span className="font-mono text-slate-600">
            SHA-256 Haber Chain Height: {status?.counts?.auditChainHeight || 0}
          </span>
        </div>
      </footer>
    </div>
  );
}
