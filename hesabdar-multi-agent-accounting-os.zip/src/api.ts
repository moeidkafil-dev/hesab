import {
  SystemStatus,
  AgentIdentity,
  MemoryItem,
  SignedMessageItem,
  AccountItem,
  JournalVoucherItem,
  RuleItem,
  CriticResult,
  FinancialReportsData,
  ArchitectureNodeItem,
  ArchitectureChapterItem,
  GraphMLNode,
  KnowledgeArticle,
  DiagnosticsReport,
  SnapshotItem,
} from './types.js';

export async function fetchSystemStatus(): Promise<SystemStatus> {
  const res = await fetch('/api/status');
  if (!res.ok) throw new Error('Failed to fetch status');
  return res.json();
}

export async function executeCEOPrompt(prompt: string): Promise<any> {
  const res = await fetch('/api/ceo/prompt', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt }),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to execute prompt');
  }
  return res.json();
}

export async function fetchAgents(): Promise<{ agents: AgentIdentity[] }> {
  const res = await fetch('/api/ceo/agents');
  if (!res.ok) throw new Error('Failed to fetch agents');
  return res.json();
}

export async function provisionAgent(agentId: string, role: string, capabilities: string[]): Promise<any> {
  const res = await fetch('/api/ceo/agents/provision', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ agentId, role, capabilities }),
  });
  return res.json();
}

export async function retireAgent(agentId: string, notes: string): Promise<any> {
  const res = await fetch('/api/ceo/agents/retire', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ agentId, notes }),
  });
  return res.json();
}

export async function fetchMemories(filter?: {
  scope?: string;
  memoryType?: string;
  family?: string;
  tag?: string;
  minImportance?: number;
}): Promise<{ memories: MemoryItem[] }> {
  const query = new URLSearchParams();
  if (filter?.scope) query.set('scope', filter.scope);
  if (filter?.memoryType) query.set('memoryType', filter.memoryType);
  if (filter?.family) query.set('family', filter.family);
  if (filter?.tag) query.set('tag', filter.tag);
  if (filter?.minImportance) query.set('minImportance', String(filter.minImportance));

  const res = await fetch(`/api/memory?${query.toString()}`);
  if (!res.ok) throw new Error('Failed to fetch memories');
  return res.json();
}

export async function writeMemory(scope: string, memoryType: string, content: any, tags: string[], importance: number): Promise<any> {
  const res = await fetch('/api/memory/write', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ scope, memoryType, content, tags, importance }),
  });
  return res.json();
}

export async function runMemoryMaintenance(): Promise<any> {
  const res = await fetch('/api/memory/maintenance', { method: 'POST' });
  return res.json();
}

export async function fetchMemoryStats(): Promise<any> {
  const res = await fetch('/api/memory/stats');
  return res.json();
}

export async function fetchAuditChain(): Promise<{ chain: SignedMessageItem[]; integrity: any }> {
  const res = await fetch('/api/messaging/audit-chain');
  if (!res.ok) throw new Error('Failed to fetch audit chain');
  return res.json();
}

export async function verifyChainIntegrity(): Promise<any> {
  const res = await fetch('/api/messaging/verify-chain');
  if (!res.ok) throw new Error('Failed to verify chain');
  return res.json();
}

export async function sendSignedMessage(senderId: string, recipientId: string, payload: any): Promise<any> {
  const res = await fetch('/api/messaging/send', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ senderId, recipientId, payload }),
  });
  return res.json();
}

export async function fetchToolGrants(): Promise<any[]> {
  const res = await fetch('/api/tools/grants');
  return res.json();
}

export async function fetchToolLogs(): Promise<any[]> {
  const res = await fetch('/api/tools/logs');
  return res.json();
}

export async function executeTool(toolName: string, params: any, agentId: string = 'CEO_Supervisor'): Promise<any> {
  const res = await fetch('/api/tools/execute', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ agentId, toolName, params }),
  });
  return res.json();
}

export async function fetchAccounts(): Promise<{ accounts: AccountItem[] }> {
  const res = await fetch('/api/ledger/accounts');
  if (!res.ok) throw new Error('Failed to fetch accounts');
  return res.json();
}

export async function createAccount(account: Partial<AccountItem>): Promise<any> {
  const res = await fetch('/api/ledger/accounts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(account),
  });
  return res.json();
}

export async function fetchVouchers(): Promise<{ vouchers: JournalVoucherItem[] }> {
  const res = await fetch('/api/ledger/vouchers');
  if (!res.ok) throw new Error('Failed to fetch vouchers');
  return res.json();
}

export async function postVoucher(voucher: {
  date: string;
  description: string;
  lines: Array<{ accountId: string; debit: number; credit: number; description?: string }>;
  createdByAgent?: string;
  ruleMatched?: string;
}): Promise<any> {
  const res = await fetch('/api/ledger/post', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(voucher),
  });
  return res.json();
}

export async function fetchTrialBalance(): Promise<any> {
  const res = await fetch('/api/ledger/trial-balance');
  return res.json();
}

export async function fetchRules(): Promise<{ rules: RuleItem[] }> {
  const res = await fetch('/api/domain/rules');
  if (!res.ok) throw new Error('Failed to fetch rules');
  return res.json();
}

export async function classifyTransaction(description: string, amount?: number, date?: string): Promise<any> {
  const res = await fetch('/api/domain/classify', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ description, amount, date }),
  });
  return res.json();
}

export async function reviewRule(ruleId: string, approve: boolean, reviewer?: string): Promise<any> {
  const res = await fetch('/api/domain/rules/review', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ruleId, approve, reviewer }),
  });
  return res.json();
}

export async function proposeRule(rule: Partial<RuleItem>): Promise<any> {
  const res = await fetch('/api/domain/rules/propose', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(rule),
  });
  return res.json();
}

export async function verifyWithCritic(description: string, lines: any[]): Promise<CriticResult> {
  const res = await fetch('/api/critic/verify', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ description, lines }),
  });
  return res.json();
}

export async function fetchFinancialReports(): Promise<FinancialReportsData> {
  const res = await fetch('/api/reports/financial');
  if (!res.ok) throw new Error('Failed to fetch financial reports');
  return res.json();
}

export async function fetchKnowledgeArticles(): Promise<{ articles: KnowledgeArticle[] }> {
  const res = await fetch('/api/knowledge/articles');
  return res.json();
}

export async function searchKnowledge(query: string): Promise<{ results: KnowledgeArticle[]; aiExplanation?: string }> {
  const res = await fetch('/api/knowledge/research', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query }),
  });
  return res.json();
}

export async function queryKnowledge(query: string): Promise<any> {
  return searchKnowledge(query);
}

export async function fetchDiagnostics(): Promise<DiagnosticsReport> {
  const res = await fetch('/api/resilience/diagnostics');
  return res.json();
}

export async function runDiagnostics(): Promise<DiagnosticsReport> {
  const res = await fetch('/api/resilience/diagnostics/run', { method: 'POST' });
  return res.json();
}

export async function runAutoRepair(): Promise<any> {
  const res = await fetch('/api/resilience/auto-repair', { method: 'POST' });
  return res.json();
}

export async function fetchSnapshots(): Promise<{ snapshots: SnapshotItem[] }> {
  const res = await fetch('/api/resilience/snapshots');
  return res.json();
}

export async function createSnapshot(label?: string): Promise<any> {
  const res = await fetch('/api/resilience/snapshots', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ label }),
  });
  return res.json();
}

export async function restoreSnapshot(snapshotId: string): Promise<any> {
  const res = await fetch('/api/resilience/snapshots/restore', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ snapshotId }),
  });
  return res.json();
}

export async function fetchGraphMLNodes(): Promise<{ nodes: GraphMLNode[]; total: number }> {
  const res = await fetch('/api/graphml/nodes');
  return res.json();
}
