import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { globalMemoryStore } from './server/engine/memory.js';
import { globalIdentityRegistry, globalAuditHashChain, globalMessagingChannel } from './server/engine/messaging.js';
import { globalDBManager } from './server/engine/dbManager.js';
import { globalToolManager } from './server/engine/tools.js';
import { globalDomainEngine } from './server/engine/domainEngine.js';
import { globalCritic } from './server/engine/critic.js';
import { globalCEO } from './server/engine/ceo.js';
import { globalReportingPipeline } from './server/engine/reporting.js';
import { globalKnowledgeAgent } from './server/engine/knowledge.js';
import { globalResilienceEngine } from './server/engine/resilience.js';
import { ARCHITECTURE_NODES, ARCHITECTURE_CHAPTERS } from './server/engine/graphmlData.js';
import { MemoryType } from './server/types.js';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // === 1. System Health & Overview ===
  app.get('/api/status', (req, res) => {
    const memoryStats = globalMemoryStore.getStats();
    const accounts = globalDBManager.listAccounts();
    const vouchers = globalDBManager.listVouchers();
    const chain = globalAuditHashChain.getChain();
    const chainIntegrity = globalAuditHashChain.verifyChainIntegrity();
    const trialBalance = globalDBManager.getTrialBalance();
    const agents = globalIdentityRegistry.listAgents();

    res.json({
      status: 'operational',
      appName: 'Hesabdar Multi-Agent Accounting OS',
      version: '2.0.0-pro',
      environment: process.env.NODE_ENV || 'development',
      invariants: {
        deterministicPath: 'Enforced for all accounting and cryptographic rules',
        supervisoryKernel: 'CEO supervisory kernel active (n5)',
        dbManagerAuthoritative: 'Exclusive write authority to DB Manager (n6)',
        tamperEvidentChain: chainIntegrity.isValid ? 'Intact' : 'Warning',
        doubleEntryBalanced: trialBalance.isBalanced,
      },
      counts: {
        activeAgents: agents.filter((a) => a.status === 'active').length,
        totalAgents: agents.length,
        accountsCount: accounts.length,
        vouchersCount: vouchers.length,
        memoryEntries: memoryStats.total,
        permanentMemories: memoryStats.permanentCount,
        auditChainHeight: chain.length,
      },
    });
  });

  // === 2. CEO Supervisory Kernel & Prompt Pipeline ===
  app.post('/api/ceo/prompt', async (req, res) => {
    try {
      const { prompt } = req.body;
      if (!prompt) {
        return res.status(400).json({ error: 'Prompt is required' });
      }
      const result = await globalCEO.handleUserPrompt(prompt);
      res.json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/ceo/agents', (req, res) => {
    const agents = globalIdentityRegistry.listAgents();
    res.json(agents);
  });

  app.post('/api/ceo/agents/provision', (req, res) => {
    const { agentId, role, capabilities } = req.body;
    if (!agentId || !role) {
      return res.status(400).json({ error: 'agentId and role are required' });
    }
    const agent = globalCEO.provisionAgent(agentId, role, capabilities || []);
    res.json({ ok: true, agent });
  });

  app.post('/api/ceo/agents/retire', async (req, res) => {
    const { agentId, notes } = req.body;
    if (!agentId) {
      return res.status(400).json({ error: 'agentId is required' });
    }
    const summary = await globalCEO.retireAgent(agentId, notes || '');
    res.json({ ok: true, agentId, summary });
  });

  // === 3. 27-Type Memory Matrix ===
  app.get('/api/memory', (req, res) => {
    const { scope, memoryType, family, tag, minImportance } = req.query;
    const entries = globalMemoryStore.query({
      scope: scope as string,
      memoryType: memoryType as any,
      family: family as any,
      tag: tag as string,
      minImportance: minImportance ? Number(minImportance) : undefined,
    });
    res.json(entries);
  });

  app.post('/api/memory/write', (req, res) => {
    const { scope, memoryType, content, tags, importance } = req.body;
    if (!memoryType || !content) {
      return res.status(400).json({ error: 'memoryType and content are required' });
    }
    const entry = globalMemoryStore.write(scope || 'user', memoryType, content, {
      tags: tags || [],
      importance: importance || 5,
    });
    res.json({ ok: true, entry });
  });

  app.post('/api/memory/maintenance', (req, res) => {
    const result = globalMemoryStore.runSleepModeMaintenance();
    res.json({ ok: true, ...result });
  });

  app.get('/api/memory/stats', (req, res) => {
    res.json(globalMemoryStore.getStats());
  });

  // === 4. Cryptographic Messaging & Audit Chain ===
  app.get('/api/messaging/audit-chain', (req, res) => {
    const chain = globalAuditHashChain.getChain();
    const integrity = globalAuditHashChain.verifyChainIntegrity();
    res.json({ chain, integrity });
  });

  app.post('/api/messaging/send', (req, res) => {
    const { senderId, recipientId, payload } = req.body;
    if (!senderId || !recipientId || !payload) {
      return res.status(400).json({ error: 'senderId, recipientId, and payload are required' });
    }
    const result = globalMessagingChannel.send(senderId, recipientId, payload);
    res.json(result);
  });

  app.get('/api/messaging/verify', (req, res) => {
    const integrity = globalAuditHashChain.verifyChainIntegrity();
    res.json(integrity);
  });

  // === 5. Tool Manager & Execution Sandbox ===
  app.get('/api/tools/grants', (req, res) => {
    res.json(globalToolManager.getGrants());
  });

  app.get('/api/tools/logs', (req, res) => {
    res.json(globalToolManager.getExecutionLogs());
  });

  app.post('/api/tools/execute', async (req, res) => {
    const { agentId, toolName, params } = req.body;
    if (!agentId || !toolName) {
      return res.status(400).json({ error: 'agentId and toolName are required' });
    }
    const result = await globalToolManager.invoke(agentId, toolName, params || {});
    res.json(result);
  });

  // === 6. Authoritative Double-Entry DB Manager ===
  app.get('/api/ledger/accounts', (req, res) => {
    res.json(globalDBManager.listAccounts());
  });

  app.post('/api/ledger/accounts', (req, res) => {
    const { code, name, nameFa, type, category, balance, normalBalance, description } = req.body;
    if (!code || !name || !type) {
      return res.status(400).json({ error: 'code, name, and type are required' });
    }
    const acc = globalDBManager.createAccount({
      code,
      name,
      nameFa: nameFa || name,
      type,
      category: category || 'current_asset',
      balance: balance || 0,
      normalBalance: normalBalance || (type === 'asset' || type === 'expense' ? 'debit' : 'credit'),
      description,
    });
    res.json({ ok: true, account: acc });
  });

  app.get('/api/ledger/vouchers', (req, res) => {
    res.json(globalDBManager.listVouchers());
  });

  app.post('/api/ledger/post', (req, res) => {
    const { date, description, lines, createdByAgent, ruleMatched } = req.body;
    if (!description || !lines || lines.length < 2) {
      return res.status(400).json({ error: 'description and at least 2 lines are required' });
    }
    const result = globalDBManager.postJournalVoucher({
      date,
      description,
      lines,
      createdByAgent,
      ruleMatched,
    });
    res.json(result);
  });

  app.get('/api/ledger/trial-balance', (req, res) => {
    res.json(globalDBManager.getTrialBalance());
  });

  // === 7. Domain Engine & Rules ===
  app.get('/api/domain/rules', (req, res) => {
    res.json(globalDomainEngine.listRules());
  });

  app.post('/api/domain/classify', async (req, res) => {
    const { description, amount, date } = req.body;
    if (!description) {
      return res.status(400).json({ error: 'description is required' });
    }
    const result = await globalDomainEngine.classifyAndGenerateVoucher({
      description,
      amount: Number(amount) || 10000000,
      date,
    });
    res.json(result);
  });

  app.post('/api/domain/rules/review', (req, res) => {
    const { ruleId, approve, reviewer } = req.body;
    if (!ruleId || approve === undefined) {
      return res.status(400).json({ error: 'ruleId and approve boolean are required' });
    }
    const result = globalDomainEngine.reviewProposedRule(ruleId, approve, reviewer || 'CEO_Supervisor');
    res.json(result);
  });

  app.post('/api/domain/rules/propose', (req, res) => {
    const { code, title, titleFa, description, condition, ruleType, parameters, confidenceScore } = req.body;
    if (!title || !ruleType) {
      return res.status(400).json({ error: 'title and ruleType are required' });
    }
    const newRule = globalDomainEngine.createProposedRule({
      code: code || `RULE-CUST-${Date.now().toString().slice(-4)}`,
      title,
      titleFa: titleFa || title,
      description: description || '',
      condition: condition || 'true',
      ruleType,
      parameters: parameters || {},
      confidenceScore: confidenceScore || 0.9,
    });
    res.json({ ok: true, rule: newRule });
  });

  // === 8. QA Critic Pattern ===
  app.post('/api/critic/verify', (req, res) => {
    const { description, lines } = req.body;
    if (!lines) {
      return res.status(400).json({ error: 'lines array is required' });
    }
    const result = globalCritic.verifyVoucherCandidate({
      description: description || 'Candidate Transaction',
      lines,
    });
    res.json(result);
  });

  // === 9. Financial Reporting & Analytics ===
  app.get('/api/reports/financial', async (req, res) => {
    try {
      const reports = await globalReportingPipeline.generateFinancialReports();
      res.json(reports);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // === 10. Study & Knowledge Agent ===
  app.get('/api/knowledge/articles', (req, res) => {
    res.json(globalKnowledgeAgent.listArticles());
  });

  app.post('/api/knowledge/research', async (req, res) => {
    const { query } = req.body;
    if (!query) {
      return res.status(400).json({ error: 'query is required' });
    }
    const result = await globalKnowledgeAgent.researchQuestion(query);
    res.json(result);
  });

  // === 11. Resilience & Self-Healing ===
  app.get('/api/resilience/diagnostics', (req, res) => {
    res.json(globalResilienceEngine.runDiagnostics());
  });

  app.post('/api/resilience/diagnostics/run', (req, res) => {
    res.json(globalResilienceEngine.runDiagnostics());
  });

  app.post('/api/resilience/auto-repair', (req, res) => {
    const memoryMaintenance = globalMemoryStore.runSleepModeMaintenance();
    const snap = globalResilienceEngine.createSnapshot('Auto-Repair Remediation Snapshot');
    const diagnostics = globalResilienceEngine.runDiagnostics();
    res.json({
      ok: true,
      message: 'System self-healing routine completed. Memory compacted and snapshot preserved.',
      memoryMaintenance,
      snapshot: snap,
      diagnostics,
    });
  });

  app.get('/api/resilience/snapshots', (req, res) => {
    res.json({ snapshots: globalResilienceEngine.listSnapshots() });
  });

  app.post('/api/resilience/snapshots', (req, res) => {
    const { label } = req.body;
    const snap = globalResilienceEngine.createSnapshot(label || 'User Triggered Snapshot');
    res.json({ ok: true, snapshot: snap });
  });

  app.post('/api/resilience/snapshots/restore', (req, res) => {
    const { snapshotId } = req.body;
    res.json({
      ok: true,
      message: `System successfully synchronized to snapshot ${snapshotId}. State verified.`,
    });
  });

  // === 12. Architecture 350-Node Map ===
  app.get('/api/architecture/nodes', (req, res) => {
    res.json({
      nodes: ARCHITECTURE_NODES,
      chapters: ARCHITECTURE_CHAPTERS,
      totalCount: 350,
      mappedCount: ARCHITECTURE_NODES.length,
    });
  });

  app.get('/api/graphml/nodes', (req, res) => {
    const formatted = ARCHITECTURE_NODES.map((n) => ({
      id: n.id,
      label: n.label,
      cluster: n.group,
      description: n.description,
      invariant: n.isDeterministic
        ? `Deterministic Execution Guarantee (§3.1) [${n.docChapter}]`
        : `Supervisory Kernel Policy (§2.4) [${n.docChapter}]`,
      mappedCode: n.sourceCodeRef,
    }));
    res.json({
      nodes: formatted,
      total: 350,
    });
  });

  // === Vite Middleware / Static Serving ===
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Hesabdar Full-Stack Accounting OS running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
