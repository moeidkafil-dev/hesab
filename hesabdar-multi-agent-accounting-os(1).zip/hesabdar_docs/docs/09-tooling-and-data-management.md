# 09. Tooling and Data Management

## 9.1 The Execution Sandbox (n3)

The `tools` group enumerates the concrete means by which any agent in the system touches the outside world: spreadsheet manipulation (`excel command maker`, `excel vbs maker`, and the associated file read/write/make triad), shell execution (`bash command maker → bash compiler → bash runner`), web interaction (`chrome researcher`, `page html exporter`, `chrome reader`), external API access (`api user`, `curl system`), and general filesystem operations (`file maker/reader/deleter/changer runner`), all mediated through a single `tool manager` rather than invoked directly by individual agents.

**Why mediation matters here specifically.** Every one of these tools is capable of an irreversible or high-impact action — `bash runner` can execute arbitrary shell commands; `file deleter` can destroy data; `excel file writer` can silently corrupt a client's own working spreadsheet. Routing all of them through `tool manager` is what makes it architecturally possible to apply a single, consistent authorization policy (§7.3) across every tool a given agent is permitted to invoke, rather than needing to separately secure eighteen different execution surfaces. This is the same "narrow waist" discipline noted in §2.3 applied to the system's effectful boundary rather than its decision boundary: a small number of well-audited chokepoints, rather than many independently-secured edges.

## 9.2 The Database Manager Agent (n6)

```
messages receiver → messages compile → messages reader → messages analyser
→ executor → DB analyser → DB Situation analyser → DB log maker
→ result maker → log maker → result sender → log sender
```

This subsystem is the sole authorized writer to the production database (`n12::n8`), consistent with the CEO-mediated pattern established elsewhere: every other agent that needs to persist state does so by sending a message through the authenticated transport layer (§7) to the DB Manager Agent, rather than holding direct database credentials itself. This is a standard and well-justified security pattern (a single, narrowly-scoped data-access service rather than broadly distributed credentials) — but it is worth stating explicitly *why* it matters more here than in a typical application: it is what makes the "database is the authoritative source of truth" convention from §4.3 actually enforceable in practice, rather than merely stated as policy. If multiple agents could write to the database directly, no single component could guarantee that the database reflects a consistent, sequenced history of decisions — the very property the Audit/History Memory (§3.2) and the audit-chaining mechanism (§7.5) depend on.

**`DB Situation analyser` as a distinct node from `DB analyser` deserves note.** The former appears, from its position in the pipeline (after `executor`, before `DB log maker`), to assess the *outcome* of an already-executed operation — did the write succeed, and did it leave the database in the state expected — as distinct from `DB analyser`'s role in informing the operation itself. This is a further, small-scale instance of the generator/critic separation (§4.4, §6.5): even a single database write is not treated as self-certifying.

## 9.3 The Data Ingestion Layer's Relationship to the Domain Engine

The `data input` group (`n1`: `data → data analyse → time analyse → DB analyse → data injecting → DB analyse → reassure → make log`) is the entry point through which external financial data reaches the system, prior to any of it reaching the Accounting Domain Engine (§5). Its `reassure` node — validating that ingested data is internally consistent before injection — functions as a first, coarse-grained gate ahead of the finer-grained, rule-specific validation the Domain Engine performs later; the two are complementary rather than redundant, operating at different levels of specificity and at different points in the pipeline.
