# 12. Glossary and Notation

## 12.1 Node-Reference Notation

Throughout this suite, a node in `حسابدار.graphml` is referenced by its internal identifier path, using `::` to indicate nesting within a group. For example, `n17::n4` refers to the node with local id `n4` inside the group with top-level id `n17` (*rule manager*), which this suite identifies by name as `transaction classifier`. Where a name is reused across multiple unrelated groups (a known, deliberate remnant of the diagram's iterative construction — see §12.3), the group qualifier disambiguates which specific instance is meant.

## 12.2 Core Terminology

**Agent** — An autonomous unit of reasoning and action within the system, typically backed by an LLM-driven planning loop (`llm → planner → schedule → plan checker → tool manager → tool executor`, the recurring pattern seen throughout `n5`), operating within resource and policy bounds set by the CEO (§4).

**Checkpoint** — A recorded point of task/stage progress, derived jointly from the retry counter (`n5::n10::n5`), the logging subsystem (§8.3), the memory architecture (§3), and the database — the last of which is the authoritative source when these disagree (§4.3).

**Critic** — A component whose sole responsibility is verifying an already-produced result against explicit criteria, structurally independent of the component that produced it (§6.1). Distinct from a **generator**, which produces the result under evaluation.

**Deterministic path** — Any decision path in the system that does not invoke a language model and whose output is a mechanical function of its input (§2.3). Contrasted with the **probabilistic path**.

**Domain Engine** — Shorthand used throughout this suite for the jointly-operating `Accounting Domain Engine` (`n16`) and `rule manager` (`n17`) subsystems, connected via `rules managers group` (`n18`); see §5.

**Rule library** — The set of accounting rules a client organization has authored and approved, stored in a form `rules loader` can read (§5.2), extensible by the client without a code change (§5.6).

**Source of truth** — The system-wide convention that, when the database and any other record of state (logs, memory, in-flight checkpoint counters) disagree, the database's record governs (§4.3).

## 12.3 A Note on Naming Consistency

Several node names recur with slightly different spellings or with identical names denoting functionally different nodes across different groups (for example, two distinct nodes both labeled `memory analyser` within `n13`, serving the write path and the maintenance path respectively — see §3.4). This suite resolves such ambiguity by always qualifying with the full group-qualified identifier when precision matters, and recommends — as a standing implementation note rather than an architectural one — that a future revision of the diagram itself adopt a consistent `[role] + [function] + (context)` naming convention throughout, so that a node's purpose is recoverable from its label alone, without requiring the group-path context this suite currently supplies.

## 12.4 Companion Repository Terminology

Terms specific to the messaging and security layer (`identity`, `authentication`, `integrity`, `authorization`, `HMAC`, `Ed25519`, `audit chain`) are defined in full, with formal notation, in the companion Agent Messenger repository's own specification and are used in §7 of this suite consistently with those definitions rather than being redefined here.
