# 05. The Accounting Domain Engine

## 5.1 Why This Subsystem Exists

Every other subsystem in this suite could, with modification, serve a different domain entirely — the memory taxonomy (§3), the orchestration kernel (§4), and the messaging layer (§7) are all domain-agnostic infrastructure. The Accounting Domain Engine — realized jointly across three cooperating node groups, `Accounting Domain Engine` (`n16`), `rule manager` (`n17`), and the connecting `rules managers group` (`n18`) — is the one subsystem whose entire purpose is to encode what makes this specifically an *accounting* system rather than a general-purpose research agent with a financial vocabulary. It is, accordingly, the subsystem a prospective enterprise customer's own accounting or audit staff will scrutinize most closely, and the one where an architectural shortcut is least forgivable.

## 5.2 The Deterministic Fast Path: `rule manager` (n17)

```
DB reader → researcher → rules maker → rules loader → transaction classifier
→ rule matcher → rule executor → self evaluation system
```

This pipeline embodies a **rule engine** in the sense long established in expert-systems and business-rules literature (Forgy's RETE algorithm, 1982, underlying production-rule engines from OPS5 through modern implementations such as Drools): accounting rules are represented as *data*, not as branching logic compiled into the agent's code, and a generic execution engine interprets them against each transaction.

**Rule provenance is layered, not monolithic.** `DB reader` is queried first: rules the client organization has already authored and approved are the primary source of truth. `researcher` and `rules maker` are invoked only when `DB reader` surfaces genuine ambiguity — no rule in the existing library unambiguously covers the transaction under consideration. This ordering is the direct implementation of the governing principle from §1.2: research augments an incomplete rule library; it does not substitute for one, and it is never the default path for a transaction the library already covers.

**Classification precedes matching for tractability.** `transaction classifier` exists so that `rule matcher` need only search the subset of rules relevant to the transaction's category (a purchase, a payroll disbursement, a depreciation event), rather than evaluating an organization's entire rule library — potentially numbering in the thousands of entries once a large enterprise's full policy set is encoded — against every transaction. This is a straightforward but necessary index-before-search discipline, without which the deterministic path's cost advantage over the research path (§4.5, rule 2) would erode as the rule library grows.

**`self evaluation system` closes the loop locally.** Distinct from the system-wide Critic pattern (§6), this node performs rule-engine-scoped self-checks — for instance, confirming that a matched rule's output type is consistent with what `transaction classifier` expected — before the result is allowed to leave the subsystem.

## 5.3 The Research Path: `Accounting Domain Engine` (n16)

```
data reader → research text maker → tool executer → result finder → result maker
→ knowledge DB → study → decision → evaluation check → result / log
```

This path is invoked precisely when §5.2's fast path finds no applicable rule. Two design features distinguish it from an undisciplined "let the model figure it out" fallback:

**Research output is durably captured, not discarded after use.** `result maker → knowledge DB → study` writes the outcome of each research episode into a persistent knowledge store *before* it informs the decision, so that structurally similar future transactions benefit from work already done — the same accumulate-then-reuse pattern the Memory Architecture (§3) uses for Learning and Experience Memory generally, applied here to the specific case of accounting-rule ambiguity.

**A research conclusion never becomes a production rule without human sign-off.** This is the single most important control in the entire Accounting Domain Engine, and it is worth stating with the precision the architecture's design review established: when `rules maker` (§5.2) or the research path (§5.3) produces a *candidate* rule to resolve an ambiguity, that candidate is routed — **through the CEO** (consistent with the CEO's general role as the system's sole channel to human oversight, §4.2) — as an alert to the human support/approval system. Only after explicit human approval does the candidate rule enter `rules loader` and become eligible to govern subsequent transactions; it is simultaneously written back to the approved rule database, so that the same ambiguity does not require re-research the next time it is encountered. This closes the system's most consequential trust boundary: **novel accounting judgment, once made, must be ratified by a human before it is trusted a second time.**

## 5.4 Connecting the Two Paths

`rules managers group` (`n18`) exists to join `n16` and `n17` into a single coherent decision process rather than leaving them as parallel, uncoordinated pipelines — an earlier revision of this architecture had precisely that gap, and its closure is recorded here as the resolution of a previously identified design risk. The intended control flow, stated explicitly because the diagram alone under-specifies it:

```
                    ┌─────────────────────────┐
transaction ──────► │ n17: transaction classifier │
                    └────────────┬────────────┘
                                 │
                    ┌────────────▼────────────┐
                    │   n17: rule matcher       │
                    └────────────┬────────────┘
                    match found? │ no match
              ┌──────────────────┴──────────────────┐
              ▼ yes                                  ▼
      n17: rule executor                    n16: research path (§5.3)
              │                                       │
              ▼                                       ▼
      n17: self evaluation                  n16: evaluation check
              │                                       │
              └──────────────────┬────────────────────┘
                                 ▼
                  n14: final checker agent (§6)
```

The fast path and the research path converge on a **single shared downstream verifier** (§6) — a matched-rule result is not exempted from independent quality assurance merely because it came from the deterministic branch, since the correctness of the rule library itself is only as good as the rules currently approved within it, and the Critic pattern of §6 provides a second, structurally independent check on that assumption.

## 5.5 Conflict Resolution Between Simultaneously Applicable Rules

A rule library of non-trivial size will eventually contain rules whose conditions both match a single transaction with conflicting prescriptions — the canonical example being a general threshold rule ("purchases under 10,000,000 require no additional approval") coexisting with a client-specific override ("all transactions with vendor X require approval regardless of amount"). The `rule executor` node is the natural point at which this is resolved, using the conservative resolution policy this architecture's design review established: **the most restrictive applicable outcome always prevails.** If any matched rule's prescription is "reject" or "require human approval," that prescription governs the transaction even if every other matched rule would have permitted it to proceed automatically. This policy trades a small amount of automation throughput for a substantial reduction in the probability that a legitimate constraint is silently overridden by a more permissive rule that happens to also match — an asymmetric error cost that, in a financial-compliance context, is the correct asymmetry to optimize for.

## 5.6 Extensibility by the Client Organization

Because rules are data rather than code (§5.2), a client organization can extend its own rule library — adding jurisdiction-specific statutory rules, industry-specific chart-of-accounts conventions, or internal-policy thresholds — without requiring a code change or redeployment on the vendor's part. This is the architectural feature that makes the "pre-sale, then customize per client" commercialization model (discussed in the business-facing materials accompanying this architecture) technically viable rather than aspirational: the customization surface is precisely the rule database `rules loader` reads from, not the engine that interprets it.
