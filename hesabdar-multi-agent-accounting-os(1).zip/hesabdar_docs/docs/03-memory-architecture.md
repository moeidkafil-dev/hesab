# 03. Memory Architecture

## 3.1 Why Memory Is Not a Single Thing

A common and costly simplification in agentic system design is to treat "memory" as a single undifferentiated store — typically a vector database — into which everything is written and from which everything is retrieved by similarity search. This conflates properties that are, in cognitive-architecture research, treated as fundamentally distinct: how long something should persist, how it should be indexed for retrieval, and what kind of information it holds are three independent design decisions, not one. Hesabdar's memory subsystem (`n4`, replicated per-agent-scope at `n5::n8` for the CEO and implicitly per specialized agent) instead adopts a **differentiated taxonomy of twenty-seven memory types**, directly modeled on the multi-store distinction that has structured cognitive architecture research since Atkinson & Shiffrin's (1968) original multi-store model of human memory, and elaborated through production-system architectures such as ACT-R (Anderson et al., 2004) and Soar (Laird, 2012), which likewise separate declarative, procedural, and working memory as architecturally distinct stores with different persistence and retrieval rules.

## 3.2 The Taxonomy

The twenty-seven memory types fall into five functional families:

**Temporal-span family** (how long information survives): Sensory Memory, Working Memory, Short-Term Memory (STM), Long-Term Memory (LTM), Temporal Memory. These mirror the classical distinction between fleeting perceptual buffers and durable storage.

**Content-type family** (what kind of information is held): Episodic Memory (specific past events), Semantic Memory (general accounting knowledge, independent of when it was learned), Procedural Memory (how to execute a task, as opposed to facts about the task).

**Task-management family**: Goal Memory, Task Memory, Planning Memory, Context Memory.

**Interaction family**: Conversation Memory, User Profile Memory, Shared Memory (cross-agent), Agent Local Memory (private to one agent instance).

**Self-monitoring family**: Learning Memory, Experience Memory, Failure Memory, Success Memory, Reflection Memory, Meta Memory, Audit / History Memory.

The remaining entries — Tool Memory, Environment/World State, RAG Memory, Cache Memory — are infrastructural: they support retrieval mechanics rather than representing a cognitive category in their own right.

## 3.3 Why the Failure/Success/Reflection Distinction Matters Specifically for Accounting

Most of the taxonomy generalizes to any agentic domain, but the explicit separation of **Failure Memory** from **Success Memory**, mediated by a distinct **Reflection Memory**, deserves domain-specific justification. An accounting agent that merges these into a single "experience" store loses the ability to answer a question a human auditor will always eventually ask: *"has this specific kind of error happened before, and if so, was the correction applied consistently?"* Keeping failures indexed separately — rather than folding them into an undifferentiated experience log — is what makes that question answerable in constant time rather than requiring a full-history scan.

## 3.4 The Missing Piece the Taxonomy Alone Does Not Solve

A taxonomy of memory *types* answers the question "where should this go?" It does not answer three operationally critical questions that the `memory manager` subsystem (`n13`) exists specifically to address:

1. **When should something be written at all**, and with what priority?
2. **When should it be forgotten**, and by what rule?
3. **How is the right memory retrieved** at decision time, out of a store that may contain years of accumulated history?

This is precisely the gap identified in the memory-augmented-LLM literature by systems such as MemGPT (Packer et al., 2023), which observes that an LLM-based agent's practical memory quality degrades sharply once naive "store everything, retrieve by similarity" policies are used at scale, and proposes explicit memory-tiering and eviction policies as the remedy. Hesabdar's `memory manager` group implements exactly this remedy, structured as two parallel pipelines:

**Write path:** `input reader → input analyser → input setter in memory → memory analyser`
The write path does not commit raw input directly; `input analyser` is interposed specifically to make the store/discard/prioritize decision before commitment, rather than after.

**Maintenance path:** `memory complete analyser → find junks → tables cleaner → memory analyser → being in sleep mode`
This path performs periodic consolidation — analogous to memory consolidation during sleep in biological cognitive systems, a metaphor the node name (`being in sleep mode`) makes explicit — during which low-value or expired entries are identified (`find junks`) and pruned (`tables cleaner`).

## 3.5 An Explicit Retention Rule (Recommended Extension)

The taxonomy and the maintenance pipeline together provide the *mechanism* for retention policy; they do not yet encode the *policy itself*. A minimal, auditable retention rule — consistent with the architecture's broader "resource-constrained trade-off" philosophy (§4.5) — is:

```
IF memory_type ∈ {Failure Memory, Audit/History Memory, Financial Transaction Memory}:
    retention = permanent; eligible_for_pruning = false
ELIF memory_type ∈ {Conversation Memory, Cache Memory}:
    retention = importance_score(recency, frequency, relevance) > threshold
    default_ttl = 30 days
ELSE:
    retention = importance_score(...) > threshold
    default_ttl = domain-configurable
```

The load-bearing invariant here is the first branch: **financial and audit-relevant memory is categorically exempt from the pruning path**, regardless of the resource pressure that triggers `find junks` elsewhere in the system. This mirrors the analogous rule already established for the logging subsystem (§8.3) — a system may economize on its own operational telemetry under load, but it may never economize on the record of what it did to someone else's money.

## 3.6 Duplication Between Agent-Local and CEO-Level Memory

`n5::n8` (*CEO memory architecture*) replicates the full twenty-seven-type taxonomy at the level of the supervisory agent, distinct from the general-purpose instance at `n4`. This is an intentional design choice, not redundancy: it reflects the same architectural principle used in capability-based operating systems, where a supervisor process maintains its own private state distinct from the resources it supervises, so that a compromised or malfunctioning subordinate agent cannot corrupt the supervisor's own working memory by writing into a shared store.
