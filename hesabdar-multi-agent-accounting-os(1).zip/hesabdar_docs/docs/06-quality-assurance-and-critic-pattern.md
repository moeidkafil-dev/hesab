# 06. Quality Assurance and the Critic Pattern

## 6.1 The Generator/Critic Distinction

A component that *produces* a result is answering an open question — given ambiguous or incomplete information, what is the most plausible correct output? A component that *verifies* a result is answering a closed question — given a specific, fully-specified output, does it satisfy an explicit criterion? These are different computational problems with different reliability profiles, and conflating them — having the same component both produce and certify its own output — is a well-documented failure mode: a systematic error in the producing component's reasoning is, by construction, invisible to a self-check performed by that same reasoning. Hesabdar addresses this by assigning verification to a structurally independent component, `final checker agent` (`n14`), realized as:

```
input → input analyser → output forecaster → output/input analyser → ceo → log → result
```

## 6.2 Position in the Overall Flow

`final checker agent` is not local to any single producing subsystem; it sits at the convergence point of the entire top-level flow (`n15`: `... → agents → first result → final checker agent → log → final result`) and, as established in §5.4, also serves as the shared downstream verifier for both branches of the Accounting Domain Engine. This placement is deliberate: a Critic that only inspects one subsystem's output cannot catch an error introduced by the interaction *between* subsystems — for instance, a result that is individually valid per the rule engine but inconsistent with a separately-computed forecast. A single, system-wide checkpoint is the only placement that can catch this class of error.

## 6.3 Layered Verification Criteria

Although the diagram represents `final checker agent` as a single node sequence, its verification responsibility is naturally layered, and implementers should preserve this layering rather than collapsing it into one undifferentiated check:

1. **Structural verification** — closed-form, deterministic checks with no ambiguity in their correct answer (e.g., debit/credit balance). These should execute first and should short-circuit: a structural failure is grounds for immediate rejection, without proceeding to the more expensive layers below.
2. **Cross-referential verification** — comparing a claimed value against the authoritative source it purports to summarize (e.g., a reported account balance against the database's own current value for that account), rather than trusting the producing agent's arithmetic.
3. **Historical/statistical verification** — flagging results that are structurally valid and consistent with the source data, but anomalous relative to the entity's own history (an order-of-magnitude deviation from a multi-period trend). This layer cannot produce a binary correct/incorrect verdict and should instead produce a confidence signal, feeding layer 4.
4. **Confidence aggregation and routing** — combining the outcomes of layers 1–3 into a single disposition: automatic release, escalation to human approval, or rejection back to the producing agent. The routing thresholds are a policy decision, not an architectural one, and should be configurable per client organization for the same reason the rule library itself is (§5.6).

## 6.4 Why Routing Passes Through the CEO

The `ceo` node within `final checker agent`'s own pipeline is not incidental. It reflects a system-wide convention, stated explicitly here because it recurs across multiple subsystems (§4.2, §5.3): **the CEO is the sole channel through which any subsystem reaches human oversight.** Centralizing this channel — rather than allowing each subsystem to independently page a human — gives the organization a single, auditable point at which every human-escalation event in the entire system can be observed, rate-limited, and prioritized, rather than an uncoordinated set of alerts from a dozen different subsystems competing for the same human attention.

## 6.5 The Critic Pattern Recurs, Not by Duplication of Effort but by Design

§4.4 already noted that the generator/critic separation appears at multiple scales within the CEO's own planning loop. `final checker agent`'s role is not redundant with those local instances; it is their system-wide counterpart, occupying the same relationship to the entire pipeline that a local `plan checker` occupies to a single agent's plan. This recurrence at multiple scales — local critics inside individual agents, plus one global critic at the point of final output — mirrors defense-in-depth as practiced in safety-critical systems engineering generally: no single verification layer is assumed sufficient on its own, and the layers are structurally distinct enough that a flaw undermining one is unlikely to simultaneously undermine the others.
