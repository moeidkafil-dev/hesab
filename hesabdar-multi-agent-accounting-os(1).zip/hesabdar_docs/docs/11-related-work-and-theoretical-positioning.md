# 11. Related Work and Theoretical Positioning

## 11.1 Statement of Contribution

Consistent with the standard this suite holds itself to (§1.3), the contribution claimed for Hesabdar is architectural composition, not the invention of any individual mechanism. Cognitive memory taxonomies, production-rule engines, generator/critic verification, supervisory-kernel orchestration, and cryptographically authenticated messaging are each independently well-established. What is specific to this project is their deliberate composition around a single governing principle (§1.2) applied consistently to the domain of automated accounting — a domain whose correctness requirements are unusually well-suited to exposing architectural shortcuts that a less exacting application area might tolerate.

## 11.2 Grounding, By Subsystem

**Memory architecture (§3).** The multi-store distinction traces to Atkinson & Shiffrin's (1968) foundational model of human memory, elaborated in cognitive-architecture research through ACT-R (Anderson, Bothell, Byrne, Douglass, Lebiere & Qin, 2004) and Soar (Laird, 2012), both of which treat declarative, procedural, and working memory as architecturally distinct. The specific problem of *maintaining* such a store at scale for an LLM-based agent — write policy, eviction policy, and retrieval quality degradation absent explicit tiering — is addressed directly in the memory-augmented-agent literature by MemGPT (Packer, Wooders, Lin, Fang, Stoica, Gonzalez & Zaharia, 2023).

**Rule engine design (§5.2).** The pattern of representing domain rules as data interpreted by a generic matching engine, rather than compiled into branching application logic, traces to Forgy's RETE algorithm (1982) for efficient production-rule matching, and is the architectural basis of production business-rule-management systems such as Drools. The client-extensibility property discussed in §5.6 (rules as a configuration surface, not a code surface) is the standard justification for this class of system in enterprise software generally.

**Generator/critic separation (§4.4, §6).** The principle that a producing process and a verifying process should be structurally independent is a specific instance of a much older idea in software correctness — the separation of a program from its specification, foundational to formal verification since Hoare's (1969) axiomatic approach to program correctness — applied here at the level of agent behavior rather than program logic.

**Supervisory orchestration (§4).** The CEO Agent's exclusive-authority role over agent lifecycle and cross-agent communication is the multi-agent-systems analogue of the microkernel principle in operating-system design (Liedtke, 1995: a small, privileged core mediating all inter-process interaction) and of the supervisor-tree pattern for fault containment in concurrent systems (Armstrong, 2003, describing the Erlang/OTP runtime's "let it crash and let the supervisor decide" philosophy — directly analogous to the Agent Killer/Agent Builder pairing in §4.2).

**Bounded retry and checkpointing (§4.3, §8.4).** The discipline of bounding automated retry behavior to prevent cascading failure is standard practice in distributed systems engineering, most commonly discussed under exponential-backoff-with-cap policies for RPC and distributed-transaction frameworks; the architectural point specific to this system is applying the same discipline uniformly to both ordinary task retry (§4.3) and automated fault remediation (§8.4), rather than treating the two as separate concerns with independent (and potentially inconsistent) retry policies.

**Messaging and cryptographic authentication (§7).** Fully grounded in the companion Agent Messenger specification, which traces its own design to Needham & Schroeder (1978) on authentication in distributed systems, the Byzantine Generals Problem (Lamport, Shostak & Pease, 1982) as justification for distrusting self-declared agent metadata, and Haber & Stornetta (1991) as the basis for tamper-evident audit chaining.

## 11.3 Threats to Validity

This suite makes the same disclaimers, for the same reasons, as its companion Agent Messenger specification:

- No formal, machine-checked proof of the rule engine's equivalence to any specific accounting standard is offered; §5's determinism guarantees the *mechanism's* consistency, not the *content* of any particular rule library's conformance to law.
- No adversarial red-team evaluation of the system as a whole has been conducted; failure modes throughout this suite (§4.3, §8.4, §6) are described analytically, from design-time reasoning about known classes of distributed-systems and agentic-AI failure, rather than from observed incidents.
- No performance, cost, or accuracy benchmarks are reported; every claim in this suite is a design intention, stated as such, pending implementation and measurement.

## 11.4 Selected References

- Atkinson, R. C., & Shiffrin, R. M. (1968). *Human Memory: A Proposed System and its Control Processes.* Psychology of Learning and Motivation, 2, 89–195.
- Anderson, J. R., Bothell, D., Byrne, M. D., Douglass, S., Lebiere, C., & Qin, Y. (2004). *An Integrated Theory of the Mind.* Psychological Review, 111(4), 1036–1060. (ACT-R.)
- Laird, J. E. (2012). *The Soar Cognitive Architecture.* MIT Press.
- Packer, C., Wooders, S., Lin, K., Fang, C., Stoica, I., Gonzalez, J. E., & Zaharia, M. (2023). *MemGPT: Towards LLMs as Operating Systems.* arXiv:2310.08560.
- Forgy, C. L. (1982). *Rete: A Fast Algorithm for the Many Pattern/Many Object Pattern Match Problem.* Artificial Intelligence, 19(1), 17–37.
- Hoare, C. A. R. (1969). *An Axiomatic Basis for Computer Programming.* Communications of the ACM, 12(10), 576–580.
- Liedtke, J. (1995). *On µ-Kernel Construction.* Proceedings of the 15th ACM Symposium on Operating Systems Principles (SOSP).
- Armstrong, J. (2003). *Making Reliable Distributed Systems in the Presence of Software Errors.* Doctoral dissertation, Royal Institute of Technology, Stockholm. (Erlang/OTP.)
- Needham, R. M., & Schroeder, M. D. (1978). *Using Encryption for Authentication in Large Networks of Computers.* Communications of the ACM, 21(12), 993–999.
- Lamport, L., Shostak, R., & Pease, M. (1982). *The Byzantine Generals Problem.* ACM Transactions on Programming Languages and Systems, 4(3), 382–401.
- Haber, S., & Stornetta, W. S. (1991). *How to Time-Stamp a Digital Document.* Journal of Cryptology, 3(2), 99–111.

As with the companion specification, these references are cited for conceptual grounding. Implementers making concrete algorithm, framework, or library choices should consult current literature and standards guidance at implementation time rather than treating this list as sufficient on its own.
