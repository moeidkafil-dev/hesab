# 08. Resilience Engineering

## 8.1 Three Distinct Failure-Handling Concerns

Hesabdar separates resilience into three subsystems that are frequently conflated in less careful architectures: **backup** (can we reconstruct state after loss?), **recovery** (can we restore operation using that reconstruction?), and **self-healing** (can the system detect and correct a fault without external intervention at all?). Each answers a different question and each fails independently of the others, which is precisely why they are modeled as separate node groups rather than one undifferentiated "reliability" subsystem.

## 8.2 Backup System (n7)

```
backup maker → self db → hidden memory → backup analyser/reader
```

Two properties of this pipeline are worth making explicit. First, the target of `backup maker` is `self db` — a store distinct from the production database (`n12::n8`) rather than a snapshot mechanism internal to it, which is the correct design for surviving failure modes that corrupt the production store itself, not merely its most recent transaction. Second, `backup analyser/reader` exists as a standing capability, not merely an emergency-invocation path — a backup that has never been read until the moment of an actual disaster is a backup whose integrity is, at that point, an untested assumption; periodic read/analysis is what converts that assumption into a verified property.

## 8.3 Recovery System (n8)

```
backup catcher → main DB setter → system analyser → system restarter
```

Recovery is modeled as strictly downstream of backup: `backup catcher` consumes what `n7` produced, and the subsystem's job is narrowly the mechanics of restoring operation from that material, not the mechanics of having produced it in the first place. `system analyser` is interposed between restoring the database and restarting the system specifically so that the cause of the original failure can be assessed before the system is returned to production traffic — restoring a corrupted database and then immediately resuming the operations that corrupted it in the first place is a well-known anti-pattern this ordering is designed to avoid.

## 8.4 Self-Healing (n9, internally labeled "Group 21")

```
log reader → all DBs reader → system analyser → check points finder
→ coding system debugger → tool executer → tools group connector
→ second analyser → system restart → tries counter → log maker
```

This is the most operationally sophisticated of the three subsystems, combining diagnosis (`system analyser`, `second analyser` — a deliberate two-pass structure, discussed below), root-cause localization (`check points finder`, leveraging the checkpoint mechanism described in §4.3), and active remediation (`coding system debugger`, `tool executer`) within a single bounded loop (`tries counter`).

**The two-pass analysis structure is a deliberate corroboration mechanism.** A single automated fault diagnosis, especially one produced under the resource pressure a live incident typically implies, is exactly the kind of high-stakes, low-verification decision the Critic pattern (§6) argues against trusting unchecked. `second analyser` exists to independently re-examine the first pass's conclusion before `system restart` acts on it — the same generator/critic separation recurring here as it does throughout the rest of the architecture (§4.4, §6.5), applied to fault diagnosis rather than to accounting output.

**The retry bound is non-negotiable for the same reason it is in §4.3.** `tries counter` prevents a self-healing loop from itself becoming a resource-exhaustion incident — an automated remediation system with no bound on its own retry behavior is a known source of cascading failure (a restart loop consuming the capacity a genuinely healthy restart would have needed) in production distributed systems generally.

## 8.5 The Interaction Between These Three Subsystems and the CEO

None of the three subsystems above acts unilaterally at the level of overall system state; `n12` shows all three connected to `CEO` and to `main memory`, consistent with the CEO's role, established in §4, as the sole point of coordinated decision-making for anything with system-wide consequence. A self-healing restart is something the CEO is informed of and whose resource cost is accounted for by the Resource Distributor (§4.5) — it is not an autonomous action invisible to the rest of the orchestration layer.

## 8.6 What Resilience Engineering Does Not Cover Here

Consistent with the disclaimers in §1.3, this suite does not specify Recovery Time Objective (RTO) or Recovery Point Objective (RPO) figures, geographic redundancy strategy, or multi-tenant data isolation guarantees — all of which are legitimate and eventually necessary extensions of the Backup and Recovery subsystems described above, but which are implementation and deployment decisions properly made once a specific hosting environment and client contractual requirements are known, rather than architectural decisions to be fixed in advance.
