# 01. Introduction and Scope

## 1.1 The Problem

Financial accounting is, at its core, a discipline of **verifiable record-keeping under formal constraint**. Every entry in a ledger is subject to mechanical laws (the equality of debits and credits, the conservation of value across transfer, the temporal ordering of accruals) and to jurisdiction-specific statutory law (recognition timing, depreciation method, disclosure thresholds) that vary by country, industry, and — not infrequently — by the internal policy of the reporting entity itself.

Large language models are, by construction, excellent at exactly the tasks accounting does *not* reward: fluent synthesis under uncertainty, plausible completion of underspecified patterns, and graceful handling of ambiguity through inference rather than lookup. Naively wrapping an LLM around a company's books inherits precisely the wrong failure mode: a system that produces confident, well-formatted, and *occasionally silently wrong* output. In a domain where the cost of an undetected error compounds — a misclassified transaction propagates into a misstated trial balance, which propagates into a misstated financial statement, which propagates into a regulatory filing — "occasionally wrong but always confident" is the single most dangerous failure profile a system can have.

## 1.2 The Governing Design Principle

Hesabdar is built around one governing principle, stated here so that it can be referred back to throughout the remainder of this suite:

> **Wherever a correctness criterion can be stated as a formal, checkable rule, it must be enforced by deterministic code — never by inference. Language-model reasoning is invoked only for the residual set of decisions that are genuinely underdetermined by explicit rule: synthesis of natural-language narrative, research into novel or ambiguous cases, and the initial proposal (never the final authority) of new rules.**

This principle is not a stylistic preference; it is the architectural spine from which nearly every subsystem in this suite is derived. §5 (the Accounting Domain Engine) is its most direct expression: a transaction is first tested against a library of deterministic, human-authored rules, and only escalated to language-model-mediated research when no applicable rule exists — and even then, any rule the research path proposes is routed through human approval before it is permitted to govern a single additional transaction (§5.4).

## 1.3 What This Suite Does Not Claim

In the interest of the same rigor the architecture itself demands of its subject matter, this documentation explicitly disclaims several things it does *not* establish:

- **No formal correctness proof.** The rule-execution pipeline (§5) is deterministic by construction, but no machine-checked proof of its equivalence to any specific jurisdiction's accounting standard is offered here. Such a proof would require formalizing the standard itself — a substantial undertaking properly scoped to implementation, not architecture.
- **No security audit.** §7 summarizes the transport-layer security model; the full specification and its threat analysis live in the companion Agent Messenger repository, which itself explicitly disclaims a completed red-team evaluation.
- **No performance benchmarks.** Every subsystem below is described in terms of what it is designed to guarantee, not measurements of latency, cost, or accuracy taken from a running implementation.

## 1.4 Intended Audience

This suite is written for three overlapping readerships, and each document attempts to serve all three simultaneously rather than picking one:

1. **Engineers** who will implement or extend a given subsystem and need to know its interfaces, invariants, and failure modes.
2. **Technical evaluators** at a prospective enterprise customer or acquirer, who need to assess whether the architecture's safety claims are substantive or decorative.
3. **The system's own designer**, for whom this suite functions as an externalized, reviewable memory of design decisions and the reasoning behind them — a role directly analogous to the `Reflection Memory` and `Audit / History Memory` subsystems described in §3.

## 1.5 Relationship to the Diagram

Nothing in this suite introduces a component that is not already present in `حسابدار.graphml`. The documentation's role is strictly interpretive: it explains *why* each node exists, *what guarantee* it is responsible for, and *how* it relates to its neighbors — information a diagram, by its nature as a visual medium, can show but not fully argue for.
