# 04. Orchestration and the CEO Agent

## 4.1 Role and Scope

The `CEO agent architecture` (`n5`) is the supervisory kernel referenced in §2.2. It is decomposed into ten subgroups, each responsible for one facet of orchestration. This document treats each in turn, then addresses the two cross-cutting concerns — checkpointing and resource trade-offs — that the CEO is uniquely positioned to enforce.

## 4.2 Subsystem Inventory

**Log Input Manager** (`n5::n0`): `log reader → log analyser → situation analyser → References analyser → Legible log`. Converts raw, high-volume operational logs into a form a downstream decision process (human or agent) can actually reason about — the terminal node's name, *Legible log*, states this purpose directly.

**Prompt Manager** (`n5::n1`): `input receiver → input compiler → input analyser → policy checker → prompt reader → prompt analyser → decision system for choosing best agents`. Notably, `policy checker` is interposed *before* agent selection, not after — intent is validated against policy prior to any agent being invoked, rather than being invoked first and checked retroactively.

**New Agent Manager** (`n5::n2`): `agent registerer → rule maker → rule signer → messenger maker → message sender → getting relationship → greeting system → sign maker`. Handles the provisioning of a new agent instance, including the cryptographic material (`rule signer`, `sign maker`) that lets the messaging layer (§7) authenticate messages the new agent later sends.

**Agent Killer** (`n5::n3`): `agent killer → saving agents rule → summary maker`. The pairing with `summary maker` is deliberate: an agent is never simply terminated and discarded — a summary of its accumulated state is captured first, feeding the Experience/Reflection Memory family described in §3.3.

**Memory Manager (CEO-scoped)** (`n5::n4`): a CEO-local instance of the write/maintenance pattern described in §3.4, paired here with a dedicated `planner system` and `schedule system`, reflecting that the CEO's memory concerns are inseparable from its planning concerns.

**CEO Agent core** (`n5::n5`): `llm → planner → schedule → plan checker → hidden memory → tool manager → tool executor`, receiving input through its own `input receiver → input compiler → input analyser → decision system` chain. The presence of `plan checker` as a distinct node from `planner` is the local instance of the generator/critic separation formalized system-wide in §6 — even the CEO's own plans are not self-certifying.

**Agents Input Messages Manager** (`n5::n6`): structurally near-identical to the CEO core, and exists to shield the CEO's own reasoning loop from directly parsing untrusted inbound agent traffic — inbound messages are received, compiled, and analyzed by a dedicated pipeline before the CEO's core planning loop ever sees them.

**Resource Distributor** (`n5::n7`): reads operational logs and agent information to make allocation decisions — the mechanism by which the trade-offs discussed in §4.5 are actually enforced at runtime, rather than merely specified.

**CEO Memory Architecture** (`n5::n8`): discussed in §3.6.

**Agent Builder** (`n5::n9`): `agent builder → teacher of agent from memory → agent configurer → agent runner → agent registerer`. The `teacher of agent from memory` node is architecturally significant: new agents are not instantiated from a static template alone but are seeded with relevant accumulated memory, giving the system a mechanism for institutional knowledge to transfer across agent instances rather than being lost each time an agent is recycled by the Agent Killer.

**Input / Output Manager** (`n5::n10`): treated in full in §4.3, as it is the system's checkpointing mechanism.

## 4.3 Checkpointing as a Lightweight Alternative to an Explicit State Machine

A natural first instinct in designing a multi-stage agentic workflow is to introduce a dedicated, explicit state-machine or workflow-engine component — a design choice with real precedent (e.g., temporal- or saga-pattern workflow engines in distributed transaction processing). Hesabdar deliberately does not do this as a separate subsystem. Instead, the `input / output manager` (`n5::n10`) implements a **bounded-retry checkpoint loop**:

```
input receiver → input compiler → input analyser → output forecaster
→ output checker → decision system → counter
                                        │
                     ┌──────────────────┴──────────────────┐
                     │ (retry)                    (exhausted / success)
                     ▼                                       ▼
              input analyser                          result / log
```

The `counter` node enforces a maximum retry bound — an application of the same bounded-retry discipline used throughout distributed systems engineering to prevent an unrecoverable fault from producing an infinite loop (cf. exponential-backoff-with-cap patterns in RPC frameworks). This is a considered trade-off, not an oversight: a fully general state machine would provide strictly more expressive workflow control, at the cost of an additional subsystem to build, test, and keep synchronized with the rest of the architecture. Given finite engineering resources, task/stage state is instead derived jointly from the checkpoint counter, the logging subsystem (§8.3), the memory architecture (§3), and the database (§9.2) — with the explicit convention, stated here as a system-wide invariant, that **the database is the authoritative source of truth whenever these four sources disagree.** This convention exists specifically to close the consistency gap that a distributed, multi-source notion of "current state" would otherwise leave open.

## 4.4 The Generator/Critic Pattern, Applied Recursively

§6 formalizes the separation between a component that *produces* a result and a component that *verifies* it. §4.2 shows this pattern is not confined to the system's final output stage — it recurs at the level of individual planning (`planner` vs. `plan checker` in `n5::n5` and `n5::n6`) and at the level of I/O itself (`output forecaster` predicting an expected result shape, `output checker` comparing the actual result against it, in `n5::n10`). The repetition of the same structural motif at multiple scales is intentional: a system-design pattern that only holds at the top level is a decoration; one that holds recursively is an architectural invariant.

## 4.5 Resource Trade-offs Under Finite Compute

The CEO's Resource Distributor (`n5::n7`) is the enforcement point for a principle stated informally during this architecture's design review and formalized here: **the system does not have unbounded compute, and every subsystem that consumes it competes for a shared budget.** Two concrete trade-off rules follow directly from this constraint and are recorded here so that future modification of the architecture preserves them:

1. **Operational telemetry is elastic; financial/decision telemetry is not.** Under resource pressure, the CEO may instruct the logging subsystem to suppress performance-only log detail (e.g., per-agent network or CPU utilization). It may never suppress logs of financial transactions, rule-engine decisions, or agent actions with real-world effect — this is the same invariant stated for memory retention in §3.5, applied to the logging subsystem.
2. **Deterministic paths are preferred to probabilistic ones when both are available**, purely as a resource-allocation consequence of §2.3: a rule-matcher lookup is orders of magnitude cheaper than an LLM invocation, and the Accounting Domain Engine's dual-path design (§5) is in part *justified* by this cost asymmetry, independent of its correctness benefits.
