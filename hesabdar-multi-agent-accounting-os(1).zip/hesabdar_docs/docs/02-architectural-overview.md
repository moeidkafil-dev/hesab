# 02. Architectural Overview

## 2.1 The System at a Glance

At the top level (`n15`, *system top architecture*), the flow of a single unit of work through Hesabdar is:

```
prompt → data → analyser → agents → first result → final checker agent → log → final result
```

This is deliberately the least detailed diagram in the entire specification — a top-level silhouette rather than a wiring guide — and its role is purely orientational: every other document in this suite zooms into exactly one of these seven stages. The corresponding "wide" view (`n12`, *main system architecture*) shows the same flow with its principal components named: `CEO`, `main agent`, `self healing system`, `recovery system`, `backup system`, `main memory`, `toolmanager`, `DB manager agent`, `DB`, and the prompt-intake chain (`user prompt → prompt analyser → prompt translator → prompt compiler`), together with the two subsystems added specifically for the accounting domain: `study/knowledge agent` and `Accounting Domain Engine`.

## 2.2 The Central Design Tension

Every non-trivial multi-agent system must resolve the same tension: **autonomy enables scale, but unchecked autonomy is precisely what makes a system unauditable and unsafe.** Hesabdar resolves this tension the same way operating-system design resolved the analogous tension between process autonomy and system stability half a century earlier — through a **supervisory kernel** (here, the CEO Agent, §4) that holds exclusive authority over agent lifecycle, resource allocation, and cross-agent communication, while individual agents retain full autonomy *within* the scope the kernel has granted them.

This is not a novel pattern in the abstract; it is the multi-agent-systems analogue of the microkernel principle in operating-system design (Liedtke, 1995) and of the supervisor tree pattern in fault-tolerant concurrent programming (Armstrong, 2003, describing the Erlang/OTP runtime). What is specific to Hesabdar is *where* the kernel boundary is drawn: not merely around agent lifecycle (which subsystem gets to run), but around **rule authority** — no agent, including the CEO itself, may unilaterally introduce a new accounting rule into production without routing it through human approval (§5.4). This is a stronger and more domain-specific invariant than general-purpose multi-agent frameworks typically enforce, and it exists because the cost of a silently-wrong accounting rule is categorically higher than the cost of a silently-wrong general-purpose agent action.

## 2.3 The Deterministic/Probabilistic Boundary

Section 1.2 stated the governing principle in the abstract; concretely, it partitions every subsystem in this suite into one of two categories:

**Deterministic — no language model in the decision path:**
- Rule matching and execution (`n17::n4`–`n17::n6`)
- Message signing and verification (external: Agent Messenger repository)
- Checkpoint counting and retry-limit enforcement (`n5::n10::n5`, `n9::n9`)
- Structural validation of accounting identities (debit/credit balance, chart-of-accounts conformance)

**Probabilistic — language-model reasoning is load-bearing:**
- Natural-language report synthesis (`n2::n2`–`n2::n6`)
- Research into ambiguous or novel transaction types (`n16::n1`, `n17::n1`)
- Forecasting and anomaly framing (`n2::n5`, `n5::n10::n7`)
- Prompt interpretation and intent classification (`n12::n11`, `n5::n1`)

A useful diagnostic when extending the architecture: **before adding a new node, ask which category it belongs to.** If a new capability sits ambiguously between the two — for instance, "classify this transaction" — the correct resolution is almost always to *split* it into a deterministic fast path (§5.2) and a probabilistic fallback (§5.3), exactly as the Accounting Domain Engine itself does, rather than to build a single node that blends both concerns.

## 2.4 Layering Summary

The remaining documents in this suite correspond to horizontal layers of the architecture, ordered here from most foundational to most externally visible:

| Layer | Responsibility | Document |
|---|---|---|
| Cognitive substrate | What the system remembers and for how long | §3 |
| Orchestration | Who decides what runs, and under what resource budget | §4 |
| Domain correctness | Whether a given accounting action is permitted | §5 |
| Quality assurance | Whether a produced result should be trusted before release | §6 |
| Transport | How agents prove identity and exchange tamper-evident messages | §7 |
| Resilience | What happens when a component fails | §8 |
| Execution | How the system touches the outside world (files, shells, browsers, APIs) | §9 |
| Presentation | How raw data becomes a report a human can act on | §10 |

Each layer depends only on the layers above it in this table; a change to the Reporting layer (§10) should never require a change to the Cognitive substrate (§3), and the architecture has been reviewed with this acyclicity as an explicit goal.
