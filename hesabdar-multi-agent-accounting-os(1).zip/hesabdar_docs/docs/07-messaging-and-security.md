# 07. Messaging and Security

## 7.1 Scope of This Document

The full specification of Hesabdar's inter-agent transport layer — identity resolution, message authentication, integrity, replay protection, and audit chaining — is maintained as an independent, self-contained repository (*Agent Messenger*) rather than duplicated here. This document summarizes the aspects of that specification most relevant to an accounting-domain reader and explains how the `new messages architecture` group (`n10`) in this project's diagram maps onto it; it is not a substitute for the companion repository's own README and section-by-section specification.

## 7.2 Why Messaging Is Treated as a Separate Concern from Domain Logic

`n10` is structured around a repeated four-stage per-channel pattern — `receiver → compiler → sign reader → read` — instantiated separately for each pairing among `CEO`, `main agent`, `self healing system`, `recovery system`, `backup system`, `toolmanager`, and `DB manager agent`. This repetition is intentional rather than an artifact of copy-paste diagramming: it reflects the architectural decision, discussed in §2.3, to keep the deterministic transport concern (does this message genuinely originate from the agent it claims to, and has it been altered in transit) entirely separate from, and prior to, any domain-level reasoning about the message's content. A message is authenticated *before* any accounting-domain component is permitted to act on it — including the Accounting Domain Engine (§5) and the Critic (§6), both of which are downstream consumers of already-authenticated messages, never participants in the authentication decision itself.

## 7.3 The Four Properties, Restated for This Domain

The companion specification's central formal distinction — identity, authentication, integrity, and authorization as four independently verifiable properties, never collapsed into one — is directly load-bearing for accounting specifically:

- **Identity** answers "which agent is this purportedly from?" — e.g., is this message from the `DB manager agent` or an impostor.
- **Authentication** answers "can we cryptographically prove that?" — via HMAC or digital signature, never a bare hash (a bare digest proves nothing about origin, since any party can compute one).
- **Integrity** answers "was the transaction data altered after signing?" — critical given that the payload frequently *is* a financial transaction or a rule-engine decision.
- **Authorization** answers "is this agent permitted to make this specific claim?" — for instance, a `tool manager` agent authenticating successfully does not, by itself, authorize it to write directly to `n6::n5` (`DB analyser`)'s target tables; that authorization is a separate, explicit policy decision, not an automatic consequence of a valid signature.

## 7.4 Algorithm Selection

Consistent with the companion specification, message authentication in this system uses keyed constructions — HMAC over a modern hash function, or a digital signature scheme such as Ed25519 for cross-organization message exchange — rather than an unkeyed digest. This is stated here explicitly because it was, at an earlier stage of this architecture's design review, an open item requiring resolution; it is recorded as resolved, with the full technical justification (and its grounding in Needham & Schroeder, 1978, and the Byzantine Generals Problem literature) available in the companion repository's own theoretical-positioning section.

## 7.5 Audit Chaining

`n10::n32` (*name and sign hasher*) is the point at which this system's messages feed into the tamper-evident audit chain described in the companion specification, itself an application of the linked-timestamping construction of Haber & Stornetta (1991). For an accounting system specifically, this provides a property beyond ordinary message authentication: not merely that a given message is genuine, but that the **sequence** of financial decisions recorded in the audit trail cannot be silently reordered or have entries retroactively inserted or removed without the tampering being cryptographically detectable — a property directly relevant to satisfying an external auditor's evidentiary requirements.
