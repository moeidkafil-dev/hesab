# حسابدار (Hesabdar) — An Agentic Accounting Operating System

### Technical Documentation Suite

---

## Abstract

This repository documents **Hesabdar**, a multi-agent system architecture designed to automate the practice of financial accounting through a coordinated society of specialized, cognitively-modeled software agents, rather than through a single monolithic language-model invocation. The architecture's central thesis is that accounting — a discipline whose value derives precisely from its determinism, auditability, and resistance to interpretive drift — cannot safely be delegated wholesale to a probabilistic reasoning system. Hesabdar accordingly partitions responsibility along a strict boundary: **deterministic, rule-governed computation** is used wherever a correctness criterion is formally expressible (double-entry balance, statutory thresholds, chart-of-accounts conformance), while **probabilistic, language-model-mediated reasoning** is reserved for the comparatively narrow set of tasks that genuinely require judgment, natural-language synthesis, or research into ambiguous or previously unencountered situations.

This document suite is organized as a set of independently readable modules, each treating one architectural subsystem in isolation while cross-referencing the others. It assumes the reader is technically sophisticated but not necessarily already familiar with this specific system; each module accordingly opens with the problem the subsystem solves before describing the mechanism that solves it.

**Companion repository:** The inter-agent transport layer referenced throughout this suite (identity, authentication, message integrity, replay protection) is specified in full in the separate *Agent Messenger* repository and is treated here as an external, already-documented dependency rather than re-derived.

---

## How to Read This Suite

The documents are ordered so that each depends only on the ones before it. A reader with limited time is directed to **01**, **02**, and **05** — together they contain the architecture's central engineering argument (the deterministic/probabilistic split) and its most safety-relevant subsystem (the accounting domain engine).

| # | Document | Subsystem Covered | Reference Nodes |
|---|---|---|---|
| 01 | [Introduction and Scope](docs/01-introduction-and-scope.md) | Motivation, positioning, non-goals | — |
| 02 | [Architectural Overview](docs/02-architectural-overview.md) | System-level composition, design philosophy | `n12`, `n15` |
| 03 | [Memory Architecture](docs/03-memory-architecture.md) | Cognitive memory taxonomy and lifecycle management | `n4`, `n5::n8`, `n13` |
| 04 | [Orchestration and the CEO Agent](docs/04-orchestration-and-ceo-agent.md) | Supervisory control, agent lifecycle, checkpointing | `n5` (all subgroups) |
| 05 | [The Accounting Domain Engine](docs/05-accounting-domain-engine.md) | Deterministic rule execution and the research fallback path | `n16`, `n17`, `n18` |
| 06 | [Quality Assurance and the Critic Pattern](docs/06-quality-assurance-and-critic-pattern.md) | Independent output verification | `n14`, `n15` |
| 07 | [Messaging and Security](docs/07-messaging-and-security.md) | Inter-agent transport (summary; full spec external) | `n10` |
| 08 | [Resilience Engineering](docs/08-resilience-engineering.md) | Backup, recovery, self-healing | `n7`, `n8`, `n9` |
| 09 | [Tooling and Data Management](docs/09-tooling-and-data-management.md) | Execution sandbox, database manager | `n3`, `n6` |
| 10 | [Reporting and Analytics Pipeline](docs/10-reporting-and-analytics-pipeline.md) | Prompt intake, data ingestion, report synthesis | `n0`, `n1`, `n2` |
| 11 | [Related Work and Theoretical Positioning](docs/11-related-work-and-theoretical-positioning.md) | Grounding in distributed systems, cognitive architecture, and rule-engine literature | — |
| 12 | [Glossary and Notation](docs/12-glossary-and-notation.md) | Node-name reference, terminology | — |

---

## Repository Layout

```
.
├── README.md                                        (this file)
├── حسابدار.graphml                                   (canonical architecture diagram — source of truth)
└── docs/
    ├── 01-introduction-and-scope.md
    ├── 02-architectural-overview.md
    ├── 03-memory-architecture.md
    ├── 04-orchestration-and-ceo-agent.md
    ├── 05-accounting-domain-engine.md
    ├── 06-quality-assurance-and-critic-pattern.md
    ├── 07-messaging-and-security.md
    ├── 08-resilience-engineering.md
    ├── 09-tooling-and-data-management.md
    ├── 10-reporting-and-analytics-pipeline.md
    ├── 11-related-work-and-theoretical-positioning.md
    └── 12-glossary-and-notation.md
```

The `.graphml` file is the **single source of architectural truth**. Every claim made in this documentation suite is traceable to a specific node or edge in that file, referenced throughout by its internal identifier (e.g., `n16::n3`). Where documentation and diagram disagree, the diagram governs, and the documentation should be corrected.

---

## Document Status

This suite describes an architecture at the design-specification stage: every subsystem discussed has been diagrammed, and several have been iteratively refined against explicit engineering critique (see §11 for the theoretical grounding underlying each revision). It has not yet been subjected to implementation, benchmarking, or third-party security review. Claims of performance, accuracy, or security are stated as **design intentions and testable hypotheses**, not as measured results, and are labeled as such throughout.
