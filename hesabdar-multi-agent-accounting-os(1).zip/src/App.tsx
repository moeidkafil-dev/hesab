import React, { useState, useEffect } from "react";
import {
  Activity,
  AlertCircle,
  ArrowDownLeft,
  ArrowUpRight,
  BookOpen,
  Boxes,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Clock,
  Cpu,
  Database,
  Download,
  FileSpreadsheet,
  FileText,
  Filter,
  Flame,
  Layers,
  Lock,
  Plus,
  RefreshCw,
  Search,
  Send,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Sliders,
  Sparkles,
  Terminal,
  Trash2,
  TrendingUp,
  User,
  Zap
} from "lucide-react";

// Types
interface Account {
  id: string;
  code: string;
  name: string;
  name_fa?: string;
  account_type: string;
  balance: number;
}

interface TransactionLine {
  id?: string;
  account_id: string;
  account_code?: string;
  account_name?: string;
  debit: number;
  credit: number;
  description?: string;
}

interface Transaction {
  id: string;
  transaction_number: string;
  transaction_date: string;
  description: string;
  status: string;
  total_debit: number;
  total_credit: number;
  verified_by_critic: number;
  lines: TransactionLine[];
  created_at: number;
}

interface Rule {
  id: string;
  name: string;
  category: string;
  priority: number;
  condition: any;
  action: any;
  is_active: number;
}

interface CandidateRule {
  id: string;
  name: string;
  proposed_by: string;
  category: string;
  condition_json: string;
  action_json: string;
  justification: string;
  status: string;
  created_at: number;
}

interface SuperLog {
  id: string;
  timestamp: number;
  task_id: string;
  agent_id: string;
  stage: string;
  level: string;
  component: string;
  summary: string;
  payload_json: string;
  discrepancy: number;
  error_detail?: string;
  recovery_action?: string;
}

interface Skill {
  id: string;
  name: string;
  version: string;
  description: string;
  capabilities: string[];
  permissions: string[];
  compatible_agents: string[];
  is_active: boolean;
}

interface SystemStats {
  total_accounts: number;
  total_transactions: number;
  active_rules: number;
  pending_candidate_rules: number;
  super_logs_count: number;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<string>("dashboard");
  const [loading, setLoading] = useState<boolean>(true);
  const [stateData, setStateData] = useState<any>(null);
  const [promptInput, setPromptInput] = useState<string>("");
  const [processingPrompt, setProcessingPrompt] = useState<boolean>(false);
  const [promptResult, setPromptResult] = useState<any>(null);
  const [selectedTxn, setSelectedTxn] = useState<Transaction | null>(null);
  const [notification, setNotification] = useState<{ message: string; type: "success" | "error" | "info" } | null>(null);

  // Quick transaction form modal state
  const [showNewTxnModal, setShowNewTxnModal] = useState<boolean>(false);
  const [newTxnDesc, setNewTxnDesc] = useState<string>("");
  const [newTxnAmount, setNewTxnAmount] = useState<string>("");
  const [newTxnCategory, setNewTxnCategory] = useState<string>("sale");
  const [newTxnPayment, setNewTxnPayment] = useState<string>("bank");

  // Regulatory search state
  const [studyTopic, setStudyTopic] = useState<string>("قوانین مالیات بر ارزش افزوده ۹ درصدی در فروش کالا");
  const [studyResult, setStudyResult] = useState<any>(null);
  const [studying, setStudying] = useState<boolean>(false);

  // Notification helper
  const showToast = (message: string, type: "success" | "error" | "info" = "success") => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 4000);
  };

  // Fetch full system state
  const fetchState = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/state");
      const data = await res.json();
      if (data.ok) {
        setStateData(data.state);
      }
    } catch (err: any) {
      showToast("خطا در برقراری ارتباط با هسته سیستم حسابدار: " + err.message, "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchState();
  }, []);

  // Submit prompt to CEO
  const handlePromptSubmit = async (customPrompt?: string) => {
    const text = customPrompt || promptInput;
    if (!text.trim()) return;

    try {
      setProcessingPrompt(true);
      setPromptResult(null);
      const res = await fetch("/api/prompt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: text }),
      });
      const data = await res.json();
      if (data.ok) {
        setPromptResult(data.result);
        showToast("دستور با موفقیت توسط عامل‌های هوشمند پردازش شد.", "success");
        fetchState();
      } else {
        setPromptResult(data.result || { error: data.error });
        showToast("خطا در پردازش دستور: " + (data.error || data.result?.message), "error");
      }
    } catch (err: any) {
      showToast("خطای سیستمی در اجرای دستور: " + err.message, "error");
    } finally {
      setProcessingPrompt(false);
    }
  };

  // Human approval for candidate rule
  const handleApproveRule = async (candidateId: string) => {
    try {
      const res = await fetch("/api/rules/approve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ candidate_id: candidateId }),
      });
      const data = await res.json();
      if (data.ok) {
        showToast("قانون با موفقیت توسط ناظر انسانی تایید و به قوانین اجرایی منتقل شد.", "success");
        fetchState();
      }
    } catch (err: any) {
      showToast("خطا در تایید قانون: " + err.message, "error");
    }
  };

  // Reject candidate rule
  const handleRejectRule = async (candidateId: string) => {
    try {
      const res = await fetch("/api/rules/reject", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ candidate_id: candidateId, reason: "رد شده توسط حسابرس ارشد" }),
      });
      const data = await res.json();
      if (data.ok) {
        showToast("قانون با موفقیت رد شد.", "info");
        fetchState();
      }
    } catch (err: any) {
      showToast("خطا در رد قانون: " + err.message, "error");
    }
  };

  // Create Snapshot Backup
  const handleMakeBackup = async () => {
    try {
      const res = await fetch("/api/backup", { method: "POST" });
      const data = await res.json();
      if (data.ok) {
        showToast("نسخه پشتیبان تایید شده و سالم با موفقیت ایجاد گردید.", "success");
        fetchState();
      }
    } catch (err: any) {
      showToast("خطا در ایجاد پشتیبان: " + err.message, "error");
    }
  };

  // Trigger Self-Healing Diagnostic
  const handleSelfHeal = async () => {
    try {
      const res = await fetch("/api/self-heal", { method: "POST" });
      const data = await res.json();
      if (data.ok) {
        const rep = data.report;
        if (rep.incident_detected) {
          showToast(`رویداد نامنظم شناسایی و اقدام جبرانی اعمال شد: ${rep.remediation_action}`, "info");
        } else {
          showToast("بررسی سلامت انجام شد: تمام پایگاه‌های داده و ترازها کاملا متوازن و بدون خطا هستند.", "success");
        }
        fetchState();
      }
    } catch (err: any) {
      showToast("خطا در اجرای خودترمیمی: " + err.message, "error");
    }
  };

  // Perform Regulatory Study
  const handlePerformStudy = async () => {
    if (!studyTopic.trim()) return;
    try {
      setStudying(true);
      const res = await fetch("/api/study", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic: studyTopic }),
      });
      const data = await res.json();
      if (data.ok) {
        setStudyResult(data.study);
      }
    } catch (err: any) {
      showToast("خطا در استعلام مقررات: " + err.message, "error");
    } finally {
      setStudying(false);
    }
  };

  const stats: SystemStats = stateData?.stats || {
    total_accounts: 0,
    total_transactions: 0,
    active_rules: 0,
    pending_candidate_rules: 0,
    super_logs_count: 0,
  };

  const balanceSheet = stateData?.financial_statements?.balance_sheet || {
    total_assets: 0,
    total_liabilities: 0,
    total_equity: 0,
  };

  const incomeStatement = stateData?.financial_statements?.income_statement || {
    total_revenue: 0,
    total_expenses: 0,
    net_income: 0,
    net_margin_pct: 0,
  };

  const recentTxns: Transaction[] = stateData?.recent_transactions || [];
  const trialBalance = stateData?.trial_balance?.records || [];
  const activeRules: Rule[] = stateData?.active_rules || [];
  const candidateRules: CandidateRule[] = stateData?.candidate_rules || [];
  const superLogs: SuperLog[] = stateData?.super_logs || [];
  const skills: Skill[] = stateData?.skills || [];
  const backups = stateData?.backups || [];
  const registeredAgents = stateData?.registered_agents || [];

  return (
    <div className="flex h-screen w-full bg-[#0d0d0d] text-gray-200 font-sans overflow-hidden" dir="rtl">
      {/* Toast Notification */}
      {notification && (
        <div
          id="toast-notification"
          className={`fixed top-6 left-6 z-50 flex items-center gap-3 px-5 py-3.5 rounded-xl text-sm font-medium shadow-2xl border transition-all animate-bounce ${
            notification.type === "success"
              ? "bg-emerald-950/90 text-emerald-300 border-emerald-800"
              : notification.type === "error"
              ? "bg-rose-950/90 text-rose-300 border-rose-800"
              : "bg-gray-900 text-gray-200 border-gray-700"
          }`}
        >
          {notification.type === "success" ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          ) : (
            <AlertCircle className="w-5 h-5 text-rose-400" />
          )}
          <span>{notification.message}</span>
        </div>
      )}

      {/* ========================================================= */}
      {/* ASIDE SIDEBAR NAVIGATION (Elegant Dark) */}
      {/* ========================================================= */}
      <aside className="w-72 bg-[#141414] border-l border-gray-800 flex flex-col shrink-0">
        <div className="p-6">
          {/* Brand & Kernel Badge */}
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 bg-emerald-500 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-900/30">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-bold tracking-tight text-white">حسابدار پرو</span>
                <span className="text-[10px] uppercase font-semibold px-2 py-0.5 bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/20">
                  v2.0 OS
                </span>
              </div>
              <p className="text-xs text-gray-500">Multi-Agent Accounting OS</p>
            </div>
          </div>

          {/* Navigation Items */}
          <nav className="space-y-1.5 text-sm">
            <button
              id="nav-dashboard-btn"
              onClick={() => setActiveTab("dashboard")}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                activeTab === "dashboard"
                  ? "bg-gray-800/60 text-emerald-400 border border-gray-700/60 shadow-sm"
                  : "text-gray-400 hover:text-gray-200 hover:bg-gray-800/30"
              }`}
            >
              <div className="flex items-center gap-3">
                <span
                  className={`w-2 h-2 rounded-full ${
                    activeTab === "dashboard" ? "bg-emerald-500 ring-4 ring-emerald-500/20" : "bg-gray-600"
                  }`}
                ></span>
                <span className="font-medium">داشبورد و گزارشات مالی</span>
              </div>
              <ChevronLeft className="w-4 h-4 opacity-60" />
            </button>

            <button
              id="nav-prompt-btn"
              onClick={() => setActiveTab("prompt")}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                activeTab === "prompt"
                  ? "bg-gray-800/60 text-emerald-400 border border-gray-700/60 shadow-sm"
                  : "text-gray-400 hover:text-gray-200 hover:bg-gray-800/30"
              }`}
            >
              <div className="flex items-center gap-3">
                <span
                  className={`w-2 h-2 rounded-full ${
                    activeTab === "prompt" ? "bg-emerald-500 ring-4 ring-emerald-500/20" : "bg-gray-600"
                  }`}
                ></span>
                <span className="font-medium">کنسول دستورات هوشمند (CEO)</span>
              </div>
              <Sparkles className="w-4 h-4 text-emerald-400" />
            </button>

            <button
              id="nav-agents-btn"
              onClick={() => setActiveTab("agents")}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                activeTab === "agents"
                  ? "bg-gray-800/60 text-emerald-400 border border-gray-700/60 shadow-sm"
                  : "text-gray-400 hover:text-gray-200 hover:bg-gray-800/30"
              }`}
            >
              <div className="flex items-center gap-3">
                <span
                  className={`w-2 h-2 rounded-full ${
                    activeTab === "agents" ? "bg-emerald-500 ring-4 ring-emerald-500/20" : "bg-gray-600"
                  }`}
                ></span>
                <span className="font-medium">شبکه عامل‌ها (Agent Kernel)</span>
              </div>
              <span className="text-[11px] px-2 py-0.5 bg-gray-800 text-gray-400 rounded-md">9 عامل</span>
            </button>

            <button
              id="nav-rules-btn"
              onClick={() => setActiveTab("rules")}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                activeTab === "rules"
                  ? "bg-gray-800/60 text-emerald-400 border border-gray-700/60 shadow-sm"
                  : "text-gray-400 hover:text-gray-200 hover:bg-gray-800/30"
              }`}
            >
              <div className="flex items-center gap-3">
                <span
                  className={`w-2 h-2 rounded-full ${
                    activeTab === "rules" ? "bg-emerald-500 ring-4 ring-emerald-500/20" : "bg-gray-600"
                  }`}
                ></span>
                <span className="font-medium">قوانین و تایید انسانی</span>
              </div>
              {candidateRules.length > 0 && (
                <span className="text-[10px] px-1.5 py-0.5 bg-amber-500/20 text-amber-400 font-bold rounded-full animate-pulse">
                  {candidateRules.length} معلق
                </span>
              )}
            </button>

            <button
              id="nav-resilience-btn"
              onClick={() => setActiveTab("resilience")}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                activeTab === "resilience"
                  ? "bg-gray-800/60 text-emerald-400 border border-gray-700/60 shadow-sm"
                  : "text-gray-400 hover:text-gray-200 hover:bg-gray-800/30"
              }`}
            >
              <div className="flex items-center gap-3">
                <span
                  className={`w-2 h-2 rounded-full ${
                    activeTab === "resilience" ? "bg-emerald-500 ring-4 ring-emerald-500/20" : "bg-gray-600"
                  }`}
                ></span>
                <span className="font-medium">تاب‌آوری و خودترمیمی</span>
              </div>
              <ShieldCheck className="w-4 h-4 text-gray-500" />
            </button>

            <button
              id="nav-logs-btn"
              onClick={() => setActiveTab("logs")}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                activeTab === "logs"
                  ? "bg-gray-800/60 text-emerald-400 border border-gray-700/60 shadow-sm"
                  : "text-gray-400 hover:text-gray-200 hover:bg-gray-800/30"
              }`}
            >
              <div className="flex items-center gap-3">
                <span
                  className={`w-2 h-2 rounded-full ${
                    activeTab === "logs" ? "bg-emerald-500 ring-4 ring-emerald-500/20" : "bg-gray-600"
                  }`}
                ></span>
                <span className="font-medium">سوپر لاگ‌ها و ردپا SHA-256</span>
              </div>
              <Terminal className="w-4 h-4 text-gray-500" />
            </button>

            <button
              id="nav-study-btn"
              onClick={() => setActiveTab("study")}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                activeTab === "study"
                  ? "bg-gray-800/60 text-emerald-400 border border-gray-700/60 shadow-sm"
                  : "text-gray-400 hover:text-gray-200 hover:bg-gray-800/30"
              }`}
            >
              <div className="flex items-center gap-3">
                <span
                  className={`w-2 h-2 rounded-full ${
                    activeTab === "study" ? "bg-emerald-500 ring-4 ring-emerald-500/20" : "bg-gray-600"
                  }`}
                ></span>
                <span className="font-medium">پژوهش و استعلام مالیاتی</span>
              </div>
              <BookOpen className="w-4 h-4 text-gray-500" />
            </button>

            <button
              id="nav-skills-btn"
              onClick={() => setActiveTab("skills")}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                activeTab === "skills"
                  ? "bg-gray-800/60 text-emerald-400 border border-gray-700/60 shadow-sm"
                  : "text-gray-400 hover:text-gray-200 hover:bg-gray-800/30"
              }`}
            >
              <div className="flex items-center gap-3">
                <span
                  className={`w-2 h-2 rounded-full ${
                    activeTab === "skills" ? "bg-emerald-500 ring-4 ring-emerald-500/20" : "bg-gray-600"
                  }`}
                ></span>
                <span className="font-medium">مهارت‌ها و سندباکس اکسل</span>
              </div>
              <FileSpreadsheet className="w-4 h-4 text-gray-500" />
            </button>
          </nav>
        </div>

        {/* System & User Profile Footer */}
        <div className="mt-auto p-6 border-t border-gray-800 bg-[#111111]">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-emerald-700 to-teal-600 border border-emerald-500/30 flex items-center justify-center text-white font-bold text-sm">
                م‌ک
              </div>
              <div>
                <p className="text-sm font-semibold text-white">معید کفیل</p>
                <p className="text-xs text-gray-500">حسابرس ارشد سیستم</p>
              </div>
            </div>
            <button
              id="refresh-state-btn"
              onClick={fetchState}
              disabled={loading}
              title="بروزرسانی وضعیت سیستم"
              className="p-2 rounded-lg bg-gray-800/60 hover:bg-gray-700 text-gray-400 hover:text-emerald-400 transition-colors"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
            </button>
          </div>
          <div className="flex items-center justify-between text-[11px] text-gray-500 pt-2 border-t border-gray-800/80">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-ping"></span>
              هسته DB انحصاری فعال
            </span>
            <span>بومی ۱۰۰٪ عملیاتی</span>
          </div>
        </div>
      </aside>

      {/* ========================================================= */}
      {/* MAIN VIEWPORT */}
      {/* ========================================================= */}
      <main className="flex-1 flex flex-col p-8 gap-6 overflow-hidden bg-[#0d0d0d]">
        {/* Top Header Bar */}
        <header className="flex justify-between items-center shrink-0">
          <div>
            <h1 className="text-2xl font-bold text-white mb-1">
              {activeTab === "dashboard" && "داشبورد عملیاتی و صورت‌های مالی"}
              {activeTab === "prompt" && "کنسول فرمان چندعاملی CEO"}
              {activeTab === "agents" && "توپولوژی و وضعیت عامل‌های خودمختار"}
              {activeTab === "rules" && "کتابخانه قوانین و درگاه بازبینی انسانی"}
              {activeTab === "resilience" && "سیستم‌های پشتیبان‌گیری، بازیابی و خودترمیمی"}
              {activeTab === "logs" && "سوپر لاگ‌های زنجیره‌ای رمزنگاری‌شده (SHA-256)"}
              {activeTab === "study" && "عامل پژوهش و تحلیل مقررات حسابداری"}
              {activeTab === "skills" && "رجیستری مهارت‌ها و ابزارهای سندباکس"}
            </h1>
            <p className="text-xs text-gray-500">
              سیستم حسابداری دوطرفه خودکار تحت نظارت منتقد ۴ لایه‌ای (Final Checker Critic)
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex items-center gap-3">
            <button
              id="header-prompt-action-btn"
              onClick={() => setActiveTab("prompt")}
              className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-medium shadow-lg shadow-emerald-900/30 transition-all cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>+ ثبت هوشمند تراکنش با پرامپت</span>
            </button>
            <button
              id="header-selfheal-btn"
              onClick={handleSelfHeal}
              className="flex items-center gap-2 px-4 py-2.5 bg-[#1a1a1a] border border-gray-800 text-gray-300 rounded-xl font-medium hover:bg-gray-800 transition-all cursor-pointer"
            >
              <Activity className="w-4 h-4 text-emerald-400" />
              <span>چک خودترمیمی</span>
            </button>
            <button
              id="header-backup-btn"
              onClick={handleMakeBackup}
              className="flex items-center gap-2 px-4 py-2.5 bg-[#1a1a1a] border border-gray-800 text-gray-300 rounded-xl font-medium hover:bg-gray-800 transition-all cursor-pointer"
            >
              <Database className="w-4 h-4 text-blue-400" />
              <span>پشتیبان‌گیری</span>
            </button>
          </div>
        </header>

        {/* Dynamic Tab Views */}
        <div className="flex-1 overflow-y-auto pr-1">
          {/* ========================================================= */}
          {/* TAB 1: DASHBOARD */}
          {/* ========================================================= */}
          {activeTab === "dashboard" && (
            <div className="space-y-6">
              {/* 3 Metric Cards matching Elegant Dark Theme */}
              <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-[#1a1a1a] p-6 rounded-2xl border border-gray-800 relative overflow-hidden">
                  <div className="flex justify-between items-start mb-2">
                    <p className="text-gray-500 text-sm font-medium">موجودی کل دارایی‌ها (Assets)</p>
                    <span className="p-2 bg-emerald-500/10 text-emerald-400 rounded-lg">
                      <TrendingUp className="w-4 h-4" />
                    </span>
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-bold text-white tracking-tight">
                      {balanceSheet.total_assets.toLocaleString("fa-IR")}
                    </span>
                    <span className="text-xs text-gray-400">ریال</span>
                  </div>
                  <div className="mt-4 flex items-center gap-2 text-emerald-400 text-xs">
                    <span className="py-0.5 px-2 bg-emerald-400/10 rounded-full font-bold">+ ۱۰۰٪ متوازن</span>
                    <span className="text-gray-400">
                      بدهی‌ها: {balanceSheet.total_liabilities.toLocaleString("fa-IR")} ریال
                    </span>
                  </div>
                </div>

                <div className="bg-[#1a1a1a] p-6 rounded-2xl border border-gray-800 relative overflow-hidden">
                  <div className="flex justify-between items-start mb-2">
                    <p className="text-gray-500 text-sm font-medium">مجموع درآمد شناسایی‌شده (Revenue)</p>
                    <span className="p-2 bg-blue-500/10 text-blue-400 rounded-lg">
                      <ArrowUpRight className="w-4 h-4" />
                    </span>
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-bold text-white tracking-tight">
                      {incomeStatement.total_revenue.toLocaleString("fa-IR")}
                    </span>
                    <span className="text-xs text-gray-400">ریال</span>
                  </div>
                  <div className="mt-4 flex items-center gap-2 text-gray-400 text-xs">
                    <span className="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden">
                      <span className="block h-full w-[80%] bg-emerald-500"></span>
                    </span>
                  </div>
                </div>

                <div className="bg-[#1a1a1a] p-6 rounded-2xl border border-gray-800 relative overflow-hidden">
                  <div className="flex justify-between items-start mb-2">
                    <p className="text-gray-500 text-sm font-medium">مجموع هزینه‌های دوره (Expenses)</p>
                    <span className="p-2 bg-rose-500/10 text-rose-400 rounded-lg">
                      <ArrowDownLeft className="w-4 h-4" />
                    </span>
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-bold text-white tracking-tight">
                      {incomeStatement.total_expenses.toLocaleString("fa-IR")}
                    </span>
                    <span className="text-xs text-gray-400">ریال</span>
                  </div>
                  <div className="mt-4 flex items-center gap-2 text-rose-400 text-xs">
                    <span className="py-0.5 px-2 bg-rose-400/10 rounded-full font-bold">
                      سود خالص: {incomeStatement.net_income.toLocaleString("fa-IR")} ریال
                    </span>
                    <span className="text-gray-400">حاشیه سود {incomeStatement.net_margin_pct}%</span>
                  </div>
                </div>
              </section>

              {/* Main Content Grid: Transactions Table + Budget & Financial Distribution */}
              <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Recent Transactions Table */}
                <div className="lg:col-span-2 bg-[#1a1a1a] rounded-2xl border border-gray-800 flex flex-col overflow-hidden">
                  <div className="p-6 border-b border-gray-800 flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-white text-base">دفتر روزنامه و تراکنش‌های اخیر</h3>
                      <span className="text-xs px-2 py-0.5 bg-emerald-500/10 text-emerald-400 rounded-full">
                        {recentTxns.length} ثبت
                      </span>
                    </div>
                    <span className="text-xs text-gray-400">همه اسناد دارای تعادل بدهکار/بستانکار</span>
                  </div>
                  <div className="overflow-x-auto p-6">
                    {recentTxns.length === 0 ? (
                      <div className="text-center py-12 text-gray-500">
                        <FileText className="w-12 h-12 mx-auto mb-3 opacity-30 text-gray-400" />
                        <p>هنوز تراکنشی ثبت نشده است. از طریق کنسول پرامپت اولین سند را صادر کنید.</p>
                      </div>
                    ) : (
                      <table className="w-full text-right text-sm">
                        <thead className="text-xs text-gray-500 uppercase border-b border-gray-800">
                          <tr>
                            <th className="pb-3 font-medium">شماره سند</th>
                            <th className="pb-3 font-medium">شرح تراکنش</th>
                            <th className="pb-3 font-medium">تاریخ</th>
                            <th className="pb-3 font-medium">وضعیت تایید منتقد</th>
                            <th className="pb-3 font-medium text-left">مبلغ سند</th>
                            <th className="pb-3 font-medium text-center">عملیات</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-800/60">
                          {recentTxns.map((txn) => (
                            <tr key={txn.id} className="hover:bg-gray-800/30 transition-colors">
                              <td className="py-4 text-xs font-mono text-gray-400">{txn.transaction_number}</td>
                              <td className="py-4 text-white font-medium max-w-xs truncate">{txn.description}</td>
                              <td className="py-4 text-xs text-gray-400">{txn.transaction_date}</td>
                              <td className="py-4">
                                {txn.verified_by_critic ? (
                                  <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-500/10 text-emerald-400 rounded-lg text-[11px] font-medium border border-emerald-500/20">
                                    <ShieldCheck className="w-3.5 h-3.5" />
                                    تایید ۴ لایه Critic
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-amber-500/10 text-amber-400 rounded-lg text-[11px] font-medium border border-amber-500/20">
                                    <Clock className="w-3.5 h-3.5" />
                                    در انتظار نظارت
                                  </span>
                                )}
                              </td>
                              <td className="py-4 text-emerald-400 font-bold text-left font-mono">
                                {txn.total_debit.toLocaleString("fa-IR")} ریال
                              </td>
                              <td className="py-4 text-center">
                                <button
                                  onClick={() => setSelectedTxn(txn)}
                                  className="text-xs px-3 py-1 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-lg transition-colors"
                                >
                                  مشاهده آرتیکل‌ها
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    )}
                  </div>
                </div>

                {/* Right Side: Account Balances & Quick Educational Box */}
                <div className="flex flex-col gap-6">
                  {/* Account Master Chart Overview */}
                  <div className="bg-[#1a1a1a] p-6 rounded-2xl border border-gray-800">
                    <h3 className="font-bold text-white mb-4 text-base flex items-center justify-between">
                      <span>تراز آزمایشی سرفصل‌ها</span>
                      <span className="text-xs text-gray-500">Trial Balance</span>
                    </h3>
                    <div className="space-y-3 max-h-64 overflow-y-auto pr-1">
                      {trialBalance.map((item: any) => (
                        <div
                          key={item.code}
                          className="flex items-center justify-between p-3 bg-gray-900/60 rounded-xl border border-gray-800/60 text-xs"
                        >
                          <div>
                            <p className="font-semibold text-white">{item.name_fa || item.name}</p>
                            <p className="text-[10px] text-gray-500 font-mono">کد {item.code}</p>
                          </div>
                          <div className="text-left font-mono">
                            <p
                              className={`font-bold ${
                                item.net_balance >= 0 ? "text-emerald-400" : "text-rose-400"
                              }`}
                            >
                              {item.net_balance.toLocaleString("fa-IR")}
                            </p>
                            <p className="text-[9px] text-gray-500">
                              {item.net_balance >= 0 ? "بدهکار" : "بستانکار"}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Educational Feature Card matching design */}
                  <div className="bg-gradient-to-br from-emerald-600 to-teal-800 p-6 rounded-2xl text-white shadow-xl shadow-emerald-950/30">
                    <div className="flex items-center gap-2 mb-2">
                      <Shield className="w-5 h-5 text-emerald-200" />
                      <h4 className="font-bold text-base">سیستم عامل حسابداری چندعاملی</h4>
                    </div>
                    <p className="text-xs opacity-90 leading-relaxed mb-4">
                      موتور قطعی حسابداری (Deterministic Fast Path) به همراه ارزیابی خودکار منتقد ۴ لایه، از بروز هرگونه
                      کسری، عدم تعادل یا خطای انسانی جلوگیری می‌کند.
                    </p>
                    <button
                      onClick={() => setActiveTab("agents")}
                      className="w-full py-2.5 bg-black/20 hover:bg-black/30 rounded-xl text-xs font-bold transition-all border border-white/20"
                    >
                      مشاهده معماری کرنل عامل‌ها
                    </button>
                  </div>
                </div>
              </section>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 2: PROMPT CONSOLE (CEO AI ENGINE) */}
          {/* ========================================================= */}
          {activeTab === "prompt" && (
            <div className="space-y-6">
              <div className="bg-[#1a1a1a] p-6 rounded-2xl border border-gray-800">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20">
                    <Sparkles className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-white">کنسول صدور هوشمند اسناد با هوش مصنوعی</h2>
                    <p className="text-xs text-gray-400">
                      هرگونه رویداد مالی را به زبان فارسی یا انگلیسی تایپ کنید. سیستم ابتدا از مسیر قطعی (Fast Path) و در
                      صورت ابهام از مسیر پژوهش (Research Path) استفاده می‌کند.
                    </p>
                  </div>
                </div>

                {/* Prompt Input Form */}
                <div className="relative mb-4">
                  <textarea
                    id="ceo-prompt-textarea"
                    rows={3}
                    value={promptInput}
                    onChange={(e) => setPromptInput(e.target.value)}
                    placeholder="مثال: فروش نقدی کالا به شرکت آلفا به مبلغ ۵۰,۰۰۰,۰۰۰ ریال با احتساب ۹٪ ارزش افزوده..."
                    className="w-full bg-[#111111] border border-gray-700 rounded-xl p-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-emerald-500 transition-colors"
                  />
                  <button
                    id="ceo-prompt-execute-btn"
                    onClick={() => handlePromptSubmit()}
                    disabled={processingPrompt || !promptInput.trim()}
                    className="absolute bottom-4 left-4 flex items-center gap-2 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:bg-gray-800 disabled:text-gray-500 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-emerald-950/40 cursor-pointer"
                  >
                    {processingPrompt ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>در حال تحلیل و بررسی ۴ لایه Critic...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>پردازش و ثبت رسمی سند</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Persian Fast Scenario Buttons */}
                <div>
                  <p className="text-xs font-semibold text-gray-400 mb-2">سناریوهای مالی آماده برای تست سریع:</p>
                  <div className="flex flex-wrap gap-2">
                    {[
                      "فروش نقدی کالا به مبلغ ۱۵۰۰۰۰۰۰ ریال با احتساب مالیات ارزش افزوده",
                      "خرید نسیه مواد اولیه از بازرگانی پارس به مبلغ ۲۵۰۰۰۰۰۰ ریال",
                      "پرداخت حقوق و دستمزد پرسنل به مبلغ ۳۸۰۰۰۰۰۰ ریال از طریق بانک",
                      "پرداخت هزینه اجاره دفتر مرکزی به مبلغ ۱۲۰۰۰۰۰۰ ریال به صورت نقدی",
                      "خرید تجهیزات و اثاثه اداری به مبلغ ۴۵۰۰۰۰۰۰ ریال با چک بانکی",
                    ].map((sample, idx) => (
                      <button
                        key={idx}
                        onClick={() => {
                          setPromptInput(sample);
                          handlePromptSubmit(sample);
                        }}
                        className="text-xs px-3 py-2 bg-gray-900/80 hover:bg-gray-800 text-gray-300 rounded-xl border border-gray-800 hover:border-gray-700 transition-all text-right"
                      >
                        {sample}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Execution Result & Pipeline Breakdown */}
              {promptResult && (
                <div className="bg-[#1a1a1a] p-6 rounded-2xl border border-gray-800 space-y-6">
                  <div className="flex items-center justify-between border-b border-gray-800 pb-4">
                    <div className="flex items-center gap-3">
                      {promptResult.ok ? (
                        <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-lg">
                          <CheckCircle2 className="w-6 h-6" />
                        </div>
                      ) : (
                        <div className="p-2 bg-rose-500/10 text-rose-400 rounded-lg">
                          <AlertCircle className="w-6 h-6" />
                        </div>
                      )}
                      <div>
                        <h3 className="font-bold text-white text-base">
                          {promptResult.ok ? "تراکنش با موفقیت پردازش و ثبت شد" : "پردازش با اخطار متوقف شد"}
                        </h3>
                        <p className="text-xs text-gray-400">{promptResult.message}</p>
                      </div>
                    </div>
                    <div className="text-left font-mono text-xs text-gray-500">
                      <p>Task ID: {promptResult.task_id}</p>
                      <p>Discrepancy: {promptResult.discrepancy || 0.0}%</p>
                    </div>
                  </div>

                  {/* Critic 4-Layer Verification Badge */}
                  {promptResult.critic_result && (
                    <div className="bg-[#111111] p-4 rounded-xl border border-gray-800">
                      <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                        <ShieldCheck className="w-4 h-4" />
                        گیت تایید اعتبار منتقد نهایی (Final Checker Critic - n14)
                      </h4>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        {promptResult.critic_result.layers?.map((layer: any, idx: number) => (
                          <div
                            key={idx}
                            className="p-3 bg-gray-900/50 rounded-lg border border-gray-800/80 flex flex-col justify-between"
                          >
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-xs font-medium text-white">{layer.layer_name}</span>
                              <span
                                className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                                  layer.passed ? "bg-emerald-500/20 text-emerald-400" : "bg-rose-500/20 text-rose-400"
                                }`}
                              >
                                {layer.passed ? "تایید شد" : "رد شد"}
                              </span>
                            </div>
                            <p className="text-[11px] text-gray-400 mt-1">{layer.details}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Double-Entry Journal Lines Generated */}
                  {promptResult.domain_result?.journal_entry && (
                    <div className="space-y-3">
                      <h4 className="text-xs font-bold text-gray-300 uppercase tracking-wider">
                        سند حسابداری دوطرفه تولید شده (Double-Entry Balanced Journal)
                      </h4>
                      <div className="overflow-x-auto bg-[#111111] rounded-xl border border-gray-800">
                        <table className="w-full text-right text-xs">
                          <thead className="border-b border-gray-800 text-gray-500 font-medium">
                            <tr>
                              <th className="p-3">کد حساب</th>
                              <th className="p-3">عنوان حساب</th>
                              <th className="p-3">شرح آرتیکل</th>
                              <th className="p-3 text-left">بدهکار (ریال)</th>
                              <th className="p-3 text-left">بستانکار (ریال)</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-gray-800/60">
                            {promptResult.domain_result.journal_entry.lines?.map((line: any, idx: number) => (
                              <tr key={idx}>
                                <td className="p-3 font-mono text-gray-400">{line.account_code}</td>
                                <td className="p-3 text-white font-medium">{line.account_name}</td>
                                <td className="p-3 text-gray-400">{line.description}</td>
                                <td className="p-3 font-mono font-bold text-emerald-400 text-left">
                                  {line.debit > 0 ? line.debit.toLocaleString("fa-IR") : "-"}
                                </td>
                                <td className="p-3 font-mono font-bold text-rose-400 text-left">
                                  {line.credit > 0 ? line.credit.toLocaleString("fa-IR") : "-"}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                          <tfoot className="bg-gray-900/60 font-bold border-t border-gray-800">
                            <tr>
                              <td colSpan={3} className="p-3 text-left">
                                جمع کل سند:
                              </td>
                              <td className="p-3 font-mono text-emerald-400 text-left">
                                {promptResult.domain_result.journal_entry.total_debit?.toLocaleString("fa-IR")}
                              </td>
                              <td className="p-3 font-mono text-rose-400 text-left">
                                {promptResult.domain_result.journal_entry.total_credit?.toLocaleString("fa-IR")}
                              </td>
                            </tr>
                          </tfoot>
                        </table>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 3: AGENTS NETWORK & GRAPHML TOPOLOGY */}
          {/* ========================================================= */}
          {activeTab === "agents" && (
            <div className="space-y-6">
              <div className="bg-[#1a1a1a] p-6 rounded-2xl border border-gray-800">
                <h2 className="text-lg font-bold text-white mb-2">معماری و ساختار عامل‌های سیستم (Hesabdar Kernel)</h2>
                <p className="text-xs text-gray-400 mb-6">
                  بر اساس دیاگرام رسمی GraphML و مستندات معماری، همه ارتباطات از طریق CEO و کانال‌های احرازشده پیام‌رسانی
                  (Authenticated Channel) انجام می‌پذیرد و عامل پایگاه داده تنها مجاز به نوشتن در دیتابیس است.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {registeredAgents.map((agent: any) => (
                    <div
                      key={agent.id}
                      className="p-5 bg-[#111111] rounded-2xl border border-gray-800/80 hover:border-emerald-500/40 transition-all flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-xs font-bold text-emerald-400 font-mono">[{agent.id}]</span>
                          <span className="text-[10px] px-2 py-0.5 bg-emerald-500/10 text-emerald-400 rounded-full font-bold">
                            {agent.status}
                          </span>
                        </div>
                        <h4 className="text-sm font-bold text-white mb-1">{agent.name}</h4>
                        <p className="text-xs text-gray-400 leading-relaxed">{agent.role}</p>
                      </div>
                      <div className="mt-4 pt-3 border-t border-gray-800/80 flex items-center justify-between text-[11px] text-gray-500">
                        <span>پروتکل: Ed25519/HMAC</span>
                        <span className="text-emerald-500">کانال امن</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 4: RULES & HUMAN APPROVAL GATE */}
          {/* ========================================================= */}
          {activeTab === "rules" && (
            <div className="space-y-6">
              {/* Candidate Rules Pending Approval */}
              <div className="bg-[#1a1a1a] p-6 rounded-2xl border border-gray-800">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-bold text-white">درگاه تایید قوانین هوش مصنوعی (Human Approval Gate)</h2>
                    <span className="text-xs px-2.5 py-0.5 bg-amber-500/20 text-amber-400 font-bold rounded-full">
                      {candidateRules.length} قانون در انتظار
                    </span>
                  </div>
                  <span className="text-xs text-gray-400">قوانین جدید بدون تایید انسان وارد فاز تولید نمی‌شوند</span>
                </div>

                {candidateRules.length === 0 ? (
                  <div className="p-8 text-center bg-[#111111] rounded-xl border border-gray-800 text-gray-500 text-xs">
                    هیچ قانون پیشنهادی معلقی در سیستم وجود ندارد. تمامی قوانین فعال فعلی تایید شده هستند.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {candidateRules.map((cRule) => (
                      <div
                        key={cRule.id}
                        className="p-4 bg-[#111111] rounded-xl border border-amber-500/30 flex flex-col md:flex-row justify-between items-start md:items-center gap-4"
                      >
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-sm font-bold text-white">{cRule.name}</span>
                            <span className="text-[10px] px-2 py-0.5 bg-amber-500/10 text-amber-400 rounded-md">
                              پیشنهاد شده توسط {cRule.proposed_by}
                            </span>
                          </div>
                          <p className="text-xs text-gray-400">{cRule.justification}</p>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            onClick={() => handleApproveRule(cRule.id)}
                            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all cursor-pointer"
                          >
                            تایید و افزودن به قوانین عملیاتی
                          </button>
                          <button
                            onClick={() => handleRejectRule(cRule.id)}
                            className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-rose-400 rounded-xl text-xs font-bold transition-all cursor-pointer"
                          >
                            رد پیشنهاد
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Active Production Rules */}
              <div className="bg-[#1a1a1a] p-6 rounded-2xl border border-gray-800">
                <h2 className="text-lg font-bold text-white mb-4">قوانین فعال حسابداری دوطرفه (Active Production Rules)</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {activeRules.map((rule) => (
                    <div key={rule.id} className="p-4 bg-[#111111] rounded-xl border border-gray-800 text-xs space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-white text-sm">{rule.name}</span>
                        <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 rounded-full font-mono text-[10px]">
                          اولویت {rule.priority}
                        </span>
                      </div>
                      <p className="text-gray-400 font-mono">دسته: {rule.category}</p>
                      <div className="bg-gray-900 p-2.5 rounded-lg font-mono text-[11px] text-gray-300 overflow-x-auto">
                        {typeof rule.action === "string" ? rule.action : JSON.stringify(rule.action)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 5: RESILIENCE & SELF-HEALING */}
          {/* ========================================================= */}
          {activeTab === "resilience" && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Snapshot Backups */}
                <div className="bg-[#1a1a1a] p-6 rounded-2xl border border-gray-800">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-bold text-white text-base flex items-center gap-2">
                      <Database className="w-5 h-5 text-emerald-400" />
                      نسخه‌های پشتیبان آزموده شده
                    </h3>
                    <button
                      onClick={handleMakeBackup}
                      className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold"
                    >
                      + ایجاد پشتیبان جدید
                    </button>
                  </div>
                  <div className="space-y-2.5 max-h-72 overflow-y-auto">
                    {backups.length === 0 ? (
                      <p className="text-xs text-gray-500">پشتیبانی ثبت نشده است.</p>
                    ) : (
                      backups.map((b: any, idx: number) => (
                        <div
                          key={idx}
                          className="p-3 bg-[#111111] rounded-xl border border-gray-800 flex items-center justify-between text-xs"
                        >
                          <div>
                            <p className="font-mono text-white font-semibold">{b.filename}</p>
                            <p className="text-[10px] text-gray-500">
                              {b.accounts} حساب | {b.transactions} تراکنش | {b.size_kb} KB
                            </p>
                          </div>
                          <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 rounded-md font-bold text-[10px]">
                            تایید یکپارچگی OK
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Self-Healing Status */}
                <div className="bg-[#1a1a1a] p-6 rounded-2xl border border-gray-800">
                  <h3 className="font-bold text-white text-base flex items-center gap-2 mb-4">
                    <Activity className="w-5 h-5 text-emerald-400" />
                    مکانیزم خودترمیمی ۲ مرحله‌ای (Self-Healing n9)
                  </h3>
                  <p className="text-xs text-gray-400 leading-relaxed mb-4">
                    در صورت بروز خطای عدم انطباق یا قطع ارتباط، سیستم با تحلیل ۲ مرحله‌ای (First Pass Analyzer + Second
                    Pass Corroborator) تراکنش‌های جبرانی را اعمال و سیستم را به آخرین نقطه بازیابی مطمئن بازمی‌گرداند.
                  </p>
                  <button
                    onClick={handleSelfHeal}
                    className="w-full py-3 bg-gray-800 hover:bg-gray-700 text-emerald-400 rounded-xl text-xs font-bold transition-all border border-gray-700/60"
                  >
                    اجرای چرخه تشخیصی خودترمیمی و جبران خطا
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 6: SUPER LOGS & CRYPTOGRAPHIC AUDIT STREAM */}
          {/* ========================================================= */}
          {activeTab === "logs" && (
            <div className="bg-[#1a1a1a] p-6 rounded-2xl border border-gray-800 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Terminal className="w-5 h-5 text-emerald-400" />
                  <h2 className="text-lg font-bold text-white">سوپر لاگ‌ها و زنجیره حسابرسی Haber-Stornetta</h2>
                </div>
                <span className="text-xs text-gray-500">زنجیره رمزنگاری SHA-256 غیرقابل دستکاری</span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead className="border-b border-gray-800 text-gray-500 font-medium">
                    <tr>
                      <th className="pb-3">زمان</th>
                      <th className="pb-3">عامل</th>
                      <th className="pb-3">مرحله</th>
                      <th className="pb-3">سطح</th>
                      <th className="pb-3">شرح رویداد</th>
                      <th className="pb-3 text-left">عدم انطباق</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-800/50">
                    {superLogs.map((log) => (
                      <tr key={log.id} className="hover:bg-gray-900/40">
                        <td className="py-3 text-[10px] font-mono text-gray-500">
                          {new Date(log.timestamp * 1000).toLocaleTimeString("fa-IR")}
                        </td>
                        <td className="py-3 font-mono text-emerald-400">{log.agent_id}</td>
                        <td className="py-3 text-gray-300 font-mono text-[11px]">{log.stage}</td>
                        <td className="py-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              log.level === "ERROR"
                                ? "bg-rose-500/20 text-rose-400"
                                : log.level === "WARN"
                                ? "bg-amber-500/20 text-amber-400"
                                : "bg-emerald-500/10 text-emerald-400"
                            }`}
                          >
                            {log.level}
                          </span>
                        </td>
                        <td className="py-3 text-white max-w-md truncate">{log.summary}</td>
                        <td className="py-3 text-left font-mono text-gray-400">{log.discrepancy || 0}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 7: STUDY & REGULATORY KNOWLEDGE */}
          {/* ========================================================= */}
          {activeTab === "study" && (
            <div className="space-y-6">
              <div className="bg-[#1a1a1a] p-6 rounded-2xl border border-gray-800">
                <div className="flex items-center gap-3 mb-4">
                  <BookOpen className="w-6 h-6 text-emerald-400" />
                  <div>
                    <h2 className="text-lg font-bold text-white">عامل پژوهش و استعلام استانداردهای حسابداری (n11)</h2>
                    <p className="text-xs text-gray-400">
                      پژوهش روی سرفصل‌های استاندارد، قوانین مالیات بر ارزش افزوده و رهنمودهای IFRS
                    </p>
                  </div>
                </div>

                <div className="flex gap-3 mb-6">
                  <input
                    type="text"
                    value={studyTopic}
                    onChange={(e) => setStudyTopic(e.target.value)}
                    placeholder="موضوع پژوهش حسابداری..."
                    className="flex-1 bg-[#111111] border border-gray-700 rounded-xl px-4 py-2.5 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-emerald-500"
                  />
                  <button
                    onClick={handlePerformStudy}
                    disabled={studying}
                    className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-emerald-950/40 cursor-pointer"
                  >
                    {studying ? "در حال مطالعه..." : "انجام پژوهش"}
                  </button>
                </div>

                {studyResult && (
                  <div className="bg-[#111111] p-6 rounded-xl border border-gray-800 space-y-4">
                    <h3 className="font-bold text-white text-base">{studyResult.topic}</h3>
                    <div className="p-4 bg-gray-900/60 rounded-xl border border-gray-800 text-sm text-gray-300 leading-relaxed">
                      {studyResult.summary}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-emerald-400 uppercase mb-2">رهنمودهای اجرایی:</h4>
                      <ul className="space-y-1.5 text-xs text-gray-300">
                        {studyResult.actionable_guidance?.map((item: string, idx: number) => (
                          <li key={idx} className="flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 8: SKILL REGISTRY & TOOLS */}
          {/* ========================================================= */}
          {activeTab === "skills" && (
            <div className="bg-[#1a1a1a] p-6 rounded-2xl border border-gray-800 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-bold text-white">رجیستری مهارت‌ها و ابزارهای سندباکس (Skill Registry - n19)</h2>
                  <p className="text-xs text-gray-400">
                    مهارت‌های ثبت شده و مجاز تحت کنترل کامل CEO و سیستم مجوزدهی سندباکس
                  </p>
                </div>
                <span className="text-xs px-2.5 py-1 bg-emerald-500/10 text-emerald-400 rounded-full font-mono">
                  {skills.length} Skill Active
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {skills.map((skill) => (
                  <div key={skill.id} className="p-5 bg-[#111111] rounded-xl border border-gray-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <h3 className="font-bold text-white text-sm">{skill.name}</h3>
                      <span className="text-xs font-mono text-emerald-400">v{skill.version}</span>
                    </div>
                    <p className="text-xs text-gray-400 leading-relaxed">{skill.description}</p>
                    <div className="flex flex-wrap gap-1.5 pt-2">
                      {skill.capabilities?.map((cap: string, idx: number) => (
                        <span key={idx} className="px-2 py-0.5 bg-gray-800 text-gray-300 rounded text-[10px]">
                          {cap}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>

      {/* ========================================================= */}
      {/* TRANSACTION JOURNAL LINES MODAL */}
      {/* ========================================================= */}
      {selectedTxn && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#141414] border border-gray-800 rounded-2xl max-w-2xl w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-gray-800 pb-3">
              <div>
                <h3 className="font-bold text-white text-base">سند شماره {selectedTxn.transaction_number}</h3>
                <p className="text-xs text-gray-400">{selectedTxn.description}</p>
              </div>
              <button
                onClick={() => setSelectedTxn(null)}
                className="p-1.5 bg-gray-800 hover:bg-gray-700 text-gray-400 rounded-lg"
              >
                ✕
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead className="border-b border-gray-800 text-gray-500 font-medium">
                  <tr>
                    <th className="pb-2">کد حساب</th>
                    <th className="pb-2">عنوان حساب</th>
                    <th className="pb-2 text-left">بدهکار</th>
                    <th className="pb-2 text-left">بستانکار</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-800/50">
                  {selectedTxn.lines?.map((l: any, idx: number) => (
                    <tr key={idx}>
                      <td className="py-2.5 font-mono text-gray-400">{l.account_code}</td>
                      <td className="py-2.5 text-white font-medium">{l.account_name}</td>
                      <td className="py-2.5 font-mono font-bold text-emerald-400 text-left">
                        {l.debit > 0 ? l.debit.toLocaleString("fa-IR") : "-"}
                      </td>
                      <td className="py-2.5 font-mono font-bold text-rose-400 text-left">
                        {l.credit > 0 ? l.credit.toLocaleString("fa-IR") : "-"}
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="border-t border-gray-800 font-bold">
                  <tr>
                    <td colSpan={2} className="py-2.5 text-left">
                      جمع:
                    </td>
                    <td className="py-2.5 font-mono text-emerald-400 text-left">
                      {selectedTxn.total_debit?.toLocaleString("fa-IR")}
                    </td>
                    <td className="py-2.5 font-mono text-rose-400 text-left">
                      {selectedTxn.total_credit?.toLocaleString("fa-IR")}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setSelectedTxn(null)}
                className="px-5 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-xl text-xs font-semibold transition-colors"
              >
                بستن
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
