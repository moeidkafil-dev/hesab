"""
دمو end-to-end از step1 + step2. با LLM محلی (Ollama/gemma2) یا هر provider
دیگه‌ای که در config.py ست شده اجرا می‌شه.

اجرا:
    python3 main.py
"""
from __future__ import annotations

from hesabdar.ceo import CEOAgentArchitecture
from hesabdar.tools import ToolManager
from hesabdar.config import DATA_DIR


def main():
    print(f"[data dir] {DATA_DIR}")

    # --- step 2: tools, with an explicit per-agent authorization policy
    tool_manager = ToolManager(sandbox_root=str(DATA_DIR / "sandbox"))
    tool_manager.grant("accounting_domain_engine", ["file_make", "file_read", "excel_make", "excel_write"])
    tool_manager.grant("study_knowledge_agent", ["web_fetch"])

    # --- step 1: CEO agent architecture, wired to the tools above
    ceo = CEOAgentArchitecture(tool_manager=tool_manager)

    print("\n== provisioning an agent (agent_builder + new_agent_manager) ==")
    agent = ceo.provision_agent("accounting_domain_engine", role="rule_execution")
    print(f"provisioned: {agent.agent_id}")
    print(f"rules: {agent.rules}")

    print("\n== routing a prompt through prompt_manager -> checkpoint loop -> CEO core ==")
    result = ceo.handle_prompt("یک تراکنش فروش نقدی ۱۰۰ تومانی ثبت کن")
    print(f"ok={result['ok']} selected_agents={result['selection']} attempts={result['attempts']}")

    print("\n== posting the transaction through the signed channel to db_manager_agent ==")
    cash = ceo.send_to_db("create_account", {"name": "Cash", "account_type": "asset"})
    revenue = ceo.send_to_db("create_account", {"name": "Sales Revenue", "account_type": "revenue"})
    print(f"accounts created: cash={cash.result} revenue={revenue.result}")

    txn = ceo.send_to_db("post_transaction", {
        "description": "cash sale",
        "lines": [
            {"account_id": cash.result, "debit": 100, "credit": 0},
            {"account_id": revenue.result, "debit": 0, "credit": 100},
        ],
    })
    print(f"transaction posted: ok={txn.ok} id={txn.result}")

    balance = ceo.send_to_db("query_balance", {"account_id": cash.result})
    print(f"cash balance: {balance.result}")

    print("\n== using a step-2 tool through the authorized agent ==")
    from hesabdar.tools import ToolManager as _TM  # noqa: F401 (illustrative import path)
    ledger = tool_manager.invoke("accounting_domain_engine", "excel_make",
                                  path="ledger.xlsx", headers=["date", "desc", "debit", "credit"])
    print(f"ledger workbook: ok={ledger.ok} path={ledger.result}")
    write = tool_manager.invoke("accounting_domain_engine", "excel_write",
                                 path="ledger.xlsx", rows=[["2026-08-15", "cash sale", 100, 0]])
    print(f"ledger row written: ok={write.ok}")

    print("\n== retiring the agent (agent_killer -> summary_maker) ==")
    summary = ceo.retire_agent("accounting_domain_engine", notes="handled one cash-sale transaction end to end")
    print(f"summary: {summary}")

    print("\n== memory maintenance sweep (being_in_sleep_mode) ==")
    print(ceo.run_memory_maintenance())

    print("\nDone. Inspect the data at:", DATA_DIR)


if __name__ == "__main__":
    main()
