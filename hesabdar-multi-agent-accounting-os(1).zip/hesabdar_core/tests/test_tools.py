import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest
from hesabdar.tools import ToolManager, AuthorizationError


def test_unauthorized_tool_call_raises(tmp_path):
    tm = ToolManager(sandbox_root=str(tmp_path))
    with pytest.raises(AuthorizationError):
        tm.invoke("random_agent", "bash_run", command="echo hi")


def test_sandbox_escape_blocked(tmp_path):
    tm = ToolManager(sandbox_root=str(tmp_path))
    tm.grant("agent_x", ["file_read"])
    result = tm.invoke("agent_x", "file_read", path="../../../etc/passwd")
    assert not result.ok
    assert "SandboxViolation" in result.log


def test_authorized_file_roundtrip(tmp_path):
    tm = ToolManager(sandbox_root=str(tmp_path))
    tm.grant("agent_x", ["file_make", "file_read"])
    made = tm.invoke("agent_x", "file_make", path="a.txt", content="hi")
    assert made.ok
    read = tm.invoke("agent_x", "file_read", path="a.txt")
    assert read.ok and read.result == "hi"
