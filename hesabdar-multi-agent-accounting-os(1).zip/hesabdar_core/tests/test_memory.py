import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from hesabdar.memory import MemoryManager, MemoryType, MemoryStore


def test_permanent_types_survive_maintenance(tmp_path):
    store = MemoryStore(db_path=tmp_path / "mem.sqlite3")
    mm = MemoryManager(scope="test", store=store)
    mm.remember({"txn": "debit cash 100"}, hint_type=MemoryType.FINANCIAL_TRANSACTION)
    mm.remember("this is low value fluff", hint_type=None)

    report = mm.being_in_sleep_mode()
    remaining = store.read("test", memory_type=MemoryType.FINANCIAL_TRANSACTION)
    assert len(remaining) == 1, "financial transaction memory must never be pruned"


def test_write_path_classifies_failure():
    mm = MemoryManager(scope="test2")
    decision = mm.input_analyser("خطا در اجرای rule engine")
    assert decision.memory_type == MemoryType.FAILURE
