import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from hesabdar.messaging import AgentIdentity, IdentityRegistry, Channel


def test_signed_message_round_trips(tmp_path, monkeypatch):
    monkeypatch.setenv("HESABDAR_DATA_DIR", str(tmp_path))
    import importlib
    import hesabdar.config as cfg
    importlib.reload(cfg)

    registry = IdentityRegistry()
    a = AgentIdentity.create("agent_a", persist=False)
    b = AgentIdentity.create("agent_b", persist=False)
    registry.register(a)
    registry.register(b)

    chan_a = Channel(a, registry)
    chan_b = Channel(b, registry)

    result = chan_a.send("agent_b", {"op": "ping"}, chan_b)
    assert result.ok
    assert result.message.payload == {"op": "ping"}


def test_tampered_signature_rejected(tmp_path):
    registry = IdentityRegistry()
    a = AgentIdentity.create("agent_a", persist=False)
    b = AgentIdentity.create("agent_b", persist=False)
    registry.register(a)
    registry.register(b)
    chan_a = Channel(a, registry)
    chan_b = Channel(b, registry)

    msg = chan_a.aim_for_message("agent_b", {"op": "post_transaction", "amount": 100})
    msg = chan_a.signner(msg)
    msg.payload["amount"] = 999999  # tamper after signing
    result = chan_b.receiver(msg)
    assert not result.ok, "tampered payload must fail signature verification"
