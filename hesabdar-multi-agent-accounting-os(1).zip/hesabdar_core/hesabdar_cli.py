"""
hesabdar_cli.py
Command-line and IPC bridge interface for the Hesabdar Multi-Agent Operating System.
Provides JSON input/output for external callers (Node Express backend, tests, scripting).
"""
import dataclasses
import json
import os
import sys
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from hesabdar.engine import HesabdarEngine


def serialize_obj(obj):
    if dataclasses.is_dataclass(obj):
        return {k: serialize_obj(v) for k, v in dataclasses.asdict(obj).items()}
    elif isinstance(obj, dict):
        return {k: serialize_obj(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [serialize_obj(i) for i in obj]
    elif hasattr(obj, "__dict__"):
        return {k: serialize_obj(v) for k, v in obj.__dict__.items() if not k.startswith("_")}
    elif hasattr(obj, "isoformat"):
        return obj.isoformat()
    return obj


def main():
    if len(sys.argv) < 2:
        print(json.dumps({"ok": False, "error": "Command required"}))
        sys.exit(1)

    cmd = sys.argv[1]
    args = {}
    if len(sys.argv) > 2:
        try:
            args = json.loads(sys.argv[2])
        except Exception:
            args = {"raw": sys.argv[2]}

    engine = HesabdarEngine()

    if cmd == "status" or cmd == "get_state":
        state = engine.get_full_state()
        print(json.dumps({"ok": True, "state": serialize_obj(state)}, ensure_ascii=False))

    elif cmd == "process_prompt":
        prompt = args.get("prompt", "")
        res = engine.process_prompt(prompt)
        print(json.dumps({"ok": res.ok, "result": serialize_obj(res)}, ensure_ascii=False))

    elif cmd == "post_transaction":
        desc = args.get("description", "Direct Transaction")
        lines = args.get("lines", [])
        ref = args.get("reference_no")
        date = args.get("transaction_date")
        db_res = engine.db_manager._op_post_transaction(desc, lines, reference_no=ref, transaction_date=date)
        print(json.dumps({"ok": True, "transaction_id": db_res}, ensure_ascii=False))

    elif cmd == "reverse_transaction":
        txn_id = args.get("transaction_id")
        reason = args.get("reason", "Manual reversal")
        rev_id = engine.db_manager._op_reverse_transaction(txn_id, reason=reason)
        print(json.dumps({"ok": True, "reversal_id": rev_id}, ensure_ascii=False))

    elif cmd == "list_accounts":
        accs = engine.db_manager._op_list_accounts()
        print(json.dumps({"ok": True, "accounts": accs}, ensure_ascii=False))

    elif cmd == "create_account":
        code = args.get("code")
        name = args.get("name")
        acc_type = args.get("account_type", "asset")
        name_fa = args.get("name_fa")
        aid = engine.db_manager._op_create_account(code, name, acc_type, name_fa=name_fa)
        print(json.dumps({"ok": True, "account_id": aid}, ensure_ascii=False))

    elif cmd == "get_ledger":
        acc_id = args.get("account_id")
        ledger = engine.db_manager._op_get_ledger(acc_id)
        print(json.dumps({"ok": True, "ledger": ledger}, ensure_ascii=False))

    elif cmd == "get_trial_balance":
        tb = engine.db_manager._op_get_trial_balance()
        print(json.dumps({"ok": True, "trial_balance": tb}, ensure_ascii=False))

    elif cmd == "get_financial_statements":
        fs = engine.db_manager._op_get_financial_statements()
        print(json.dumps({"ok": True, "financial_statements": fs}, ensure_ascii=False))

    elif cmd == "generate_report":
        rep_type = args.get("type", "monthly")
        rep = engine.report_maker.generate_comprehensive_report(report_type=rep_type)
        print(json.dumps({"ok": True, "report": serialize_obj(rep)}, ensure_ascii=False))

    elif cmd == "list_rules":
        rules = engine.db_manager._op_list_rules()
        print(json.dumps({"ok": True, "rules": rules}, ensure_ascii=False))

    elif cmd == "create_rule":
        name = args.get("name")
        cat = args.get("category")
        cond = json.dumps(args.get("condition", {}))
        act = json.dumps(args.get("action", {}))
        rid = engine.db_manager._op_insert_rule(name, cat, cond, act)
        print(json.dumps({"ok": True, "rule_id": rid}, ensure_ascii=False))

    elif cmd == "approve_candidate_rule":
        cid = args.get("candidate_id")
        res = engine.db_manager._op_approve_candidate_rule(cid)
        print(json.dumps({"ok": True, "result": res}, ensure_ascii=False))

    elif cmd == "reject_candidate_rule":
        cid = args.get("candidate_id")
        reason = args.get("reason", "Rejected by user")
        res = engine.db_manager._op_reject_candidate_rule(cid, reason=reason)
        print(json.dumps({"ok": True, "result": res}, ensure_ascii=False))

    elif cmd == "make_backup":
        rec = engine.backup_system.make_backup(label="manual")
        print(json.dumps({"ok": True, "backup": serialize_obj(rec)}, ensure_ascii=False))

    elif cmd == "recover_backup":
        b_path = args.get("backup_path")
        rec_res = engine.recovery_system.recover(b_path)
        print(json.dumps({"ok": rec_res.ok, "recovery": serialize_obj(rec_res)}, ensure_ascii=False))

    elif cmd == "self_heal":
        heal_res = engine.self_healing_system.diagnose_and_heal()
        print(json.dumps({"ok": heal_res.ok, "report": serialize_obj(heal_res)}, ensure_ascii=False))

    elif cmd == "query_logs":
        limit = int(args.get("limit", 50))
        logs = engine.db_manager._op_query_super_logs(limit=limit)
        print(json.dumps({"ok": True, "logs": logs}, ensure_ascii=False))

    elif cmd == "study_topic":
        topic = args.get("topic", "")
        study = engine.knowledge_agent.study_topic(topic)
        print(json.dumps({"ok": True, "study": serialize_obj(study)}, ensure_ascii=False))

    else:
        print(json.dumps({"ok": False, "error": f"Unknown command {cmd}"}))


if __name__ == "__main__":
    main()
