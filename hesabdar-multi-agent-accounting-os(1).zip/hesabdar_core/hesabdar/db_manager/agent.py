"""
n13::n1 "DB manager agent architecture" == n6 in the overview doc.
Exact pipeline per docs/09-tooling-and-data-management.md §9.2:

    messages receiver -> messages compile -> messages reader -> messages analyser
    -> executor -> DB analyser -> DB Situation analyser -> DB log maker
    -> result maker -> log maker -> result sender -> log sender

Sole authorized writer to the production DB (§9.2).
"""
from __future__ import annotations

import datetime
import json
import sqlite3
import time
import uuid
from dataclasses import dataclass
from typing import Any, Optional

from hesabdar.config import PRODUCTION_DB_PATH
from hesabdar.db_manager.schema import SCHEMA
from hesabdar.messaging.message import Message


@dataclass
class DBResult:
    ok: bool
    result: Any
    log: str


class DBManagerAgent:
    def __init__(self, db_path=PRODUCTION_DB_PATH):
        self.conn = sqlite3.connect(str(db_path), check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self.conn.commit()
        self._seed_default_accounts()
        self._seed_default_rules()

    def _seed_default_accounts(self) -> None:
        """Seed standard Iranian & International Chart of Accounts if empty."""
        count = self.conn.execute("SELECT COUNT(*) AS c FROM accounts").fetchone()["c"]
        if count > 0:
            return

        now = time.time()
        standard_accounts = [
            # Assets (1000s)
            ("1010", "Cash on Hand", "صندوق و وجه نقد", "asset", "debit", None),
            ("1020", "Bank Account (Main)", "بانک تجارت / حساب جاری", "asset", "debit", None),
            ("1030", "Bank Account (Reserve)", "بانک سامان / حساب پس‌انداز", "asset", "debit", None),
            ("1050", "Accounts Receivable", "حساب‌های دریافتنی تجاری", "asset", "debit", None),
            ("1060", "Notes Receivable", "اسناد دریافتنی (چک‌ها)", "asset", "debit", None),
            ("1070", "Inventory (Merchandise)", "موجودی کالا و مواد اولیه", "asset", "debit", None),
            ("1080", "Prepaid Expenses", "پیش‌پرداخت‌ها (بیمه، اجاره)", "asset", "debit", None),
            ("1510", "Office Equipment", "تجهیزات و ملزومات اداری", "asset", "debit", None),
            ("1520", "Accumulated Depreciation", "استهلاک انباشته", "asset", "credit", None),
            # Liabilities (2000s)
            ("2010", "Accounts Payable", "حساب‌های پرداختنی تجاری", "liability", "credit", None),
            ("2020", "Notes Payable", "اسناد پرداختنی تجاری", "liability", "credit", None),
            ("2030", "Salaries Payable", "حقوق و دستمزد پرداختنی", "liability", "credit", None),
            ("2040", "Taxes / VAT Payable", "مالیات بر ارزش افزوده پرداختنی", "liability", "credit", None),
            ("2050", "Short-term Loans", "تسهیلات مالی کوتاه‌مدت", "liability", "credit", None),
            # Equity (3000s)
            ("3010", "Owner's Capital", "سرمایه اولیه سهامداران", "equity", "credit", None),
            ("3020", "Retained Earnings", "سود و زیان انباشته", "equity", "credit", None),
            ("3030", "Current Year Profit/Loss", "سود (زیان) سال جاری", "equity", "credit", None),
            # Revenue (4000s)
            ("4010", "Sales Revenue", "درآمد حاصل از فروش کالا", "revenue", "credit", None),
            ("4020", "Service Revenue", "درآمد حاصل از خدمات", "revenue", "credit", None),
            ("4030", "Interest & Other Income", "سایر درآمدهای غیرعملیاتی", "revenue", "credit", None),
            # Expenses (5000s)
            ("5010", "Cost of Goods Sold (COGS)", "بهای تمام شده کالای فروش رفته", "expense", "debit", None),
            ("5020", "Salaries & Wages Expense", "هزینه حقوق و دستمزد", "expense", "debit", None),
            ("5030", "Rent Expense", "هزینه اجاره دفتر و انبار", "expense", "debit", None),
            ("5040", "Utilities & Internet Expense", "هزینه آب، برق، گاز و اینترنت", "expense", "debit", None),
            ("5050", "Marketing & Advertising Expense", "هزینه تبلیغات و بازاریابی", "expense", "debit", None),
            ("5060", "Depreciation Expense", "هزینه استهلاک دارایی‌ها", "expense", "debit", None),
            ("5070", "Bank Fees & Financial Charges", "کارمزد بانکی و هزینه‌های مالی", "expense", "debit", None),
            ("5080", "Office Supplies & Maintenance", "هزینه ملزومات اداری و نگهداری", "expense", "debit", None),
        ]
        for code, name, name_fa, acc_type, normal_bal, parent_id in standard_accounts:
            self.conn.execute(
                "INSERT INTO accounts (id, code, name, name_fa, account_type, normal_balance, parent_id, is_active, created_at) "
                "VALUES (?,?,?,?,?,?,?,?,?)",
                (str(uuid.uuid4()), code, name, name_fa, acc_type, normal_bal, parent_id, 1, now),
            )
        self.conn.commit()

    def _seed_default_rules(self) -> None:
        """Seed initial deterministic accounting rules."""
        count = self.conn.execute("SELECT COUNT(*) AS c FROM rules").fetchone()["c"]
        if count > 0:
            return

        now = time.time()
        default_rules = [
            (
                "Cash Sale with VAT",
                1,
                100,
                "sale",
                json.dumps({"type": "sale", "payment_method": "cash", "vat_rate": 0.09}),
                json.dumps({
                    "debit": [{"account_code": "1010", "portion": 1.09, "desc": "Cash received including 9% VAT"}],
                    "credit": [
                        {"account_code": "4010", "portion": 1.0, "desc": "Sales Revenue"},
                        {"account_code": "2040", "portion": 0.09, "desc": "VAT Payable"}
                    ]
                }),
                "SYSTEM_INIT"
            ),
            (
                "Bank Transfer Sale",
                1,
                90,
                "sale",
                json.dumps({"type": "sale", "payment_method": "bank"}),
                json.dumps({
                    "debit": [{"account_code": "1020", "portion": 1.0, "desc": "Bank receipt for sale"}],
                    "credit": [{"account_code": "4010", "portion": 1.0, "desc": "Sales Revenue"}]
                }),
                "SYSTEM_INIT"
            ),
            (
                "Credit Sale (On Account)",
                1,
                85,
                "sale",
                json.dumps({"type": "sale", "payment_method": "credit"}),
                json.dumps({
                    "debit": [{"account_code": "1050", "portion": 1.0, "desc": "Accounts Receivable created"}],
                    "credit": [{"account_code": "4010", "portion": 1.0, "desc": "Sales Revenue"}]
                }),
                "SYSTEM_INIT"
            ),
            (
                "Direct Operational Expense via Bank",
                1,
                80,
                "expense",
                json.dumps({"type": "expense", "payment_method": "bank"}),
                json.dumps({
                    "debit": [{"account_code": "5040", "portion": 1.0, "desc": "Expense recognized"}],
                    "credit": [{"account_code": "1020", "portion": 1.0, "desc": "Bank payment"}]
                }),
                "SYSTEM_INIT"
            ),
            (
                "Monthly Salary Disbursement",
                1,
                95,
                "payroll",
                json.dumps({"type": "payroll"}),
                json.dumps({
                    "debit": [{"account_code": "5020", "portion": 1.0, "desc": "Gross Salaries Expense"}],
                    "credit": [{"account_code": "1020", "portion": 1.0, "desc": "Net Salary Paid via Bank"}]
                }),
                "SYSTEM_INIT"
            ),
            (
                "Inventory Purchase on Credit",
                1,
                80,
                "purchase",
                json.dumps({"type": "purchase", "payment_method": "credit"}),
                json.dumps({
                    "debit": [{"account_code": "1070", "portion": 1.0, "desc": "Inventory asset increase"}],
                    "credit": [{"account_code": "2010", "portion": 1.0, "desc": "Accounts Payable liability"}]
                }),
                "SYSTEM_INIT"
            )
        ]

        for name, version, priority, category, cond_json, act_json, approved_by in default_rules:
            self.conn.execute(
                "INSERT INTO rules (id, name, version, priority, category, condition_json, action_json, is_active, approved_by, created_at) "
                "VALUES (?,?,?,?,?,?,?,1,?,?)",
                (str(uuid.uuid4()), name, version, priority, category, cond_json, act_json, approved_by, now)
            )
        self.conn.commit()

    # ---- the exact §9.2 pipeline
    def handle(self, message: Message) -> DBResult:
        m = self.messages_receiver(message)
        m = self.messages_compile(m)
        parsed = self.messages_reader(m)
        analysis = self.messages_analyser(parsed)
        exec_result = self.executor(parsed, analysis)
        db_state = self.db_analyser(exec_result)
        situation = self.db_situation_analyser(exec_result, db_state)
        self.db_log_maker(message, exec_result, situation)
        result = self.result_maker(exec_result, situation)
        log_entry = self.log_maker(message, result, situation)
        sent_result = self.result_sender(result)
        self.log_sender(log_entry)
        return sent_result

    def messages_receiver(self, message: Message) -> Message:
        return message

    def messages_compile(self, message: Message) -> Message:
        return message

    def messages_reader(self, message: Message) -> dict:
        return message.payload

    def messages_analyser(self, parsed: dict) -> dict:
        op = parsed.get("op")
        known_ops = {
            "create_account", "post_transaction", "query_balance", "list_transactions",
            "list_accounts", "get_account_by_code", "get_ledger", "get_trial_balance",
            "get_financial_statements", "list_rules", "insert_rule", "get_candidate_rules",
            "approve_candidate_rule", "reject_candidate_rule", "propose_candidate_rule",
            "reverse_transaction", "save_super_log", "query_super_logs", "save_checkpoint",
            "get_checkpoint", "record_audit_chain", "get_system_stats"
        }
        return {"op": op, "known": op in known_ops}

    def executor(self, parsed: dict, analysis: dict) -> DBResult:
        if not analysis["known"]:
            return DBResult(False, None, f"unknown op {parsed.get('op')!r}")
        op = analysis["op"]
        args = parsed.get("args", {})
        try:
            handler = getattr(self, f"_op_{op}")
            result = handler(**args)
            return DBResult(True, result, f"{op} ok")
        except Exception as exc:
            return DBResult(False, None, f"{op} failed: {exc}")

    def db_analyser(self, exec_result: DBResult) -> dict:
        return {"ok": exec_result.ok}

    def db_situation_analyser(self, exec_result: DBResult, db_state: dict) -> dict:
        if not exec_result.ok:
            return {"consistent": False, "reason": exec_result.log}
        try:
            check = self.conn.execute("PRAGMA integrity_check").fetchone()
            return {"consistent": True, "integrity": dict(check) if check else "ok"}
        except sqlite3.DatabaseError as exc:
            return {"consistent": False, "reason": str(exc)}

    def db_log_maker(self, message: Message, exec_result: DBResult, situation: dict) -> None:
        self.conn.execute(
            "INSERT INTO db_operation_log VALUES (?,?,?,?,?)",
            (str(uuid.uuid4()), message.payload.get("op", "?"), int(exec_result.ok),
             f"{exec_result.log} | situation={situation}", time.time()),
        )
        self.conn.commit()

    def result_maker(self, exec_result: DBResult, situation: dict) -> DBResult:
        ok = exec_result.ok and situation.get("consistent", False)
        return DBResult(ok=ok, result=exec_result.result, log=exec_result.log)

    def log_maker(self, message: Message, result: DBResult, situation: dict) -> dict:
        return {"message_id": message.id, "sender": message.sender, "ok": result.ok,
                "log": result.log, "situation": situation, "at": time.time()}

    def result_sender(self, result: DBResult) -> DBResult:
        return result

    def log_sender(self, log_entry: dict) -> dict:
        return log_entry

    # ---- Concrete DB Operations ----
    def _op_create_account(self, code: str, name: str, account_type: str, name_fa: Optional[str] = None, normal_balance: Optional[str] = None, parent_id: Optional[str] = None) -> str:
        acc_id = str(uuid.uuid4())
        norm_bal = normal_balance or ("credit" if account_type in ("liability", "equity", "revenue") else "debit")
        self.conn.execute(
            "INSERT INTO accounts (id, code, name, name_fa, account_type, normal_balance, parent_id, is_active, created_at) "
            "VALUES (?,?,?,?,?,?,?,1,?)",
            (acc_id, code, name, name_fa or name, account_type, norm_bal, parent_id, time.time())
        )
        self.conn.commit()
        return acc_id

    def _op_list_accounts(self) -> list[dict]:
        rows = self.conn.execute("SELECT * FROM accounts WHERE is_active=1 ORDER BY code ASC").fetchall()
        accounts = []
        for r in rows:
            acc = dict(r)
            bal_row = self.conn.execute(
                "SELECT COALESCE(SUM(debit),0) AS total_debit, COALESCE(SUM(credit),0) AS total_credit "
                "FROM transaction_lines WHERE account_id=?", (acc["id"],)
            ).fetchone()
            d = bal_row["total_debit"]
            c = bal_row["total_credit"]
            acc["total_debit"] = d
            acc["total_credit"] = c
            acc["balance"] = (d - c) if acc["normal_balance"] == "debit" else (c - d)
            accounts.append(acc)
        return accounts

    def _op_get_account_by_code(self, code: str) -> Optional[dict]:
        row = self.conn.execute("SELECT * FROM accounts WHERE code=?", (code,)).fetchone()
        return dict(row) if row else None

    def _op_post_transaction(self, description: str, lines: list[dict], reference_no: Optional[str] = None, transaction_date: Optional[str] = None, source_message_id: Optional[str] = None, verified_by_critic: int = 1) -> str:
        if not lines:
            raise ValueError("Transaction must have at least two balanced lines")
        total_debit = sum(float(l.get("debit", 0)) for l in lines)
        total_credit = sum(float(l.get("credit", 0)) for l in lines)
        if round(total_debit, 2) != round(total_credit, 2):
            raise ValueError(f"Unbalanced entry! Debit={total_debit:.2f} Credit={total_credit:.2f}")

        txn_id = str(uuid.uuid4())
        t_date = transaction_date or datetime.date.today().isoformat()
        ref_no = reference_no or f"TXN-{int(time.time()*1000)%1000000:06d}"
        now = time.time()

        self.conn.execute(
            "INSERT INTO transactions (id, reference_no, description, transaction_date, status, source_message_id, verified_by_critic, created_at) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (txn_id, ref_no, description, t_date, "posted", source_message_id, verified_by_critic, now)
        )

        for line in lines:
            acc_id = line["account_id"]
            # allow passing code as account_id if not a UUID
            if not acc_id.count("-") >= 4:
                acc_row = self.conn.execute("SELECT id FROM accounts WHERE code=?", (acc_id,)).fetchone()
                if acc_row:
                    acc_id = acc_row["id"]

            self.conn.execute(
                "INSERT INTO transaction_lines (id, transaction_id, account_id, debit, credit, description, created_at) "
                "VALUES (?,?,?,?,?,?,?)",
                (str(uuid.uuid4()), txn_id, acc_id, float(line.get("debit", 0)), float(line.get("credit", 0)), line.get("description", description), now)
            )

        self.conn.commit()
        return txn_id

    def _op_reverse_transaction(self, transaction_id: str, reason: str = "Compensating rollback") -> str:
        """Resilience & Error compensation: posts a reversing entry."""
        orig = self.conn.execute("SELECT * FROM transactions WHERE id=?", (transaction_id,)).fetchone()
        if not orig:
            raise ValueError(f"Transaction {transaction_id} not found")
        orig_lines = self.conn.execute("SELECT * FROM transaction_lines WHERE transaction_id=?", (transaction_id,)).fetchall()
        
        rev_lines = []
        for l in orig_lines:
            rev_lines.append({
                "account_id": l["account_id"],
                "debit": l["credit"],   # swap debit/credit to reverse
                "credit": l["debit"],
                "description": f"REVERSAL: {reason}"
            })

        rev_id = self._op_post_transaction(
            description=f"REVERSAL of {orig['reference_no']}: {reason}",
            lines=rev_lines,
            reference_no=f"REV-{orig['reference_no']}",
            source_message_id=f"reversal_of_{transaction_id}"
        )
        self.conn.execute("UPDATE transactions SET status='reversed' WHERE id=?", (transaction_id,))
        self.conn.commit()
        return rev_id

    def _op_query_balance(self, account_id: str) -> float:
        acc = self.conn.execute("SELECT * FROM accounts WHERE id=? OR code=?", (account_id, account_id)).fetchone()
        if not acc:
            raise ValueError(f"Account {account_id} not found")
        row = self.conn.execute(
            "SELECT COALESCE(SUM(debit),0) AS d, COALESCE(SUM(credit),0) AS c "
            "FROM transaction_lines WHERE account_id=?", (acc["id"],)
        ).fetchone()
        return (row["d"] - row["c"]) if acc["normal_balance"] == "debit" else (row["c"] - row["d"])

    def _op_list_transactions(self, limit: int = 100) -> list[dict]:
        rows = self.conn.execute("SELECT * FROM transactions ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
        txns = []
        for r in rows:
            t = dict(r)
            lines = self.conn.execute(
                "SELECT tl.*, a.code, a.name, a.name_fa FROM transaction_lines tl "
                "JOIN accounts a ON tl.account_id=a.id WHERE tl.transaction_id=?", (t["id"],)
            ).fetchall()
            t["lines"] = [dict(line) for line in lines]
            t["total_amount"] = sum(l["debit"] for l in t["lines"])
            txns.append(t)
        return txns

    def _op_get_ledger(self, account_id: Optional[str] = None) -> list[dict]:
        query = (
            "SELECT tl.*, t.reference_no, t.description AS txn_desc, t.transaction_date, "
            "a.code, a.name, a.name_fa, a.account_type "
            "FROM transaction_lines tl "
            "JOIN transactions t ON tl.transaction_id=t.id "
            "JOIN accounts a ON tl.account_id=a.id "
        )
        params = []
        if account_id:
            query += "WHERE a.id=? OR a.code=? "
            params.extend([account_id, account_id])
        query += "ORDER BY t.transaction_date ASC, tl.created_at ASC"
        rows = self.conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]

    def _op_get_trial_balance(self) -> dict:
        accounts = self._op_list_accounts()
        total_debit = sum(a["total_debit"] for a in accounts)
        total_credit = sum(a["total_credit"] for a in accounts)
        balanced = round(total_debit, 2) == round(total_credit, 2)
        return {
            "accounts": accounts,
            "total_debit": total_debit,
            "total_credit": total_credit,
            "is_balanced": balanced,
            "difference": abs(total_debit - total_credit)
        }

    def _op_get_financial_statements(self) -> dict:
        accounts = self._op_list_accounts()
        assets = [a for a in accounts if a["account_type"] == "asset"]
        liabilities = [a for a in accounts if a["account_type"] == "liability"]
        equity = [a for a in accounts if a["account_type"] == "equity"]
        revenues = [a for a in accounts if a["account_type"] == "revenue"]
        expenses = [a for a in accounts if a["account_type"] == "expense"]

        total_assets = sum(a["balance"] for a in assets)
        total_liabilities = sum(a["balance"] for a in liabilities)
        total_equity = sum(a["balance"] for a in equity)
        total_revenue = sum(a["balance"] for a in revenues)
        total_expenses = sum(a["balance"] for a in expenses)
        net_income = total_revenue - total_expenses

        # In balance sheet: Assets = Liabilities + Equity + Net Income
        total_liab_and_equity = total_liabilities + total_equity + net_income
        bs_balanced = round(total_assets, 2) == round(total_liab_and_equity, 2)

        return {
            "balance_sheet": {
                "assets": assets,
                "liabilities": liabilities,
                "equity": equity,
                "total_assets": total_assets,
                "total_liabilities": total_liabilities,
                "total_equity": total_equity,
                "net_income": net_income,
                "total_liabilities_and_equity": total_liab_and_equity,
                "is_balanced": bs_balanced
            },
            "income_statement": {
                "revenues": revenues,
                "expenses": expenses,
                "total_revenue": total_revenue,
                "total_expenses": total_expenses,
                "net_income": net_income,
                "net_margin_pct": (net_income / total_revenue * 100) if total_revenue > 0 else 0
            }
        }

    def _op_list_rules(self) -> list[dict]:
        rows = self.conn.execute("SELECT * FROM rules ORDER BY priority DESC, created_at DESC").fetchall()
        rules = []
        for r in rows:
            rule = dict(r)
            rule["condition"] = json.loads(rule["condition_json"])
            rule["action"] = json.loads(rule["action_json"])
            rules.append(rule)
        return rules

    def _op_insert_rule(self, name: str, category: str, condition_json: str, action_json: str, priority: int = 10, approved_by: str = "HUMAN_APPROVED") -> str:
        rule_id = str(uuid.uuid4())
        self.conn.execute(
            "INSERT INTO rules (id, name, version, priority, category, condition_json, action_json, is_active, approved_by, created_at) "
            "VALUES (?,?,1,?,?,?,?,1,?,?)",
            (rule_id, name, priority, category, condition_json, action_json, approved_by, time.time())
        )
        self.conn.commit()
        return rule_id

    def _op_get_candidate_rules(self, status: Optional[str] = None) -> list[dict]:
        query = "SELECT * FROM candidate_rules "
        params = []
        if status:
            query += "WHERE status=? "
            params.append(status)
        query += "ORDER BY created_at DESC"
        rows = self.conn.execute(query, params).fetchall()
        candidates = []
        for r in rows:
            c = dict(r)
            c["condition"] = json.loads(c["condition_json"])
            c["action"] = json.loads(c["action_json"])
            candidates.append(c)
        return candidates

    def _op_propose_candidate_rule(self, name: str, proposed_by: str, category: str, condition_json: str, action_json: str, justification: str = "") -> str:
        cid = str(uuid.uuid4())
        self.conn.execute(
            "INSERT INTO candidate_rules (id, name, proposed_by, category, condition_json, action_json, justification, status, created_at) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            (cid, name, proposed_by, category, condition_json, action_json, justification, "PENDING", time.time())
        )
        self.conn.commit()
        return cid

    def _op_approve_candidate_rule(self, candidate_id: str, reviewer: str = "HUMAN_AUDITOR") -> dict:
        row = self.conn.execute("SELECT * FROM candidate_rules WHERE id=?", (candidate_id,)).fetchone()
        if not row:
            raise ValueError(f"Candidate rule {candidate_id} not found")
        cand = dict(row)
        now = time.time()
        rule_id = self._op_insert_rule(
            name=cand["name"],
            category=cand["category"],
            condition_json=cand["condition_json"],
            action_json=cand["action_json"],
            approved_by=reviewer
        )
        self.conn.execute(
            "UPDATE candidate_rules SET status='APPROVED', reviewed_by=?, reviewed_at=? WHERE id=?",
            (reviewer, now, candidate_id)
        )
        self.conn.commit()
        return {"candidate_id": candidate_id, "promoted_rule_id": rule_id, "status": "APPROVED"}

    def _op_reject_candidate_rule(self, candidate_id: str, reviewer: str = "HUMAN_AUDITOR", reason: str = "Policy conflict") -> dict:
        self.conn.execute(
            "UPDATE candidate_rules SET status='REJECTED', reviewed_by=?, reviewed_at=?, rejection_reason=? WHERE id=?",
            (reviewer, time.time(), reason, candidate_id)
        )
        self.conn.commit()
        return {"candidate_id": candidate_id, "status": "REJECTED", "reason": reason}

    def _op_save_super_log(self, agent_id: str, stage: str, component: str, summary: str, level: str = "INFO", task_id: Optional[str] = None, payload_json: Optional[str] = None, discrepancy: float = 0.0, error_detail: Optional[str] = None, recovery_action: Optional[str] = None) -> str:
        log_id = str(uuid.uuid4())
        self.conn.execute(
            "INSERT INTO super_logs (id, timestamp, task_id, agent_id, stage, level, component, summary, payload_json, discrepancy, error_detail, recovery_action) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (log_id, time.time(), task_id, agent_id, stage, level, component, summary, payload_json, discrepancy, error_detail, recovery_action)
        )
        self.conn.commit()
        return log_id

    def _op_query_super_logs(self, limit: int = 100, level: Optional[str] = None, agent_id: Optional[str] = None) -> list[dict]:
        query = "SELECT * FROM super_logs "
        params = []
        conds = []
        if level:
            conds.append("level=?")
            params.append(level)
        if agent_id:
            conds.append("agent_id=?")
            params.append(agent_id)
        if conds:
            query += "WHERE " + " AND ".join(conds) + " "
        query += "ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)
        rows = self.conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]

    def _op_save_checkpoint(self, task_id: str, stage: str, state_json: str, attempts: int = 1) -> str:
        cid = str(uuid.uuid4())
        self.conn.execute(
            "INSERT INTO system_checkpoints (id, task_id, stage, attempts, state_json, created_at) "
            "VALUES (?,?,?,?,?,?)",
            (cid, task_id, stage, attempts, state_json, time.time())
        )
        self.conn.commit()
        return cid

    def _op_get_checkpoint(self, task_id: str) -> Optional[dict]:
        row = self.conn.execute(
            "SELECT * FROM system_checkpoints WHERE task_id=? ORDER BY created_at DESC LIMIT 1",
            (task_id,)
        ).fetchone()
        return dict(row) if row else None

    def _op_record_audit_chain(self, prev_hash: str, curr_hash: str, message_id: str, sender: str, payload_hash: str, sequence: int) -> str:
        aid = str(uuid.uuid4())
        self.conn.execute(
            "INSERT INTO audit_chain (id, sequence, prev_hash, curr_hash, message_id, sender, payload_hash, timestamp) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (aid, sequence, prev_hash, curr_hash, message_id, sender, payload_hash, time.time())
        )
        self.conn.commit()
        return aid

    def _op_get_system_stats(self) -> dict:
        acc_count = self.conn.execute("SELECT COUNT(*) AS c FROM accounts").fetchone()["c"]
        txn_count = self.conn.execute("SELECT COUNT(*) AS c FROM transactions").fetchone()["c"]
        rules_count = self.conn.execute("SELECT COUNT(*) AS c FROM rules WHERE is_active=1").fetchone()["c"]
        cand_count = self.conn.execute("SELECT COUNT(*) AS c FROM candidate_rules WHERE status='PENDING'").fetchone()["c"]
        log_count = self.conn.execute("SELECT COUNT(*) AS c FROM super_logs").fetchone()["c"]
        return {
            "accounts_count": acc_count,
            "transactions_count": txn_count,
            "rules_count": rules_count,
            "pending_candidate_rules": cand_count,
            "super_logs_count": log_count,
            "timestamp": time.time()
        }
