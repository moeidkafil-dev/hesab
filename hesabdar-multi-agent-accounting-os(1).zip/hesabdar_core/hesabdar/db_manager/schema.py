"""
hesabdar/db_manager/schema.py
Production database schema supporting:
- Chart of Accounts with standard codes, types, and hierarchy
- Double-entry Transactions & Balanced Transaction Lines
- Versioned Accounting Production Rules
- AI Candidate Rules (for Human Approval Gate)
- Super Logs with discrepancy and diagnostic metadata
- System Checkpoints for bounded-retry recovery
- Audit Trail Chaining (Haber-Stornetta linked hashes)
"""

SCHEMA = """
CREATE TABLE IF NOT EXISTS accounts (
    id TEXT PRIMARY KEY,
    code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    name_fa TEXT,
    account_type TEXT NOT NULL,   -- asset / liability / equity / revenue / expense
    normal_balance TEXT NOT NULL, -- debit / credit
    parent_id TEXT,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    reference_no TEXT,
    description TEXT NOT NULL,
    transaction_date TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'posted', -- posted / draft / reversed
    source_message_id TEXT,
    verified_by_critic INTEGER NOT NULL DEFAULT 0,
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS transaction_lines (
    id TEXT PRIMARY KEY,
    transaction_id TEXT NOT NULL REFERENCES transactions(id),
    account_id TEXT NOT NULL REFERENCES accounts(id),
    debit REAL NOT NULL DEFAULT 0,
    credit REAL NOT NULL DEFAULT 0,
    description TEXT,
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS rules (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    version INTEGER NOT NULL DEFAULT 1,
    priority INTEGER NOT NULL DEFAULT 10,
    category TEXT NOT NULL,       -- sale / purchase / expense / payroll / tax / asset / transfer
    condition_json TEXT NOT NULL,
    action_json TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    approved_by TEXT NOT NULL DEFAULT 'SYSTEM',
    effective_date TEXT,
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS candidate_rules (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    proposed_by TEXT NOT NULL,
    category TEXT NOT NULL,
    condition_json TEXT NOT NULL,
    action_json TEXT NOT NULL,
    justification TEXT,
    status TEXT NOT NULL DEFAULT 'PENDING', -- PENDING / APPROVED / REJECTED
    reviewed_by TEXT,
    reviewed_at REAL,
    rejection_reason TEXT,
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS super_logs (
    id TEXT PRIMARY KEY,
    timestamp REAL NOT NULL,
    task_id TEXT,
    agent_id TEXT NOT NULL,
    stage TEXT NOT NULL,
    level TEXT NOT NULL DEFAULT 'INFO', -- INFO / WARN / ERROR / CRITICAL / AUDIT
    component TEXT NOT NULL,
    summary TEXT NOT NULL,
    payload_json TEXT,
    discrepancy REAL DEFAULT 0.0,
    error_detail TEXT,
    recovery_action TEXT
);

CREATE TABLE IF NOT EXISTS system_checkpoints (
    id TEXT PRIMARY KEY,
    task_id TEXT NOT NULL,
    stage TEXT NOT NULL,
    attempts INTEGER NOT NULL DEFAULT 1,
    state_json TEXT NOT NULL,
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_chain (
    id TEXT PRIMARY KEY,
    sequence INTEGER NOT NULL,
    prev_hash TEXT NOT NULL,
    curr_hash TEXT NOT NULL,
    message_id TEXT NOT NULL,
    sender TEXT NOT NULL,
    payload_hash TEXT NOT NULL,
    timestamp REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS db_operation_log (
    id TEXT PRIMARY KEY,
    op TEXT NOT NULL,
    ok INTEGER NOT NULL,
    detail TEXT,
    created_at REAL NOT NULL
);
"""
