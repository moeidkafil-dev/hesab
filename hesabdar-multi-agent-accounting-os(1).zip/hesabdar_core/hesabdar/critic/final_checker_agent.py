"""
n14 "final checker agent" (The Critic Pattern)
Per docs/06-quality-assurance-and-critic-pattern.md:
Structurally independent verifier sitting at the convergence point of the pipeline.
Implements 4 layered verification criteria:
1. Structural verification (closed-form deterministic check, sum(debit) == sum(credit))
2. Cross-referential verification (reconciles against authoritative DB records)
3. Historical/statistical anomaly verification (variance and duplicate detection)
4. Confidence aggregation and CEO routing (auto-release, human escalation, or agent rejection)
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Optional
from hesabdar.accounting.rule_executor import JournalEntryResult


@dataclass
class VerificationLayerResult:
    layer_name: str
    passed: bool
    score: float
    details: str
    violations: list[str] = field(default_factory=list)


@dataclass
class FinalCriticResult:
    passed: bool
    disposition: str            # "AUTO_RELEASE" | "ESCALATE_TO_HUMAN" | "REJECT_TO_AGENT"
    confidence_score: float     # 0.0 to 1.0
    layers: list[VerificationLayerResult] = field(default_factory=list)
    rejection_reasons: list[str] = field(default_factory=list)
    verification_time_ms: float = 0.0


class FinalCheckerAgent:
    def __init__(self, db_manager: Any = None):
        self.db_manager = db_manager
        # Anomaly baseline parameters
        self.max_single_transaction_threshold = 1_000_000_000.0  # 1 billion rials/units
        self.recent_entries_cache: list[dict] = []

    def verify(self, entry: JournalEntryResult, agent_id: str = "accounting_domain_engine") -> FinalCriticResult:
        start_t = time.time()
        layers: list[VerificationLayerResult] = []
        rejections: list[str] = []

        # ==========================================
        # Layer 1: Structural Verification (Deterministic)
        # ==========================================
        l1_violations = []
        if not entry.is_balanced or round(entry.total_debit, 2) != round(entry.total_credit, 2):
            l1_violations.append(f"Mathematical imbalance: debit={entry.total_debit} != credit={entry.total_credit}")

        if entry.total_debit <= 0:
            l1_violations.append("Zero or negative transaction total amount")

        if not entry.lines or len(entry.lines) < 2:
            l1_violations.append("Insufficient lines for double-entry integrity")

        for idx, line in enumerate(entry.lines):
            d = line.get("debit", 0)
            c = line.get("credit", 0)
            if d < 0 or c < 0:
                l1_violations.append(f"Line #{idx+1} contains negative value (d={d}, c={c})")
            if not line.get("account_id"):
                l1_violations.append(f"Line #{idx+1} lacks valid account reference")

        l1_passed = len(l1_violations) == 0
        layers.append(VerificationLayerResult(
            layer_name="Layer 1: Structural Deterministic Verification",
            passed=l1_passed,
            score=1.0 if l1_passed else 0.0,
            details="All mathematical & schema invariants verified." if l1_passed else "; ".join(l1_violations),
            violations=l1_violations
        ))

        # Short-circuit on structural failure
        if not l1_passed:
            exec_time = (time.time() - start_t) * 1000
            return FinalCriticResult(
                passed=False,
                disposition="REJECT_TO_AGENT",
                confidence_score=0.0,
                layers=layers,
                rejection_reasons=l1_violations,
                verification_time_ms=exec_time
            )

        # ==========================================
        # Layer 2: Cross-Referential Verification
        # ==========================================
        l2_violations = []
        if self.db_manager:
            try:
                for line in entry.lines:
                    acc_id = line["account_id"]
                    # verify account exists in DB
                    row = self.db_manager.conn.execute("SELECT id, name FROM accounts WHERE id=? OR code=?", (acc_id, acc_id)).fetchone()
                    if not row:
                        l2_violations.append(f"Referenced account {acc_id} does not exist in authoritative DB")
            except Exception as e:
                l2_violations.append(f"Database cross-referencing error: {e}")

        l2_passed = len(l2_violations) == 0
        layers.append(VerificationLayerResult(
            layer_name="Layer 2: Authoritative Cross-Referential Reconciliation",
            passed=l2_passed,
            score=1.0 if l2_passed else 0.4,
            details="All account identities reconciled with DB master chart." if l2_passed else "; ".join(l2_violations),
            violations=l2_violations
        ))

        # ==========================================
        # Layer 3: Historical / Statistical Anomaly Detection
        # ==========================================
        l3_violations = []
        l3_score = 1.0

        # Check extreme high value
        if entry.total_debit > self.max_single_transaction_threshold:
            l3_violations.append(f"Transaction amount {entry.total_debit:,.2f} exceeds standard automated approval threshold")
            l3_score -= 0.3

        # Duplicate check within recent cache
        now = time.time()
        for past in self.recent_entries_cache[-20:]:
            if (now - past.get("time", 0) < 60) and (past.get("desc") == entry.description) and (past.get("amount") == entry.total_debit):
                l3_violations.append("Potential duplicate rapid submission detected within 60s window")
                l3_score -= 0.4
                break

        # Cache this submission
        self.recent_entries_cache.append({
            "desc": entry.description,
            "amount": entry.total_debit,
            "time": now
        })
        if len(self.recent_entries_cache) > 100:
            self.recent_entries_cache = self.recent_entries_cache[-50:]

        l3_passed = len(l3_violations) == 0
        layers.append(VerificationLayerResult(
            layer_name="Layer 3: Historical & Statistical Anomaly Check",
            passed=l3_passed,
            score=max(0.0, l3_score),
            details="Pattern within normal operational variance." if l3_passed else "; ".join(l3_violations),
            violations=l3_violations
        ))

        # ==========================================
        # Layer 4: Confidence Aggregation & Routing Disposition
        # ==========================================
        total_score = (
            (layers[0].score * 0.40) +
            (layers[1].score * 0.35) +
            (layers[2].score * 0.25)
        )

        all_violations = l1_violations + l2_violations + l3_violations

        if not l1_passed or not l2_passed:
            disposition = "REJECT_TO_AGENT"
            passed = False
        elif not l3_passed or total_score < 0.85:
            disposition = "ESCALATE_TO_HUMAN"
            passed = True  # conditionally valid, needs supervisor eye
        else:
            disposition = "AUTO_RELEASE"
            passed = True

        exec_time = (time.time() - start_t) * 1000

        return FinalCriticResult(
            passed=passed,
            disposition=disposition,
            confidence_score=round(total_score, 3),
            layers=layers,
            rejection_reasons=all_violations,
            verification_time_ms=exec_time
        )
