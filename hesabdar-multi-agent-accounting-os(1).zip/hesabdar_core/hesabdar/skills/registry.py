"""
hesabdar/skills/registry.py
Per PRD Section 9: SKILL REGISTRY — CEO CONTROLLED
Skills are dynamically discoverable, versioned resources registered with:
- id, version, repository/doc URLs
- declared capabilities (e.g. excel_analysis, pdf_ocr, bank_reconciliation, tax_calculator)
- permissions required (filesystem_read, filesystem_write, network_api, db_read)
- compatible agent roles

CEO controls skill discovery, validation, permission enforcement, and agent assignment.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class SkillDefinition:
    id: str
    name: str
    version: str
    description: str
    repository: str
    readme: str
    documentation: str
    capabilities: list[str]
    permissions: list[str]
    compatible_agents: list[str]
    is_active: bool = True
    installed_at: float = field(default_factory=time.time)


class SkillRegistry:
    def __init__(self):
        self._skills: dict[str, SkillDefinition] = {}
        self._seed_standard_skills()

    def _seed_standard_skills(self) -> None:
        standard = [
            SkillDefinition(
                id="excel_financial_compiler",
                name="Excel Financial Statements Compiler",
                version="1.2.0",
                description="Generates compliant multi-tab Excel workbooks for Balance Sheet, Ledger, and Trial Balance.",
                repository="https://github.com/hesabdar-skills/excel-financial-compiler",
                readme="https://github.com/hesabdar-skills/excel-financial-compiler/blob/main/README.md",
                documentation="https://docs.hesabdar.internal/skills/excel_financial_compiler",
                capabilities=["excel_make", "excel_write", "spreadsheet_styling", "formula_injection"],
                permissions=["filesystem_write", "sandbox_access"],
                compatible_agents=["accounting_domain_engine", "report_maker", "ceo_core"]
            ),
            SkillDefinition(
                id="vat_tax_compliance_engine",
                name="VAT & Statutory Tax Compliance Engine",
                version="2.0.1",
                description="Calculates 9% VAT, seasonal duty rates, and withholding tax rules.",
                repository="https://github.com/hesabdar-skills/vat-tax-compliance",
                readme="https://github.com/hesabdar-skills/vat-tax-compliance/blob/main/README.md",
                documentation="https://docs.hesabdar.internal/skills/vat_tax_compliance",
                capabilities=["tax_calculation", "vat_audit", "statutory_compliance"],
                permissions=["rule_query"],
                compatible_agents=["accounting_domain_engine", "rules_maker"]
            ),
            SkillDefinition(
                id="bank_statement_reconciler",
                name="Bank Statement Multi-Format Parser & Reconciler",
                version="1.0.4",
                description="Ingests CSV/MT940/JSON bank feeds, performs fuzzy matching against open ledger items.",
                repository="https://github.com/hesabdar-skills/bank-statement-reconciler",
                readme="https://github.com/hesabdar-skills/bank-statement-reconciler/blob/main/README.md",
                documentation="https://docs.hesabdar.internal/skills/bank_statement_reconciler",
                capabilities=["bank_feed_parsing", "reconciliation", "fuzzy_match"],
                permissions=["filesystem_read", "db_read"],
                compatible_agents=["data_input_agent", "accounting_domain_engine"]
            ),
            SkillDefinition(
                id="regulatory_rag_searcher",
                name="Accounting Standards & Tax Law RAG Searcher",
                version="1.1.0",
                description="Retrieves official accounting standards, statutory legal circulars, and tax court rulings.",
                repository="https://github.com/hesabdar-skills/regulatory-rag-searcher",
                readme="https://github.com/hesabdar-skills/regulatory-rag-searcher/blob/main/README.md",
                documentation="https://docs.hesabdar.internal/skills/regulatory_rag_searcher",
                capabilities=["semantic_search", "legal_citation", "statute_lookup"],
                permissions=["network_web", "memory_rag"],
                compatible_agents=["study_knowledge_agent", "researcher"]
            )
        ]
        for s in standard:
            self._skills[s.id] = s

    def register_skill(self, skill: SkillDefinition) -> dict:
        self._skills[skill.id] = skill
        return {"ok": True, "skill_id": skill.id, "message": f"Skill '{skill.name}' registered successfully."}

    def get_skill(self, skill_id: str) -> Optional[SkillDefinition]:
        return self._skills.get(skill_id)

    def list_skills(self) -> list[dict]:
        return [
            {
                "id": s.id,
                "name": s.name,
                "version": s.version,
                "description": s.description,
                "repository": s.repository,
                "readme": s.readme,
                "documentation": s.documentation,
                "capabilities": s.capabilities,
                "permissions": s.permissions,
                "compatible_agents": s.compatible_agents,
                "is_active": s.is_active,
                "installed_at": s.installed_at
            }
            for s in self._skills.values()
        ]

    def find_skills_for_agent(self, agent_id: str) -> list[SkillDefinition]:
        return [
            s for s in self._skills.values()
            if s.is_active and (agent_id in s.compatible_agents or "all" in s.compatible_agents)
        ]

    def check_permission(self, skill_id: str, requested_permission: str) -> bool:
        skill = self.get_skill(skill_id)
        if not skill or not skill.is_active:
            return False
        return requested_permission in skill.permissions
