"""
hesabdar/engine.py
Master Orchestration Engine for Hesabdar Multi-Agent Accounting Operating System.
Connects:
- CEO Agent Architecture (n5 kernel)
- Accounting Domain Engine (n16/n17/n18 dual-path)
- Final Checker Agent / Critic (n14 4-layer verifier)
- DB Manager Agent (n6 authoritative writer)
- Cognitive Memory Architecture (n13 / n5::n8 27-type taxonomy)
- Authenticated Messaging Transport (n10 HMAC + Audit Chaining)
- Resilience Subsystem (n7 Backup, n8 Recovery, n9 Self-Healing)
- Reporting & Analytics Pipeline (n1 Ingestion, n2 Report Maker, n11 Knowledge Agent)
- Skill Registry & Tool Sandboxing (n19 / n14::n0)
- Super Logger (Section 16 & 21 structured diagnostic stream)
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from hesabdar.config import DATA_DIR, RESOURCES, SANDBOX_DIR
from hesabdar.llm import LLMProvider, get_llm
from hesabdar.messaging.identity import AgentIdentity, IdentityRegistry
from hesabdar.messaging.channel import Channel
from hesabdar.messaging.message import Message
from hesabdar.db_manager.agent import DBManagerAgent
from hesabdar.ceo.orchestrator import CEOAgentArchitecture
from hesabdar.accounting.accounting_domain_engine import AccountingDomainEngine, DomainEngineResult
from hesabdar.critic.final_checker_agent import FinalCheckerAgent, FinalCriticResult
from hesabdar.resilience.backup import BackupSystem
from hesabdar.resilience.recovery import RecoverySystem
from hesabdar.resilience.self_healing import SelfHealingSystem, SelfHealingReport
from hesabdar.reporting.report_maker import ReportMaker, FinancialReport
from hesabdar.reporting.data_input import DataInputLayer
from hesabdar.reporting.knowledge_agent import StudyKnowledgeAgent
from hesabdar.skills.registry import SkillRegistry
from hesabdar.tools.tool_manager import ToolManager
from hesabdar.super_logs.super_logger import SuperLogger


@dataclass
class HesabdarExecutionResult:
    ok: bool
    task_id: str
    action_type: str
    prompt: str
    selected_agents: list[str]
    domain_result: Optional[dict] = None
    critic_result: Optional[dict] = None
    posted_transaction_id: Optional[str] = None
    discrepancy: float = 0.0
    attempts: int = 1
    super_log_id: Optional[str] = None
    message: str = ""


class HesabdarEngine:
    def __init__(self, llm: Optional[LLMProvider] = None, data_dir: Path = DATA_DIR):
        self.llm = llm or get_llm()
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)

        # 1. Authoritative DB Manager (n6)
        self.db_manager = DBManagerAgent()

        # 2. Tool Sandbox & Manager (n14::n0)
        self.tool_manager = ToolManager(sandbox_root=str(SANDBOX_DIR))
        self._configure_tool_permissions()

        # 3. Super Logger (n16/n21)
        self.super_logger = SuperLogger(self.db_manager)

        # 4. CEO Agent Architecture Kernel (n5)
        self.ceo = CEOAgentArchitecture(llm=self.llm, tool_manager=self.tool_manager)

        # 5. Accounting Domain Engine (n16/n17/n18)
        self.accounting_engine = AccountingDomainEngine(
            db_manager=self.db_manager,
            llm=self.llm,
            tool_manager=self.tool_manager
        )

        # 6. Final Checker Agent / Critic (n14)
        self.critic = FinalCheckerAgent(db_manager=self.db_manager)

        # 7. Resilience Subsystems (n7, n8, n9)
        self.backup_system = BackupSystem()
        self.recovery_system = RecoverySystem()
        self.self_healing_system = SelfHealingSystem(db_manager=self.db_manager)

        # 8. Reporting & Analytics (n1, n2, n11)
        self.report_maker = ReportMaker(db_manager=self.db_manager, llm=self.llm)
        self.data_input = DataInputLayer()
        self.knowledge_agent = StudyKnowledgeAgent(llm=self.llm, memory_manager=self.ceo.memory)

        # 9. Skill Registry (n19)
        self.skill_registry = SkillRegistry()

        # Log system initialization
        self.super_logger.log(
            agent_id="ceo",
            stage="SYSTEM_INIT",
            component="kernel",
            summary="Hesabdar Multi-Agent Operating System started successfully."
        )

    def _configure_tool_permissions(self) -> None:
        self.tool_manager.grant("accounting_domain_engine", ["file_make", "file_read", "excel_make", "excel_write"])
        self.tool_manager.grant("report_maker", ["excel_make", "excel_write", "file_make"])
        self.tool_manager.grant("study_knowledge_agent", ["web_fetch", "file_read"])
        self.tool_manager.grant("ceo_core", ["bash_run", "file_read", "file_make", "excel_make", "excel_write"])

    def process_prompt(self, prompt: str, user_id: str = "human_user") -> HesabdarExecutionResult:
        """
        Master Pipeline execution for any prompt or accounting instruction:
        User Prompt -> CEO Prompt Manager -> Resource Allocation -> Domain Engine -> Critic -> DB Manager -> Super Log
        """
        start_t = time.time()
        task_id = f"TASK-{int(start_t*1000)%1000000}"

        # 1. Resource Allocation Check (n5::n7)
        alloc = self.ceo.resource_distributor.request_allocation("ceo_core", is_financial=True)
        if not alloc.granted:
            return HesabdarExecutionResult(
                ok=False,
                task_id=task_id,
                action_type="REJECTED_RESOURCES",
                prompt=prompt,
                selected_agents=[],
                message=f"Resource allocation denied: {alloc.reason}"
            )

        # 2. CEO Prompt Processing (n5::n1)
        try:
            selection = self.ceo.prompt_manager.process(prompt)
            chosen_agents = selection.chosen_agents
        except Exception as e:
            self.ceo.resource_distributor.release("ceo_core")
            return HesabdarExecutionResult(
                ok=False,
                task_id=task_id,
                action_type="POLICY_VIOLATION",
                prompt=prompt,
                selected_agents=[],
                message=str(e)
            )

        # 3. Predict / Forecast Expected Outcome (CEO Discrepancy System Section 6)
        expected_debit_credit = 0.0 # CEO expected balance
        
        # 4. Check if this is an accounting transaction vs analytical query
        is_transaction = any(kw in prompt.lower() for kw in [
            "ثبت", "خرید", "فروش", "هزینه", "حقوق", "واریز", "برداشت", "تراکنش",
            "sale", "buy", "purchase", "expense", "salary", "pay", "post", "transfer", "tax"
        ])

        if is_transaction:
            # Route to Accounting Domain Engine (n16/n17)
            domain_res = self.accounting_engine.process_transaction(prompt)

            # Route generated journal entry to Critic / Final Checker Agent (n14)
            critic_res = self.critic.verify(domain_res.journal_entry)

            # Discrepancy Evaluation (Section 6)
            discrepancy = 0.0
            if not critic_res.passed:
                discrepancy = 1.0 - critic_res.confidence_score

            posted_txn_id = None
            if critic_res.passed and critic_res.disposition in ("AUTO_RELEASE", "ESCALATE_TO_HUMAN"):
                # Commit to Authoritative DB via DB Manager (n6)
                entry = domain_res.journal_entry
                db_resp = self.ceo.send_to_db("post_transaction", {
                    "description": entry.description,
                    "lines": entry.lines,
                    "transaction_date": entry.transaction_date,
                    "verified_by_critic": 1 if critic_res.disposition == "AUTO_RELEASE" else 0
                })
                if db_resp.ok:
                    posted_txn_id = db_resp.result

            # Emit Super Log Entry
            log_entry = self.super_logger.log(
                agent_id="accounting_domain_engine",
                stage="TRANSACTION_EXECUTION",
                component="domain_engine",
                summary=f"Processed '{prompt[:60]}': Critic disposition={critic_res.disposition}",
                level="INFO" if critic_res.passed else "WARN",
                task_id=task_id,
                payload={
                    "domain_path": domain_res.path,
                    "total_amount": domain_res.journal_entry.total_debit,
                    "critic_score": critic_res.confidence_score,
                    "posted_txn_id": posted_txn_id
                },
                discrepancy=discrepancy,
                error_detail=None if critic_res.passed else "; ".join(critic_res.rejection_reasons)
            )

            self.ceo.resource_distributor.release("ceo_core")

            return HesabdarExecutionResult(
                ok=critic_res.passed and (posted_txn_id is not None or critic_res.disposition == "ESCALATE_TO_HUMAN"),
                task_id=task_id,
                action_type="FINANCIAL_TRANSACTION",
                prompt=prompt,
                selected_agents=chosen_agents,
                domain_result={
                    "path": domain_res.path,
                    "classified": domain_res.classified.__dict__,
                    "journal_entry": domain_res.journal_entry.__dict__,
                    "self_evaluation": domain_res.self_evaluation.__dict__,
                    "candidate_proposal": domain_res.candidate_proposal
                },
                critic_result={
                    "passed": critic_res.passed,
                    "disposition": critic_res.disposition,
                    "confidence_score": critic_res.confidence_score,
                    "layers": [l.__dict__ for l in critic_res.layers],
                    "rejection_reasons": critic_res.rejection_reasons
                },
                posted_transaction_id=posted_txn_id,
                discrepancy=discrepancy,
                attempts=1,
                super_log_id=log_entry.id,
                message=f"Transaction processed via {domain_res.path}. Critic disposition: {critic_res.disposition}."
            )

        else:
            # Analytical or Reporting Query (n2 / n11)
            ceo_result = self.ceo.handle_prompt(prompt)
            
            # Generate relevant financial telemetry report if requested
            rep = self.report_maker.generate_comprehensive_report(report_type="monthly")

            log_entry = self.super_logger.log(
                agent_id="ceo",
                stage="QUERY_EXECUTION",
                component="ceo_core",
                summary=f"Processed query '{prompt[:60]}'",
                task_id=task_id,
                payload={"ceo_result": ceo_result, "report_id": rep.report_id}
            )

            self.ceo.resource_distributor.release("ceo_core")

            return HesabdarExecutionResult(
                ok=ceo_result.get("ok", True),
                task_id=task_id,
                action_type="ANALYTICAL_QUERY",
                prompt=prompt,
                selected_agents=chosen_agents,
                domain_result={"report": rep.__dict__},
                attempts=ceo_result.get("attempts", 1),
                super_log_id=log_entry.id,
                message=f"Query answered with {len(chosen_agents)} cooperating agents."
            )

    def get_full_state(self) -> dict:
        """Returns comprehensive state for web frontend & observability."""
        stats = self.db_manager._op_get_system_stats()
        trial_bal = self.db_manager._op_get_trial_balance()
        fin_statements = self.db_manager._op_get_financial_statements()
        transactions = self.db_manager._op_list_transactions(limit=25)
        rules = self.db_manager._op_list_rules()
        candidates = self.db_manager._op_get_candidate_rules()
        logs = self.db_manager._op_query_super_logs(limit=40)
        skills = self.skill_registry.list_skills()
        backups = self.backup_system.list_backups()

        return {
            "stats": stats,
            "trial_balance": trial_bal,
            "financial_statements": fin_statements,
            "recent_transactions": transactions,
            "active_rules": rules,
            "candidate_rules": candidates,
            "super_logs": logs,
            "skills": skills,
            "backups": backups,
            "registered_agents": [
                {"id": "ceo", "name": "CEO Agent Kernel", "role": "Supervisor / Orchestrator", "status": "ACTIVE"},
                {"id": "db_manager_agent", "name": "Database Manager Agent", "role": "Sole Authorized DB Writer", "status": "ACTIVE"},
                {"id": "accounting_domain_engine", "name": "Accounting Domain Engine", "role": "Rule Matcher & Executor", "status": "ACTIVE"},
                {"id": "final_checker_agent", "name": "Final Checker Agent (Critic)", "role": "4-Layer Verification Gate", "status": "ACTIVE"},
                {"id": "study_knowledge_agent", "name": "Study / Knowledge Agent", "role": "Regulatory & Legal Research", "status": "ACTIVE"},
                {"id": "report_maker", "name": "Report Maker Agent", "role": "Financial Statements & Analytics", "status": "ACTIVE"},
                {"id": "self_healing_system", "name": "Self-Healing System", "role": "Diagnostic & Compensation", "status": "ACTIVE"},
                {"id": "backup_system", "name": "Backup System", "role": "State Snapshotting", "status": "ACTIVE"},
                {"id": "recovery_system", "name": "Recovery System", "role": "Disaster Recovery", "status": "ACTIVE"},
            ],
            "timestamp": time.time()
        }
