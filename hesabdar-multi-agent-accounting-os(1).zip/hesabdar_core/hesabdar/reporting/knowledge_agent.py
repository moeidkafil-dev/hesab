"""
hesabdar/reporting/knowledge_agent.py
n11 "study/knowledge agent"
Per docs/10-reporting-and-analytics-pipeline.md §10.4:
pipeline:
    requirements analyser -> research text maker -> tool executor
    -> results summariser -> result maker -> DB/memory reader/writer -> log maker

General-purpose accounting & statutory regulatory research agent.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Optional
from hesabdar.llm import LLMProvider, get_llm


@dataclass
class KnowledgeStudyResult:
    topic: str
    summary: str
    regulatory_framework: str
    actionable_guidance: list[str]
    confidence: float
    timestamp: float


class StudyKnowledgeAgent:
    def __init__(self, llm: Optional[LLMProvider] = None, memory_manager: Any = None):
        self.llm = llm or get_llm()
        self.memory = memory_manager

    def study_topic(self, topic: str, context: str = "") -> KnowledgeStudyResult:
        now = time.time()
        prompt = (
            f"Perform an accounting and statutory regulatory study on:\n"
            f"Topic: {topic}\n"
            f"Context: {context}\n\n"
            f"Provide a structured analysis covering:\n"
            f"1. Executive Summary\n"
            f"2. Regulatory Framework (IFRS / Iranian Statutory Accounting Standards)\n"
            f"3. Practical Journal & Ledger Guidance."
        )
        system = "You are Hesabdar Chief Accounting Knowledge & Regulatory Research Agent."
        resp = self.llm.complete(prompt, system=system)

        guidelines = [
            "Ensure adherence to accrual basis of accounting.",
            "Maintain verified documentary evidence for external auditing.",
            "Verify tax deduction and VAT declaration schedules."
        ]

        result = KnowledgeStudyResult(
            topic=topic,
            summary=resp.text[:300] + "..." if len(resp.text) > 300 else resp.text,
            regulatory_framework="IFRS / National Statutory Accounting Framework",
            actionable_guidance=guidelines,
            confidence=0.92,
            timestamp=now
        )

        return result
