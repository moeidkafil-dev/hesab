"""
hesabdar/reporting/data_input.py
n1 "data input"
Per docs/09-tooling-and-data-management.md §9.3:
pipeline: data -> data analyse -> time analyse -> DB analyse -> data injecting -> DB analyse -> reassure -> make log

External data ingestion layer with coarse-grained structural validation
prior to passing transactions to the Accounting Domain Engine.
"""
from __future__ import annotations

import csv
import io
import json
import time
from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class IngestionResult:
    ok: bool
    batch_size: int
    valid_records: list[dict]
    invalid_records: list[dict]
    summary: str


class DataInputLayer:
    def parse_csv(self, csv_content: str) -> IngestionResult:
        valid = []
        invalid = []
        reader = csv.DictReader(io.StringIO(csv_content))
        for row_idx, row in enumerate(reader):
            desc = row.get("description") or row.get("desc") or row.get("memo") or row.get("شرح")
            amount_str = row.get("amount") or row.get("mablagh") or row.get("مبلغ") or "0"
            try:
                amount = float(amount_str.replace(",", ""))
                if amount <= 0:
                    invalid.append({"row": row_idx + 1, "data": row, "reason": "Amount must be strictly positive"})
                    continue
                valid.append({
                    "description": desc or f"Transaction row {row_idx+1}",
                    "amount": amount,
                    "payment_method": row.get("payment_method") or row.get("method") or "bank",
                    "category": row.get("category") or "expense",
                    "date": row.get("date") or row.get("تاریخ")
                })
            except Exception as e:
                invalid.append({"row": row_idx + 1, "data": row, "reason": str(e)})

        return IngestionResult(
            ok=len(invalid) == 0,
            batch_size=len(valid) + len(invalid),
            valid_records=valid,
            invalid_records=invalid,
            summary=f"Ingested {len(valid)} valid items, {len(invalid)} rejected items."
        )

    def parse_json(self, json_content: str | list | dict) -> IngestionResult:
        if isinstance(json_content, str):
            try:
                data = json.loads(json_content)
            except Exception as e:
                return IngestionResult(False, 0, [], [{"error": str(e)}], "Invalid JSON format")
        else:
            data = json_content

        items = data if isinstance(data, list) else [data]
        valid = []
        invalid = []

        for idx, item in enumerate(items):
            desc = item.get("description") or item.get("text") or item.get("memo")
            amount = float(item.get("amount", 0.0))
            if not desc or amount <= 0:
                invalid.append({"index": idx, "data": item, "reason": "Description and positive amount required"})
            else:
                valid.append(item)

        return IngestionResult(
            ok=len(invalid) == 0,
            batch_size=len(items),
            valid_records=valid,
            invalid_records=invalid,
            summary=f"Ingested {len(valid)} valid items, {len(invalid)} rejected items."
        )
