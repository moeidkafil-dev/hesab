"""
n5 "CEO agent architecture" — wires the 11 subgroups documented in
docs/04-orchestration-and-ceo-agent.md §4.2 into a single entry point.
This is intentionally a thin composition layer: all real logic lives in
the per-subgroup modules next to this file, named after their node.
"""
from __future__ import annotations

from typing import Any, Optional

from hesabdar.llm import LLMProvider, get_llm
from hesabdar.messaging.identity import AgentIdentity, IdentityRegistry
from hesabdar.messaging.channel import Channel
from hesabdar.messaging.message import Message
from hesabdar.db_manager.agent import DBManagerAgent

from hesabdar.ceo.log_input_manager import LogInputManager
from hesabdar.ceo.prompt_manager import PromptManager, PolicyViolation
from hesabdar.ceo.new_agent_manager import NewAgentManager
from hesabdar.ceo.agent_killer import AgentKiller
from hesabdar.ceo.ceo_memory_manager import CEOMemoryManager
from hesabdar.ceo.ceo_core import CEOAgentCore
from hesabdar.ceo.agents_input_messages_manager import AgentsInputMessagesManager
from hesabdar.ceo.resource_distributor import ResourceDistributor
from hesabdar.ceo.agent_builder import AgentBuilder
from hesabdar.ceo.input_output_manager import InputOutputManager


class CEOAgentArchitecture:
    def __init__(self, llm: Optional[LLMProvider] = None, tool_manager: Any = None):
        self.llm = llm or get_llm()

        # -- identity / transport (backs n5::n2, n5::n6, and every DB call)
        self.registry = IdentityRegistry()
        self.identity = AgentIdentity.load_or_create("ceo")
        self.registry.register(self.identity)
        self.channel = Channel(self.identity, self.registry)

        # -- n5::n8 CEO memory architecture (full 27-type taxonomy, scope='ceo')
        # -- n5::n4 memory manager, paired planner/schedule
        self.memory = CEOMemoryManager(llm=self.llm)

        # -- the 11 subgroups
        self.log_input_manager = LogInputManager()                          # n5::n0
        self.prompt_manager = PromptManager()                               # n5::n1
        self.new_agent_manager = NewAgentManager(self.registry)             # n5::n2
        self.agent_killer = AgentKiller(self.new_agent_manager, self.memory, llm=self.llm)  # n5::n3
        # n5::n4 == self.memory (above)
        self.core = CEOAgentCore(self.memory, llm=self.llm, tool_manager=tool_manager)      # n5::n5
        self.inbound = AgentsInputMessagesManager(self.core)                # n5::n6
        self.resource_distributor = ResourceDistributor()                   # n5::n7
        # n5::n8 == self.memory's taxonomy (above)
        self.agent_builder = AgentBuilder(self.new_agent_manager, self.memory)  # n5::n9
        self.io_manager = InputOutputManager()                              # n5::n10

        # -- companion subsystem this file wires the CEO to, per §9.2
        self.db_manager = DBManagerAgent()
        self.db_identity = AgentIdentity.load_or_create("db_manager_agent")
        self.registry.register(self.db_identity)
        self.db_channel = Channel(self.db_identity, self.registry)

    # ---------------------------------------------------------------- entry points
    def handle_prompt(self, raw_prompt: str) -> dict:
        """n5::n1 -> n5::n5, guarded by n5::n10's checkpoint loop and
        n5::n7's resource allocation."""
        alloc = self.resource_distributor.request_allocation("ceo_core", is_financial=True)
        if not alloc.granted:
            return {"ok": False, "reason": alloc.reason}
        try:
            selection = self.prompt_manager.process(raw_prompt)
        except PolicyViolation as exc:
            return {"ok": False, "reason": str(exc)}

        def action(text):
            return self.core.run(text, context=f"selected_agents={selection.chosen_agents}")

        checkpoint = self.io_manager.run(raw_prompt, action)
        self.resource_distributor.release("ceo_core")
        return {"ok": checkpoint.ok, "attempts": checkpoint.attempts,
                "selection": selection.chosen_agents, "result": checkpoint.result}

    def handle_inbound_message(self, message: Message) -> dict:
        """n10 authenticated transport -> n5::n6 shield -> n5::n5 core."""
        delivery = self.channel.receiver(message)
        if not delivery.ok:
            return {"ok": False, "reason": delivery.reason}
        return self.inbound.handle(delivery.message)

    def send_to_db(self, op: str, args: dict) -> Any:
        """Every DB write in the whole system goes through this one path:
        CEO channel -> authenticated Channel -> DBManagerAgent (§9.2)."""
        delivery = self.channel.send("db_manager_agent", {"op": op, "args": args}, self.db_channel)
        if not delivery.ok:
            return {"ok": False, "reason": delivery.reason}
        return self.db_manager.handle(delivery.message)

    def provision_agent(self, agent_id: str, role: str, related_to: Optional[list[str]] = None):
        return self.agent_builder.build(agent_id, role, related_to=related_to)

    def retire_agent(self, agent_id: str, notes: str = "") -> str:
        return self.agent_killer.terminate(agent_id, session_notes=notes)

    def ingest_logs(self, raw_logs: list[dict]):
        return self.log_input_manager.legible_log(raw_logs)

    def run_memory_maintenance(self) -> dict:
        """Callers wire this to a scheduler for the 'every 2 hours' cadence
        the diagram's `being in sleep mode` node describes."""
        return self.memory.being_in_sleep_mode()
