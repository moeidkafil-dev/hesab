"""
n5::n5 "CEO AGENT" core: input receiver -> input compiler -> input analyser
-> decision system -> llm -> planner -> schedule -> plan checker ->
hidden memory -> tool manager -> tool executor.

§4.4: `plan checker` is a distinct node from `planner` — the generator/critic
separation applied to the CEO's own plans; even the CEO's plans are not
self-certifying.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from hesabdar.llm import LLMProvider, get_llm
from hesabdar.memory.memory_manager import MemoryManager
from hesabdar.memory.taxonomy import MemoryType


@dataclass
class Plan:
    steps: list[str]
    rationale: str


@dataclass
class PlanCheckResult:
    approved: bool
    reason: str


@dataclass
class ScheduleEntry:
    step: str
    order: int


class CEOAgentCore:
    def __init__(self, ceo_memory: MemoryManager, llm: Optional[LLMProvider] = None, tool_manager: Any = None):
        self.hidden_memory = ceo_memory  # n5::n5::n4 — the CEO's private working store
        self.llm = llm or get_llm()
        self.tool_manager = tool_manager  # wired in once hesabdar.tools exists (step 2)

    # ---------------------------------------------------------------- intake
    def input_reciver(self, raw_input: Any) -> Any:
        return raw_input

    def input_compiler(self, raw_input: Any) -> dict:
        return {"input": raw_input}

    def input_analyser(self, compiled: dict) -> dict:
        return compiled

    def desicion_system(self, analysed: dict) -> str:
        """Chooses which reasoning path to take. Deterministic paths are
        preferred to probabilistic ones when both are available (§4.5 rule 2);
        here that just means: trivial/echo inputs skip the LLM entirely."""
        text = str(analysed.get("input", ""))
        return "trivial" if len(text.strip()) == 0 else "reason"

    # ------------------------------------------------------------- reasoning
    def llm_step(self, analysed: dict, context: str = "") -> str:
        prompt = f"Context:\n{context}\n\nRequest:\n{analysed.get('input')}"
        try:
            return self.llm.complete(prompt, system="You are the CEO agent of an accounting multi-agent system. "
                                                      "Propose a short, concrete plan.").text
        except ConnectionError as exc:
            return f"[llm unavailable: {exc}]"

    def planner(self, llm_text: str) -> Plan:
        steps = [line.strip("-* ").strip() for line in llm_text.splitlines() if line.strip()]
        steps = steps or ["no-op"]
        return Plan(steps=steps, rationale=llm_text[:200])

    def schedule(self, plan: Plan) -> list[ScheduleEntry]:
        return [ScheduleEntry(step=s, order=i) for i, s in enumerate(plan.steps)]

    def plan_chcker(self, plan: Plan) -> PlanCheckResult:
        """Generator/critic separation (§4.4) applied to the CEO's own plan."""
        if not plan.steps or plan.steps == ["no-op"]:
            return PlanCheckResult(False, "empty plan")
        if any(len(s) > 500 for s in plan.steps):
            return PlanCheckResult(False, "a step is implausibly long; likely malformed llm output")
        return PlanCheckResult(True, "ok")

    def tool_manager_step(self, schedule_entries: list[ScheduleEntry]) -> list[dict]:
        """n5::n5::n5 tool manager -> n5::n5::n6 tool executor. Actual
        execution is delegated to hesabdar.tools.ToolManager once wired;
        without it, steps are recorded as pending rather than silently
        dropped."""
        if self.tool_manager is None:
            return [{"step": e.step, "status": "pending: no tool_manager wired"} for e in schedule_entries]
        results = []
        for e in schedule_entries:
            results.append(self.tool_manager.dispatch_freeform(e.step))
        return results

    def run(self, raw_input: Any, context: str = "") -> dict:
        compiled = self.input_compiler(self.input_reciver(raw_input))
        analysed = self.input_analyser(compiled)
        route = self.desicion_system(analysed)
        if route == "trivial":
            return {"route": "trivial", "plan": None, "results": []}

        llm_text = self.llm_step(analysed, context=context)
        plan = self.planner(llm_text)
        self.schedule(plan)
        check = self.plan_chcker(plan)
        self.hidden_memory.remember({"plan": plan.steps, "approved": check.approved, "reason": check.reason},
                                     hint_type=MemoryType.PLANNING)
        if not check.approved:
            return {"route": "reason", "plan": plan, "approved": False, "reason": check.reason, "results": []}

        schedule_entries = self.schedule(plan)
        results = self.tool_manager_step(schedule_entries)
        return {"route": "reason", "plan": plan, "approved": True, "results": results}
