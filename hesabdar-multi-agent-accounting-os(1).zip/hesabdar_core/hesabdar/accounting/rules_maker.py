"""
n17::n2 "rules maker"
Per docs/05-accounting-domain-engine.md §5.2 and §5.3:
Synthesizes candidate rules from ambiguous transactions, research output,
or policy definitions. CRITICAL INVARIANT: A synthesized candidate rule
is NEVER committed directly to production; it is routed to candidate_rules
for Human Approval Gate.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Optional
from hesabdar.accounting.transaction_classifier import ClassifiedTransaction


@dataclass
class CandidateRuleProposal:
    name: str
    proposed_by: str
    category: str
    condition: dict
    action: dict
    justification: str


class RulesMaker:
    def synthesize_candidate_rule(
        self,
        classified: ClassifiedTransaction,
        research_notes: str = "",
        proposed_by: str = "AccountingDomainEngine"
    ) -> CandidateRuleProposal:
        category = classified.category
        payment = classified.payment_method

        # Heuristic synthesis based on accounting standard practices
        if category == "sale":
            debit_acc = "1010" if payment == "cash" else ("1020" if payment == "bank" else "1050")
            action = {
                "debit": [{"account_code": debit_acc, "portion": 1.0, "desc": f"Receipt from {payment} sale"}],
                "credit": [{"account_code": "4010", "portion": 1.0, "desc": "Sales Revenue"}]
            }
        elif category == "purchase":
            credit_acc = "1010" if payment == "cash" else ("1020" if payment == "bank" else "2010")
            action = {
                "debit": [{"account_code": "1070", "portion": 1.0, "desc": "Inventory addition"}],
                "credit": [{"account_code": credit_acc, "portion": 1.0, "desc": f"Payment/Liability for purchase via {payment}"}]
            }
        elif category == "payroll":
            action = {
                "debit": [{"account_code": "5020", "portion": 1.0, "desc": "Salaries & Wages Expense"}],
                "credit": [{"account_code": "1020", "portion": 1.0, "desc": "Bank payment for net salary"}]
            }
        elif category == "asset":
            credit_acc = "1020" if payment == "bank" else "2010"
            action = {
                "debit": [{"account_code": "1510", "portion": 1.0, "desc": "Office Equipment addition"}],
                "credit": [{"account_code": credit_acc, "portion": 1.0, "desc": "Bank/Payable for equipment"}]
            }
        else: # expense default
            credit_acc = "1010" if payment == "cash" else "1020"
            action = {
                "debit": [{"account_code": "5080", "portion": 1.0, "desc": f"General Expense ({classified.raw_text})"}],
                "credit": [{"account_code": credit_acc, "portion": 1.0, "desc": f"Payment via {payment}"}]
            }

        cond = {
            "type": category,
            "payment_method": payment
        }
        if classified.vat_applicable:
            cond["vat_applicable"] = True

        name = f"Auto-Proposed: {category.title()} via {payment.title()}"
        justification = (
            f"Synthesized from ambiguous transaction '{classified.raw_text}'. "
            f"Research summary: {research_notes or 'Standard double-entry recognition principles applied.'}"
        )

        return CandidateRuleProposal(
            name=name,
            proposed_by=proposed_by,
            category=category,
            condition=cond,
            action=action,
            justification=justification
        )
