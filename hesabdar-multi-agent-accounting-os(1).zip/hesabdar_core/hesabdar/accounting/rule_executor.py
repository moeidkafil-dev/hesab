"""
n17::n6 "rule executor"
Per docs/05-accounting-domain-engine.md §5.2:
Executes the matched accounting rule against transaction data, generating
balanced double-entry journal lines (Debit == Credit).
"""
from __future__ import annotations

import datetime
from dataclasses import dataclass, field
from typing import Any, Optional
from hesabdar.accounting.transaction_classifier import ClassifiedTransaction


@dataclass
class JournalEntryLine:
    account_code: str
    account_name: str
    debit: float
    credit: float
    description: str


@dataclass
class JournalEntryResult:
    ok: bool
    description: str
    transaction_date: str
    lines: list[dict] = field(default_factory=list)
    total_debit: float = 0.0
    total_credit: float = 0.0
    is_balanced: bool = False
    applied_rule_id: Optional[str] = None
    applied_rule_name: Optional[str] = None
    error: Optional[str] = None


class RuleExecutor:
    def __init__(self, accounts_map: Optional[dict[str, dict]] = None):
        """accounts_map: {code_or_id: {"id": "...", "code": "...", "name": "..."}}"""
        self.accounts_map = accounts_map or {}

    def update_accounts(self, accounts: list[dict]) -> None:
        self.accounts_map = {}
        for a in accounts:
            self.accounts_map[a["code"]] = a
            self.accounts_map[a["id"]] = a

    def execute(self, classified: ClassifiedTransaction, rule: dict) -> JournalEntryResult:
        action = rule.get("action", {})
        base_amount = classified.amount
        if base_amount <= 0:
            # Fallback default amount if parsing didn't catch a specific number
            base_amount = 100.0

        debit_specs = action.get("debit", [])
        credit_specs = action.get("credit", [])

        lines = []
        total_debit = 0.0
        total_credit = 0.0

        # Calculate Debits
        for spec in debit_specs:
            code = spec.get("account_code", "1010")
            portion = float(spec.get("portion", 1.0))
            line_amount = round(base_amount * portion, 2)
            acc_info = self.accounts_map.get(code, {"id": code, "code": code, "name": spec.get("desc", code)})
            lines.append({
                "account_id": acc_info["id"],
                "account_code": code,
                "account_name": acc_info.get("name", ""),
                "debit": line_amount,
                "credit": 0.0,
                "description": spec.get("desc", classified.raw_text)
            })
            total_debit += line_amount

        # Calculate Credits
        for spec in credit_specs:
            code = spec.get("account_code", "4010")
            portion = float(spec.get("portion", 1.0))
            line_amount = round(base_amount * portion, 2)
            acc_info = self.accounts_map.get(code, {"id": code, "code": code, "name": spec.get("desc", code)})
            lines.append({
                "account_id": acc_info["id"],
                "account_code": code,
                "account_name": acc_info.get("name", ""),
                "debit": 0.0,
                "credit": line_amount,
                "description": spec.get("desc", classified.raw_text)
            })
            total_credit += line_amount

        is_balanced = round(total_debit, 2) == round(total_credit, 2)
        if not is_balanced:
            # Auto-balance rounding discrepancies if within 0.02
            diff = round(total_debit - total_credit, 2)
            if abs(diff) <= 0.05 and lines:
                if diff > 0: # credit is smaller
                    lines[-1]["credit"] = round(lines[-1]["credit"] + diff, 2)
                    total_credit = round(total_credit + diff, 2)
                else:
                    lines[0]["debit"] = round(lines[0]["debit"] - diff, 2)
                    total_debit = round(total_debit - diff, 2)
                is_balanced = round(total_debit, 2) == round(total_credit, 2)

        return JournalEntryResult(
            ok=is_balanced,
            description=f"Transaction: {classified.raw_text}",
            transaction_date=datetime.date.today().isoformat(),
            lines=lines,
            total_debit=round(total_debit, 2),
            total_credit=round(total_credit, 2),
            is_balanced=is_balanced,
            applied_rule_id=rule.get("id"),
            applied_rule_name=rule.get("name"),
            error=None if is_balanced else f"Unbalanced lines: debit={total_debit} credit={total_credit}"
        )
