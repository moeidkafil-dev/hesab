"""
n17::n5 "rule matcher"
Per docs/05-accounting-domain-engine.md §5.2:
Matches classified transactions against loaded active production rules
using deterministic criteria (category, payment method, VAT, thresholds).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional
from hesabdar.accounting.transaction_classifier import ClassifiedTransaction


@dataclass
class MatchedRuleResult:
    matched: bool
    rule: Optional[dict] = None
    reason: str = ""
    match_score: float = 0.0


class RuleMatcher:
    def __init__(self, rules: Optional[list[dict]] = None):
        self.rules = rules or []

    def set_rules(self, rules: list[dict]) -> None:
        self.rules = sorted(rules, key=lambda r: (r.get("priority", 0), r.get("created_at", 0)), reverse=True)

    def match(self, classified: ClassifiedTransaction) -> MatchedRuleResult:
        if not self.rules:
            return MatchedRuleResult(matched=False, reason="No active rules available in rule library")

        # 1. Filter by category first for indexed fast-path
        candidates = [r for r in self.rules if r.get("category") == classified.category and r.get("is_active", 1)]

        for rule in candidates:
            cond = rule.get("condition", {})
            if self._matches_condition(cond, classified):
                return MatchedRuleResult(
                    matched=True,
                    rule=rule,
                    reason=f"Matched rule '{rule.get('name')}' (priority {rule.get('priority')})",
                    match_score=1.0
                )

        # 2. Check general fallback rules with matching type or category wildcard
        for rule in self.rules:
            if not rule.get("is_active", 1):
                continue
            cond = rule.get("condition", {})
            if cond.get("type") == classified.category or cond.get("category") == classified.category:
                if self._matches_condition(cond, classified, relaxed=True):
                    return MatchedRuleResult(
                        matched=True,
                        rule=rule,
                        reason=f"Fallback match on rule '{rule.get('name')}'",
                        match_score=0.8
                    )

        return MatchedRuleResult(
            matched=False,
            reason=f"No deterministic rule matched category '{classified.category}' and payment method '{classified.payment_method}'"
        )

    def _matches_condition(self, cond: dict, classified: ClassifiedTransaction, relaxed: bool = False) -> bool:
        if "type" in cond and cond["type"] != classified.category:
            return False
        if "payment_method" in cond and not relaxed:
            if cond["payment_method"] != classified.payment_method:
                return False
        if "vat_applicable" in cond:
            if cond["vat_applicable"] != classified.vat_applicable:
                return False
        if "min_amount" in cond and classified.amount < cond["min_amount"]:
            return False
        if "max_amount" in cond and classified.amount > cond["max_amount"]:
            return False
        return True
