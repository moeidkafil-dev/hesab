"""
n18 "rules managers group"
Per docs/05-accounting-domain-engine.md §5.4:
Joins n16 (research path) and n17 (deterministic fast path) into a single coherent
decision process. Coordinates candidate rule staging, Human-in-the-Loop approval,
and promotion of ratified rules into the authoritative production rule library.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Optional
from hesabdar.accounting.rules_maker import CandidateRuleProposal


class RulesGroupManager:
    def __init__(self, db_manager: Any = None):
        self.db_manager = db_manager

    def propose_candidate(self, proposal: CandidateRuleProposal) -> dict:
        """Stage a proposed rule for human review."""
        if self.db_manager:
            cid = self.db_manager._op_propose_candidate_rule(
                name=proposal.name,
                proposed_by=proposal.proposed_by,
                category=proposal.category,
                condition_json=json.dumps(proposal.condition),
                action_json=json.dumps(proposal.action),
                justification=proposal.justification
            )
            return {"candidate_id": cid, "status": "PENDING", "message": "Candidate rule routed to Human Approval Gate."}
        return {"status": "STAGED", "proposal": proposal}

    def list_pending_candidates(self) -> list[dict]:
        if self.db_manager:
            return self.db_manager._op_get_candidate_rules(status="PENDING")
        return []

    def approve_candidate(self, candidate_id: str, reviewer: str = "HUMAN_AUDITOR") -> dict:
        """Human approval moves the candidate rule into active production rules."""
        if self.db_manager:
            return self.db_manager._op_approve_candidate_rule(candidate_id, reviewer=reviewer)
        return {"error": "No DB Manager available"}

    def reject_candidate(self, candidate_id: str, reviewer: str = "HUMAN_AUDITOR", reason: str = "Policy violation") -> dict:
        if self.db_manager:
            return self.db_manager._op_reject_candidate_rule(candidate_id, reviewer=reviewer, reason=reason)
        return {"error": "No DB Manager available"}
