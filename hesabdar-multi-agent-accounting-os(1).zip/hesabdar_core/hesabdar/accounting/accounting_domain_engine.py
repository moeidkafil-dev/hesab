"""
n16 "Accounting Domain Engine" & n17 "rule manager"
Per docs/05-accounting-domain-engine.md:
Complete implementation of the dual-path accounting engine:
1. Fast Path (Deterministic): DB Reader -> Rules Loader -> Classifier -> Rule Matcher -> Rule Executor -> Self Evaluation
2. Research Path (Probabilistic): Invoked when no rule matches -> Researcher -> Rules Maker -> Candidate Rule Stage -> Self Evaluation

Invariants:
- Balanced double-entry (Debit == Credit) is mathematically guaranteed.
- Novel rules are NEVER silently injected into production; they are routed through candidate_rules for human approval.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Any, Optional

from hesabdar.accounting.transaction_classifier import TransactionClassifier, ClassifiedTransaction
from hesabdar.accounting.rules_loader import RulesLoader
from hesabdar.accounting.rule_matcher import RuleMatcher, MatchedRuleResult
from hesabdar.accounting.rule_executor import RuleExecutor, JournalEntryResult
from hesabdar.accounting.self_evaluation import SelfEvaluationSystem, SelfEvaluationResult
from hesabdar.accounting.researcher import AccountingResearcher
from hesabdar.accounting.rules_maker import RulesMaker
from hesabdar.accounting.rules_group import RulesGroupManager
from hesabdar.llm import LLMProvider, get_llm


@dataclass
class DomainEngineResult:
    ok: bool
    path: str                   # "deterministic_fast_path" | "probabilistic_research_path"
    classified: ClassifiedTransaction
    journal_entry: JournalEntryResult
    self_evaluation: SelfEvaluationResult
    rule_info: Optional[dict] = None
    candidate_proposal: Optional[dict] = None
    execution_time_ms: float = 0.0
    error: Optional[str] = None


class AccountingDomainEngine:
    def __init__(self, db_manager: Any = None, llm: Optional[LLMProvider] = None, tool_manager: Any = None):
        self.db_manager = db_manager
        self.llm = llm or get_llm()
        self.tool_manager = tool_manager

        self.classifier = TransactionClassifier()
        self.rules_loader = RulesLoader(self.db_manager)
        self.rule_matcher = RuleMatcher()
        self.rule_executor = RuleExecutor()
        self.self_eval = SelfEvaluationSystem()
        self.researcher = AccountingResearcher(self.llm)
        self.rules_maker = RulesMaker()
        self.rules_group = RulesGroupManager(self.db_manager)

        self._refresh_state()

    def _refresh_state(self) -> None:
        """Syncs accounts and rules from DB."""
        if self.db_manager:
            try:
                accounts = self.db_manager._op_list_accounts()
                self.rule_executor.update_accounts(accounts)
                rules = self.rules_loader.load_rules()
                self.rule_matcher.set_rules(rules)
            except Exception:
                pass

    def process_transaction(self, raw_input: str | dict, agent_id: str = "accounting_domain_engine") -> DomainEngineResult:
        start_t = time.time()
        self._refresh_state()

        # Step 1: Ingest & Classify (n17::n4)
        classified = self.classifier.classify(raw_input)

        # Step 2: Try Deterministic Rule Matcher (n17::n5)
        match_result = self.rule_matcher.match(classified)

        if match_result.matched and match_result.rule:
            # Deterministic Fast Path (n17)
            journal_entry = self.rule_executor.execute(classified, match_result.rule)
            self_eval = self.self_eval.evaluate(journal_entry)
            exec_time = (time.time() - start_t) * 1000

            return DomainEngineResult(
                ok=self_eval.passed,
                path="deterministic_fast_path",
                classified=classified,
                journal_entry=journal_entry,
                self_evaluation=self_eval,
                rule_info=match_result.rule,
                execution_time_ms=exec_time,
                error=None if self_eval.passed else "; ".join(self_eval.violations)
            )

        # Step 3: Probabilistic Research Fallback (n16)
        research = self.researcher.research_transaction(classified)
        
        # Synthesize a candidate rule (n17::n2)
        candidate = self.rules_maker.synthesize_candidate_rule(
            classified=classified,
            research_notes=research.recommendation,
            proposed_by=agent_id
        )

        # Stage candidate in DB for human approval (n18)
        candidate_resp = self.rules_group.propose_candidate(candidate)

        # Build dynamic one-off rule for current transaction execution
        ephemeral_rule = {
            "id": f"ephemeral_{int(time.time())}",
            "name": f"Ephemeral Research: {candidate.name}",
            "condition": candidate.condition,
            "action": candidate.action
        }
        journal_entry = self.rule_executor.execute(classified, ephemeral_rule)
        self_eval = self.self_eval.evaluate(journal_entry)
        exec_time = (time.time() - start_t) * 1000

        return DomainEngineResult(
            ok=self_eval.passed,
            path="probabilistic_research_path",
            classified=classified,
            journal_entry=journal_entry,
            self_evaluation=self_eval,
            rule_info=ephemeral_rule,
            candidate_proposal=candidate_resp,
            execution_time_ms=exec_time,
            error=None if self_eval.passed else "; ".join(self_eval.violations)
        )
