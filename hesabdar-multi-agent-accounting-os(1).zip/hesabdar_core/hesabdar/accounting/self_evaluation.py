"""
n17::n7 "self evaluation system"
Per docs/05-accounting-domain-engine.md §5.2:
Rule-engine-scoped local self-check confirming:
- Output structural validity
- Positive non-zero numbers
- Valid account references
- Balance parity before exiting the domain engine
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional
from hesabdar.accounting.rule_executor import JournalEntryResult


@dataclass
class SelfEvaluationResult:
    passed: bool
    score: float
    violations: list[str]
    checked_entry: JournalEntryResult


class SelfEvaluationSystem:
    def evaluate(self, entry: JournalEntryResult) -> SelfEvaluationResult:
        violations = []

        if not entry.ok:
            violations.append("Entry reported ok=False from executor")

        if not entry.is_balanced:
            violations.append(f"Debit/Credit disparity: debit={entry.total_debit} credit={entry.total_credit}")

        if entry.total_debit <= 0 or entry.total_credit <= 0:
            violations.append("Total transaction value must be strictly positive")

        if len(entry.lines) < 2:
            violations.append("Double-entry accounting requires at least two lines")

        for idx, line in enumerate(entry.lines):
            d = line.get("debit", 0)
            c = line.get("credit", 0)
            if d < 0 or c < 0:
                violations.append(f"Line #{idx+1} contains negative amount (d={d}, c={c})")
            if d == 0 and c == 0:
                violations.append(f"Line #{idx+1} has zero for both debit and credit")
            if not line.get("account_id"):
                violations.append(f"Line #{idx+1} is missing account_id reference")

        passed = len(violations) == 0
        score = 1.0 if passed else max(0.0, 1.0 - (0.25 * len(violations)))

        return SelfEvaluationResult(
            passed=passed,
            score=score,
            violations=violations,
            checked_entry=entry
        )
