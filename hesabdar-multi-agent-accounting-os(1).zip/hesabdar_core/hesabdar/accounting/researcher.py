"""
n16 / n17::n1 "researcher & Accounting Domain Engine research path"
Per docs/05-accounting-domain-engine.md §5.3:
Invoked when deterministic fast path finds no applicable rule.
Durable capture of research in Knowledge DB, LLM reasoning for ambiguous cases,
and proposal of candidate rules for human sign-off.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Optional
from hesabdar.accounting.transaction_classifier import ClassifiedTransaction
from hesabdar.llm import LLMProvider, get_llm


@dataclass
class ResearchResult:
    query: str
    recommendation: str
    suggested_debit_code: str
    suggested_credit_code: str
    confidence: float
    requires_human_approval: bool = True
    knowledge_entry: str = ""


class AccountingResearcher:
    def __init__(self, llm: Optional[LLMProvider] = None):
        self.llm = llm or get_llm()

    def research_transaction(self, classified: ClassifiedTransaction) -> ResearchResult:
        prompt = (
            f"Analyze and provide accounting journal mapping for transaction:\n"
            f"Description: {classified.raw_text}\n"
            f"Category: {classified.category}\n"
            f"Amount: {classified.amount}\n"
            f"Payment Method: {classified.payment_method}\n"
            f"VAT Applicable: {classified.vat_applicable}\n\n"
            f"Respond with JSON specifying suggested_debit_code, suggested_credit_code, recommendation, confidence."
        )
        system = (
            "You are Hesabdar Accounting Domain Researcher. Map financial transactions to double-entry Chart of Accounts: "
            "1010=Cash, 1020=Bank, 1050=Receivable, 1070=Inventory, 1510=Equipment, 2010=Payable, 2040=VAT, "
            "3010=Capital, 4010=Sales Revenue, 5020=Salaries, 5030=Rent, 5040=Utilities, 5080=General Expense."
        )

        resp = self.llm.complete(prompt, system=system)
        
        # Parse or provide heuristic fallback
        try:
            data = json.loads(resp.text)
            debit = data.get("suggested_debit_code", "5080")
            credit = data.get("suggested_credit_code", "1020")
            rec = data.get("recommendation", "Standard transaction recognition")
            conf = float(data.get("confidence", 0.90))
        except Exception:
            # Domain heuristic fallback
            if classified.category == "sale":
                debit, credit = ("1020", "4010")
            elif classified.category == "purchase":
                debit, credit = ("1070", "2010")
            elif classified.category == "payroll":
                debit, credit = ("5020", "1020")
            else:
                debit, credit = ("5080", "1020")
            rec = f"Heuristic mapping for {classified.category} transaction"
            conf = 0.85

        knowledge_summary = f"Research on '{classified.raw_text}' concluded Debit {debit} / Credit {credit} ({rec})."

        return ResearchResult(
            query=classified.raw_text,
            recommendation=rec,
            suggested_debit_code=debit,
            suggested_credit_code=credit,
            confidence=conf,
            requires_human_approval=True,
            knowledge_entry=knowledge_summary
        )
