"""
n17::n4 "transaction classifier"
Per docs/05-accounting-domain-engine.md §5.2:
Classifies raw financial transactions into indexable categories
(sales, purchases, payroll, operational expense, tax, asset transfer)
before rule matching, ensuring efficient O(1)/indexed lookup.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class ClassifiedTransaction:
    raw_text: str
    category: str               # "sale" | "purchase" | "expense" | "payroll" | "tax" | "asset" | "transfer"
    amount: float
    payment_method: str         # "cash" | "bank" | "credit" | "cheque"
    vat_applicable: bool = False
    vat_rate: float = 0.09
    counterparty: Optional[str] = None
    account_hints: dict[str, str] = field(default_factory=dict)
    confidence: float = 1.0
    extracted_metadata: dict[str, Any] = field(default_factory=dict)


class TransactionClassifier:
    """
    Deterministic rule-assisted classifier with Persian & English regex parsers.
    """
    def __init__(self):
        # Persian digit converter
        self._fa_to_en = str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789")

    def normalize_digits(self, text: str) -> str:
        return text.translate(self._fa_to_en)

    def extract_amount(self, text: str) -> float:
        cleaned = self.normalize_digits(text)
        # Match numbers with optional commas/decimals
        matches = re.findall(r"(\d+(?:[,\.]\d+)?)", cleaned)
        if not matches:
            return 0.0
        # Return the largest candidate number (or first significant)
        nums = []
        for m in matches:
            val_str = m.replace(",", "")
            try:
                nums.append(float(val_str))
            except ValueError:
                pass
        return nums[0] if nums else 0.0

    def classify(self, raw_input: str | dict) -> ClassifiedTransaction:
        if isinstance(raw_input, dict):
            return self._classify_dict(raw_input)
        return self._classify_text(str(raw_input))

    def _classify_dict(self, data: dict) -> ClassifiedTransaction:
        category = data.get("category") or data.get("type", "expense")
        amount = float(data.get("amount", 0.0))
        payment = data.get("payment_method", "bank")
        vat = bool(data.get("vat_applicable", False) or data.get("vat_rate", 0) > 0)
        return ClassifiedTransaction(
            raw_text=json_safe_str(data),
            category=category,
            amount=amount,
            payment_method=payment,
            vat_applicable=vat,
            vat_rate=float(data.get("vat_rate", 0.09)),
            counterparty=data.get("counterparty") or data.get("customer") or data.get("vendor"),
            extracted_metadata=data
        )

    def _classify_text(self, text: str) -> ClassifiedTransaction:
        norm = self.normalize_digits(text).lower()
        amount = self.extract_amount(norm)

        # Determine Category
        category = "expense"
        if any(w in norm for w in ["فروش", "sale", "sold", "revenue", "صورتحساب فروش", "درآمد"]):
            category = "sale"
        elif any(w in norm for w in ["خرید کالا", "purchase", "inventory", "موجودی کالا", "مواد اولیه"]):
            category = "purchase"
        elif any(w in norm for w in ["حقوق", "salary", "payroll", "دستمزد", "پاداش"]):
            category = "payroll"
        elif any(w in norm for w in ["مالیات", "tax", "ارزش افزوده", "vat"]):
            category = "tax"
        elif any(w in norm for w in ["انتقال", "transfer", "جابجایی بین بانکی"]):
            category = "transfer"
        elif any(w in norm for w in ["خرید تجهیزات", "دارایی", "asset", "اثاثه", "خودرو"]):
            category = "asset"
        elif any(w in norm for w in ["هزینه", "expense", "اجاره", "قبض", "اینترنت", "پذیرایی", "تبلیغات"]):
            category = "expense"

        # Determine Payment Method
        payment = "bank"
        if any(w in norm for w in ["نقدی", "نقدا", "cash", "صندوق"]):
            payment = "cash"
        elif any(w in norm for w in ["نسیه", "credit", "حساب", "طلب", "بدهی", "مدت‌دار"]):
            payment = "credit"
        elif any(w in norm for w in ["چک", "cheque", "check", "سفته", "اسناد"]):
            payment = "cheque"
        elif any(w in norm for w in ["بانک", "کارت", "پایا", "ساتنا", "bank", "transfer", "pos"]):
            payment = "bank"

        # Check VAT
        vat_applicable = any(w in norm for w in ["ارزش افزوده", "vat", "با مالیات", "مالیات ۹٪", "مالیات 9%"])

        return ClassifiedTransaction(
            raw_text=text,
            category=category,
            amount=amount,
            payment_method=payment,
            vat_applicable=vat_applicable,
            vat_rate=0.09 if vat_applicable else 0.0,
            confidence=0.95
        )


def json_safe_str(obj: Any) -> str:
    import json
    try:
        return json.dumps(obj, ensure_ascii=False)
    except Exception:
        return str(obj)
