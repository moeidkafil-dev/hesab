"""
n17::n3 "rules loader"
Per docs/05-accounting-domain-engine.md §5.2:
Loads active, approved rules from DB reader / storage into in-memory
indexed caches for deterministic execution.
"""
from __future__ import annotations

from typing import Any, Optional


class RulesLoader:
    def __init__(self, db_manager: Any = None):
        self.db_manager = db_manager
        self.cached_rules: list[dict] = []

    def load_rules(self) -> list[dict]:
        if self.db_manager:
            try:
                res = self.db_manager._op_list_rules()
                self.cached_rules = [r for r in res if r.get("is_active", 1)]
                return self.cached_rules
            except Exception:
                pass
        return self.cached_rules

    def get_rule_by_id(self, rule_id: str) -> Optional[dict]:
        for r in self.cached_rules:
            if r.get("id") == rule_id:
                return r
        return None
