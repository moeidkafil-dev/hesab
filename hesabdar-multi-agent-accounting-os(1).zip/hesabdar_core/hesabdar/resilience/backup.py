"""
hesabdar/resilience/backup.py
n7 "backup system"
Per docs/08-resilience-engineering.md §8.2:
pipeline: backup maker -> self db -> hidden memory -> backup analyser/reader

Survives failure modes that corrupt the production store itself by maintaining
an isolated snapshot store and actively verifying backup integrity.
"""
from __future__ import annotations

import datetime
import json
import os
import shutil
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from hesabdar.config import BACKUP_DB_PATH, BACKUP_DIR, PRODUCTION_DB_PATH


@dataclass
class BackupRecord:
    backup_id: str
    timestamp: float
    path: str
    file_size_bytes: int
    account_count: int
    transaction_count: int
    integrity_verified: bool
    status: str


class BackupSystem:
    def __init__(self, prod_db_path: Path = PRODUCTION_DB_PATH, backup_dir: Path = BACKUP_DIR):
        self.prod_db_path = Path(prod_db_path)
        self.backup_dir = Path(backup_dir)
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        self.backup_records: list[BackupRecord] = []

    def make_backup(self, label: str = "auto") -> BackupRecord:
        """n7::backup_maker -> self db"""
        now = time.time()
        dt_str = datetime.datetime.fromtimestamp(now).strftime("%Y%m%d_%H%M%S")
        backup_filename = f"backup_{label}_{dt_str}.sqlite3"
        dest_path = self.backup_dir / backup_filename

        if not self.prod_db_path.exists():
            raise FileNotFoundError(f"Production DB {self.prod_db_path} does not exist for backup")

        # Atomic copy using SQLite backup API if possible or file copy
        try:
            src_conn = sqlite3.connect(str(self.prod_db_path))
            dst_conn = sqlite3.connect(str(dest_path))
            src_conn.backup(dst_conn)
            src_conn.close()
            dst_conn.close()
        except Exception:
            shutil.copy2(self.prod_db_path, dest_path)

        # Update default backup reference
        shutil.copy2(dest_path, BACKUP_DB_PATH)

        # Analyze & Read backup (n7::backup_analyser/reader)
        integrity = self.analyze_backup(dest_path)
        
        record = BackupRecord(
            backup_id=backup_filename,
            timestamp=now,
            path=str(dest_path),
            file_size_bytes=dest_path.stat().st_size,
            account_count=integrity.get("accounts_count", 0),
            transaction_count=integrity.get("transactions_count", 0),
            integrity_verified=integrity.get("ok", False),
            status="READY"
        )
        self.backup_records.append(record)
        return record

    def analyze_backup(self, backup_path: Path) -> dict:
        """n7::backup analyser/reader - converts an assumption into a verified property."""
        try:
            conn = sqlite3.connect(str(backup_path))
            conn.row_factory = sqlite3.Row
            chk = conn.execute("PRAGMA integrity_check").fetchone()
            acc_c = conn.execute("SELECT COUNT(*) AS c FROM accounts").fetchone()["c"]
            txn_c = conn.execute("SELECT COUNT(*) AS c FROM transactions").fetchone()["c"]
            conn.close()
            return {
                "ok": chk and chk[0] == "ok",
                "accounts_count": acc_c,
                "transactions_count": txn_c,
                "integrity_msg": chk[0] if chk else "failed"
            }
        except Exception as e:
            return {"ok": False, "error": str(e), "accounts_count": 0, "transactions_count": 0}

    def list_backups(self) -> list[dict]:
        backups = []
        for f in sorted(self.backup_dir.glob("*.sqlite3"), key=lambda p: p.stat().st_mtime, reverse=True):
            info = self.analyze_backup(f)
            backups.append({
                "filename": f.name,
                "path": str(f),
                "size_kb": round(f.stat().st_size / 1024, 2),
                "modified": f.stat().st_mtime,
                "integrity": info.get("ok", False),
                "accounts": info.get("accounts_count", 0),
                "transactions": info.get("transactions_count", 0)
            })
        return backups
