"""
hesabdar/resilience/recovery.py
n8 "recovery system"
Per docs/08-resilience-engineering.md §8.3:
pipeline: backup catcher -> main DB setter -> system analyser -> system restarter

Restores operation from backup, performs root-cause analysis before reopening
traffic to avoid immediately re-corrupting the restored state.
"""
from __future__ import annotations

import shutil
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from hesabdar.config import BACKUP_DB_PATH, PRODUCTION_DB_PATH


@dataclass
class RecoveryResult:
    ok: bool
    restored_from: str
    target_db: str
    pre_restart_analysis: dict
    timestamp: float
    message: str


class RecoverySystem:
    def __init__(self, prod_db_path: Path = PRODUCTION_DB_PATH, backup_db_path: Path = BACKUP_DB_PATH):
        self.prod_db_path = Path(prod_db_path)
        self.backup_db_path = Path(backup_db_path)

    def recover(self, specific_backup_path: Optional[str] = None) -> RecoveryResult:
        now = time.time()
        src_path = Path(specific_backup_path) if specific_backup_path else self.backup_db_path
        
        # 1. backup catcher
        if not src_path.exists():
            return RecoveryResult(
                ok=False,
                restored_from=str(src_path),
                target_db=str(self.prod_db_path),
                pre_restart_analysis={"error": "Backup source file not found"},
                timestamp=now,
                message="Recovery aborted: no valid backup found"
            )

        # 2. main DB setter (atomic restore)
        try:
            temp_target = self.prod_db_path.with_suffix(".tmp_restore")
            shutil.copy2(src_path, temp_target)
            if self.prod_db_path.exists():
                # keep old corrupted for forensic analysis
                corrupt_dump = self.prod_db_path.with_suffix(f".corrupt_{int(now)}")
                shutil.move(self.prod_db_path, corrupt_dump)
            shutil.move(temp_target, self.prod_db_path)
        except Exception as e:
            return RecoveryResult(
                ok=False,
                restored_from=str(src_path),
                target_db=str(self.prod_db_path),
                pre_restart_analysis={"error": f"Copy failed: {e}"},
                timestamp=now,
                message=f"DB setter failed: {e}"
            )

        # 3. system analyser
        analysis = self._system_analyser(self.prod_db_path)

        # 4. system restarter
        if analysis.get("healthy", False):
            return RecoveryResult(
                ok=True,
                restored_from=str(src_path),
                target_db=str(self.prod_db_path),
                pre_restart_analysis=analysis,
                timestamp=now,
                message="System successfully restored from verified backup snapshot."
            )
        else:
            return RecoveryResult(
                ok=False,
                restored_from=str(src_path),
                target_db=str(self.prod_db_path),
                pre_restart_analysis=analysis,
                timestamp=now,
                message="System restarter withheld: pre-restart analysis detected consistency defects."
            )

    def _system_analyser(self, db_path: Path) -> dict:
        try:
            conn = sqlite3.connect(str(db_path))
            conn.row_factory = sqlite3.Row
            chk = conn.execute("PRAGMA integrity_check").fetchone()
            acc_c = conn.execute("SELECT COUNT(*) AS c FROM accounts").fetchone()["c"]
            txn_c = conn.execute("SELECT COUNT(*) AS c FROM transactions").fetchone()["c"]
            conn.close()
            return {
                "healthy": chk and chk[0] == "ok",
                "integrity_check": chk[0] if chk else "failed",
                "accounts_restored": acc_c,
                "transactions_restored": txn_c,
            }
        except Exception as e:
            return {"healthy": False, "error": str(e)}
