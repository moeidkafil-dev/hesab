"""
Physical storage for the 27-type taxonomy. One SQLite table
(`memory_entries`), partitioned logically by `memory_type` + `scope`
(scope = "ceo" or an agent id, per §3.6's CEO/agent-local split), rather
than 27 physical tables — simpler to operate, identical semantics.
"""
from __future__ import annotations

import json
import sqlite3
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Optional

from hesabdar.config import MEMORY_DB_PATH
from hesabdar.memory.taxonomy import MemoryType, PERMANENT_MEMORY_TYPES, DEFAULT_TTL_DAYS

SCHEMA = """
CREATE TABLE IF NOT EXISTS memory_entries (
    id TEXT PRIMARY KEY,
    scope TEXT NOT NULL,              -- 'ceo' or an agent_id
    memory_type TEXT NOT NULL,
    content TEXT NOT NULL,            -- JSON-encoded payload
    importance REAL NOT NULL DEFAULT 0.5,
    created_at REAL NOT NULL,
    last_accessed_at REAL NOT NULL,
    access_count INTEGER NOT NULL DEFAULT 0,
    ttl_days INTEGER,                 -- NULL = no TTL / rely on importance
    permanent INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_mem_scope_type ON memory_entries(scope, memory_type);
"""


@dataclass
class MemoryEntry:
    id: str
    scope: str
    memory_type: MemoryType
    content: Any
    importance: float
    created_at: float
    last_accessed_at: float
    access_count: int
    ttl_days: Optional[int]
    permanent: bool

    @classmethod
    def _from_row(cls, row: sqlite3.Row) -> "MemoryEntry":
        return cls(
            id=row["id"], scope=row["scope"], memory_type=MemoryType(row["memory_type"]),
            content=json.loads(row["content"]), importance=row["importance"],
            created_at=row["created_at"], last_accessed_at=row["last_accessed_at"],
            access_count=row["access_count"], ttl_days=row["ttl_days"], permanent=bool(row["permanent"]),
        )


class MemoryStore:
    def __init__(self, db_path=MEMORY_DB_PATH):
        self.conn = sqlite3.connect(str(db_path))
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    def write(self, scope: str, memory_type: MemoryType, content: Any, importance: float = 0.5) -> MemoryEntry:
        now = time.time()
        permanent = memory_type in PERMANENT_MEMORY_TYPES
        ttl = None if permanent else DEFAULT_TTL_DAYS.get(memory_type)
        entry = MemoryEntry(
            id=str(uuid.uuid4()), scope=scope, memory_type=memory_type, content=content,
            importance=importance, created_at=now, last_accessed_at=now, access_count=0,
            ttl_days=ttl, permanent=permanent,
        )
        self.conn.execute(
            "INSERT INTO memory_entries VALUES (?,?,?,?,?,?,?,?,?,?)",
            (entry.id, entry.scope, entry.memory_type.value, json.dumps(content, ensure_ascii=False),
             entry.importance, entry.created_at, entry.last_accessed_at, entry.access_count,
             entry.ttl_days, int(entry.permanent)),
        )
        self.conn.commit()
        return entry

    def read(self, scope: str, memory_type: Optional[MemoryType] = None, limit: int = 50) -> list[MemoryEntry]:
        if memory_type is None:
            cur = self.conn.execute(
                "SELECT * FROM memory_entries WHERE scope=? ORDER BY created_at DESC LIMIT ?",
                (scope, limit),
            )
        else:
            cur = self.conn.execute(
                "SELECT * FROM memory_entries WHERE scope=? AND memory_type=? ORDER BY created_at DESC LIMIT ?",
                (scope, memory_type.value, limit),
            )
        rows = [MemoryEntry._from_row(r) for r in cur.fetchall()]
        if rows:
            ids = [r.id for r in rows]
            self.conn.executemany(
                "UPDATE memory_entries SET access_count = access_count + 1, last_accessed_at=? WHERE id=?",
                [(time.time(), i) for i in ids],
            )
            self.conn.commit()
        return rows

    def find_junks(self, scope: str, importance_threshold: float = 0.3) -> list[MemoryEntry]:
        """n13::n3::n1::n5 — locate prunable entries: not permanent, past TTL
        or below the importance threshold. Never touches PERMANENT_MEMORY_TYPES."""
        now = time.time()
        cur = self.conn.execute("SELECT * FROM memory_entries WHERE scope=? AND permanent=0", (scope,))
        junk = []
        for row in cur.fetchall():
            entry = MemoryEntry._from_row(row)
            expired = entry.ttl_days is not None and (now - entry.created_at) > entry.ttl_days * 86400
            low_value = entry.importance < importance_threshold and entry.access_count == 0
            if expired or low_value:
                junk.append(entry)
        return junk

    def tables_cleaner(self, junk: list[MemoryEntry]) -> int:
        """n13::n3::n1::n6 — delete the entries `find_junks` identified.
        Defense in depth: re-asserts the permanent-type exemption here too,
        not only at find_junks time, per §3.5's invariant."""
        ids = [e.id for e in junk if not e.permanent and e.memory_type not in PERMANENT_MEMORY_TYPES]
        if not ids:
            return 0
        self.conn.executemany("DELETE FROM memory_entries WHERE id=?", [(i,) for i in ids])
        self.conn.commit()
        return len(ids)
