"""
hesabdar/super_logs/__init__.py
"""
from hesabdar.super_logs.super_logger import SuperLogger, SuperLogEntry

__all__ = ["SuperLogger", "SuperLogEntry"]
