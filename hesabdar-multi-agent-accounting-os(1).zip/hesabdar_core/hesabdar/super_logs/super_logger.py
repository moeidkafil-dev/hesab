"""
hesabdar/super_logs/super_logger.py
Per PRD Section 16 (Super Logs) & Section 21 (Observability):
Authoritative diagnostic and audit logging stream for CEO and Self-Healing.
Provides:
- Machine-readable structured logging (JSONL & DB)
- Cryptographic Haber-Stornetta sequence hash chaining
- Discrepancy & anomaly tracking
- Full agent, tool, skill, and resource attribution
"""
from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from hesabdar.config import SUPER_LOG_PATH


@dataclass
class SuperLogEntry:
    id: str
    timestamp: float
    task_id: str
    agent_id: str
    stage: str
    level: str                  # "INFO" | "WARN" | "ERROR" | "CRITICAL" | "AUDIT"
    component: str
    summary: str
    payload: dict = field(default_factory=dict)
    discrepancy: float = 0.0
    error_detail: Optional[str] = None
    recovery_action: Optional[str] = None
    prev_hash: str = ""
    curr_hash: str = ""


class SuperLogger:
    def __init__(self, db_manager: Any = None, log_file: Path = SUPER_LOG_PATH):
        self.db_manager = db_manager
        self.log_file = Path(log_file)
        self.log_file.parent.mkdir(parents=True, exist_ok=True)
        self._last_hash = "GENESIS_BLOCK_00000000000000000000000000000000"
        self._sequence = 0

    def log(
        self,
        agent_id: str,
        stage: str,
        component: str,
        summary: str,
        level: str = "INFO",
        task_id: Optional[str] = None,
        payload: Optional[dict] = None,
        discrepancy: float = 0.0,
        error_detail: Optional[str] = None,
        recovery_action: Optional[str] = None
    ) -> SuperLogEntry:
        now = time.time()
        log_id = str(uuid.uuid4())
        tid = task_id or f"TASK-{int(now*1000)%1000000}"
        p_dict = payload or {}

        # Compute cryptographic hash for audit chain
        payload_str = json.dumps(p_dict, sort_keys=True, ensure_ascii=False)
        hash_input = f"{self._sequence}|{self._last_hash}|{log_id}|{now}|{agent_id}|{summary}|{payload_str}"
        curr_hash = hashlib.sha256(hash_input.encode("utf-8")).hexdigest()

        entry = SuperLogEntry(
            id=log_id,
            timestamp=now,
            task_id=tid,
            agent_id=agent_id,
            stage=stage,
            level=level,
            component=component,
            summary=summary,
            payload=p_dict,
            discrepancy=discrepancy,
            error_detail=error_detail,
            recovery_action=recovery_action,
            prev_hash=self._last_hash,
            curr_hash=curr_hash
        )

        self._last_hash = curr_hash
        self._sequence += 1

        # Write to JSONL file
        try:
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry.__dict__, ensure_ascii=False) + "\n")
        except Exception:
            pass

        # Write to DB if DB manager is connected
        if self.db_manager:
            try:
                self.db_manager._op_save_super_log(
                    agent_id=agent_id,
                    stage=stage,
                    component=component,
                    summary=summary,
                    level=level,
                    task_id=tid,
                    payload_json=payload_str,
                    discrepancy=discrepancy,
                    error_detail=error_detail,
                    recovery_action=recovery_action
                )
            except Exception:
                pass

        return entry

    def query_logs(self, limit: int = 100, level: Optional[str] = None) -> list[dict]:
        if self.db_manager:
            try:
                return self.db_manager._op_query_super_logs(limit=limit, level=level)
            except Exception:
                pass
        return []
