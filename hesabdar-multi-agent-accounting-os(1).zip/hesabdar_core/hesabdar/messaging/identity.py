"""
Per-agent cryptographic identity. Backs `sign maker` / `rule signer`
(n5::n2::n2, n5::n2::n7) at agent-creation time, and the `sign reader`
stage repeated in every n10 channel.

docs/07-messaging-and-security.md §7.4: "message authentication ... uses
keyed constructions (such as HMAC) or a digital signature scheme such as Ed25519"
Supports Ed25519 when cryptography is installed, with standard library HMAC-SHA256 fallback.
"""
from __future__ import annotations

import hashlib
import hmac
import os
import secrets
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from hesabdar.config import KEYS_DIR

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
    from cryptography.hazmat.primitives import serialization
    from cryptography.exceptions import InvalidSignature
    _HAVE_ED25519 = True
except ImportError:
    _HAVE_ED25519 = False


@dataclass
class AgentIdentity:
    agent_id: str
    private_key: Any
    public_key: Any

    def sign(self, payload: bytes) -> bytes:
        if _HAVE_ED25519 and hasattr(self.private_key, "sign"):
            return self.private_key.sign(payload)
        # HMAC-SHA256 fallback using standard library
        key_bytes = self.private_key if isinstance(self.private_key, bytes) else str(self.private_key).encode("utf-8")
        return hmac.new(key_bytes, payload, hashlib.sha256).digest()

    def public_bytes(self) -> bytes:
        if _HAVE_ED25519 and hasattr(self.public_key, "public_bytes"):
            return self.public_key.public_bytes(
                encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
            )
        return self.public_key if isinstance(self.public_key, bytes) else str(self.public_key).encode("utf-8")

    @classmethod
    def create(cls, agent_id: str, persist: bool = True) -> "AgentIdentity":
        if _HAVE_ED25519:
            priv = Ed25519PrivateKey.generate()
            identity = cls(agent_id=agent_id, private_key=priv, public_key=priv.public_key())
        else:
            secret = secrets.token_bytes(32)
            pub = hashlib.sha256(secret).digest()
            identity = cls(agent_id=agent_id, private_key=secret, public_key=pub)

        if persist:
            identity._save()
        return identity

    @classmethod
    def load_or_create(cls, agent_id: str) -> "AgentIdentity":
        path = KEYS_DIR / f"{agent_id}.key"
        if path.exists():
            data = path.read_bytes()
            if _HAVE_ED25519 and len(data) == 32:
                try:
                    priv = Ed25519PrivateKey.from_private_bytes(data)
                    return cls(agent_id=agent_id, private_key=priv, public_key=priv.public_key())
                except Exception:
                    pass
            pub = hashlib.sha256(data).digest()
            return cls(agent_id=agent_id, private_key=data, public_key=pub)
        return cls.create(agent_id, persist=True)

    def _save(self) -> None:
        path = KEYS_DIR / f"{self.agent_id}.key"
        if _HAVE_ED25519 and hasattr(self.private_key, "private_bytes"):
            raw = self.private_key.private_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PrivateFormat.Raw,
                encryption_algorithm=serialization.NoEncryption(),
            )
        else:
            raw = self.private_key if isinstance(self.private_key, bytes) else str(self.private_key).encode("utf-8")
        path.write_bytes(raw)
        try:
            path.chmod(0o600)
        except Exception:
            pass


class IdentityRegistry:
    """Tracks known agents' public keys so a `sign reader` stage can verify
    a message claiming to be from any registered agent, per §7.3's
    'Identity' property."""

    def __init__(self):
        self._public_keys: dict[str, Any] = {}
        self._identities: dict[str, AgentIdentity] = {}

    def register(self, identity: AgentIdentity) -> None:
        self._public_keys[identity.agent_id] = identity.public_key
        self._identities[identity.agent_id] = identity

    def is_registered(self, agent_id: str) -> bool:
        return agent_id in self._public_keys

    def verify(self, agent_id: str, payload: bytes, signature: bytes) -> bool:
        if agent_id not in self._public_keys:
            return False
        pub = self._public_keys[agent_id]

        if _HAVE_ED25519 and hasattr(pub, "verify"):
            try:
                pub.verify(signature, payload)
                return True
            except InvalidSignature:
                return False

        # HMAC verification fallback
        identity = self._identities.get(agent_id)
        if not identity:
            return False
        expected_sig = identity.sign(payload)
        return hmac.compare_digest(expected_sig, signature)

