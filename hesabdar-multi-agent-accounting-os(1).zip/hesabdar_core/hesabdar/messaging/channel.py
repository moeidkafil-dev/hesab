"""
n13::n2 "new massages architecture". The diagram instantiates the same
four-stage pattern (receiver -> compiler -> sign reader -> read) separately
for every pairing among CEO / main agent / self-healing / recovery /
backup / tool manager / DB manager agent (§7.2: kept separate from domain
logic, and repeated per-pairing rather than shared, on purpose). In code
this is one reusable Channel class, instantiated once per pair — the
repetition the diagram encodes structurally is encoded here as one class
used N times, which is the same design intent without literal duplication.
"""
from __future__ import annotations

from dataclasses import dataclass

from hesabdar.messaging.identity import AgentIdentity, IdentityRegistry
from hesabdar.messaging.message import Message, NameAndSignHasher, new_message


class AuthenticationError(Exception):
    pass


@dataclass
class DeliveryResult:
    ok: bool
    message: Message
    reason: str = ""


class Channel:
    """One transport pairing, e.g. Channel(ceo_identity, db_manager_registry)."""

    def __init__(self, local: AgentIdentity, registry: IdentityRegistry, hasher: NameAndSignHasher | None = None):
        self.local = local
        self.registry = registry
        self.hasher = hasher or NameAndSignHasher()

    # ------------------------------------------------------------- send side
    def system_authentication(self) -> None:
        """n13::n2::n0 — confirms the local identity is registered before
        anything is sent; refuses to originate traffic from an unregistered
        identity."""
        if not self.registry.is_registered(self.local.agent_id):
            raise AuthenticationError(f"{self.local.agent_id} is not a registered identity")

    def aim_for_message(self, recipient: str, payload: dict) -> Message:
        """n13::n2::n1"""
        self.system_authentication()
        return new_message(self.local.agent_id, recipient, payload)

    def signner(self, message: Message) -> Message:
        """n13::n2::n2"""
        message.signature = self.local.sign(message.canonical_bytes())
        return message

    def sender(self, message: Message, outbox: "Channel") -> DeliveryResult:
        """n13::n2::n3 -> hands off to the recipient's receiver. `outbox`
        is the recipient-side Channel instance in this single-process
        reference implementation; in a distributed deployment this would
        instead be a network send."""
        message = self.hasher.chain(message)
        return outbox.receiver(message)

    def send(self, recipient: str, payload: dict, outbox: "Channel") -> DeliveryResult:
        message = self.aim_for_message(recipient, payload)
        message = self.signner(message)
        return self.sender(message, outbox)

    # ---------------------------------------------------------- receive side
    def receiver(self, message: Message) -> DeliveryResult:
        """n13::n2::n4"""
        return self.compiler(message)

    def compiler(self, message: Message) -> DeliveryResult:
        """n13::n2::n5 — normalizes/parses the incoming envelope before
        signature verification."""
        return self.sign_reader(message)

    def sign_reader(self, message: Message) -> DeliveryResult:
        """n13::n2::n6 — the load-bearing authentication step (§7.3
        'Authentication'): message is rejected here, before `read`, if the
        signature does not verify against the claimed sender's registered
        public key."""
        if message.signature is None:
            return DeliveryResult(False, message, "missing signature")
        ok = self.registry.verify(message.sender, message.canonical_bytes(), message.signature)
        if not ok:
            return DeliveryResult(False, message, "signature verification failed")
        return self.read(message)

    def read(self, message: Message) -> DeliveryResult:
        """n13::n2::n7 — only reached for an authenticated message; this is
        the handoff point to domain-level logic (CEO / DB manager / etc.),
        which per §7.2 never participates in the authentication decision
        itself."""
        return DeliveryResult(True, message, "authenticated")
