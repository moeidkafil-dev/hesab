"""
Central configuration for Hesabdar Multi-Agent Accounting Operating System.
Environment-driven with resilient defaults.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get("HESABDAR_DATA_DIR", PROJECT_ROOT / "data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)

KEYS_DIR = DATA_DIR / "keys"
KEYS_DIR.mkdir(parents=True, exist_ok=True)

SANDBOX_DIR = DATA_DIR / "sandbox"
SANDBOX_DIR.mkdir(parents=True, exist_ok=True)

BACKUP_DIR = DATA_DIR / "backups"
BACKUP_DIR.mkdir(parents=True, exist_ok=True)

MEMORY_DB_PATH = DATA_DIR / "memory.sqlite3"
PRODUCTION_DB_PATH = DATA_DIR / "production.sqlite3"
BACKUP_DB_PATH = BACKUP_DIR / "backup_self.sqlite3"
AUDIT_LOG_PATH = DATA_DIR / "audit_chain.jsonl"
SUPER_LOG_PATH = DATA_DIR / "super_logs.jsonl"


@dataclass
class LLMConfig:
    """
    provider: "gemini" | "ollama" | "anthropic" | "openai" | "heuristic" | "mock"
    Defaults to Gemini if GEMINI_API_KEY is available, or Ollama/Heuristic.
    """
    provider: str = field(
        default_factory=lambda: os.environ.get(
            "HESABDAR_LLM_PROVIDER",
            "gemini" if os.environ.get("GEMINI_API_KEY") else "heuristic"
        )
    )
    model: str = field(
        default_factory=lambda: os.environ.get("HESABDAR_LLM_MODEL", "gemini-2.5-flash")
    )
    gemini_api_key: str = field(
        default_factory=lambda: os.environ.get("GEMINI_API_KEY", "")
    )
    ollama_host: str = field(
        default_factory=lambda: os.environ.get("OLLAMA_HOST", "http://localhost:11434")
    )
    anthropic_api_key: str = field(
        default_factory=lambda: os.environ.get("ANTHROPIC_API_KEY", "")
    )
    openai_api_key: str = field(
        default_factory=lambda: os.environ.get("OPENAI_API_KEY", "")
    )
    temperature: float = 0.2
    max_tokens: int = 2048


@dataclass
class ResourceConfig:
    """
    Enforcement knobs for CEO's Resource Distributor (n5::n7),
    per §4.5 of 04-orchestration-and-ceo-agent.md.
    """
    max_concurrent_agents: int = int(os.environ.get("HESABDAR_MAX_AGENTS", "8"))
    max_io_retries: int = int(os.environ.get("HESABDAR_MAX_RETRIES", "3"))
    prefer_deterministic: bool = True
    financial_logs_are_permanent: bool = True
    discrepancy_threshold_financial: float = 0.02  # Low tolerance for financial discrepancies
    discrepancy_threshold_narrative: float = 0.15


LLM = LLMConfig()
RESOURCES = ResourceConfig()
