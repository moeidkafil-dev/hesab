"""
n14::n0::n0-n5 "excel command maker / excel vbs maker / file injector /
excel file reader / excel file writer / excel file maker". Sheet
manipulation via openpyxl for the reader/writer/maker triad; the
command/vbs-maker nodes are exposed as text generators only (they produce
a command/VBS *string* — actually executing a `.vbs` file is a Windows-only
concern well outside this Kali-based stack, so `file_injector` here just
writes that generated script to disk via FileTool for the user to run
themselves on a machine that has Excel/VBA, rather than attempting to run
cscript in a Linux sandbox).
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

import csv
from pathlib import Path
from typing import Any, Optional

try:
    import openpyxl
    _HAVE_OPENPYXL = True
except ImportError:
    _HAVE_OPENPYXL = False

from hesabdar.tools.file_tool import FileTool


class ExcelTool:
    def __init__(self, sandbox_root: Optional[str] = None):
        self.file_tool = FileTool(sandbox_root=sandbox_root)

    def excel_command_maker(self, instruction: str) -> str:
        """Produces a human/agent-readable description of the intended edit."""
        return f"EXCEL_OP: {instruction}"

    def excel_vbs_maker(self, macro_body: str, sub_name: str = "HesabdarMacro") -> str:
        """command to file — generates VBS/VBA source text only."""
        return f'Sub {sub_name}()\n{macro_body}\nEnd Sub\n'

    def file_injector(self, path: str, script_text: str) -> str:
        return self.file_tool.file_maker(path, script_text)

    def excel_file_maker(self, path: str, headers: Optional[list[str]] = None) -> str:
        resolved = self.file_tool._resolve(path)
        resolved.parent.mkdir(parents=True, exist_ok=True)
        if _HAVE_OPENPYXL:
            wb = openpyxl.Workbook()
            ws = wb.active
            if headers:
                ws.append(headers)
            wb.save(resolved)
        else:
            with open(resolved, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                if headers:
                    writer.writerow(headers)
        return str(resolved)

    def excel_file_reader(self, path: str, sheet: Optional[str] = None) -> list[list[Any]]:
        resolved = self.file_tool._resolve(path)
        if _HAVE_OPENPYXL and resolved.suffix in (".xlsx", ".xlsm"):
            wb = openpyxl.load_workbook(resolved, data_only=True)
            ws = wb[sheet] if sheet else wb.active
            return [list(row) for row in ws.iter_rows(values_only=True)]
        else:
            with open(resolved, "r", encoding="utf-8", errors="ignore") as f:
                reader = csv.reader(f)
                return [row for row in reader]

    def excel_file_writer(self, path: str, rows: list[list[Any]], sheet: Optional[str] = None,
                           append: bool = True) -> str:
        resolved = self.file_tool._resolve(path)
        if _HAVE_OPENPYXL and resolved.suffix in (".xlsx", ".xlsm"):
            if resolved.exists():
                wb = openpyxl.load_workbook(resolved)
                ws = wb[sheet] if sheet else wb.active
                if not append:
                    ws.delete_rows(1, ws.max_row)
            else:
                wb = openpyxl.Workbook()
                ws = wb.active
                if sheet:
                    ws.title = sheet
            for row in rows:
                ws.append(row)
            wb.save(resolved)
        else:
            mode = "a" if append and resolved.exists() else "w"
            with open(resolved, mode, newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                for row in rows:
                    writer.writerow(row)
        return str(resolved)

