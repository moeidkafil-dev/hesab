import express, { Request, Response } from "express";
import { execFile } from "child_process";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// Helper to execute Python Hesabdar CLI
function runHesabdarCLI(command: string, args: Record<string, any> = {}): Promise<any> {
  return new Promise((resolve, reject) => {
    const pythonScript = path.resolve(__dirname, "hesabdar_core", "hesabdar_cli.py");
    const argsJson = JSON.stringify(args);

    execFile("python3", [pythonScript, command, argsJson], { maxBuffer: 10 * 1024 * 1024 }, (error, stdout, stderr) => {
      if (error) {
        console.error(`CLI Error [${command}]:`, stderr || error.message);
        try {
          // If python outputted valid JSON before error
          const parsed = JSON.parse(stdout);
          return resolve(parsed);
        } catch {
          return reject(new Error(stderr || error.message));
        }
      }
      try {
        const parsed = JSON.parse(stdout);
        resolve(parsed);
      } catch (err) {
        console.error("JSON parse error:", stdout);
        resolve({ ok: false, error: "Malformed output from accounting kernel", raw: stdout });
      }
    });
  });
}

// ----------------------------------------------------
// API ROUTES
// ----------------------------------------------------

// Get full system state (accounts, trial balance, statements, rules, candidate rules, logs, skills)
app.get("/api/state", async (req: Request, res: Response) => {
  try {
    const data = await runHesabdarCLI("status");
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Process Natural Language Prompt through CEO Multi-Agent Pipeline
app.post("/api/prompt", async (req: Request, res: Response) => {
  try {
    const { prompt } = req.body;
    if (!prompt) {
      return res.status(400).json({ ok: false, error: "Prompt is required" });
    }
    const data = await runHesabdarCLI("process_prompt", { prompt });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Post Direct Balanced Transaction
app.post("/api/transaction", async (req: Request, res: Response) => {
  try {
    const { description, lines, reference_no, transaction_date } = req.body;
    const data = await runHesabdarCLI("post_transaction", {
      description,
      lines,
      reference_no,
      transaction_date
    });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Reverse a Transaction with Compensating Entry
app.post("/api/transaction/reverse", async (req: Request, res: Response) => {
  try {
    const { transaction_id, reason } = req.body;
    const data = await runHesabdarCLI("reverse_transaction", { transaction_id, reason });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Create new Account in Chart of Accounts
app.post("/api/accounts", async (req: Request, res: Response) => {
  try {
    const { code, name, name_fa, account_type } = req.body;
    const data = await runHesabdarCLI("create_account", { code, name, name_fa, account_type });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Get Ledger for Specific Account
app.get("/api/ledger/:accountId", async (req: Request, res: Response) => {
  try {
    const { accountId } = req.params;
    const data = await runHesabdarCLI("get_ledger", { account_id: accountId });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Candidate Rule Human Approval
app.post("/api/rules/approve", async (req: Request, res: Response) => {
  try {
    const { candidate_id } = req.body;
    const data = await runHesabdarCLI("approve_candidate_rule", { candidate_id });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Candidate Rule Rejection
app.post("/api/rules/reject", async (req: Request, res: Response) => {
  try {
    const { candidate_id, reason } = req.body;
    const data = await runHesabdarCLI("reject_candidate_rule", { candidate_id, reason });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Create Manual / Automated Rule
app.post("/api/rules", async (req: Request, res: Response) => {
  try {
    const { name, category, condition, action } = req.body;
    const data = await runHesabdarCLI("create_rule", { name, category, condition, action });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Trigger Resilience Backup
app.post("/api/backup", async (req: Request, res: Response) => {
  try {
    const data = await runHesabdarCLI("make_backup");
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Trigger Recovery Snapshot
app.post("/api/recover", async (req: Request, res: Response) => {
  try {
    const { backup_path } = req.body;
    const data = await runHesabdarCLI("recover_backup", { backup_path });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Trigger Self-Healing Diagnostic & Compensation
app.post("/api/self-heal", async (req: Request, res: Response) => {
  try {
    const data = await runHesabdarCLI("self_heal");
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Generate Comprehensive Financial Report
app.get("/api/report/:type", async (req: Request, res: Response) => {
  try {
    const { type } = req.params;
    const data = await runHesabdarCLI("generate_report", { type });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Knowledge & Regulatory Study
app.post("/api/study", async (req: Request, res: Response) => {
  try {
    const { topic } = req.body;
    const data = await runHesabdarCLI("study_topic", { topic });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Health check
app.get("/api/health", (req: Request, res: Response) => {
  res.json({ ok: true, name: "Hesabdar Multi-Agent Accounting OS", status: "OPERATIONAL", port: PORT });
});

// ----------------------------------------------------
// VITE DEV SERVER / STATIC SERVING
// ----------------------------------------------------
async function startServer() {
  const isProd = process.env.NODE_ENV === "production";
  
  if (!isProd) {
    const { createServer } = await import("vite");
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, "dist");
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get("*", (req: Request, res: Response) => {
        res.sendFile(path.resolve(distPath, "index.html"));
      });
    }
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Hesabdar OS] Fullstack server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(console.error);
